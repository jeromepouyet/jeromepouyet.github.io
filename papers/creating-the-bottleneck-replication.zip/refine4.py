# -*- coding: utf-8 -*-
"""refine4.py -- checks behind the wording pass: (#33) weak effects need not imply
a tax; (#5) where the integrated device margin turns negative in the complements
range, relative to the psi segment."""
import sympy as sp, numpy as np

uB, uS, g, v, r = sp.symbols('u_B u_S gamma v r', positive=True)
a, p1, p2 = sp.symbols('a p_1 p_2')
sig = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
_x,_y,_f = sp.symbols('_x _y _f')
Dk = (2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DS = (uS*(2*v-_x-_y)-_f)/M
D1 = Dk.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
D2 = Dk.subs({_x:p2,_y:p1,_f:a}, simultaneous=True)
DSe = DS.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
sol = sp.solve([sp.diff((p1+r)*D1 + a*DSe, p1), sp.diff((p2+r)*D2, p2)], [p1,p2], dict=True)[0]
S = sp.Symbol('sigma')
H = ((S+4)**2*(3*S+4)**2 - 2*(S+2)*(3*S+4)**2*uB**2
     - 2*(3*S+4)*(S*(7*S+32)+32)*uB*uS - 2*(S*(S*(7*S+40)+64)+32)*uS**2)
B = (3*S*(S*(S+7)+16)+32)*uS - 2*(S+2)*(3*S+4)*uB
ast = ((3*S+4)*(v+r)*B/H).subs(S, sig)
F = {nm: sp.lambdify((uB,uS,g,v,r,a), e, 'numpy') for nm,e in
     [('m1', sol[p1]+r), ('m2', sol[p2]+r), ('D1', D1.subs(sol)),
      ('D2', D2.subs(sol)), ('q', DSe.subs(sol))]}
astf = sp.lambdify((uB,uS,g,v,r), ast, 'numpy')
Hf = sp.lambdify((uB,uS,S), H, 'numpy')

# ---- #33: weak effects, strongly buyer-skewed -> subsidy
print("(#33) R_a(sigma) threshold on u_B/u_S, and a** at weak buyer-skewed effects:")
Ra = lambda s: (3*s*(s*(s+7)+16)+32)/(2*(s+2)*(3*s+4))
for gv in [1.0, 4.0]:
    print("   gamma=%g: R_a(sigma->gamma) = %.3f" % (gv, Ra(gv)))
for e in [1e-2, 1e-3]:
    uBv, uSv = 5*e, e
    print("   (u_B,u_S)=(%.4g,%.4g), gamma=4: a** = %+.5f" % (uBv, uSv, astf(uBv,uSv,4.,2.,.5)))

# ---- #5: negative integrated device margin in the complements range
print("\n(#5) complements range, gamma=4: where does m_1(a**) < 0 occur?")
gv = 4.0; tot = concav = neg_m1 = neg_in_psi = neg_out_psi = 0
for uBv in np.arange(0.02, 1.60, 0.01):
    for uSv in np.arange(0.02, 1.60, 0.01):
        if 2*uBv*uSv >= 1: continue
        s = gv - 2*uBv*uSv*(1+gv)
        if not (-1 < s < 0): continue
        tot += 1
        if Hf(uBv, uSv, s) <= 0: continue            # concavity fails
        concav += 1
        ah = astf(uBv, uSv, 2.0, 0.5, gv) if False else astf(uBv, uSv, gv, 2.0, 0.5)
        if F['m1'](uBv, uSv, gv, 2.0, 0.5, ah) < 0:
            neg_m1 += 1
            sm = -s; psi = 2*sm*(2-sm)/((4-2*sm)*(4-3*sm))
            if uBv/uSv <= psi: neg_in_psi += 1
            else: neg_out_psi += 1
print("   sigma in (-1,0) grid points: %d; concavity-admissible: %d" % (tot, concav))
print("   of the concavity-admissible, m_1(a**) < 0 at %d (%.1f%%): %d inside the "
      "segment u_B/u_S <= psi, %d outside it" % (neg_m1, 100*neg_m1/max(concav,1),
                                                 neg_in_psi, neg_out_psi))

# ---- does Proposition B.1's alignment survive on the excluded loss-leader points?
print("\n(#5, follow-up) alignment on concavity-admissible points excluded by m_1 > 0:")
VB = (v*(D1.subs(sol)+D2.subs(sol)) + uB*DSe.subs(sol)*(D1.subs(sol)+D2.subs(sol))
      - (2*(D1.subs(sol)**2+D2.subs(sol)**2)+g*(D1.subs(sol)+D2.subs(sol))**2)/(4*(1+g))
      - sol[p1]*D1.subs(sol) - sol[p2]*D2.subs(sol))
pi2 = (sol[p2]+r)*D2.subs(sol)
FB = sp.lambdify((uB,uS,g,v,r,a), VB, 'numpy')
FP = sp.lambdify((uB,uS,g,v,r,a), pi2, 'numpy')
FQ = F['q']
for gv in [4.0, 1.0]:
    out_ok = out_bad = psi_ok = psi_bad = 0
    for uBv in np.arange(0.02, 1.60, 0.01):
        for uSv in np.arange(0.02, 1.60, 0.01):
            if 2*uBv*uSv >= 1: continue
            s = gv - 2*uBv*uSv*(1+gv)
            if not (-1 < s < 0) or Hf(uBv, uSv, s) <= 0: continue
            ah = astf(uBv, uSv, gv, 2.0, 0.5)
            A = (uBv,uSv,gv,2.0,0.5,ah); A0 = (uBv,uSv,gv,2.0,0.5,0.0)
            if F['m1'](*A) >= 0: continue                     # kept by the paper
            # other interiority objects must still be sane to make the test meaningful
            if min(F['D1'](*A), F['D2'](*A), FQ(*A), F['m2'](*A)) <= 0: continue
            sgn = -np.sign(ah)
            ok = (np.sign(FP(*A)-FP(*A0)) == sgn and np.sign(FQ(*A)**2-FQ(*A0)**2) == sgn
                  and np.sign(FB(*A)-FB(*A0)) == sgn)
            sm = -s; psi = 2*sm*(2-sm)/((4-2*sm)*(4-3*sm))
            if uBv/uSv <= psi:
                psi_ok += ok; psi_bad += (not ok)
            else:
                out_ok += ok; out_bad += (not ok)
    print("   gamma=%g: excluded points with u_B/u_S > psi: aligned %d, misaligned %d"
          % (gv, out_ok, out_bad))
    print("            excluded points with u_B/u_S <= psi: aligned %d, misaligned %d"
          % (psi_ok, psi_bad))

print("\n(#5, decomposition) which constituency misaligns on the excluded points?")
for gv in [4.0, 1.0]:
    cnt = {'rival':0, 'developer':0, 'buyers':0, 'n':0, 'tax':0}
    for uBv in np.arange(0.02, 1.60, 0.01):
        for uSv in np.arange(0.02, 1.60, 0.01):
            if 2*uBv*uSv >= 1: continue
            s = gv - 2*uBv*uSv*(1+gv)
            if not (-1 < s < 0) or Hf(uBv, uSv, s) <= 0: continue
            ah = astf(uBv, uSv, gv, 2.0, 0.5)
            A = (uBv,uSv,gv,2.0,0.5,ah); A0 = (uBv,uSv,gv,2.0,0.5,0.0)
            if F['m1'](*A) >= 0: continue
            if min(F['D1'](*A), F['D2'](*A), FQ(*A), F['m2'](*A)) <= 0: continue
            sgn = -np.sign(ah); cnt['n'] += 1; cnt['tax'] += (ah > 0)
            if np.sign(FP(*A)-FP(*A0)) != sgn: cnt['rival'] += 1
            if np.sign(FQ(*A)**2-FQ(*A0)**2) != sgn: cnt['developer'] += 1
            if np.sign(FB(*A)-FB(*A0)) != sgn: cnt['buyers'] += 1
    print("   gamma=%g: %d excluded points (%d taxing); misaligned: rival %d, "
          "developer %d, buyers %d" % (gv, cnt['n'], cnt['tax'], cnt['rival'],
                                       cnt['developer'], cnt['buyers']))
