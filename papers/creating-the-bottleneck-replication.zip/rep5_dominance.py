# -*- coding: utf-8 -*-
"""rep5_dominance.py -- the dominant-platform benchmark (Section 5.2 of the
paper and Online Appendix B.5).  Replaces delta_sep.py and
delta_sep3.py.

The separation benchmark is the best package the separated platform can
post.  Two programmes are solved exactly, by enumerating active sets:

  benchmark      : the SYMMETRIC programme of the earlier text,
                     max_{beta <= 1, a}  2 (1-beta) r D + a q_S
                     s.t.  beta r >= r - delta,   a <= a_kill(beta, delta),
                   a quadratic on a polygon in (x, a), x = beta r - (r-delta);
  benchmark_asym : the ASYMMETRIC programme, which is the benchmark of the
                   paper (Proposition B.2): the platform hands back x_1 to one
                   manufacturer and holds the other at its floor, on
                   {0 <= x_2 <= x_1 <= delta, a <= kappa x_1}.  It weakly
                   improves on the symmetric one, strictly at most points where
                   the symmetric programme taxes (rep35_dominance_asym.py, which
                   also checks it against the enumerated adoption game).

The integrated firm's problem is the two-instrument problem with the rival's
participation constraint at outside option r - delta, whose binding share is
bar-beta(delta) = 1 - (delta/r)(8+sigma(8+sigma))/(8(1+sigma)).
"""
import numpy as np
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_sep,
                      prices_int, surpluses, admissible, a_kill, N2val)

V, R = V_DEF, R_DEF
TOL = 1e-9

# ---------------------------------------------------------------- closed forms
def kappa(uB, sig):
    """a_kill = kappa * x, with x = beta r - (r - delta)."""
    return (8 + sig*(8 + sig))/(2*uB*(4 + 3*sig))

def mu(sig):
    """u_B * kappa, the rate at which the fee erodes demand along a_kill."""
    return (sig*sig + 8*sig + 8)/(2*(3*sig + 4))

def a_sub(uB, uS, sig, dl, v=V, r=R):
    return (sig+2)*(uS*(v+r) - dl*(uB+uS))/(sig + 4 - 4*uB*uS)

def delta_bar(uB, uS, v=V, r=R):
    return uS*(v+r)/(uB+uS)

def beta_bar(sig, dl, r=R):
    """Rival's participation share against the integrated firm."""
    return 1.0 - (dl/r)*(8 + sig*(8+sig))/(8*(1+sig))

# ------------------------------------------------- benchmark: exact quadratic
def _bench_objects(uB, uS, sig, dl, x, a, v=V, r=R):
    """Symmetric separation at b = r - delta + x and fee a."""
    M = Mof(uB, uS); b = r - dl + x
    D  = (sig+2)*(v + b - uB*a)/((sig+4)*M)
    qS = (2*uS*(sig+2)*(v+b) - a*(sig+4-4*uB*uS))/((sig+4)*M)
    return b, D, qS

def _bench_value(uB, uS, sig, dl, x, a):
    b, D, qS = _bench_objects(uB, uS, sig, dl, x, a)
    return 2*(R - b)*D + a*qS

def benchmark(uB, uS, g, dl, v=V, r=R):
    """Exact solution of the separation programme under dominance."""
    sig = sigma_of(uB, uS, g); M = Mof(uB, uS); k = kappa(uB, sig)
    A = (sig+2)/((sig+4)*M)          # D = A (v + b - uB a)
    B = (sig+4-4*uB*uS)/((sig+4)*M)  # qS = 2 uS A (v+b) - B a
    w = v + r - dl                   # v + b = w + x

    # Pi(x,a) = 2 (delta - x) A (w + x - uB a) + a [2 uS A (w + x) - B a]
    # quadratic; collect coefficients
    def Pi(x, a): return 2*(dl-x)*A*(w+x-uB*a) + a*(2*uS*A*(w+x) - B*a)
    def dPi_dx(x, a): return -2*A*(w+x-uB*a) + 2*(dl-x)*A + 2*uS*A*a
    def dPi_da(x, a): return -2*(dl-x)*A*uB + 2*uS*A*(w+x) - 2*B*a

    cands = []
    # (1) interior stationary point
    #   dPi_dx = 0 : -2A w - 4A x + 2A uB a + 2 A delta + 2 uS A a = 0
    #   dPi_da = 0 : -2 A uB delta + 2 A uB x + 2 uS A w + 2 uS A x - 2 B a = 0
    Mx = np.array([[-4*A, 2*A*(uB+uS)],
                   [2*A*(uB+uS), -2*B]])
    rhs = np.array([2*A*w - 2*A*dl, 2*A*uB*dl - 2*uS*A*w])
    if abs(np.linalg.det(Mx)) > 1e-14:
        xa = np.linalg.solve(Mx, rhs); cands.append((xa[0], xa[1]))
    # (2) edges
    for xf in (0.0, dl):                        # x fixed, a free
        den = -2*B
        if abs(den) > 1e-14:
            cands.append((xf, -(-2*(dl-xf)*A*uB + 2*uS*A*(w+xf))/den))
    #     a = kappa x (the fee constraint binds): one-dimensional in x
    def Pi_kill(x): return Pi(x, k*x)
    # quadratic in x: fit exactly on three points
    xs = np.array([0.0, 1.0, 2.0]); ys = np.array([Pi_kill(t) for t in xs])
    c2, c1, c0 = np.polyfit(xs, ys, 2)
    if abs(c2) > 1e-14:
        xstar = -c1/(2*c2); cands.append((xstar, k*xstar))
    # (3) vertices
    for xf in (0.0, dl): cands.append((xf, k*xf))

    best = None
    for (x, a) in cands:
        if x < -TOL or x > dl + TOL: continue
        if a > k*x + 1e-9: continue
        x = min(max(x, 0.0), dl)
        b, D, qS = _bench_objects(uB, uS, sig, dl, x, a)
        if D <= 0 or qS <= 0: continue
        p1, p2 = prices_sep(uB, uS, sig, b, b, a)
        if p1 + b <= 0: continue                      # positive markup
        val = 2*(r-b)*D + a*qS
        if best is None or val > best[0] + 1e-12:
            VB, VS = surpluses(uB, uS, g, p1, p2, D, D, qS)
            best = (val, b/r, a, (p1+b)*D, VB, VS, VB+VS+2*(p1+b)*D+val, x)
    return best   # (platform, beta, a_sep, pi_manuf, V_B, V_S, W, x)

# ------------------------------------------- benchmark: asymmetric packages
# The programme above restricts the platform to a common share.  The best
# package is generally asymmetric: the platform hands back x_1 to ONE
# manufacturer, enough for its adoption alone to beat joint refusal
# (a <= kappa x_1), and holds the other at its floor r - delta, where it accepts
# once its rival is on the system (the acceptance convention).  With x_1 >= x_2
# the feasible set is the convex polyhedron
#     P^a = {0 <= x_2 <= x_1 <= delta,  a <= kappa x_1},
# on which the quadratic profit (delta - x_1) D_1 + (delta - x_2) D_2 + a q_S
# is strictly concave (its Hessian is that of the two-host programme, negative
# definite iff Delta_delta > 0).  The optimum is found exactly by enumerating
# the active sets (rep35_dominance_asym.py verifies the closed forms and
# checks the programme against the enumerated adoption game).
import itertools

def _asym_objects(uB, uS, sig, dl, x1, x2, a, v=V, r=R):
    b1, b2 = r - dl + x1, r - dl + x2
    p1, p2 = prices_sep(uB, uS, sig, b1, b2, a, v)
    D1, D2, qS = demands(uB, uS, sig, p1, p2, a, v)
    return dict(b1=b1, b2=b2, p1=p1, p2=p2, D1=D1, D2=D2, qS=qS,
                pi1=(p1+b1)*D1, pi2=(p2+b2)*D2, Pi=(r-b1)*D1 + (r-b2)*D2 + a*qS)

def _asym_quadratic(uB, uS, sig, dl, v=V, r=R):
    """Exact coefficients of Pi(x1, x2, a) = c0 + g.x + x'Qx (fit on 16 points)."""
    rng = np.random.default_rng(3)
    X = rng.uniform(-0.5, 1.0, size=(16, 3))
    A = np.array([[1, x[0], x[1], x[2], x[0]**2, x[1]**2, x[2]**2,
                   x[0]*x[1], x[0]*x[2], x[1]*x[2]] for x in X])
    y = np.array([_asym_objects(uB, uS, sig, dl, *x, v, r)['Pi'] for x in X])
    c, *_ = np.linalg.lstsq(A, y, rcond=None)
    Q = np.array([[c[4], c[7]/2, c[8]/2], [c[7]/2, c[5], c[9]/2], [c[8]/2, c[9]/2, c[6]]])
    return c[0], c[1:4], Q

# active sets, in the order (a = kappa x1, x1 = delta, x2 = 0, x2 = x1)
_REGIME = {(): 'seam', (3,): 'seam',                     # no constraint binding (symmetric by symmetry)
           (0,): 'edge-two', (1,): 'cap-two', (0, 1): 'cap-corner-two',   # M2 handed back part of the premium
           (2,): 'one-interior',                          # M2 at the floor, x1 interior, fee slack
           (0, 2): 'edge',                                # M2 at the floor, a = kappa x1: the taxing edge
           (1, 2): 'cap', (0, 1, 2): 'cap-corner',        # M1 at beta = 1, M2 at the floor
           (1, 3): 'cap-both', (0, 1, 3): 'cap-both-corner',   # both at beta = 1 (the monetizing regime)
           (0, 3): 'sym-edge',                            # symmetric taxing branch
           (2, 3): 'floor', (0, 2, 3): 'floor', (1, 2, 3): 'floor', (0, 1, 2, 3): 'floor'}

def benchmark_asym(uB, uS, g, dl, v=V, r=R):
    """Exact optimum of the asymmetric programme on P^a.  Returns a dict with
    the package (x1, x2, a, beta1, beta2), the regime (which constraints bind:
    'floor' both at r - delta; 'edge' M2 at the floor, a = kappa x1; 'cap' M1
    at beta = 1, M2 at the floor, fee slack; 'cap-corner' idem with a = kappa
    delta; 'seam' no constraint binding; '...-two' M2 handed back as well) and
    the equilibrium objects, or None."""
    sig = sigma_of(uB, uS, g); k = kappa(uB, sig)
    c0, gv, Q = _asym_quadratic(uB, uS, sig, dl, v, r)
    if not np.all(np.linalg.eigvalsh(Q) < 0):
        return None                                  # not concave: outside A*
    # constraints A x <= b, in the order: a - kappa x1 <= 0 ; x1 - delta <= 0 ;
    # -x2 <= 0 ; x2 - x1 <= 0
    A = np.array([[-k, 0, 1.], [1., 0, 0], [0, -1., 0], [-1., 1., 0]])
    b = np.array([0., dl, 0., 0.])
    f = lambda x: c0 + gv @ x + x @ Q @ x
    best = None
    for kk in range(5):
        for Sset in itertools.combinations(range(4), kk):
            Sset = list(Sset); n = 3 + len(Sset)
            K = np.zeros((n, n)); rhs = np.zeros(n)
            K[:3, :3] = 2*Q; rhs[:3] = -gv
            if Sset:
                K[:3, 3:] = -A[Sset].T; K[3:, :3] = A[Sset]; rhs[3:] = b[Sset]
            try:
                x = np.linalg.solve(K, rhs)[:3]
            except np.linalg.LinAlgError:
                continue
            if not np.all(A @ x <= b + 1e-9):
                continue
            val = f(x)
            if best is None or val > best[0] + 1e-12:
                best = (val, x, tuple(Sset))
    if best is None:
        return None
    val, x, Sset = best
    x1, x2, a = float(x[0]), float(x[1]), float(x[2])
    x1 = min(max(x1, 0.0), dl); x2 = min(max(x2, 0.0), x1); a = min(a, k*x1)
    o = _asym_objects(uB, uS, sig, dl, x1, x2, a, v, r)
    if min(o['D1'], o['D2'], o['qS']) <= 0 or min(o['p1']+o['b1'], o['p2']+o['b2']) <= 0:
        return None
    VB, VS = surpluses(uB, uS, g, o['p1'], o['p2'], o['D1'], o['D2'], o['qS'], v)
    reg = _REGIME.get(Sset, 'other')
    if reg == 'floor' and a < -1e-12: reg = 'floor-subsidy'
    o.update(x1=x1, x2=x2, a=a, beta1=o['b1']/r, beta2=o['b2']/r, regime=reg,
             active=Sset, VB=VB, VS=VS, W=VB + VS + o['pi1'] + o['pi2'] + o['Pi'])
    return o

# ------------------------------------------------------- integrated firm
def integrated_walk(uB, uS, g, dl, v=V, r=R):
    """M2 on its outside option (benefit r - delta): the integrated firm earns
    no licensing margin and holds one instrument only.  This is the relevant
    configuration when bar-beta(delta) < 0, i.e. when the cap beta <= 1 cannot
    keep the rival on the platform's system at any admissible share."""
    sig = sigma_of(uB, uS, g)
    def val(a):
        p1, p2 = prices_int(uB, uS, sig, r, a)      # no licensing margin: b2 = r
        # M2 is outside, so it prices at perceived benefit r - dl, not r
        from rep_core import demands as _d
        # resolve the pricing equilibrium with M1 integrated and M2 at r-dl
        A = np.array([[-2*(2+sig)*(1.0), sig],[sig, -2*(2+sig)]])
        rhs = np.array([-(2*v-2*uB*a) + (2+sig)*r + 2*uS*a,
                        -(2*v-2*uB*a) + (2+sig)*(r-dl)])
        P = np.linalg.solve(A, rhs)
        D1, D2, qS = _d(uB, uS, sig, P[0], P[1], a)
        return (P[0]+r)*D1 + a*qS, P[0], P[1], D1, D2, qS
    xs = np.array([-1.0, 0.0, 1.0]); ys = np.array([val(t)[0] for t in xs])
    c2, c1, c0 = np.polyfit(xs, ys, 2)
    if c2 >= 0: return None
    a = -c1/(2*c2)
    vv, p1, p2, D1, D2, qS = val(a)
    if min(D1, D2) <= 0 or qS <= 0: return None
    if p2 + (r-dl) <= 0: return None
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, qS)
    return (vv, None, a, (p2+(r-dl))*D2, VB, VS, VB+VS+(p2+(r-dl))*D2+vv)

def integrated(uB, uS, g, dl, v=V, r=R):
    """Two-instrument optimum with the rival's participation at r - delta."""
    sig = sigma_of(uB, uS, g); M = Mof(uB, uS)
    bb = max(0.0, beta_bar(sig, dl, r))            # participation floor
    def val(beta2, a):
        b2 = beta2*r
        p1, p2 = prices_int(uB, uS, sig, b2, a)
        D1, D2, qS = demands(uB, uS, sig, p1, p2, a)
        return (p1+r)*D1 + a*qS + (r-b2)*D2, p1, p2, D1, D2, qS
    # Pi^I is quadratic in (beta2, a): fit exactly and optimise on [bb,1] x R
    pts = [(0.0,0.0),(1.0,0.0),(0.0,1.0),(1.0,1.0),(0.5,0.0),(0.0,0.5)]
    Amat = np.array([[1,p,q,p*p,p*q,q*q] for (p,q) in pts], float)
    yv = np.array([val(p,q)[0] for (p,q) in pts])
    c = np.linalg.solve(Amat, yv)                  # c0 + c1 b + c2 a + c3 b^2 + c4 ba + c5 a^2
    Hs = np.array([[2*c[3], c[4]],[c[4], 2*c[5]]])
    cands = []
    if abs(np.linalg.det(Hs)) > 1e-14:
        cands.append(tuple(np.linalg.solve(Hs, -np.array([c[1], c[2]]))))
    for bfix in (bb, 1.0):
        if abs(2*c[5]) > 1e-14:
            cands.append((bfix, -(c[2] + c[4]*bfix)/(2*c[5])))
    # bar-beta(delta) < 0 means the rival would stay even at a zero share: the
    # participation constraint is slack on [0,1] and the platform sits at the
    # corner beta^2 = 0.  This is the fourth regime the paper sets aside; the
    # flag `corner` below records where it is reached.
    best = None
    for (beta2, a) in cands:
        if beta2 < bb - TOL or beta2 > 1 + TOL: continue
        beta2 = min(max(beta2, bb), 1.0)
        vv, p1, p2, D1, D2, qS = val(beta2, a)
        if min(D1, D2) <= 0 or qS <= 0: continue
        if p2 + beta2*r <= 0: continue
        if best is None or vv > best[0] + 1e-12:
            VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, qS)
            best = (vv, beta2, a, (p2+beta2*r)*D2, VB, VS, VB+VS+(p2+beta2*r)*D2+vv,
                    beta_bar(sig, dl, r) < 0)          # corner beta^2 = 0
    return best

# ---------------------------------------------------- game-consistent check
def sweep_benchmark(uB, uS, g, dl, nb=241, na=1201, amin=-3.0, amax=4.0):
    """Brute-force sweep over symmetric packages, enumerating adoption
    equilibria and applying the joint-profit selection rule.  Used only to
    check `benchmark`."""
    sig = sigma_of(uB, uS, g); best = None
    for beta in np.linspace(max(0.0, 1-dl/R), 1.0, nb):
        b = beta*R
        for a in np.linspace(amin, amax, na):
            # profile (adopt, adopt)
            p1, p2 = prices_sep(uB, uS, sig, b, b, a)
            D1, D2, qS = demands(uB, uS, sig, p1, p2, a)
            if min(D1, D2) <= 0 or qS <= 0: continue
            pi_aa = (p1+b)*D1
            # profile (adopt, refuse)
            q1, q2 = prices_sep(uB, uS, sig, b, R-dl, a)
            E1, E2, _ = demands(uB, uS, sig, q1, q2, a)
            pi_ar_adopt = (q1+b)*E1
            # profile (refuse, refuse): no fee collected if a > 0
            af = a if a <= 0 else 0.0
            s1, s2 = prices_sep(uB, uS, sig, R-dl, R-dl, af)
            F1, F2, _ = demands(uB, uS, sig, s1, s2, af)
            pi_rr = (s1+(R-dl))*F1
            # (adopt,adopt) must be an equilibrium: no unilateral refusal
            if pi_aa < (q2+(R-dl))*E2 - 1e-12: continue
            # selection rule: joint refusal must not be selected over it
            if pi_rr >= pi_ar_adopt - 1e-12 and 2*pi_rr > 2*pi_aa + 1e-12: continue
            val = 2*(R-b)*D1 + a*qS
            if best is None or val > best[0]: best = (val, beta, a)
    return best

# --------------------------------------------------------------- closed form
def x_star(uB, uS, sig, dl, v=V, r=R):
    """Interior optimum along the binding fee constraint a = a_kill(beta,delta):
    the taxing regime of the proposition, in closed form (clip to [0, delta]).

        x* = 2 u_B (sigma+2)(3 sigma+4) N / Dn,     a_sep = kappa * x*

    with Lambda = 8 + sigma(8+sigma),
        N  = delta [u_B (sigma^2-4 sigma-8) + u_S Lambda]
             + (v+r) [2 u_B (3 sigma+4) - u_S Lambda]
    and Dn the (negative) denominator below, so that the branch is concave.
    """
    L = 8 + sig*(8+sig)
    N = dl*(uB*(sig*sig-4*sig-8) + uS*L) + (v+r)*(2*uB*(3*sig+4) - uS*L)
    Dn = (-sig**5 + 12*sig**4*uB**2 + 16*sig**4*uB*uS - 20*sig**4
          + 64*sig**3*uB**2 + 200*sig**3*uB*uS - 144*sig**3
          + 112*sig**2*uB**2 + 768*sig**2*uB*uS - 448*sig**2
          + 64*sig*uB**2 + 1088*sig*uB*uS - 576*sig + 512*uB*uS - 256)
    return 2*uB*(sig+2)*(3*sig+4)*N/Dn

def corner_threshold(sig, r=R):
    """Above this premium the rival's participation constraint stops binding and
    the integrated firm sits at the corner beta^2 = 0."""
    return r*8*(1+sig)/(8 + sig*(8+sig))

def admissible_grid(g=4.0, n=40, lo=0.02, hi=1.4):
    """The paper's dominance grid: N_2 < 0 and sigma >= 0.  774 points at
    gamma = 4, n = 40, [0.02, 1.4]."""
    gr = np.linspace(lo, hi, n)
    return [(u1,u2) for u1 in gr for u2 in gr
            if Mof(u1,u2) > 0 and sigma_of(u1,u2,g) >= 0
            and N2val(u1,u2,sigma_of(u1,u2,g)) < 0]

# ==============================================================================
if __name__ == "__main__":
    G = 4.0
    REF = [(0.1,0.1),(0.5,0.18),(0.15,1.0)]
    print("rep5_dominance -- gamma = 4, v = 2, r = 1/2\n")

    print("A. Symmetric programme vs its game-consistent sweep, and the asymmetric programme (platform value)")
    print("   %-13s %-6s %-11s %-11s %-9s | %-11s %-28s" % ("(u_B,u_S)","delta","symmetric","sweep","gap","asymmetric","package (beta1, beta2, a), regime"))
    for (uB,uS) in REF:
        for dl in (0.1,0.2,0.3):
            e = benchmark(uB,uS,G,dl); s = sweep_benchmark(uB,uS,G,dl); b = benchmark_asym(uB,uS,G,dl)
            print("   %-13s %-6.2f %-11.5f %-11.5f %-9.1e | %-11.5f (%.3f, %.3f, %+.3f) %s" %
                  ("(%.2f,%.2f)"%(uB,uS), dl, e[0], s[0], e[0]-s[0], b['Pi'], b['beta1'], b['beta2'], b['a'], b['regime']))

    print("\nB. Closed form of the taxing branch against the numerical optimum")
    mx = 0.0
    for (uB,uS) in REF:
        for dl in (0.1,0.2,0.3,0.4):
            sig = sigma_of(uB,uS,G)
            xc = min(max(x_star(uB,uS,sig,dl), 0.0), dl)
            e = benchmark(uB,uS,G,dl)
            mx = max(mx, abs(xc - e[7]))
    print("   max |x* (closed form) - x* (active set)| = %.2e" % mx)

    print("\nC. Reference-point quantities (paper's values in brackets)")
    uB,uS,dl = 0.15,1.0,0.1; sig = sigma_of(uB,uS,G); s = benchmark(uB,uS,G,dl)
    b = R-dl; D = (sig+2)*(V+b)/((sig+4)*Mof(uB,uS))
    p1,p2 = prices_sep(uB,uS,sig,b,b,0.0)
    print("   divide-and-conquer value at (0.15,1.0), delta=0.1 : %.4f   [3.63]" % s[0])
    print("   a_kill(1, 0.1)                                    : %.4f   [0.993]" %
          a_kill(uB,sig,R,R,dl))
    print("   hosted manufacturer under divide-and-conquer      : %.4f   [1.682]" % s[3])
    print("   pi^bench_delta (b = r-delta, a = 0)               : %.4f   [1.753]" % ((p1+b)*D))

    print("\nD. Table B.3 regenerated (asymmetric benchmark; the rival is the manufacturer held at its floor)")
    hdr = ["delta=0","0.1","0.2","0.3","0.4"]
    print("   %-13s %-16s %s" % ("(u_B,u_S)","","  ".join("%9s"%h for h in hdr)))
    for (uB,uS) in REF:
        rows = {"fee increment":[], "rival dpi2":[], "welfare dW":[]}; corner=[]
        for dl in (0.0,0.1,0.2,0.3,0.4):
            s = benchmark_asym(uB,uS,G,dl); i = integrated(uB,uS,G,dl)
            rows["fee increment"].append(i[2]-s['a'])
            rows["rival dpi2"].append(i[3]-s['pi2'])
            rows["welfare dW"].append(i[6]-s['W']); corner.append(i[7])
        for k,vv in rows.items():
            print("   %-13s %-16s %s" % ("(%.2f,%.2f)"%(uB,uS) if k=="fee increment" else "",
                  k, "  ".join("%8.3f%s"%(z,"*" if c else " ") for z,c in zip(vv,corner))))
    print("   (* : corner beta^2 = 0, where the rival's participation constraint is slack)")

    print("\nE. Grid statistics (40x40 on [0.02,1.4], N_2 < 0 and sigma >= 0; asymmetric benchmark)")
    adm = admissible_grid(G)
    print("   admissible points: %d" % len(adm))
    print("   %-8s %-22s %-22s %-16s" % ("delta","W falls at","benchmark subsidizes","corner beta^2=0"))
    for dl in (0.0,0.1,0.2,0.3):
        neg=tot=sub=cor=0
        for (u1,u2) in adm:
            s = benchmark_asym(u1,u2,G,dl); i = integrated(u1,u2,G,dl)
            if s is None or i is None: continue
            tot += 1
            if i[6]-s['W'] < 0: neg += 1
            if s['a'] < -1e-9: sub += 1
            if i[7]: cor += 1
        print("   %-8.2f %-22s %-22s %-16s" % (dl, "%3d/%3d = %2.0f%%"%(neg,tot,100*neg/tot),
              "%3d points"%sub, "%3d points"%cor))
    print("\n   a_sep > a**(delta) on the taxing range:")
    for dl in (0.1,0.2,0.3):
        n=t=0
        for (u1,u2) in adm:
            s = benchmark_asym(u1,u2,G,dl); i = integrated(u1,u2,G,dl)
            if s is None or i is None or s['a'] <= 1e-9: continue
            t += 1
            if s['a'] > i[2]+1e-9: n += 1
        print("      delta=%-5.2f : %2d exception(s) out of %3d taxing points" % (dl,n,t))
