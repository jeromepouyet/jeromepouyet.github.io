# -*- coding: utf-8 -*-
"""verifL.py -- A dominant platform: the benchmark can subsidize (revision of
August 2026, correcting Proposition [dominant](i)-(ii)).

The premium program of part (iii) is defined for a < 0 as well: with a < 0 the
subsidy is collected on the platform's store whatever the adoption profile
(equation (3)), so the application stock is the same in every configuration and,
by monotonicity fact (i), adoption at any benefit b > r - delta is strictly
dominant. Joint refusal is then not an equilibrium and no compensation is owed.
Setting b = r - delta (closed by the acceptance convention) the platform solves
    max_a  Pi_S(a) = delta (D_1 + D_2) + a q_S .
Checks:
 (1) closed forms: Pi_S'(0), Pi_S'' (globally concave), a_sub, the frontier
     delta-bar, and the envelope identity Pi_S'' = 2 dq_S/da;
 (2) equilibrium: adoption strictly dominant, joint refusal not an equilibrium;
 (3) the subsidy branch beats the compensated program where it is active;
 (4) interiority at a_sub;
 (5) a game-consistent search over (beta, a) recovers a_sub as the optimum;
 (6) the four reference points of Table B.3 are unaffected (delta-bar > r there).
Run: python3 verifL.py   (about a minute)
"""
import sympy as sp
import numpy as np

uB, uS, g, v, r, delta = sp.symbols('u_B u_S gamma v r delta', positive=True)
a, p1, p2, b = sp.symbols('a p_1 p_2 b')
sig = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
S = sp.Symbol('sigma')
_x, _y, _f = sp.symbols('_x _y _f')
Dk = (2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DSx = (uS*(2*v-_x-_y)-_f)/M
D1 = Dk.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
D2 = Dk.subs({_x: p2, _y: p1, _f: a}, simultaneous=True)
DSe = DSx.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
gg = sp.solve(sp.Eq(S, sig), g)[0]
sform = lambda e: sp.factor(sp.cancel(sp.together(e).subs(g, gg)))

# ---------------------------------------------------------------- (1) forms
sol = sp.solve([sp.diff((p1+b)*D1, p1), sp.diff((p2+b)*D2, p2)], [p1, p2], dict=True)[0]
SD = D1.subs(sol) + D2.subs(sol); q = DSe.subs(sol)
PiS = ((r-b)*SD + a*q).subs(b, r-delta)
qS = q.subs(b, r-delta)
P0 = sform(sp.diff(PiS, a).subs(a, 0)); Ppp = sform(sp.diff(PiS, a, 2))
a_sub = sform(sp.cancel(-sp.diff(PiS, a).subs(a, 0)/sp.diff(PiS, a, 2)))
print("(1) Pi_S'(0)  =", P0)
print("    Pi_S''    =", Ppp)
print("    a_sub     =", a_sub)
print("    Pi_S'' - 2 dq_S/da =", sp.simplify(sp.diff(PiS, a, 2) - 2*sp.diff(qS, a)))
claim_P0 = 2*(S+2)*(uS*(v+r) - delta*(uB+uS))/((S+4)*(1-2*uB*uS))
claim_pp = -2*(S+4-4*uB*uS)/((S+4)*(1-2*uB*uS))
claim_as = (S+2)*(uS*(v+r) - delta*(uB+uS))/(S+4-4*uB*uS)
print("    residuals vs displayed forms:",
      sp.simplify(P0 - claim_P0), sp.simplify(Ppp - claim_pp), sp.simplify(a_sub - claim_as))
print("    Pi_S'' < 0 always on the admissible set (sigma > -1, 2 u_B u_S < 1):",
      "sigma+4 > 3 > 2 > 4 u_B u_S")
print("    frontier: a_sub < 0 iff delta > delta-bar = u_S(v+r)/(u_B+u_S);"
      " nonempty (delta < r) iff u_B/u_S > v/r")
print("    exclusivity: on u_S >= u_B, delta-bar >=",
      sp.simplify((uS*(v+r)/(uB+uS)).subs(uS, uB)), "so branches are disjoint when r <= v")

# ------------------------------------------------------- numerical machinery
V, R = 2.0, 0.5
def eq_both(uBv, uSv, gv, bv, av):
    """both adopt at benefit b; subsidy always collected, tax only if u_S n_B >= a"""
    s = gv - 2*uBv*uSv*(1+gv); Mv = 1-2*uBv*uSv
    A = np.array([[-2*(2+s), s], [s, -2*(2+s)]])
    rhs = np.array([-(2*V-2*uBv*av) + (2+s)*bv]*2)
    P = np.linalg.solve(A, rhs)
    D = np.array([(2*V-(2+s)*P[0]+s*P[1]-2*uBv*av)/(2*Mv),
                  (2*V-(2+s)*P[1]+s*P[0]-2*uBv*av)/(2*Mv)])
    qv = (uSv*(2*V-P[0]-P[1])-av)/Mv
    return P, D, qv
def eq_asym(uBv, uSv, gv, b_host, b_out, av):
    s = gv - 2*uBv*uSv*(1+gv); Mv = 1-2*uBv*uSv
    A = np.array([[-2*(2+s), s], [s, -2*(2+s)]])
    rhs = np.array([-(2*V-2*uBv*av) + (2+s)*b_host, -(2*V-2*uBv*av) + (2+s)*b_out])
    P = np.linalg.solve(A, rhs)
    D = np.array([(2*V-(2+s)*P[0]+s*P[1]-2*uBv*av)/(2*Mv),
                  (2*V-(2+s)*P[1]+s*P[0]-2*uBv*av)/(2*Mv)])
    qv = (uSv*(2*V-P[0]-P[1])-av)/Mv
    return P, D, qv
def config(uBv, uSv, gv, bv, av, who):
    """who: 'both', 'none', 'one'. Returns (manufacturer profits, platform profit)."""
    if who == 'both':
        P, D, qv = eq_both(uBv, uSv, gv, bv, av)
        if av > 0 and uSv*(D[0]+D[1]) < av:     # publication fails: fee dead
            P, D, qv = eq_both(uBv, uSv, gv, bv, 0.0); av_eff = 0.0
        else: av_eff = av
        pim = (P+bv)*D
        return pim, (R-bv)*(D[0]+D[1]) + av_eff*qv
    if who == 'none':
        av_eff = av if av <= 0 else 0.0          # nobody hosts: a tax is dead
        P, D, qv = eq_both(uBv, uSv, gv, R-delta_v, av_eff)
        return (P+(R-delta_v))*D, 0.0
    P, D, qv = eq_asym(uBv, uSv, gv, bv, R-delta_v, av)
    if av > 0 and uSv*D[0] < av:
        P, D, qv = eq_asym(uBv, uSv, gv, bv, R-delta_v, 0.0); av_eff = 0.0
    else: av_eff = av
    return np.array([(P[0]+bv)*D[0], (P[1]+(R-delta_v))*D[1]]), (R-bv)*D[0] + av_eff*qv

# ------------------------------------------------- (2)-(5) at test points
astf = sp.lambdify((uB, uS, g, v, r, delta), a_sub.subs(S, sig), 'numpy')
dbar = lambda uBv, uSv: uSv*(V+R)/(uBv+uSv)
print("\n(2)-(5) game-consistent checks (gamma=4, v=2, r=1/2):")
for (uBv, uSv, delta_v) in [(0.5, 0.01, 0.4), (0.6, 0.05, 0.45), (0.9, 0.1, 0.4)]:
    gv = 4.0
    s = gv - 2*uBv*uSv*(1+gv)
    ah = astf(uBv, uSv, gv, V, R, delta_v)
    # (2) adoption strictly dominant at b = r-delta+eps, a<0 ; joint refusal not NE
    bv = R - delta_v + 1e-6
    pim_b, _ = config(uBv, uSv, gv, bv, ah, 'both')
    pim_n, _ = config(uBv, uSv, gv, bv, ah, 'none')
    pim_o, _ = config(uBv, uSv, gv, bv, ah, 'one')
    dominant = pim_b[0] > pim_o[1] and pim_o[0] > pim_n[0]
    # (5) game-consistent search over (beta, a)
    best = (-1e9, None)
    for beta in np.linspace(1-delta_v/R, 1.0, 60):
        bb = beta*R
        for av in np.linspace(-3.0, 3.0, 601):
            pim_bb, PI_b = config(uBv, uSv, gv, bb, av, 'both')
            pim_nn, _ = config(uBv, uSv, gv, bb, av, 'none')
            pim_oo, _ = config(uBv, uSv, gv, bb, av, 'one')
            both_ne = pim_bb[0] >= pim_oo[1]           # no unilateral walk
            none_ne = pim_nn[0] >= pim_oo[0]           # no unilateral adopt
            if not both_ne: continue
            if none_ne and sum(pim_nn) > sum(pim_bb): continue   # selection picks refusal
            if PI_b > best[0]: best = (PI_b, (beta, av))
    _, PI_sub = config(uBv, uSv, gv, R-delta_v, ah, 'both')
    print("  (u_B,u_S,delta)=(%.2f,%.2f,%.2f): delta-bar=%.3f  a_sub=%+.4f"
          % (uBv, uSv, delta_v, dbar(uBv, uSv), ah))
    print("     adoption strictly dominant & joint refusal not NE:", dominant)
    print("     branch value %.4f   |   search optimum %.4f at (beta,a)=(%.3f,%+.3f)"
          % (PI_sub, best[0], best[1][0], best[1][1]))
    # (3) compensated program is stuck at a_comp = 0 here (u_S < u_B)
    _, PI_comp = config(uBv, uSv, gv, R-delta_v, 0.0, 'both')
    print("     compensated program (a_comp = 0 since u_S < u_B): %.4f" % PI_comp)
    # (4) interiority at a_sub
    P, D, qv = eq_both(uBv, uSv, gv, R-delta_v, ah)
    print("     interiority at a_sub: D=(%.3f,%.3f) q=%.3f markups=(%.3f,%.3f)"
          % (D[0], D[1], qv, P[0]+R, P[1]+R))

# ---------------------------------------------------- (6) Table B.3 reference points
print("\n(6) reference points of the dominance table: delta-bar vs the tabulated delta")
for (uBv, uSv) in [(0.1, 0.1), (0.5, 0.18), (0.15, 1.0), (0.215, 1.106)]:
    print("    (%.3f,%.3f): delta-bar = %.3f  (delta ranges up to r = %.1f: %s)"
          % (uBv, uSv, dbar(uBv, uSv), R,
             "subsidy branch inactive" if dbar(uBv, uSv) > R else "ACTIVE -- table affected"))

# ------------------------------------------------- (7) the three programs on the grid
print("\n(7) benchmark optimum on the 40x40 admissible grid, gamma = 4")
def N2f(uBv, uSv, s):
    return (9*s**3*((uBv+uSv)**2-2)+5*s**2*(9*uBv**2+22*uBv*uSv+9*uSv**2-20)
            +16*s*(5*uBv**2+14*uBv*uSv+5*uSv**2-12)+16*((3*uBv+uSv)*(uBv+3*uSv)-8))
def programs(uBv, uSv, gv, dv):
    """returns (value, fee) of the compensated, divide-and-conquer and subsidy routes"""
    s = gv - 2*uBv*uSv*(1+gv); Mv = 1-2*uBv*uSv
    # compensated
    ac = min((uSv-uBv)*(V+R-dv)*(2+s)/(Mv*(4+s)), dv/uBv) if uSv > uBv else 0.0
    _, PIc = config(uBv, uSv, gv, R-dv+uBv*ac, ac, 'both')
    # divide-and-conquer (taxing): a = a_kill(beta, delta)
    best_dc = (-1e9, 0.0)
    for beta in np.linspace(1-dv/R, 1.0, 40):
        ak = (beta*R-(R-dv))*(8+s*(8+s))/(2*uBv*(4+3*s))
        _, PIk = config(uBv, uSv, gv, beta*R, ak, 'both')
        if PIk > best_dc[0]: best_dc = (PIk, ak)
    # subsidy branch
    asub = astf(uBv, uSv, gv, V, R, dv)
    asub = min(asub, 0.0)
    _, PIs = config(uBv, uSv, gv, R-dv, asub, 'both')
    return [(PIc, ac), best_dc, (PIs, asub)]

gv = 4.0
grid = np.linspace(0.02, 1.4, 40)
for dv in [0.1, 0.25, 0.4]:
    delta_v = dv
    tot = neg = 0; worst = None
    for uBv in grid:
        for uSv in grid:
            if 2*uBv*uSv >= 1: continue
            s = gv - 2*uBv*uSv*(1+gv)
            if s <= 0 or N2f(uBv, uSv, s) >= 0: continue
            tot += 1
            vals = programs(uBv, uSv, gv, dv)
            val, fee = max(vals, key=lambda t: t[0])
            if fee < -1e-9:
                neg += 1
                if worst is None or fee < worst[2]: worst = (uBv, uSv, fee)
    print("   delta=%.2f: %d admissible points, a_sep < 0 at %d of them%s"
          % (dv, tot, neg, "" if neg == 0 else
             "  (most negative %+.3f at (u_B,u_S)=(%.2f,%.2f))" % (worst[2], worst[0], worst[1])))
