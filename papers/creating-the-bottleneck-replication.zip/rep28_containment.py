# -*- coding: utf-8 -*-
"""rep28_containment.py -- C: the cell (floor, cap) is empty, as an identity.

Numerically the integration cap region never meets the separation floor region
(0 points out of 7,225-9,687 at gamma in {1,2,4,8,16}).  Here it is proved.

Both regions are single explicit inequalities:
  cap   (integration) : phi(r) >= 0, phi being affine and decreasing in b2, so
                        b2* >= r iff phi(r) >= 0.  In (sigma, u_S) coordinates
                        this is u_S^2 >= X_cap(sigma), equation (B.16) of the OA.
  floor (separation)  : u_B/u_S >= R_Phi = Lambda/(3 sigma + 4), the taxing
                        frontier of the asymmetric benchmark (rep35), i.e.
                        u_S^2 <= w/R_Phi with w = u_B u_S = (gamma-sigma)/(2(1+gamma)).
So the cells are disjoint iff  X_cap(sigma) >= w/R_Phi(sigma)  on 0 <= sigma
<= gamma, which is a rational inequality in (sigma, gamma) alone.  Cleared of
denominators and written in gamma = sigma + t, t >= 0, its coefficients should
have a single sign -- the method the paper uses elsewhere.  (R_Phi = 2 R_delta,
so the inequality is implied by the earlier one with R_delta; both are shown.)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
P = lambda *a: print(*a, flush=True)
ok = lambda c: "PASS" if c else "**FAIL**"
P("="*78); P("rep28 (C) -- the cells (floor, cap) are disjoint"); P("="*78)

uB,uS,s,v,r,d,g,t,p1,p2,b2,a = sp.symbols('u_B u_S sigma v r delta gamma t p_1 p_2 b_2 a', positive=True)
M=1-2*uB*uS; Lam=8+s*(8+s)
D1e=(2*v-(2+s)*p1+s*p2-2*uB*a)/(2*M); D2e=(2*v-(2+s)*p2+s*p1-2*uB*a)/(2*M)
QSe=(uS*(2*v-p1-p2)-a)/M
objI=(p1+r)*D1e+a*QSe+(r-b2)*D2e
inte=sp.solve([sp.diff(objI,p1),sp.diff((p2+b2)*D2e,p2)],[p1,p2],dict=True)[0]
PiI=sp.cancel(sp.together(objI.subs(inte)))
a_of=sp.cancel(sp.solve(sp.Eq(sp.diff(PiI,a),0),a)[0])
phi =sp.cancel(sp.together(sp.diff(PiI,b2).subs(a,a_of)))

# --- 1. the cap region is {phi(r) >= 0} -------------------------------------
phir = sp.cancel(sp.together(phi.subs(b2, r)))
P("\n 1. phi is affine and strictly decreasing in b2, so b2* >= r iff phi(r) >= 0")
P("     phi affine in b2 :", ok(sp.simplify(sp.diff(phi, b2, 2)) == 0))
fphir = sp.lambdify((uB,uS,s,v,r), phir, 'numpy')
fb2s  = sp.lambdify((uB,uS,s,v,r), sp.cancel(sp.solve(sp.Eq(phi,0),b2)[0]), 'numpy')
GRID=np.arange(0.02,1.4001,0.02); bad=0; n=0
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for x1 in GRID:
        for x2 in GRID:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,G)
            if sg<0 or N2val(x1,x2,sg)>=0: continue
            n+=1
            if (fphir(x1,x2,sg,V,R)>=0) != (fb2s(x1,x2,sg,V,R)>=R): bad+=1
P("     {phi(r) >= 0} == {b2* >= r} on %d points : %s" % (n, ok(bad==0)))

# --- 2. in (sigma, u_S) coordinates ----------------------------------------
w = (g-s)/(2*(1+g))                       # u_B u_S on the sigma level set
X = sp.Symbol('X', positive=True)         # X = u_S^2
phir_X = sp.cancel(sp.together(phir.subs({uB: w/uS, uS: sp.sqrt(X)})))
num_phi = sp.expand(sp.numer(sp.cancel(phir_X)))
P("\n 2. phi(r) in (sigma, X = u_S^2) coordinates")
P("     degree in X of the numerator :", sp.Poly(num_phi, X).degree())
roots = sp.solve(sp.Eq(num_phi, 0), X)
P("     number of roots :", len(roots))
Xcap = None
for z in roots:
    zz = sp.simplify(z)
    if zz.is_real is not False:
        Xcap = zz
P("     X_cap(sigma) =", sp.simplify(Xcap))

# the paper's closed form, equation (B.16)
Xpap = (g + s + sp.Rational(8,3) + 8*s/(9*s**2+33*s+36))/(2*(g+1))
P("     matches the OA's (B.16) :",
  ok(sp.simplify(sp.factor(Xcap - Xpap)) == 0))

# --- 3. the containment inequality ------------------------------------------
for name, Rx in (("R_Phi", Lam/(3*s+4)), ("R_delta", Lam/(2*(3*s+4)))):
    target = sp.cancel(sp.together(Xpap - w/Rx))
    nt, dt = sp.fraction(target)
    P("\n 3. containment  <=>  X_cap(sigma) - w/%s(sigma) >= 0" % name)
    nt2 = sp.expand(sp.factor(sp.expand(nt)).subs(g, s+t))
    dt2 = sp.expand(sp.factor(sp.expand(dt)).subs(g, s+t))
    nt2 = sp.expand(sp.numer(sp.cancel(sp.together(nt2))))
    dt2 = sp.expand(sp.numer(sp.cancel(sp.together(dt2))))
    sn = set(sp.sign(c) for c in sp.Poly(nt2, s, t).coeffs())
    sd = set(sp.sign(c) for c in sp.Poly(dt2, s, t).coeffs())
    P("     after gamma = sigma + t (t >= 0):")
    P("       numerator   coefficient signs :", sn)
    P("       denominator coefficient signs :", sd)
    P("     => X_cap - w/%s > 0 on 0 <= sigma <= gamma :" % name,
      ok(sn == {1} and sd == {1}))
    P("\n     numerator   =", sp.factor(nt2))
    P("     denominator =", sp.factor(dt2))
