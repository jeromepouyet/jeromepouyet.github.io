# -*- coding: utf-8 -*-
"""rep34_coordination.py -- the separation benchmark under a
coordination motive (Online Appendix B.6), corrected for the adoption
constraint, and the merger's increments against it.

Under a coordination motive alpha_B every buyer enjoys an extra gross benefit
when both manufacturers run the platform's system.  Under separation the
independent platform can price this premium, but only with packages under
which joint adoption is a Nash equilibrium of the adoption game AND is the
equilibrium the selection rule retains.  Two constraints follow, and the
earlier text of B.6 kept only the second:

  (NE)   a unilateral walker loses the premium but keeps the whole per-user
         benefit r; joint adoption is an equilibrium iff
             beta >= beta_NE = 1 - 2(4+3s) alpha_B / (Lambda r),
         a floor independent of the fee (fee incidence is the same for the
         hosted and the walking manufacturer);
  (SEL)  joint refusal is an equilibrium at every capped package; the rule
         retains adoption iff joint profit under adoption is at least the
         joint profit under refusal, i.e. iff
             beta r >= r - alpha_B + u_B max(a, 0)
         (the compensated locus of the earlier text, for a > 0).

Since beta_NE r >= r - alpha_B, (NE) binds for fees up to the crossing
u_B a_x = alpha_B s(2+s)/Lambda and (SEL) beyond.  The benchmark maximizes the
platform's quadratic profit on the convex polygon the two floors and the cap
beta <= 1 delimit; the maximum is found exactly from the interior stationary
point, the edge stationary points and the vertices.

Blocks: (A) symbolic verification of the constraints and closed forms;
(B) the corrected benchmark on the reference grid, its regimes, and a
brute-force check against the enumerated adoption game at reference points;
(C) the merger's increments, against the undistorted benchmark (as Figure
OA-10 draws them) and against the corrected one; (D) the polar cases.
Porting costs are the same problem with (v, alpha_B) -> (v - u_B c, u_B c),
verified in block (A).
"""
import os, sys
import numpy as np
import sympy as sp
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_sep,
                      prices_int, surpluses, N2val)
from rep4_efficiency import beta_tilde
from rep4_figures import _optimum

V, R = V_DEF, R_DEF
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
ALPHAS = (0.2, 0.4)
GRID = np.arange(0.02, 1.4001, 0.02)          # reference grid
ok = lambda c: "PASS" if c else "**FAIL**"

def Lam(s): return 8 + s*(8 + s)

def beta_NE(sig, aB, r=R):
    """Share below which a unilateral walker is better off (joint adoption is
    not a Nash equilibrium of the adoption game)."""
    return 1.0 - 2*(4+3*sig)*aB/(Lam(sig)*r)

# =========================================================================== A
def symbolic():
    uB, uS, v, r, g, aB, c = sp.symbols('u_B u_S v r gamma alpha_B c', positive=True)
    a, beta, S = sp.Symbol('a'), sp.Symbol('beta'), sp.Symbol('sigma', positive=True)
    p1, p2 = sp.symbols('p1 p2')
    M = 1 - 2*uB*uS
    L = 8 + S*(8+S); den = (4+S)*(4+3*S)

    def sep(Vint, b1, b2, a_):
        """Both manufacturers standalone: markups (m1, m2), demands, stock."""
        D1 = (2*Vint-(2+S)*p1+S*p2-2*uB*a_)/(2*M)
        D2 = (2*Vint-(2+S)*p2+S*p1-2*uB*a_)/(2*M)
        DS = (uS*(2*Vint-p1-p2)-a_)/M
        sol = sp.solve([sp.diff((p1+b1)*D1,p1), sp.diff((p2+b2)*D2,p2)], [p1,p2], dict=True)[0]
        return (sp.simplify(sol[p1]+b1), sp.simplify(sol[p2]+b2),
                sp.simplify(D1.subs(sol)), sp.simplify(D2.subs(sol)), sp.simplify(DS.subs(sol)))

    print("A. Symbolic verification (coordination motive alpha_B)\n")
    mAA = sep(v+aB, beta*r, beta*r, a)          # both hosted, premium active
    mAR = sep(v,    beta*r, r,      a)          # M1 hosted, M2 walks: no premium, fee active
    mRR = sep(v,    r,      r,      0)          # joint refusal, fee dead (a >= 0)
    mRRs= sep(v,    r,      r,      a)          # joint refusal with a subsidy collected (a < 0)

    # 1. the walker's markup and the NE floor
    mw = (2*(4+3*S)*(v-uB*a) + L*r - S*(2+S)*beta*r)/den
    print(" 1. walker's markup m_w = [2(4+3s)(v-u_B a) + Lambda r - s(2+s) beta r]/den :",
          ok(sp.simplify(mAR[1]-mw) == 0))
    diff = sp.simplify(mAA[1] - mAR[1])
    print("    m_AA - m_w = [2(4+3s) alpha_B - Lambda r (1-beta)]/den, free of a      :",
          ok(sp.simplify(diff - (2*(4+3*S)*aB - L*r*(1-beta))/den) == 0
             and sp.diff(diff, a) == 0))
    bNE = sp.solve(sp.Eq(diff, 0), beta)[0]
    print("    beta_NE = 1 - 2(4+3s) alpha_B/(Lambda r)                              :",
          ok(sp.simplify(bNE - (1 - 2*(4+3*S)*aB/(L*r))) == 0))
    # 2. joint refusal is a Nash equilibrium at every capped package
    d_pos = sp.simplify(mAR[0] - mRR[0])        # lone adopter vs refusal, a >= 0
    d_neg = sp.simplify(mAR[0] - mRRs[0])       # same with the subsidy collected, a < 0
    print(" 2. lone adopter minus refusal: -[2(4+3s)u_B a + Lambda r(1-beta)]/den (a>=0):",
          ok(sp.simplify(d_pos + (2*(4+3*S)*uB*a + L*r*(1-beta))/den) == 0))
    print("    and -Lambda r(1-beta)/den when the subsidy is collected (a<0)          :",
          ok(sp.simplify(d_neg + L*r*(1-beta)/den) == 0))
    # 3. selection: joint profit under adoption vs refusal
    sel_pos = sp.solve(sp.Eq(mAA[0], mRR[0]), beta)[0]
    sel_neg = sp.solve(sp.Eq(mAA[0], mRRs[0]), beta)[0]
    print(" 3. selection floor: beta r = r - alpha_B + u_B a (a>=0), r - alpha_B (a<0)  :",
          ok(sp.simplify(sel_pos*r - (r-aB+uB*a)) == 0 and sp.simplify(sel_neg*r - (r-aB)) == 0))
    # 4. the NE floor is the higher one at a <= a_x
    print(" 4. beta_NE r - (r - alpha_B) = alpha_B s(2+s)/Lambda >= 0                   :",
          ok(sp.simplify(bNE*r - (r-aB) - aB*S*(2+S)/L) == 0))
    ax = sp.solve(sp.Eq(bNE*r, r-aB+uB*a), a)[0]
    print("    crossing u_B a_x = alpha_B s(2+s)/Lambda                              :",
          ok(sp.simplify(ax*uB - aB*S*(2+S)/L) == 0))
    # 5. at the compensated package with a = 0 the walker beats the hosted markup
    gap = sp.simplify((mAR[1]-mAA[1]).subs(a, 0).subs(beta, (r-aB)/r))
    print(" 5. at (beta r = r - alpha_B, a = 0): m_w - m_AA = alpha_B s(2+s)/den       :",
          ok(sp.simplify(gap - aB*S*(2+S)/den) == 0))
    # 6. platform profit and the two branches
    D = mAA[2]; q = mAA[4]
    Pi = 2*(1-beta)*r*D + a*q
    Pi1 = Pi.subs(beta, bNE)                      # branch 1: beta = beta_NE
    a1 = sp.solve(sp.diff(Pi1, a), a)[0]
    dNE = 2*(4+3*S)*aB/L                          # (1 - beta_NE) r
    a1p = (2+S)*(uS*(v+aB+r) - dNE*(uB+uS))/(S+4-4*uB*uS)
    print(" 6. branch 1 (beta = beta_NE): concave in a, maximizer                       :",
          ok(sp.simplify(sp.diff(Pi1, a, 2) + 2*(S+4-4*uB*uS)/((S+4)*M)) == 0
             and sp.simplify(a1 - a1p) == 0))
    Pi2 = Pi.subs(beta, (r-aB+uB*a)/r)            # branch 2: the compensated locus
    a2 = sp.solve(sp.diff(Pi2, a), a)[0]
    a2p = (uS-uB)*(v+r)*(2+S)/((1-2*uB*uS)*(4+S))
    print("    branch 2 (locus): demand constant, maximizer a_comp of (asep) with v+r  :",
          ok(sp.diff(sp.simplify(D.subs(beta, (r-aB+uB*a)/r)), a) == 0
             and sp.simplify(a2 - a2p) == 0))
    # 7. subsidy at the benchmark: dPi_1/da at 0
    d0 = sp.simplify(sp.diff(Pi1, a).subs(a, 0))
    thr = (v+r+aB)*L/(2*(4+3*S)*aB) - 1
    print(" 7. dPi_1/da(0) < 0  iff  u_B/u_S > (v+r+alpha_B)Lambda/(2(4+3s)alpha_B) - 1 :",
          ok(sp.simplify(d0*(S+4)*M/(2*(2+S)) - (uS*(v+aB+r-dNE) - uB*dNE)) == 0
             and sp.simplify((uS*(v+aB+r-dNE) - uB*dNE) - dNE*(uS*thr - uB)) == 0))
    # 8. the integrated floor is lower: the merger extracts more from the rival
    bt = 1 - (aB/r)*(4+3*S)/(4*(1+S))
    print(" 8. beta_NE - beta_tilde = alpha_B (4+3s) s^2/(4(1+s) Lambda r) >= 0         :",
          ok(sp.simplify(bNE - bt - aB*(4+3*S)*S**2/(4*(1+S)*L*r)) == 0))
    # 9. the a-tilde = 0 frontier of the integrated policy at beta = beta_tilde
    P1, P2 = sp.symbols('P1 P2')
    Vi = v + aB; b2 = bt*r
    D1i = (2*Vi-(2+S)*P1+S*P2-2*uB*a)/(2*M); D2i = (2*Vi-(2+S)*P2+S*P1-2*uB*a)/(2*M)
    DSi = (uS*(2*Vi-P1-P2)-a)/M
    obj = (P1+r)*D1i + a*DSi + (r-b2)*D2i
    soli = sp.solve([sp.diff(obj,P1), sp.diff((P2+b2)*D2i,P2)], [P1,P2], dict=True)[0]
    PiI = sp.simplify(obj.subs(soli))
    at = sp.solve(sp.diff(PiI, a), a)[0]
    x = sp.Symbol('x', positive=True)
    num = sp.numer(sp.together(sp.simplify(at.subs(uB, (g-S)/(2*(1+g)*uS)))))
    P = sp.Poly(sp.expand(num), uS)
    low = min(mon[0] for mon in P.monoms())
    num = sp.expand(sp.cancel(num / uS**low)).subs(uS**2, x)
    root = sp.solve(sp.Eq(num, 0), x)
    xt = ((g-S)*(3*S+4)*(8*(r+v)*(2+S) + aB*(3*S**2+20*S+32))
          / (2*(g+1)*(4*(r+v)*(3*S**3+21*S**2+48*S+32) + aB*(3*S**3+32*S**2+96*S+64))))
    xt_old = ((g-S)*(4+3*S)*(8*(r+v)*(2+S) + aB*(4+S)*(8+3*S))
              / (2*(1+g)*(8*(r+v)*(32+3*S*(16+S*(7+S))) + aB*(4+S)*(16+S*(20+3*S)))))
    print(" 9. a-tilde = 0 frontier: x = x_cm(s) with 4(r+v) in the denominator         :",
          ok(len(root) == 1 and sp.simplify(root[0] - xt) == 0))
    print("    the earlier text's formula (8(r+v)) is not the root                      :",
          ok(sp.simplify(root[0] - xt_old) != 0))
    # sign check: a-tilde changes sign from - to + across x_cm (sampled parameters)
    at_x = at.subs(uB, (g-S)/(2*(1+g)*uS))
    signs = []
    for gg in (sp.Rational(1,2), 1, 4, 16):
        for ab in (sp.Rational(1,5), sp.Rational(2,5)):
            for ss in (sp.Rational(1,100), gg/2, gg*sp.Rational(9,10)):
                sub = {g: gg, S: ss, v: 2, r: sp.Rational(1,2), aB: ab}
                x0 = xt.subs(sub)
                lo = at_x.subs(sub).subs(uS, sp.sqrt(x0*sp.Rational(99,100)))
                hi = at_x.subs(sub).subs(uS, sp.sqrt(x0*sp.Rational(101,100)))
                signs.append(lo < 0 and hi > 0)
    print("    positive fee iff x >= x_cm (numerator linear in x; sign sampled)        :",
          ok(sp.Poly(num, x).degree() == 1 and all(signs)))
    # 10. porting costs: the same constraints with (v, alpha_B) -> (v - u_B c, u_B c)
    #     AA: one system, no porting cost, intercept v.  AR and RR: two systems, the
    #     developer bears c once, which enters the developer's condition as a fee does.
    pAA = sep(v, beta*r, beta*r, a)
    pAR = sep(v, beta*r, r, a + c)               # fee a collected, cost c borne: a + c in demands
    pRR = sep(v, r, r, c)
    dP = sp.simplify(pAA[1] - pAR[1])
    print("10. porting: m_AA - m_w = [2(4+3s) u_B c - Lambda r(1-beta)]/den               :",
          ok(sp.simplify(dP - (2*(4+3*S)*uB*c - L*r*(1-beta))/den) == 0))
    selP = sp.solve(sp.Eq(pAA[0], pRR[0]), beta)[0]
    print("    selection floor beta r = r - u_B c + u_B a                                :",
          ok(sp.simplify(selP*r - (r - uB*c + uB*a)) == 0))

# =========================================================================== B
def sym_state(uB, uS, g, Vint, b, a):
    """Symmetric standalone configuration at intercept Vint, benefit b, fee a."""
    sig = sigma_of(uB, uS, g)
    p1, p2 = prices_sep(uB, uS, sig, b, b, a, v=Vint)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a, v=Vint)
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q, v=Vint)
    return dict(p=p1, D=D1, q=q, pi=(p1+b)*D1, VB=VB, VS=VS)

def platform_profit(uB, uS, g, aB, beta, a):
    s = sym_state(uB, uS, g, V+aB, beta*R, a)
    return 2*(1-beta)*R*s['D'] + a*s['q'], s

def bench_cm(uB, uS, g, aB, v=V, r=R):
    """Corrected separation benchmark: maximize the platform's quadratic profit
    over beta in [beta_NE, 1] and beta r >= r - alpha_B + u_B max(a, 0).
    Exact for a quadratic on a convex polygon: interior stationary point, edge
    stationary points and vertices.  Returns a dict with the package, the
    regime and the state."""
    sig = sigma_of(uB, uS, g)
    bNE = beta_NE(sig, aB, r)
    ax = aB*sig*(2+sig)/(Lam(sig)*uB)             # crossing of the two floors
    acap = aB/uB                                  # locus reaches beta = 1
    f = lambda b, a: platform_profit(uB, uS, g, aB, b, a)[0]
    # quadratic coefficients from six evaluations
    pts = [(0.,0.),(1.,0.),(0.,1.),(1.,1.),(.5,0.),(0.,.5)]
    A = np.array([[1,p,q,p*p,p*q,q*q] for (p,q) in pts], float)
    c = np.linalg.solve(A, np.array([f(p,q) for (p,q) in pts]))
    Hs = np.array([[2*c[3], c[4]],[c[4], 2*c[5]]])
    feas = lambda b, a: (b >= bNE-1e-12 and b <= 1+1e-12
                         and b*r >= r - aB + uB*max(a,0.) - 1e-12)
    cands = []
    if np.all(np.linalg.eigvalsh(Hs) < 0):
        cands.append(('interior', tuple(np.linalg.solve(Hs, -np.array([c[1], c[2]])))))
    for name, bf in (('floor_NE', bNE), ('cap', 1.0)):       # edges beta = const
        cands.append((name, (bf, -(c[2]+c[4]*bf)/(2*c[5]))))
    # edge along the locus: beta = (r - aB + uB a)/r, a in [ax, acap]
    k0, k1 = (r-aB)/r, uB/r
    # f(k0 + k1 a, a) = quadratic in a
    qa = c[3]*k1*k1 + c[4]*k1 + c[5]
    qb = c[1]*k1 + c[2] + 2*c[3]*k0*k1 + c[4]*k0
    if qa < 0: cands.append(('locus', (k0 + k1*(-qb/(2*qa)), -qb/(2*qa))))
    cands += [('vertex_x', (bNE, ax)), ('vertex_cap', (1.0, acap))]
    best = None
    for name, (b, a) in cands:
        if not feas(b, a): continue
        b = min(max(b, bNE), 1.0)
        val, s = platform_profit(uB, uS, g, aB, b, a)
        if best is None or val > best['Pi'] + 1e-13:
            best = dict(Pi=val, beta=b, a=a, where=name, **s)
    if best is None: return None
    b, a = best['beta'], best['a']
    w = best['where']
    if w == 'floor_NE': reg = 'subsidy' if a < -1e-12 else 'tax_floor'   # NE floor binds alone
    elif w == 'vertex_x': reg = 'kink'          # both floors bind: a = a_x (a = 0 where sigma = 0)
    elif w == 'locus': reg = 'locus'            # selection floor binds alone
    elif w == 'interior': reg = 'interior'      # no constraint binds
    else: reg = 'cap'                           # beta = 1 (edge or vertex)
    best.update(regime=reg, bNE=bNE, ax=ax, acap=acap, sig=sig,
                pub=uS*2*best['D'] - a,           # publication slack on the platform's store
                concave=bool(np.all(np.linalg.eigvalsh(Hs) < 0)))
    return best

def undistorted(uB, uS, g, v=V, r=R):
    """Joint refusal at intercept v, fee dead: the benchmark of Proposition 1."""
    s = sym_state(uB, uS, g, v, r, 0.0)
    return dict(pi=s['pi'], VB=s['VB'], VS=s['VS'], W=2*s['pi']+s['VB']+s['VS'],
                D=s['D'], q=s['q'], p=s['p'])

# --- brute force: the enumerated adoption game
def game_cm(uB, uS, g, beta, a, aB, v=V, r=R):
    """2x2 adoption game at the symmetric capped package (beta, a) under a
    coordination motive: AA has intercept v + alpha_B, the others v; the fee is
    active whenever a device runs the platform's system, and a subsidy is
    collected under joint refusal as well.  Ties in acceptance go to
    acceptance, ties in selection to adoption.  Returns (platform value,
    selected configuration) or None if some configuration is not interior."""
    sig = sigma_of(uB, uS, g)
    def cfg(Vint, b1, b2, a_):
        p1, p2 = prices_sep(uB, uS, sig, b1, b2, a_, v=Vint)
        D1, D2, q = demands(uB, uS, sig, p1, p2, a_, v=Vint)
        return dict(D1=D1, D2=D2, q=q, pi1=(p1+b1)*D1, pi2=(p2+b2)*D2)
    ae = a if a < 0 else 0.0
    C = {'AA': cfg(v+aB, beta*r, beta*r, a), 'AR': cfg(v, beta*r, r, a),
         'RA': cfg(v, r, beta*r, a),         'RR': cfg(v, r, r, ae)}
    for k in C:
        if min(C[k]['D1'], C[k]['D2'], C[k]['q']) <= 0: return None
    pay = {k: (C[k]['pi1'], C[k]['pi2']) for k in C}
    t, NE = 1e-12, []
    for prof, alt1, alt2 in [('AA','RA','AR'), ('AR','RR','AA'),
                             ('RA','AA','RR'), ('RR','AR','RA')]:
        d1 = pay[alt1][0] - pay[prof][0]; d2 = pay[alt2][1] - pay[prof][1]
        ok1 = d1 < -t or (abs(d1) <= t and prof[0] == 'A')
        ok2 = d2 < -t or (abs(d2) <= t and prof[1] == 'A')
        if ok1 and ok2: NE.append(prof)
    if not NE: return None
    sel = max(NE, key=lambda k: pay[k][0] + pay[k][1])
    c = C[sel]
    val = {'AA': 2*(1-beta)*r*c['D1'] + a*c['q'],
           'AR': (1-beta)*r*c['D1'] + a*c['q'],
           'RA': (1-beta)*r*c['D2'] + a*c['q'],
           'RR': ae*c['q']}[sel]
    return val, sel

def brute(uB, uS, g, aB, nb=401, na=801, amin=-2.0, amax=3.0):
    best = (-np.inf, None)
    for b in np.linspace(0.0, 1.0, nb):
        for a in np.linspace(amin, amax, na):
            out = game_cm(uB, uS, g, b, a, aB)
            if out and out[0] > best[0]: best = (out[0], (b, a, out[1]))
    return best

def block_B():
    print("\nB. The corrected benchmark on the reference grid\n")
    print("   %-6s %-5s %6s | %-52s | %-12s %-9s %-10s" %
          ("gamma", "aB", "points", "regime: subsidy / tax_floor / kink / locus / interior / cap",
           "Pi>0", "pub ok", "concave"))
    res = {}
    for aB in ALPHAS:
        for g in GAMMAS:
            cnt = dict(subsidy=0, tax_floor=0, kink=0, locus=0, interior=0, cap=0)
            tot = pos = pub = conc = 0; where = {}
            for uB in GRID:
                for uS in GRID:
                    if Mof(uB, uS) <= 0: continue
                    sig = sigma_of(uB, uS, g)
                    if sig < 0 or N2val(uB, uS, sig) >= 0: continue
                    b = bench_cm(uB, uS, g, aB)
                    if b is None: continue
                    tot += 1; cnt[b['regime']] += 1
                    pos += b['Pi'] > 0; pub += b['pub'] >= 0; conc += b['concave']
                    where[b['where']] = where.get(b['where'], 0) + 1
                    res[(aB, g, round(uB,2), round(uS,2))] = b
            print("   %-6g %-5g %6d | %5d / %5d / %5d / %5d / %5d / %5d | %5d/%-5d %5d/%-5d %5d"
                  % (g, aB, tot, cnt['subsidy'], cnt['tax_floor'], cnt['kink'], cnt['locus'],
                     cnt['interior'], cnt['cap'], pos, tot, pub, tot, conc))
    # subsidy region: where is it
    for aB in ALPHAS:
        pts = [(k[2], k[3], k[1]) for k, b in res.items() if k[0] == aB and b['regime'] == 'subsidy']
        if pts:
            ratios = [x/y for x, y, _ in pts]
            print("   alpha_B = %g: %d subsidizing points, u_B/u_S in [%.1f, %.1f], u_S <= %.2f, u_B >= %.2f"
                  % (aB, len(pts), min(ratios), max(ratios), max(y for _, y, _ in pts),
                     min(x for x, _, _ in pts)))
    return res

def block_B_brute():
    print("\n   Brute-force check: enumerated adoption game vs the analytic optimum")
    print("   %-5s %-6s %-5s %-5s | %-9s %-9s %-9s | %-9s %-9s %-9s %s" %
          ("gamma", "aB", "u_B", "u_S", "Pi*", "beta*", "a*", "Pi_bf", "beta_bf", "a_bf", "sel"))
    worst = 0.0
    for g, uB, uS in [(0.5, 0.3, 0.3), (1.0, 0.8, 0.2), (2.0, 0.2, 0.8), (4.0, 0.5, 0.5),
                      (4.0, 1.2, 0.1), (4.0, 0.1, 1.2), (8.0, 0.9, 0.4), (16.0, 0.4, 0.9),
                      (16.0, 1.4, 0.1)]:
        for aB in ALPHAS:
            b = bench_cm(uB, uS, g, aB)
            if b is None: continue
            bf = brute(uB, uS, g, aB, nb=201, na=501)
            gap = bf[0] - b['Pi']
            worst = max(worst, gap)
            print("   %-5g %-6g %-5.2f %-5.2f | %-9.5f %-9.5f %-+9.4f | %-9.5f %-9.5f %-+9.4f %s"
                  % (g, aB, uB, uS, b['Pi'], b['beta'], b['a'], bf[0], bf[1][0], bf[1][1], bf[1][2]))
    print("   largest excess of the brute-force value over the analytic optimum: %.2e" % worst,
          "(grid resolution effects only)" if worst < 1e-3 else "**CHECK**")
    # asymmetric packages at three points
    print("\n   Asymmetric packages (beta^1, beta^2, a), coarse sweep, three points at gamma = 4")
    for uB, uS in [(0.5, 0.5), (1.2, 0.1), (0.1, 1.2)]:
        for aB in ALPHAS:
            b = bench_cm(uB, uS, 4.0, aB)
            best = (-np.inf, None)
            for b1 in np.linspace(0.0, 1.0, 51):
                for b2 in np.linspace(0.0, 1.0, 51):
                    for a in np.linspace(-1.0, 3.0, 81):
                        out = game_cm_asym(uB, uS, 4.0, b1, b2, a, aB)
                        if out and out[0] > best[0]: best = (out[0], (b1, b2, a, out[1]))
            print("   (%.1f, %.1f) aB = %g: symmetric optimum %.5f, best asymmetric on the sweep %.5f at %s"
                  % (uB, uS, aB, b['Pi'], best[0], tuple(round(z, 3) if isinstance(z, float) else z for z in best[1])))

def game_cm_asym(uB, uS, g, b1_, b2_, a, aB, v=V, r=R):
    sig = sigma_of(uB, uS, g)
    def cfg(Vint, b1, b2, a_):
        p1, p2 = prices_sep(uB, uS, sig, b1, b2, a_, v=Vint)
        D1, D2, q = demands(uB, uS, sig, p1, p2, a_, v=Vint)
        return dict(D1=D1, D2=D2, q=q, pi1=(p1+b1)*D1, pi2=(p2+b2)*D2)
    ae = a if a < 0 else 0.0
    C = {'AA': cfg(v+aB, b1_*r, b2_*r, a), 'AR': cfg(v, b1_*r, r, a),
         'RA': cfg(v, r, b2_*r, a),         'RR': cfg(v, r, r, ae)}
    for k in C:
        if min(C[k]['D1'], C[k]['D2'], C[k]['q']) <= 0: return None
    pay = {k: (C[k]['pi1'], C[k]['pi2']) for k in C}
    t, NE = 1e-12, []
    for prof, alt1, alt2 in [('AA','RA','AR'), ('AR','RR','AA'),
                             ('RA','AA','RR'), ('RR','AR','RA')]:
        d1 = pay[alt1][0] - pay[prof][0]; d2 = pay[alt2][1] - pay[prof][1]
        ok1 = d1 < -t or (abs(d1) <= t and prof[0] == 'A')
        ok2 = d2 < -t or (abs(d2) <= t and prof[1] == 'A')
        if ok1 and ok2: NE.append(prof)
    if not NE: return None
    sel = max(NE, key=lambda k: pay[k][0] + pay[k][1])
    c = C[sel]
    val = {'AA': (1-b1_)*r*c['D1'] + (1-b2_)*r*c['D2'] + a*c['q'],
           'AR': (1-b1_)*r*c['D1'] + a*c['q'],
           'RA': (1-b2_)*r*c['D2'] + a*c['q'],
           'RR': ae*c['q']}[sel]
    return val, sel

# =========================================================================== C
def integrated_cm(uB, uS, g, aB):
    sig = sigma_of(uB, uS, g)
    fl = max(0.0, beta_tilde(sig, aB, R))
    e = _optimum(uB, uS, g, R, fl, V + aB)
    if e is None: return None
    vv, b2, a, p1, p2, D1, D2, q = e
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q, v=V+aB)
    pi2 = (p2 + b2*R)*D2
    if b2 <= fl + 1e-9: reg = 'floor'
    elif b2 >= 1 - 1e-9: reg = 'cap'
    else: reg = 'interior'
    return dict(PiI=vv, beta=b2, a=a, pi2=pi2, VB=VB, VS=VS, W=vv+pi2+VB+VS,
                q=q, D1=D1, D2=D2, regime=reg, floor=fl, pub=uS*(D1+D2)-a)

def block_C(res):
    print("\nC. The merger's increments: undistorted benchmark (as Figure OA-10) and corrected benchmark\n")
    print("   %-6s %-4s %6s | %-33s | %-33s | %-27s" %
          ("gamma", "aB", "points", "vs undistorted: dpi2<0 dVB<0 dVS<0 dW<0",
           "vs corrected:   dpi2<0 dVB<0 dVS<0 dW<0", "integrated regime floor/int/cap, a**<0"))
    summary = {}
    for aB in ALPHAS:
        for g in GAMMAS:
            tot = 0; n0 = np.zeros(4, int); n1 = np.zeros(4, int); ir = dict(floor=0, interior=0, cap=0); neg = 0
            asep_gt = 0; bsep_gt = 0; sub_both = 0; sub_sep_only = 0
            for k, b in res.items():
                if k[0] != aB or k[1] != g: continue
                uB, uS = k[2], k[3]
                e = integrated_cm(uB, uS, g, aB)
                if e is None: continue
                u = undistorted(uB, uS, g)
                tot += 1
                Wb = 2*b['pi'] + b['Pi'] + b['VB'] + b['VS']
                d0 = (e['pi2']-u['pi'], e['VB']-u['VB'], e['VS']-u['VS'], e['W']-u['W'])
                d1 = (e['pi2']-b['pi'], e['VB']-b['VB'], e['VS']-b['VS'], e['W']-Wb)
                n0 += np.array([x < 0 for x in d0]); n1 += np.array([x < 0 for x in d1])
                ir[e['regime']] += 1; neg += e['a'] < 0
                asep_gt += b['a'] > e['a'] + 1e-9
                sub_both += (b['a'] < 0 and e['a'] < 0); sub_sep_only += (b['a'] < 0 and e['a'] >= 0)
                b['int'] = e; b['d0'] = d0; b['d1'] = d1; b['Wb'] = Wb
            pc = lambda n: "%3.0f%%" % (100.0*n/tot)
            print("   %-6g %-4g %6d | %s %s %s %s              | %s %s %s %s              | %4d/%4d/%4d, %4d"
                  % (g, aB, tot, *[pc(x) for x in n0], *[pc(x) for x in n1],
                     ir['floor'], ir['interior'], ir['cap'], neg))
            summary[(aB, g)] = dict(tot=tot, n0=n0.copy(), n1=n1.copy(), ir=ir, neg=neg,
                                    asep_gt=asep_gt, sub_both=sub_both, sub_sep_only=sub_sep_only)
    print("\n   Fees: points where the benchmark fee exceeds the integrated fee (a_sep > a**), and subsidies")
    for (aB, g), s in summary.items():
        print("   gamma = %-4g aB = %g: a_sep > a** at %d of %d; both subsidize at %d, separation alone at %d"
              % (g, aB, s['asep_gt'], s['tot'], s['sub_both'], s['sub_sep_only']))
    # where does each sign fall, against the corrected benchmark, by benchmark regime
    print("\n   Against the corrected benchmark, by benchmark regime: share of points with each increment negative,")
    print("   share at which the benchmark fee exceeds the integrated fee, share at which the integrated firm is at its floor / cap")
    for aB in ALPHAS:
        for g in GAMMAS:
            by = {}
            for k, b in res.items():
                if k[0] != aB or k[1] != g or 'd1' not in b: continue
                r_ = by.setdefault(b['regime'], [0, np.zeros(4, int), 0, 0, 0])
                r_[0] += 1; r_[1] += np.array([x < 0 for x in b['d1']])
                r_[2] += b['a'] > b['int']['a'] + 1e-9
                r_[3] += b['int']['regime'] == 'floor'; r_[4] += b['int']['regime'] == 'cap'
            for reg in ('subsidy', 'tax_floor', 'kink', 'locus', 'interior', 'cap'):
                if reg not in by: continue
                n, neg, af, fl, cp = by[reg]
                print("   aB = %g gamma = %-4g %-9s %4d: dpi2<0 %3.0f%%  dVB<0 %3.0f%%  dVS<0 %3.0f%%  dW<0 %3.0f%% | a_sep>a** %3.0f%% | int. floor %3.0f%% cap %3.0f%%"
                      % (aB, g, reg, n, *[100.0*x/n for x in neg], 100.0*af/n, 100.0*fl/n, 100.0*cp/n))
    return summary

# =========================================================================== D
def block_D():
    print("\nD. Polar cases against the corrected benchmark (gamma = 4, alpha_B = 0.2)\n")
    g, aB = 4.0, 0.2
    print("   u_S -> 0 (u_S = 0.02): benchmark package, integrated package, increments")
    print("   %-5s | %-8s %-8s %-8s | %-8s %-8s | %-+9s %-+9s %-+9s %-+9s" %
          ("u_B", "beta_sep", "a_sep", "Pi_sep", "beta**", "a**", "dpi2", "dVB", "dVS", "dW"))
    for uB in (0.05, 0.2, 0.5, 0.8, 1.2):
        uS = 0.02
        b = bench_cm(uB, uS, g, aB); e = integrated_cm(uB, uS, g, aB)
        if b is None or e is None: print("   %.2f: none" % uB); continue
        Wb = 2*b['pi'] + b['Pi'] + b['VB'] + b['VS']
        print("   %-5.2f | %-8.4f %-+8.4f %-8.4f | %-8.4f %-+8.4f | %-+9.5f %-+9.5f %-+9.5f %-+9.5f"
              % (uB, b['beta'], b['a'], b['Pi'], e['beta'], e['a'],
                 e['pi2']-b['pi'], e['VB']-b['VB'], e['VS']-b['VS'], e['W']-Wb))
    print("\n   u_B -> 0 (u_B = 0.02)")
    for uS in (0.05, 0.2, 0.5, 0.8, 1.2):
        uB = 0.02
        b = bench_cm(uB, uS, g, aB); e = integrated_cm(uB, uS, g, aB)
        if b is None or e is None: print("   %.2f: none" % uS); continue
        Wb = 2*b['pi'] + b['Pi'] + b['VB'] + b['VS']
        print("   u_S = %-4.2f | %-8.4f %-+8.4f %-8.4f | %-8.4f %-+8.4f | %-+9.5f %-+9.5f %-+9.5f %-+9.5f"
              % (uS, b['beta'], b['a'], b['Pi'], e['beta'], e['a'],
                 e['pi2']-b['pi'], e['VB']-b['VB'], e['VS']-b['VS'], e['W']-Wb))

def block_E(res):
    print("\nE. The private gain from integration against the corrected benchmark, and the polar slices\n")
    for aB in ALPHAS:
        for g in GAMMAS:
            tot = neg = 0; gmin = np.inf
            for k, b in res.items():
                if k[0] != aB or k[1] != g or 'int' not in b: continue
                sep_state = sym_state(k[2], k[3], g, V+aB, b['beta']*R, b['a'])
                G = b['int']['PiI'] - (sep_state['pi'] + b['Pi'])   # merged profit minus (M1 + platform) under separation
                tot += 1; neg += G < 0; gmin = min(gmin, G)
            print("   gamma = %-4g aB = %g: G < 0 at %d of %d points (min G = %+.4f)" % (g, aB, neg, tot, gmin))
    print("\n   Polar slices at gamma = 4 (step 0.02 along the axis, the other coordinate at 0.02): sign counts")
    for aB in ALPHAS:
        for lab, pts in (("u_S = 0.02", [(x, 0.02) for x in GRID]), ("u_B = 0.02", [(0.02, y) for y in GRID])):
            n = np.zeros(4, int); tot = 0; first_pos = {}
            for (uB, uS) in pts:
                b = bench_cm(uB, uS, 4.0, aB); e = integrated_cm(uB, uS, 4.0, aB)
                if b is None or e is None: continue
                Wb = 2*b['pi'] + b['Pi'] + b['VB'] + b['VS']
                d = (e['pi2']-b['pi'], e['VB']-b['VB'], e['VS']-b['VS'], e['W']-Wb)
                tot += 1; n += np.array([x < 0 for x in d])
                for i, nm in enumerate(("dpi2", "dVB", "dVS", "dW")):
                    if d[i] > 0 and nm not in first_pos: first_pos[nm] = (uB if lab.startswith("u_S") else uS)
            print("   aB = %g, %s: %d points; negative counts dpi2 %d, dVB %d, dVS %d, dW %d; first positive at %s"
                  % (aB, lab, tot, *n, first_pos))

# =========================================================================== F
def figure_cm(path, pars=ALPHAS, g=4.0, HI=1.6, N=230):
    """Figure OA-10: the merger's effect on the rival's profit and on buyer
    surplus against the corrected benchmark, at gamma = 4 (an illustration;
    the shares the text quotes are six-gamma counts from block C)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2, 2, figsize=(8.4, 7.0))
    gr = np.linspace(1e-3, HI, N)
    for row, aB in enumerate(pars):
        Z = [np.full((N, N), np.nan) for _ in range(2)]
        for i, uS in enumerate(gr):
            for j, uB in enumerate(gr):
                if Mof(uB, uS) <= 0: continue
                sig = sigma_of(uB, uS, g)
                if sig < 0 or N2val(uB, uS, sig) >= 0: continue
                b = bench_cm(uB, uS, g, aB); e = integrated_cm(uB, uS, g, aB)
                if b is None or e is None: continue
                d = (e['pi2'] - b['pi'], e['VB'] - b['VB'])
                for k in (0, 1): Z[k][i, j] = 1.0 if d[k] > 0 else 0.0
        cmap = matplotlib.colors.ListedColormap(["#d62728", "#1f77b4"])
        for k, nm in enumerate([r"\Delta\pi_2", r"\Delta V_B"]):
            ax = axes[row][k]
            ax.imshow(Z[k], origin="lower", extent=[0, HI, 0, HI], aspect="auto",
                      cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
            xs = np.linspace(1e-3, HI, 600)
            ax.plot(xs, np.clip(g/(2*(1+g)*xs), 0, HI), color="k", lw=1.0)
            ax.set_xlim(0, HI); ax.set_ylim(0, HI)
            ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$")
            ax.set_title(r"$%s$, $\alpha_B = %g$" % (nm, aB), fontsize=10)
        print("  panel alpha_B = %g done" % aB, flush=True)
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

if __name__ == "__main__":
    print("rep34_coordination\n")
    symbolic()
    res = block_B()
    block_B_brute()
    block_C(res)
    block_D()
    block_E(res)
    if "--nofig" not in sys.argv:
        print("\nF. Figure OA-10 against the corrected benchmark (gamma = 4)")
        figure_cm(os.path.join(os.path.dirname(os.path.abspath(__file__)), "figB7-coordination.pdf"))
