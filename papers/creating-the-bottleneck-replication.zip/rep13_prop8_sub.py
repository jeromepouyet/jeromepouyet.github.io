# -*- coding: utf-8 -*-
"""rep13_prop8_sub.py -- the subsidizing halves of Proposition B.1(ii)-(iii) are
analytic on the complements range.

Proposition B.1's Status note filed parts (ii) and (iii) as computational.  On
a** < 0 they are identities, by the argument the proposition's own proof
imports from Proposition 5.  This script checks each step for sigma in (-1,0).
"""
import sympy as sp, numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

uB, uS, sg = sp.symbols('u_B u_S sigma', positive=True)
s = sp.symbols('s', positive=True)           # sigma = -s, s in (0,1)

Ra = (3*sg**3 + 21*sg**2 + 48*sg + 32)/(2*(sg+2)*(3*sg+4))
print("1. R_a - 1 =", sp.factor(sp.simplify(Ra - 1)))
q = 3*sg**2 + 12*sg + 16
print("   the quadratic 3s^2+12s+16 has discriminant", sp.discriminant(q, sg),
      "< 0, so it is positive everywhere")
print("   hence R_a > 1 on sigma > -1, and a** < 0 forces u_B > u_S : True")

# buyer factorization: the coefficient (sigma+2) u_B - u_S
cB = (sg+2)*uB - uS
print("\n2. buyer coefficient (sigma+2)u_B - u_S, at sigma = -s :",
      sp.expand(cB.subs(sg, -s)))
print("   = (2-s)u_B - u_S > u_B - u_S > 0 for s in (0,1) and u_B > u_S : True")

# developer factorization: the coefficient sigma + 4 - 2 u_S (2 u_B + u_S)
g = sp.symbols('gamma', positive=True)
cS = sg + 4 - 2*uS*(2*uB + uS)
cS_g = cS.subs(sg, g - 2*uB*uS*(1+g))
print("\n3. developer coefficient sigma + 4 - 2u_S(2u_B+u_S), in gamma :")
print("   =", sp.expand(cS_g))
print("   = gamma + 4 - 2 u_B u_S (gamma+3) - 2 u_S^2 :",
      sp.expand(cS_g - (g + 4 - 2*uB*uS*(g+3) - 2*uS**2)) == 0)
print("   with 2 u_B u_S < 1 and 2 u_S^2 < 2 u_B u_S < 1 (since u_S < u_B),")
print("   > gamma + 4 - (gamma+3) - 1 = 0.  No side condition, no restriction on sigma.")

# ---------------------------------------------------------- numerical control
print("\n" + "="*66)
print("Control on the complements grid (step 0.02 over [0.02,1.60], gamma = 4)")
print("="*66)
from rep_core import sigma_of, Mof, demands, prices_int, surpluses, V_DEF, R_DEF
from rep1_frontiers import a_star
V, R = V_DEF, R_DEF
gr = np.arange(0.02, 1.602, 0.02)
n = sub = okB = okS = 0
for u1 in gr:
    for u2 in gr:
        if Mof(u1, u2) <= 0: continue
        sig = sigma_of(u1, u2, 4.0)
        if not (-1 < sig < 0): continue
        a = a_star(u1, u2, sig)
        p1, p2 = prices_int(u1, u2, sig, R, a)
        D1, D2, q = demands(u1, u2, sig, p1, p2, a)
        if min(D1, D2, q) <= 0 or p1 + R <= 0 or p2 + R <= 0: continue
        n += 1
        if a >= 0: continue
        sub += 1
        VB1, VS1 = surpluses(u1, u2, 4.0, p1, p2, D1, D2, q)
        q1, q2 = prices_int(u1, u2, sig, R, 0.0)
        d1, d2, qq = demands(u1, u2, sig, q1, q2, 0.0)
        VB0, VS0 = surpluses(u1, u2, 4.0, q1, q2, d1, d2, qq)
        if VB1 > VB0: okB += 1
        if VS1 > VS0: okS += 1
print("  admissible complements points : %d" % n)
print("  of which subsidizing          : %d" % sub)
print("  buyers gain                   : %d of %d" % (okB, sub))
print("  developer gains               : %d of %d" % (okS, sub))
print("\nno exception: the subsidizing halves hold at every point, as the identities say.")
