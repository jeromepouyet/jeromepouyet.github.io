# -*- coding: utf-8 -*-
"""rep4_figures.py -- the efficiency-gains impact map (figB7-efficiency.pdf)
and the shares the text quotes from it, plus the coordination-motive shares
against the UNDISTORTED benchmark, which Online Appendix B.11 quotes for
comparison with the efficiency case.

Both are two-instrument problems, so the domain is {N_2 < 0, sigma >= 0}.  The
integrated firm chooses a share for the rival and a developer fee; the rival's
participation constraint binds from below at bar-beta(r_0) with an efficiency
gain and at beta-tilde(alpha_B) with a coordination motive.  The comparison
here is against the separation benchmark of Proposition 1 (both manufacturers
outside, fee dead, intercepts v).  Under a coordination motive that benchmark
is not the pre-merger outcome: the independent platform prices part of the
premium, and the paper's Figure OA-10 (figB7-coordination.pdf) is drawn
against the corrected benchmark by rep34_coordination.py, which imports
_optimum from this file.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_int,
                      prices_sep, surpluses, N2val)
from rep4_efficiency import beta_bar_r0, beta_tilde

V, R = V_DEF, R_DEF
HI, N = 1.6, 230

def _optimum(uB, uS, g, r_int, floor, v_int):
    """Two-instrument optimum: the integrated firm keeps benefit r_int, the rival
    is hosted at share beta2 >= floor, demand intercepts are v_int."""
    sig = sigma_of(uB, uS, g)
    def val(beta2, a):
        b2 = beta2*r_int
        p1, p2 = prices_int(uB, uS, sig, b2, a, r=r_int, v=v_int)
        D1, D2, q = demands(uB, uS, sig, p1, p2, a, v=v_int)
        return (p1+r_int)*D1 + a*q + (r_int-b2)*D2, p1, p2, D1, D2, q
    pts = [(0.,0.),(1.,0.),(0.,1.),(1.,1.),(.5,0.),(0.,.5)]
    A = np.array([[1,p,q,p*p,p*q,q*q] for (p,q) in pts], float)
    c = np.linalg.solve(A, np.array([val(p,q)[0] for (p,q) in pts]))
    Hs = np.array([[2*c[3], c[4]],[c[4], 2*c[5]]])
    cands = []
    if abs(np.linalg.det(Hs)) > 1e-14:
        cands.append(tuple(np.linalg.solve(Hs, -np.array([c[1], c[2]]))))
    for bf in (floor, 1.0):
        if abs(2*c[5]) > 1e-14: cands.append((bf, -(c[2]+c[4]*bf)/(2*c[5])))
    best = None
    for (b2, a) in cands:
        if b2 < floor - 1e-12 or b2 > 1 + 1e-12: continue
        b2 = min(max(b2, floor), 1.0)
        vv, p1, p2, D1, D2, q = val(b2, a)
        if min(D1, D2) <= 0 or q <= 0: continue
        if best is None or vv > best[0]: best = (vv, b2, a, p1, p2, D1, D2, q)
    return best

def benchmark(uB, uS, g):
    sig = sigma_of(uB, uS, g)
    p1, p2 = prices_sep(uB, uS, sig, R, R, 0.0)
    D1, D2, q = demands(uB, uS, sig, p1, p2, 0.0)
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
    return (p2+R)*D2, VB

def deltas(uB, uS, g, kind, par):
    """kind = 'eff' (efficiency gain Delta) or 'cm' (coordination premium)."""
    sig = sigma_of(uB, uS, g)
    if kind == "eff":
        r0 = R + par
        e = _optimum(uB, uS, g, r0, max(0.0, beta_bar_r0(sig, r0, R)), V)
        r_int = r0
    else:
        e = _optimum(uB, uS, g, R, max(0.0, beta_tilde(sig, par, R)), V + par)
        r_int = R
    if e is None: return None
    pi2b, VBb = benchmark(uB, uS, g)
    VB, _ = surpluses(uB, uS, g, e[3], e[4], e[5], e[6], e[7],
                      v=(V + par if kind == "cm" else V))
    return (e[4] + e[1]*r_int)*e[6] - pi2b, VB - VBb

def figure(kind, pars, path, g=4.0):
    lab = r"r_0 - r" if kind == "eff" else r"\alpha_B"
    fig, axes = plt.subplots(2, 2, figsize=(8.4, 7.0))
    gr = np.linspace(1e-3, HI, N)
    for row, par in enumerate(pars):
        Z = [np.full((N, N), np.nan) for _ in range(2)]
        for i, uS in enumerate(gr):
            for j, uB in enumerate(gr):
                if Mof(uB, uS) <= 0: continue
                sig = sigma_of(uB, uS, g)
                if sig < 0 or N2val(uB, uS, sig) >= 0: continue
                d = deltas(uB, uS, g, kind, par)
                if d is None: continue
                for k in (0, 1): Z[k][i, j] = 1.0 if d[k] > 0 else 0.0
        cmap = matplotlib.colors.ListedColormap(["#d62728", "#1f77b4"])
        for k, nm in enumerate([r"\Delta\pi_2", r"\Delta V_B"]):
            ax = axes[row][k]
            ax.imshow(Z[k], origin="lower", extent=[0, HI, 0, HI], aspect="auto",
                      cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
            xs = np.linspace(1e-3, HI, 600)
            ax.plot(xs, np.clip(g/(2*(1+g)*xs), 0, HI), color="k", lw=1.0)
            ax.set_xlim(0, HI); ax.set_ylim(0, HI)
            ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$")
            ax.set_title(r"$%s$, $%s = %g$" % (nm, lab, par), fontsize=10)
        print("  panel %s = %g done" % (lab, par), flush=True)
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

def shares(kind, pars, g=4.0):
    gr = np.arange(0.02, 1.402, 0.02)
    for par in pars:
        tot = n2 = nB = 0
        for uB in gr:
            for uS in gr:
                if Mof(uB, uS) <= 0: continue
                sig = sigma_of(uB, uS, g)
                if sig < 0 or N2val(uB, uS, sig) >= 0: continue
                d = deltas(uB, uS, g, kind, par)
                if d is None: continue
                tot += 1
                if d[0] < 0: n2 += 1
                if d[1] < 0: nB += 1
        print("   %s = %.1f : %d points, dpi2 < 0 at %.0f%%, dV_B < 0 at %.0f%%"
              % (kind, par, tot, 100*n2/tot, 100*nB/tot))

if __name__ == "__main__":
    print("shares on the reference grid (gamma = 4), against the undistorted benchmark")
    shares("eff", (0.3, 0.6)); shares("cm", (0.2, 0.4))
    figure("eff", (0.3, 0.6), "figB7-efficiency.pdf")
    # the coordination map of the paper is drawn against the corrected
    # benchmark by rep34_coordination.py; the undistorted version is kept
    # under another name for comparison
    figure("cm",  (0.2, 0.4), "figB7-coordination-undistorted.pdf")
