# -*- coding: utf-8 -*-
"""rep33_bothhost_grid.py -- packages hosting both manufacturers never beat the
single-host package where u_B >= u_S: the grid finding behind Proposition 6,
at the six gamma of the reference calibration.

Proposition 6 (Section 4, Appendix A.3) is analytic for single-host packages,
capped packages and subsidies.  For packages hosting both manufacturers
Lemma B.1 places the interior optimum of the both-host program (it calls for
a subsidy wherever u_S < u_B), but that does not exclude the family: packages
with beta^k > 1 and a > 0 exist at which mutual acceptance is a Nash
equilibrium of the adoption game with positive platform profit.  What excludes
them is the selection rule, joint refusal being an equilibrium too and the
one the manufacturers rank first.  The set of packages the rule selects is
not convex, so concavity does not bound the platform's profit on it, and we
have no analytic argument.  This script does the exclusion on the grid.

Protocol.  At every point of A* with u_B >= u_S (sigma >= 0 as in Assumption
1; the region of Proposition 6(i) lies inside it, since u_B / u_S >= R_Phi >= 2
there), at the six gamma of the reference calibration,
v = 2, r = 1/2, on the reference grid (step 0.02 on [0.02, 1.40]^2), we sweep
packages (beta^1, beta^2, a) with

    a      in [0.01, 4]                (40 values)
    beta^1 in [1, bar-beta(a) + 2]     (20 values)
    beta^2 in [1, beta^1]              ( 8 values),

the two manufacturers being relabeled so that beta^2 <= beta^1.  At each
package the pure Nash equilibria of the adoption game are found from the
closed-form configuration values, with the conventions of the paper: an
indifferent manufacturer accepts, and among equilibria the one maximizing the
manufacturers' joint profit is played, ties going to adoption (Section 2.3).
With beta^k >= 1 mutual acceptance is always an equilibrium (a manufacturer
hosted at a share of one is outcome-equivalent to one that walked, and its
hosted markup rises in its own share, equation (m2-monotone) of Appendix
A.3); joint refusal is one iff a lone adopter of the larger share does not
beat the benchmark.  Packages at which the mutually-accepted configuration is
not interior are discarded.

The value of the best selected both-host package is compared with the
single-host value max{Phi(a-hat), 0}.  The claim verified is that the former
never exceeds the latter; in the region of Proposition 6(i) the single-host
value is zero, so the claim there is that no selected both-host package earns
anything.  A cross-check on a random sample of packages confirms that the
inline adoption-game solver agrees with rep3_contracts.game().

The bounds of the sweep are certified.  The platform's profit at a both-host
package, Pi(beta^1, beta^2, a) = sum_k (1 - beta^k) r D_k + a q_S at the
pricing equilibrium, is a quadratic, concave on A* (Corollary A.1: Delta > 0
is its second-order condition).  Outside the swept wedge W = {0 <= a <= 4,
1 <= beta^2 <= beta^1 <= bar-beta(a) + 2} (up to relabeling), every package
with shares at or above one lies in one of two convex polyhedra, O1 = {a >= 4,
beta^k >= 1} and O2 = {0 <= a <= 4, beta^1 >= bar-beta(a) + 2, beta^2 >= 1};
the exact maximum of the concave quadratic on each (active-set enumeration)
is computed at every grid point and compared with the single-host value.
Where both maxima fall short, no package outside W, selected or not, can beat
the single-host package, and only the interior of W rests on the grid.
Packages with a share below one reduce to capped or single-host packages,
which Appendix A.3 treats analytically, and so do subsidies.

Run: python3 rep33_bothhost_grid.py       (about five minutes)
"""
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (V_DEF, R_DEF, sigma_of, admissible, demands,
                      prices_sep)
from rep3_contracts import bbar, Phi_prime0, Phi, a_hat, game

V, R = V_DEF, R_DEF
GRID = np.arange(0.02, 1.4001, 0.02)
A_MAX = 4.0
A_VALUES = np.linspace(0.01, A_MAX, 40)
N_B1, N_B2 = 20, 8
TOL = 1e-9


# ------------------------------------------------ the certificate of the bounds
def _pi_quadratic(uB, uS, sig, r=R):
    """Coefficients (c0, g, Q) of the both-host platform profit as a quadratic
    in x = (beta^1, beta^2, a): Pi = c0 + g.x + x'Qx (exact fit on 16 points)."""
    def f(b1, b2, a):
        p1, p2 = prices_sep(uB, uS, sig, b1*r, b2*r, a)
        D1, D2, q = demands(uB, uS, sig, p1, p2, a)
        return (1 - b1)*r*D1 + (1 - b2)*r*D2 + a*q
    rng = np.random.default_rng(1)
    X = rng.uniform(0, 2, size=(16, 3))
    A = np.array([[1, x[0], x[1], x[2], x[0]**2, x[1]**2, x[2]**2,
                   x[0]*x[1], x[0]*x[2], x[1]*x[2]] for x in X])
    y = np.array([f(*x) for x in X])
    c, *_ = np.linalg.lstsq(A, y, rcond=None)
    Q = np.array([[c[4], c[7]/2, c[8]/2], [c[7]/2, c[5], c[9]/2],
                  [c[8]/2, c[9]/2, c[6]]])
    return c[0], c[1:4], Q


def _max_on_polyhedron(c0, g, Q, A, b):
    """Exact maximum of the concave quadratic c0 + g.x + x'Qx on {A x <= b}:
    the stationary point on each face of the polyhedron (every subset of
    active constraints), kept if feasible, the best of them returned."""
    import itertools
    f = lambda x: c0 + g @ x + x @ Q @ x
    m = A.shape[0]; best = -np.inf
    for k in range(m + 1):
        for S in itertools.combinations(range(m), k):
            S = list(S); n = 3 + len(S)
            K = np.zeros((n, n)); rhs = np.zeros(n)
            K[:3, :3] = 2*Q; rhs[:3] = -g
            if S:
                K[:3, 3:] = -A[S].T; K[3:, :3] = A[S]; rhs[3:] = b[S]
            try:
                x = np.linalg.solve(K, rhs)[:3]
            except np.linalg.LinAlgError:
                continue
            if np.all(A @ x <= b + 1e-9):
                best = max(best, f(x))
    return best


def certificate(uB, uS, sig, single, amax=A_MAX, r=R):
    """True if the both-host profit is concave at this point and its exact
    maximum on each of the two regions outside the swept wedge is below the
    single-host value."""
    c0, g, Q = _pi_quadratic(uB, uS, sig, r)
    if not np.all(np.linalg.eigvalsh(Q) < 0):
        return False, np.nan, np.nan
    kap = 2*uB*(3*sig + 4)/(r*(8 + sig*(8 + sig)))   # bar-beta(a) = 1 + kap a
    A1 = np.array([[0, 0, -1.], [-1, 0, 0], [0, -1, 0]])
    b1 = np.array([-amax, -1., -1.])                   # a >= amax, beta^k >= 1
    A2 = np.array([[0, 0, -1.], [0, 0, 1.], [-1, 0, kap], [0, -1, 0]])
    b2 = np.array([0., amax, -3., -1.])                # 0<=a<=amax, beta^1 >= 3+kap a, beta^2 >= 1
    m1 = _max_on_polyhedron(c0, g, Q, A1, b1)
    m2 = _max_on_polyhedron(c0, g, Q, A2, b2)
    return (m1 < single and m2 < single), m1 - single, m2 - single


def _cfg(uB, uS, sig, b1, b2, a, r=R):
    p1, p2 = prices_sep(uB, uS, sig, b1*r, b2*r, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    return p1, p2, D1, D2, q


def best_selected(uB, uS, sig, pib, r=R):
    """Best platform value over the package grid among packages at which the
    rule selects mutual acceptance.  Returns (value, package, n_tested)."""
    best, pkg, n = -np.inf, None, 0
    for a in A_VALUES:
        bb = bbar(uB, uS, sig, a)
        for b1 in np.linspace(1.0, bb + 2.0, N_B1):
            # joint refusal is an equilibrium iff a lone adopter of the
            # larger share does not beat the benchmark
            p1a, _, D1a, _, _ = _cfg(uB, uS, sig, b1, 1.0, a)
            lone = (p1a + b1*r)*D1a
            RR_is_NE = lone <= pib + 1e-12
            for b2 in np.linspace(1.0, b1, N_B2):
                p1, p2, D1, D2, q = _cfg(uB, uS, sig, b1, b2, a)
                if min(D1, D2, q, p1 + b1*r, p2 + b2*r) <= 0:
                    continue
                n += 1
                Pi = (1 - b1)*r*D1 + (1 - b2)*r*D2 + a*q
                pi1, pi2 = (p1 + b1*r)*D1, (p2 + b2*r)*D2
                selected = (not RR_is_NE) or (pi1 + pi2 >= 2*pib - 1e-12)
                if selected and Pi > best:
                    best, pkg = Pi, (b1, b2, a)
    return best, pkg, n


def main():
    t0 = time.time()
    print("rep33_bothhost_grid.py: both-host packages against the single-host"
          " package on A* with u_B >= u_S\n")
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        pts = [(uB, uS, sigma_of(uB, uS, g)) for uB in GRID for uS in GRID
               if admissible(uB, uS, g, True) and sigma_of(uB, uS, g) >= 0
               and uB >= uS]
        n_notax = sum(1 for (uB, uS, sig) in pts if Phi_prime0(uB, uS, sig) <= 0)
        tested = 0; viol = []; worst = -np.inf; pos_notax = 0
        cert = 0; cert_gap = -np.inf
        for (uB, uS, sig) in pts:
            p1, _, D1, _, _ = _cfg(uB, uS, sig, 1.0, 1.0, 0.0)
            pib = (p1 + R)*D1
            ah = a_hat(uB, uS, sig, g)
            single = max(Phi(uB, uS, sig, g, ah), 0.0) if ah > 0 else 0.0
            ok, d1, d2 = certificate(uB, uS, sig, single)
            cert += ok; cert_gap = max(cert_gap, d1, d2)
            best, pkg, n = best_selected(uB, uS, sig, pib)
            tested += n
            gap = best - single
            worst = max(worst, gap)
            if gap > TOL:
                viol.append((uB, uS, best, single, pkg))
            if Phi_prime0(uB, uS, sig) <= 0 and best > TOL:
                pos_notax += 1
        print("gamma = %g: %d points of A* with u_B >= u_S, of which %d in the"
              " region of Proposition 6(i)" % (g, len(pts), n_notax))
        print("   packages tested                                  : %d" % tested)
        print("   points where a selected both-host package beats"
              " max{Phi(a-hat), 0} : %d" % len(viol))
        print("   points of the 6(i) region where one earns anything : %d" % pos_notax)
        print("   largest (best both-host value - single-host value) : %.3e"
              % worst)
        print("   points where the bounds of the sweep are certified  : %d"
              " (largest outside-region excess over the single-host value: %.3f)"
              % (cert, cert_gap))
        for vv in viol[:10]:
            print("      violation at", vv)
    # cross-check of the inline solver against rep3_contracts.game()
    rng = np.random.default_rng(0)
    agree = total = 0
    for _ in range(3000):
        g = rng.choice([0.5, 1.0, 2.0, 4.0, 8.0, 16.0])
        uB, uS = rng.choice(GRID), rng.choice(GRID)
        if not admissible(uB, uS, g, True) or sigma_of(uB, uS, g) < 0 or uB < uS:
            continue
        sig = sigma_of(uB, uS, g)
        a = rng.uniform(0.01, A_MAX)
        b1 = rng.uniform(1.0, bbar(uB, uS, sig, a) + 2.0)
        b2 = rng.uniform(1.0, b1)
        out = game(uB, uS, g, b1, b2, a)
        if out is None:
            continue
        p1, p2, D1, D2, q = _cfg(uB, uS, sig, b1, b2, a)
        p1a, _, D1a, _, _ = _cfg(uB, uS, sig, b1, 1.0, a)
        p10, _, D10, _, _ = _cfg(uB, uS, sig, 1.0, 1.0, 0.0)
        pib = (p10 + R)*D10
        RR_is_NE = (p1a + b1*R)*D1a <= pib + 1e-12
        pi1, pi2 = (p1 + b1*R)*D1, (p2 + b2*R)*D2
        selected = (not RR_is_NE) or (pi1 + pi2 >= 2*pib - 1e-12)
        val = (1 - b1)*R*D1 + (1 - b2)*R*D2 + a*q if selected else 0.0
        total += 1
        if abs(out[0] - val) < 1e-9 and (out[1] == 'AA') == selected:
            agree += 1
    print("\ncross-check against rep3_contracts.game() on %d random packages:"
          " %d agree" % (total, agree))
    print("\ntime: %.0f s" % (time.time() - t0))


if __name__ == '__main__':
    main()
