# -*- coding: utf-8 -*-
"""Extension 2 : benchmark (I licencie a M_1, M_2 integre) contre fusion."""
import os
import sympy as sp, pickle
v, r, uB, uS, s = sp.symbols('v r u_B u_S sigma', positive=True)
a1, a2, p1, p2 = sp.symbols('a_1 a_2 p_1 p_2', real=True)
M = 1 - 2*uB*uS; A = a1 + a2
D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*A)/(2*M)
D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*A)/(2*M)
qS = (uS*(2*v - p1 - p2) - A)/M

def price_eq(Pi1, Pi2):
    sol = sp.solve([sp.Eq(sp.diff(Pi1,p1),0), sp.Eq(sp.diff(Pi2,p2),0)],[p1,p2],dict=True)[0]
    return sp.simplify(sol[p1]), sp.simplify(sol[p2])

# ---------------- BENCHMARK : M_1 nu (a_1 = 0), M_2 integre --------------
Pb1 = (p1 + r)*D1.subs(a1,0)
Pb2 = (p2 + r)*D2.subs(a1,0) + a2*qS.subs(a1,0)
P1b, P2b = price_eq(Pb1, Pb2)
Pb2e = sp.simplify(Pb2.subs({p1:P1b, p2:P2b}))
a2b  = sp.factor(sp.simplify(sp.solve(sp.Eq(sp.diff(Pb2e,a2),0), a2)[0]))
print("BENCHMARK : a_2^bench =", a2b)
nb, db = sp.fraction(sp.together(a2b))
print("\n  numerateur :", sp.factor(sp.expand(nb)))

# ---------------- FUSION : deux integrees --------------------------------
Pm1 = (p1 + r)*D1 + a1*qS
Pm2 = (p2 + r)*D2 + a2*qS
P1m, P2m = price_eq(Pm1, Pm2)
Pm1e = sp.simplify(Pm1.subs({p1:P1m,p2:P2m})); Pm2e = sp.simplify(Pm2.subs({p1:P1m,p2:P2m}))
fees = sp.solve([sp.Eq(sp.diff(Pm1e,a1),0), sp.Eq(sp.diff(Pm2e,a2),0)],[a1,a2],dict=True)[0]
aM = sp.factor(sp.simplify(fees[a1]))
print("\nFUSION : a_1 = a_2 =", aM)

# ---------------- comparaison des fees TOTAUX ---------------------------
tot_b = a2b                     # benchmark : a_1 = 0
tot_m = 2*aM
diff  = sp.factor(sp.simplify(tot_m - tot_b))
print("\nfee total apres fusion moins fee total avant =", diff)
nd, dd = sp.fraction(sp.together(diff))
print("\n  numerateur :", sp.factor(sp.expand(nd)))
print("  denominateur :", sp.factor(sp.expand(dd)))

pickle.dump({'a2b':sp.srepr(a2b),'aM':sp.srepr(aM),
             'P1b':sp.srepr(P1b),'P2b':sp.srepr(P2b),
             'P1m':sp.srepr(P1m),'P2m':sp.srepr(P2m)},
            open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ext2.pkl'),'wb'))
print("\nsauvegarde ok")
