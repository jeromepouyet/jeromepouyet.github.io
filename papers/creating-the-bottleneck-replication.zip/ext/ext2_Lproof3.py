# -*- coding: utf-8 -*-
"""L > 0 comme identite polynomiale (version corrigee : on nettoie les
fractions AVANT d'extraire les coefficients)."""
import sympy as sp
g, s, x, t = sp.symbols('gamma sigma x t', positive=True)
w = (g-s)/(2*(1+g))
den_m = (9*s**3 - 24*s**2*(w**2/x) - 46*s**2*w - 16*s**2*x + 84*s**2
         - 80*s*(w**2/x) - 200*s*w - 72*s*x + 240*s
         - 64*(w**2/x) - 192*w - 64*x + 192)
num_m = sp.expand(sp.numer(sp.cancel(sp.together(den_m))))   # signe de den_m (x>0)
xL = (3*s+4)*(3*g*s+8*g+8*s+16)/(8*s*(g+1))

def sign_identity(label, expr):
    e = sp.cancel(sp.together(expr.subs(g, s+t)))
    n_, d_ = sp.fraction(e)
    n_, d_ = sp.expand(n_), sp.expand(d_)
    def side(p):
        P = sp.Poly(p, s, t)
        cs = set(sp.sign(c) for c in P.coeffs())
        return 'pos' if cs=={1} else ('neg' if cs=={-1} else 'MIXTE')
    sn, sd = side(n_), side(d_)
    got = {('pos','pos'):'>0',('neg','neg'):'>0',
           ('pos','neg'):'<0',('neg','pos'):'<0'}.get((sn,sd),'??')
    print("  %-30s num=%-6s den=%-6s -> %s" % (label, sn, sd, got))
    return got

print("Identites a etablir sur 0 <= sigma < gamma (substitution gamma = sigma + t) :\n")
r1 = sign_identity("den_m(x_L)",        num_m.subs(x, xL))
r2 = sign_identity("d/dx den_m en x_L", sp.diff(num_m, x).subs(x, xL))
print("\n  den_m(x_L) < 0  et  den_m decroissante en x_L")
print("  => x_L est strictement a droite de l'intervalle ou den_m > 0,")
print("     donc tout l'ensemble admissible verifie x < x_L, donc L > 0.")
print("\n  resultat :", "ETABLI" if (r1=='<0' and r2=='<0') else "NON ETABLI (%s, %s)"%(r1,r2))
