# -*- coding: utf-8 -*-
"""Etape 7 : la carte (u_B,u_S) quand N grandit, a gamma fixe.

Deux canaux jouent en sens contraire :
  - R_a^N croit en N (la region taxante s'elargit a sigma donne) ;
  - sigma_N = gamma - N u_B u_S (1+gamma) decroit en N (et R_a croit en sigma).
On tranche numeriquement, sur l'ensemble admissible propre a chaque N.
"""
import numpy as np

def sigma_N(uB, uS, g, N): return g - N*uB*uS*(1+g)
def M_N(uB, uS, N):        return 1 - N*uB*uS

def Ra(s, N):
    num = (2*N**3*s**3 + 8*N**3*s**2 + 10*N**3*s + 4*N**3 - 5*N**2*s**3
           - 13*N**2*s**2 - 8*N**2*s + 4*N*s**3 + 4*N*s**2 - s**3 + s**2)
    den = 2*(N*s + N - s)*(2*N*s + 2*N - s)
    return num/den

def Hpos(uB, uS, s, N):
    """concavite : -Pi'' > 0, numerateur issu du calcul symbolique."""
    return -( 4*N**5*s**3*uB*uS + 16*N**5*s**2*uB*uS + 20*N**5*s*uB*uS + 8*N**5*uB*uS
      - 4*N**4*s**4 + 4*N**4*s**3*uB**2 - 8*N**4*s**3*uB*uS + 3*N**4*s**3*uS**2 - 24*N**4*s**3
      + 12*N**4*s**2*uB**2 - 20*N**4*s**2*uB*uS + 11*N**4*s**2*uS**2 - 52*N**4*s**2
      + 12*N**4*s*uB**2 - 12*N**4*s*uB*uS + 12*N**4*s*uS**2 - 48*N**4*s
      + 4*N**4*uB**2 + 4*N**4*uS**2 - 16*N**4 + 12*N**3*s**4 - 8*N**3*s**3*uB**2
      + 7*N**3*s**3*uB*uS - 6*N**3*s**3*uS**2 + 52*N**3*s**3 - 16*N**3*s**2*uB**2
      + 8*N**3*s**2*uB*uS - 14*N**3*s**2*uS**2 + 72*N**3*s**2 - 8*N**3*s*uB**2
      - 8*N**3*s*uS**2 + 32*N**3*s - 13*N**2*s**4 + 5*N**2*s**3*uB**2 - 4*N**2*s**3*uB*uS
      + 4*N**2*s**3*uS**2 - 36*N**2*s**3 + 5*N**2*s**2*uB**2 - 2*N**2*s**2*uB*uS
      + 4*N**2*s**2*uS**2 - 24*N**2*s**2 + 6*N*s**4 - N*s**3*uB**2 + N*s**3*uB*uS
      - N*s**3*uS**2 + 8*N*s**3 - s**4 )

g = 4.0
gr = np.arange(0.02, 1.402, 0.02)
print("gamma = 4, grille de pas 0.02 sur [0.02, 1.40]\n")
print("  %-4s %-10s %-10s %-10s %-12s" % ("N","admissibles","taxants","subv.","part subv."))
for N in (2,3,4,5,8,10,20):
    adm=tax=sub=0
    for uB in gr:
        for uS in gr:
            if M_N(uB,uS,N) <= 0: continue
            s = sigma_N(uB,uS,g,N)
            if s < 0: continue
            if Hpos(uB,uS,s,N) <= 0: continue
            adm += 1
            if uB/uS < Ra(s,N): tax += 1
            else: sub += 1
    print("  %-4d %-10d %-10d %-10d %-12s" % (N, adm, tax, sub,
          ("%.1f%%" % (100*sub/adm)) if adm else "-"))

print("\nR_a^N(sigma) a sigma = 0 :", [ (N, round(Ra(0.0,N),3)) for N in (2,3,5,10,20) ])
