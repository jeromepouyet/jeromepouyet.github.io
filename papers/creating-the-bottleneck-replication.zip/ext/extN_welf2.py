# -*- coding: utf-8 -*-
"""Etape 10 : (a) Prop 5(ii) au voisinage de la frontiere taxante ;
              (b) recomptage sur l'ensemble A du papier (concavite + interiorite)."""
import os
import sympy as sp, pickle, numpy as np
N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
b = sp.Symbol('b', real=True)
MN = 1 - N*uB*uS
D = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'welfN.pkl'),'rb'))
A = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'feeN.pkl'),'rb'))
E = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
W = sp.sympify(D['W']); dW0 = sp.sympify(D['dW0'])
astar = sp.sympify(A['astar']); d2 = sp.sympify(A['d2'])
p1I = sp.sympify(E['p1I']).subs(b,r); pI = sp.sympify(E['pI']).subs(b,r)
pbar = (p1I + (N-1)*pI)/N
Dp = sp.cancel((v - (1+s)*pI + s*pbar - uB*a)/MN)      # demande d'un rival

args=(N,uB,uS,s,v,r)
fW=sp.lambdify(args+(a,),W,'numpy'); fdW0=sp.lambdify(args,dW0,'numpy')
fa=sp.lambdify(args,astar,'numpy');  fd2=sp.lambdify(args,d2,'numpy')
fDp=sp.lambdify(args+(a,),Dp,'numpy')

def Ra(sig,n):
    num=(2*n**3*sig**3+8*n**3*sig**2+10*n**3*sig+4*n**3-5*n**2*sig**3
         -13*n**2*sig**2-8*n**2*sig+4*n*sig**3+4*n*sig**2-sig**3+sig**2)
    return num/(2*(n*sig+n-sig)*(2*n*sig+2*n-sig))

V,R = 2.0,0.5
gr = np.arange(0.02,1.402,0.02)

def scan(n, G, interior=True):
    pts=[]
    for x in gr:
        for y in gr:
            if 1-n*x*y<=0: continue
            sig=G-n*x*y*(1+G)
            if sig<0: continue
            if fd2(n,x,y,sig,V,R)>=0: continue
            ast=fa(n,x,y,sig,V,R)
            if interior and fDp(n,x,y,sig,V,R,ast)<=0: continue
            dW=fW(n,x,y,sig,V,R,ast)-fW(n,x,y,sig,V,R,0.0)
            pts.append((x,y,sig,ast,dW,x/y<Ra(sig,n)))
    return pts

print("(a) Prop 5(ii) : Delta W < 0 au VOISINAGE de la frontiere taxante")
print("    (points taxants avec a** parmi les 10 %% les plus petits), aux six gamma")
print("  %-5s %-4s %-14s %-14s" % ("gamma","N","points testes","dW < 0"))
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for n in (2,3,5,10):
        tax=[p for p in scan(n,G) if p[5] and p[3]>0]
        tax.sort(key=lambda p:p[3])
        near=tax[:max(1,len(tax)//10)]
        neg=sum(1 for p in near if p[4]<0)
        print("  %-5g %-4d %-14d %-14s" % (G,n,len(near),"%d (%.0f%%)"%(neg,100*neg/len(near))))

print("\n(b) sur l'ensemble A du papier : concavite ET interiorite D_rival(a**) > 0, aux six gamma")
print("  %-5s %-4s %-8s %-9s %-12s %-14s %-12s" % ("gamma","N","adm.","taxants","dW>0 total","dW>0 taxants","dW>0 subv."))
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for n in (2,3,5,10):
        P=scan(n,G); tot=len(P)
        tax=[p for p in P if p[5]]; sub=[p for p in P if not p[5]]
        wt=sum(1 for p in tax if p[4]>0); ws=sum(1 for p in sub if p[4]>0)
        print("  %-5g %-4d %-8d %-9d %-12s %-14s %-12s" % (G,n,tot,len(tax),
            "%.1f%%"%(100*(wt+ws)/tot), "%d/%d"%(wt,len(tax)), "%d/%d"%(ws,len(sub))))
