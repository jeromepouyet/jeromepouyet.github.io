# -*- coding: utf-8 -*-
"""Etape 5 : la frontiere taxation / subvention en fonction de N."""
import os
import sympy as sp, pickle
N, v, r, uB, uS, s = sp.symbols('N v r u_B u_S sigma', positive=True)
astar = sp.sympify(pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'feeN.pkl'),'rb'))['astar'])

num, den = sp.fraction(sp.together(astar))
# le crochet qui porte le signe : on retire les facteurs de signe connu
K = sp.simplify(sp.cancel(num / (-N*(v+r)*(2*N*s+2*N-s))))
K = sp.expand(K)
cS = sp.factor(sp.expand(K.coeff(uS,1).coeff(uB,0)))
cB = sp.factor(sp.expand(K.coeff(uB,1).coeff(uS,0)))
print("coefficient de u_S :", cS)
print("coefficient de u_B :", cB)

# a** > 0  <=>  u_B/u_S < R_a^N(sigma)
Ra = sp.simplify(sp.factor(-cS/cB))
print("\nR_a^N(sigma) =", Ra)
Ra2 = sp.simplify(Ra.subs(N,2))
paper = (3*s*(s*(s+7)+16)+32)/(2*(s+2)*(3*s+4))
print("\nN=2 : R_a identique au papier :", sp.simplify(Ra2-paper)==0, "  ->", sp.simplify(Ra2))

# --- monotonie en N a sigma fixe ----------------------------------------
dRa = sp.simplify(sp.factor(sp.diff(Ra, N)))
print("\ndR_a^N/dN =", dRa)
nn, dd = sp.fraction(sp.together(dRa))
print("  num =", sp.factor(sp.expand(nn)))
print("  den =", sp.factor(sp.expand(dd)))

print("\nvaleurs de R_a^N(sigma) :")
print("  %-8s %-10s %-10s %-10s %-10s %-10s" % ("sigma","N=2","N=3","N=5","N=10","N->inf"))
for sv in (0, 0.5, 1, 2, 4):
    row=[]
    for Nv in (2,3,5,10):
        row.append(float(Ra.subs({s:sv, N:Nv})))
    lim = sp.limit(Ra, N, sp.oo)
    row.append(float(lim.subs(s,sv)))
    print("  %-8.1f %-10.4f %-10.4f %-10.4f %-10.4f %-10.4f" % (sv,*row))
print("\nlimite N -> infini :", sp.simplify(sp.limit(Ra, N, sp.oo)))
