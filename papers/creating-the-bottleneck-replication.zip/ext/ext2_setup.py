# -*- coding: utf-8 -*-
"""Extension 2 : M_2 verticalement integre, ne licencie jamais.

Structure Apple / Google.  M_2 possede son propre systeme AVEC son store, donc
il percoit la totalite du benefice par utilisateur ET fixe son propre fee a_2.

Convention du developpeur, celle du papier lui-meme (version 2025, section 2.1) :
il developpe q applications a cout q^2/2, publie sur le store i des que
u_S n^i_B - a_i >= 0, et son profit net est q * sum_i (u_S n^i_B - a_i) - q^2/2.
Avec deux stores :  q_S = u_S (n^1_B + n^2_B) - a_1 - a_2.

Consequence structurelle : le systeme de demande est CELUI DU PAPIER, avec le
fee total a = a_1 + a_2.  Les deux fees sont substituts parfaits dans le cout
du developpeur : c'est une structure de complements a la Cournot.

  Benchmark (avant fusion) : I licencie a M_1 (profit nul par free-riding,
      beta = 1, a_1 = 0) ; M_2 integre choisit (p_2, a_2).
  Apres fusion : deux firmes integrees symetriques, chacune (p_k, a_k).
"""
import sympy as sp

v, r, uB, uS, s = sp.symbols('v r u_B u_S sigma', positive=True)
a1, a2, p1, p2 = sp.symbols('a_1 a_2 p_1 p_2', real=True)
M = 1 - 2*uB*uS
A = a1 + a2                                    # fee total supporte par le developpeur

D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*A)/(2*M)
D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*A)/(2*M)
qS = (uS*(2*v - p1 - p2) - A)/M

# --- verification : c'est bien le systeme du papier avec a = a_1 + a_2 ---
from sympy import Symbol
a = Symbol('a', real=True)
D1p = (2*v - (2+s)*p1 + s*p2 - 2*uB*a)/(2*M)
print("systeme identique au papier avec a = a_1+a_2 :",
      sp.simplify(D1.subs(a2, a-a1) - D1p) == 0)

# ============ APRES FUSION : deux firmes integrees symetriques ===========
Pi1 = (p1 + r)*D1 + a1*qS
Pi2 = (p2 + r)*D2 + a2*qS
sol = sp.solve([sp.Eq(sp.diff(Pi1,p1),0), sp.Eq(sp.diff(Pi2,p2),0)], [p1,p2], dict=True)[0]
P1, P2 = sp.simplify(sol[p1]), sp.simplify(sol[p2])
Pi1e = sp.simplify(Pi1.subs({p1:P1, p2:P2}))
Pi2e = sp.simplify(Pi2.subs({p1:P1, p2:P2}))
fees = sp.solve([sp.Eq(sp.diff(Pi1e,a1),0), sp.Eq(sp.diff(Pi2e,a2),0)], [a1,a2], dict=True)[0]
a1M, a2M = sp.simplify(sp.factor(fees[a1])), sp.simplify(sp.factor(fees[a2]))
print("\nAPRES FUSION (deux integrees) :")
print("  a_1 = a_2 =", a1M)
print("  symetrique ?", sp.simplify(a1M - a2M) == 0)
print("  fee TOTAL sur le developpeur, a_1+a_2 =", sp.simplify(sp.factor(a1M + a2M)))

# ============ referentiel : le papier (M_2 sans store) ==================
# firme 1 integree choisit (p_1, a_1) ; M_2 nu maximise (p_2+r)D_2 ; a_2 = 0
D1b = D1.subs(a2, 0); D2b = D2.subs(a2, 0); qSb = qS.subs(a2, 0)
solb = sp.solve([sp.Eq(sp.diff((p1+r)*D1b + a1*qSb, p1),0),
                 sp.Eq(sp.diff((p2+r)*D2b, p2),0)], [p1,p2], dict=True)[0]
P1b, P2b = sp.simplify(solb[p1]), sp.simplify(solb[p2])
PiIb = sp.simplify(((p1+r)*D1b + a1*qSb).subs({p1:P1b, p2:P2b}))
aPaper = sp.simplify(sp.factor(sp.solve(sp.Eq(sp.diff(PiIb,a1),0), a1)[0]))
paper = ((3*s+4)*(v+r)*((3*s*(s*(s+7)+16)+32)*uS - 2*(s+2)*(3*s+4)*uB)
         /((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
           - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS - 2*(s*(s*(7*s+40)+64)+32)*uS**2))
print("\nCONTROLE : avec M_2 sans store, on retrouve le a** du papier :",
      sp.simplify(aPaper - paper) == 0)
