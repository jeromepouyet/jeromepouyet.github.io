# -*- coding: utf-8 -*-
"""Peut-on prouver L > 0 comme identite, et rendre analytique l'enonce
   << la fusion augmente le fee total ssi la region est taxante >> ?

Methode du papier : passer en (sigma, x) avec x = u_S^2 et
u_B u_S = (gamma - sigma)/(2(1+gamma)).  L est alors AFFINE decroissante en x,
donc L > 0 <=> x < x_L(sigma, gamma).  Il suffit de montrer que l'ensemble
admissible est sous x_L.
"""
import sympy as sp
g, s, x = sp.symbols('gamma sigma x', positive=True)
uS = sp.sqrt(x); w = (g-s)/(2*(1+g))          # w = u_B u_S
uB = w/uS

L = (9*s**3+60*s**2+112*s+64 - 2*w*(15*s**2+44*s+32) - 8*s*x*(s+1))
L = sp.simplify(sp.expand(L))
print("L en (sigma, x) :", sp.factor(L))
print("  affine en x ?", sp.degree(sp.Poly(L, x)) == 1)

xL = sp.simplify(sp.solve(sp.Eq(L, 0), x)[0])
print("\nseuil x_L =", sp.factor(xL))

# borne superieure de l'ensemble admissible : la racine haute de den_m
den_m = (9*s**3-24*s**2*uB**2-46*s**2*uB*uS-16*s**2*uS**2+84*s**2-80*s*uB**2
         -200*s*uB*uS-72*s*uS**2+240*s-64*uB**2-192*uB*uS-64*uS**2+192)
den_m = sp.simplify(sp.expand(sp.together(den_m)))
num_m = sp.numer(sp.together(den_m))
P = sp.Poly(sp.expand(num_m), x)
print("\nden_m : degre en x =", P.degree())

# x_L - x_haut(den_m) : signe ?
roots = sp.solve(sp.Eq(sp.expand(num_m), 0), x)
print("  nombre de racines :", len(roots))
for i, rt in enumerate(roots):
    d = sp.simplify(xL - rt)
    print("\n  x_L - racine %d :" % i)
    print("   ", sp.simplify(sp.factor(d)))
    # test numerique du signe sur 0 <= sigma < gamma
    import numpy as np
    f = sp.lambdify((s, g), d, 'numpy')
    bad = 0; tot = 0
    for gv in (0.5,1,2,4,8,16):
        for sv in np.linspace(1e-6, gv*0.999, 400):
            try:
                val = f(sv, gv)
                if np.isreal(val):
                    tot += 1; bad += (float(np.real(val)) <= 0)
            except Exception: pass
    print("    signe > 0 sur %d/%d points testes" % (tot-bad, tot))
