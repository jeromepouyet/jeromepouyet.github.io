# -*- coding: utf-8 -*-
"""Extension 2 : (a) double marginalisation correctement calculee ;
                 (b) alignement rival non fusionnant / developpeur."""
import os
import sympy as sp, pickle, numpy as np
v, r, uB, uS, s = sp.symbols('v r u_B u_S sigma', positive=True)
a1, a2, p1, p2, T = sp.symbols('a_1 a_2 p_1 p_2 T', real=True)
M = 1-2*uB*uS; A = a1+a2
D1=(2*v-(2+s)*p1+s*p2-2*uB*A)/(2*M); D2=(2*v-(2+s)*p2+s*p1-2*uB*A)/(2*M)
qS=(uS*(2*v-p1-p2)-A)/M
E=pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ext2.pkl'),'rb'))
a2b=sp.sympify(E['a2b']); aM=sp.sympify(E['aM'])
P1b,P2b=sp.sympify(E['P1b']),sp.sympify(E['P2b'])
P1m,P2m=sp.sympify(E['P1m']),sp.sympify(E['P2m'])

# --- (a) fees coordonnes : on impose a_1 = a_2 = T/2 AVANT de deriver ----
sub_T = {a1: T/2, a2: T/2}
q1, q2 = sp.simplify(P1m.subs(sub_T)), sp.simplify(P2m.subs(sub_T))
sub_all = {p1:q1, p2:q2, a1:T/2, a2:T/2}
Pj = sp.together((q1+r)*D1.subs(sub_all) + (q2+r)*D2.subs(sub_all) + T*qS.subs(sub_all))
Tc = sp.simplify(sp.solve(sp.Eq(sp.diff(Pj, T), 0), T)[0])
print("fee total coordonne T^c =", sp.factor(Tc))
print("\n2 a^M - T^c =", sp.factor(sp.simplify(2*aM - Tc)))

args=(uB,uS,s,v,r); L=lambda e: sp.lambdify(args,e,'numpy')
faM, fTc, fa2b = L(aM), L(Tc), L(a2b)

# --- (b) alignement : Delta Pi_2 et Delta V_S ----------------------------
def pack(pp1,pp2,aa1,aa2):
    sub={p1:pp1,p2:pp2,a1:aa1,a2:aa2}
    d2_,q_=D2.subs(sub),qS.subs(sub)
    return L((pp2+r)*d2_+aa2*q_), L(q_**2/2), L(D1.subs(sub)), L(d2_), L(q_)
fPi2b,fVSb,fd1b,fd2b,fqb = pack(P1b.subs({a1:0,a2:a2b}),P2b.subs({a1:0,a2:a2b}),0,a2b)
fPi2m,fVSm,fd1m,fd2m,fqm = pack(P1m.subs({a1:aM,a2:aM}),P2m.subs({a1:aM,a2:aM}),aM,aM)
Ra=lambda S:(3*S**3+21*S**2+48*S+32)/(2*(S+2)*(3*S+4))

print("\n%-6s %-7s %-9s %-24s %-22s" % ("gamma","adm.","taxants","dPi_2 et dV_S memes signes","2a^M > T^c (taxants)"))
for G in (0.5,1.0,2.0,4.0,8.0,16.0):
    gr=np.arange(0.02,1.402,0.02); n=tax=same=over=ntax=0; rats=[]
    for x in gr:
        for y in gr:
            if 1-2*x*y<=0: continue
            S=G-2*x*y*(1+G)
            if S<0: continue
            if min(fd1b(x,y,S,2.,.5),fd2b(x,y,S,2.,.5),fqb(x,y,S,2.,.5),
                   fd1m(x,y,S,2.,.5),fd2m(x,y,S,2.,.5),fqm(x,y,S,2.,.5))<=0: continue
            n+=1
            dP2=fPi2m(x,y,S,2.,.5)-fPi2b(x,y,S,2.,.5)
            dVS=fVSm(x,y,S,2.,.5)-fVSb(x,y,S,2.,.5)
            same += (dP2>0)==(dVS>0)
            if x/y < Ra(S):
                tax+=1; ntax+=1
                tm,tc = 2*faM(x,y,S,2.,.5), fTc(x,y,S,2.,.5)
                if tm>tc: over+=1
                if abs(tc)>1e-9: rats.append(tm/tc)
    rats=np.array(rats)
    print("%-6.3g %-7d %-9d %-24s %-22s" % (G,n,tax,
      "%d/%d (%.1f%%)"%(same,n,100*same/n),
      "%d/%d ; ratio med. %.2f"%(over,ntax,np.median(rats))))
