# -*- coding: utf-8 -*-
"""Etape 1 : le systeme de demande avec N fabricants.

On garde Shubik-Levitan avec p_bar = (1/N) sum p_j, les effets de reseau
additifs, le portage gratuit (un stock d'applications commun), et le
developpeur a cout quadratique.  On verifie que N = 2 redonne exactement le
systeme du papier.
"""
import sympy as sp

N, v, a, uB, uS, g = sp.symbols('N v a u_B u_S gamma', positive=True)
p1, p = sp.symbols('p_1 p', real=True)          # prix de la firme 1, prix commun des N-1 autres
qS = sp.Symbol('q_S', real=True)

pbar = (p1 + (N-1)*p)/N

# demandes "quasi" avant point fixe
Q1 = v - p1 - g*(p1 - pbar) + uB*qS
Qj = v - p  - g*(p  - pbar) + uB*qS
tot = Q1 + (N-1)*Qj

# point fixe du developpeur : q_S = u_S * (buyers totaux) - a
sol = sp.solve(sp.Eq(qS, uS*tot - a), qS, dict=True)[0][qS]
sol = sp.simplify(sol)

MN  = 1 - N*uB*uS
sN  = g - N*uB*uS*(1+g)

print("q_S =", sp.simplify(sol))
print("q_S * M_N - [u_S(N v - sum p) - a] =",
      sp.simplify(sol*MN - (uS*(N*v - (p1+(N-1)*p)) - a)))

D1 = sp.simplify(Q1.subs(qS, sol))
Dj = sp.simplify(Qj.subs(qS, sol))

# forme annoncee : M_N D_k = v - (1+sigma_N) p_k + sigma_N pbar - u_B a
claim1 = (v - (1+sN)*p1 + sN*pbar - uB*a)/MN
claimj = (v - (1+sN)*p  + sN*pbar - uB*a)/MN
print("\nD_1 conforme a la forme annoncee :", sp.simplify(D1 - claim1) == 0)
print("D_j conforme a la forme annoncee :", sp.simplify(Dj - claimj) == 0)

print("\n(1+gamma) M_N - (1+sigma_N) =", sp.simplify((1+g)*MN - (1+sN)))

# --- verification contre le papier a N = 2 -------------------------------
s2 = sp.Symbol('sigma', positive=True)
D1_2 = sp.simplify(D1.subs(N, 2))
paper = (2*v - (2+s2)*p1 + s2*p - 2*uB*a)/(2*(1-2*uB*uS))
paper = paper.subs(s2, g - 2*uB*uS*(1+g))
print("\nN=2 : D_1 identique au papier :", sp.simplify(D1_2 - paper) == 0)

qS_2 = sp.simplify(sol.subs(N, 2))
paper_q = (uS*(2*v - p1 - p) - a)/(1-2*uB*uS)
print("N=2 : q_S identique au papier   :", sp.simplify(qS_2 - paper_q) == 0)

# --- substituabilite : signe de dD_k/dp_l -------------------------------
cross = sp.simplify(sp.diff(D1, p)/(N-1))   # effet d'UN rival
print("\ndD_1/dp_l (un rival) =", sp.simplify(cross))
print("  = sigma_N / (N M_N) ? ", sp.simplify(cross - sN/(N*MN)) == 0)
