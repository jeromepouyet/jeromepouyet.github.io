# -*- coding: utf-8 -*-
"""Extension 2 : signes, bien-etre, et carte."""
import os
import sympy as sp, pickle, numpy as np
v, r, uB, uS, s = sp.symbols('v r u_B u_S sigma', positive=True)
a1, a2, p1, p2 = sp.symbols('a_1 a_2 p_1 p_2', real=True)
M = 1 - 2*uB*uS; A = a1 + a2
D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*A)/(2*M)
D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*A)/(2*M)
qS = (uS*(2*v - p1 - p2) - A)/M
g  = (s + 2*uB*uS)/M

E = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ext2.pkl'),'rb'))
a2b = sp.sympify(E['a2b']); aM = sp.sympify(E['aM'])
P1b, P2b = sp.sympify(E['P1b']), sp.sympify(E['P2b'])
P1m, P2m = sp.sympify(E['P1m']), sp.sympify(E['P2m'])

def welfare(pp1, pp2, aa1, aa2):
    sub = {p1: pp1, p2: pp2, a1: aa1, a2: aa2}
    d1, d2, q = D1.subs(sub), D2.subs(sub), qS.subs(sub)
    VB = (v*(d1+d2) + uB*q*(d1+d2) - (2*(d1**2+d2**2)+g*(d1+d2)**2)/(4*(1+g))
          - pp1*d1 - pp2*d2)
    VS = q**2/2
    Pi1 = (pp1+r)*d1 + aa1*q
    Pi2 = (pp2+r)*d2 + aa2*q
    return sp.together(VB + VS + Pi1 + Pi2), d1, d2, q

# benchmark : a_1 = 0, a_2 = a2b ; fusion : a_1 = a_2 = aM
Wb, d1b, d2b, qb = welfare(P1b.subs(a2,a2b).subs(a1,0), P2b.subs(a2,a2b).subs(a1,0), 0, a2b)
Wm, d1m, d2m, qm = welfare(P1m.subs({a1:aM,a2:aM}), P2m.subs({a1:aM,a2:aM}), aM, aM)

K  = uS*(3*s**3+21*s**2+48*s+32) - 2*(s+2)*(3*s+4)*uB
L  = 9*s**3-30*s**2*uB*uS-8*s**2*uS**2+60*s**2-88*s*uB*uS-8*s*uS**2+112*s-64*uB*uS+64
den_m = (9*s**3-24*s**2*uB**2-46*s**2*uB*uS-16*s**2*uS**2+84*s**2-80*s*uB**2
         -200*s*uB*uS-72*s*uS**2+240*s-64*uB**2-192*uB*uS-64*uS**2+192)
den_b = (9*s**4-18*s**3*uB**2-42*s**3*uB*uS-14*s**3*uS**2+96*s**3-84*s**2*uB**2
         -248*s**2*uB*uS-80*s**2*uS**2+352*s**2-128*s*uB**2-448*s*uB*uS
         -128*s*uS**2+512*s-64*uB**2-256*uB*uS-64*uS**2+256)

args=(uB,uS,s,v,r)
f = {n: sp.lambdify(args, e, 'numpy') for n,e in
     [('K',K),('L',L),('dm',den_m),('db',den_b),('a2b',a2b),('aM',aM),
      ('Wb',Wb),('Wm',Wm),('d1b',d1b),('d2b',d2b),('qb',qb),
      ('d1m',d1m),('d2m',d2m),('qm',qm)]}
Ra = lambda S: (3*S**3+21*S**2+48*S+32)/(2*(S+2)*(3*S+4))

G,V,R = 4.0,2.0,0.5
gr = np.arange(0.02,1.402,0.02)
tot=Lpos=dmpos=dbpos=0; tax=0; wUp=0; wtax=0; wsub=0; feeUp=0; feeUpTax=0
for x in gr:
    for y in gr:
        if 1-2*x*y<=0: continue
        S = G-2*x*y*(1+G)
        if S<0: continue
        if f['dm'](x,y,S,V,R)<=0 or f['db'](x,y,S,V,R)<=0: continue
        if min(f['d1m'](x,y,S,V,R), f['d2m'](x,y,S,V,R), f['qm'](x,y,S,V,R),
               f['d1b'](x,y,S,V,R), f['d2b'](x,y,S,V,R), f['qb'](x,y,S,V,R))<=0: continue
        tot+=1
        Lpos += f['L'](x,y,S,V,R)>0
        istax = x/y < Ra(S); tax += istax
        dfee = 2*f['aM'](x,y,S,V,R) - f['a2b'](x,y,S,V,R)
        if dfee>0:
            feeUp+=1; feeUpTax += istax
        dW = f['Wm'](x,y,S,V,R) - f['Wb'](x,y,S,V,R)
        if dW>0:
            wUp+=1
            if istax: wtax+=1
            else: wsub+=1
print("gamma=4, grille 0.02 sur [0.02,1.40], concavite + interiorite des DEUX regimes")
print("  points admissibles          : %d" % tot)
print("  facteur L > 0               : %d (%.1f%%)" % (Lpos, 100*Lpos/tot))
print("  points taxants (u_B/u_S<R_a): %d (%.1f%%)" % (tax, 100*tax/tot))
print("  fee TOTAL en hausse         : %d (%.1f%%)  dont taxants %d/%d"
      % (feeUp, 100*feeUp/tot, feeUpTax, tax))
print("  bien-etre en hausse         : %d (%.1f%%)  taxants %d/%d, subv. %d/%d"
      % (wUp, 100*wUp/tot, wtax, tax, wsub, tot-tax))
