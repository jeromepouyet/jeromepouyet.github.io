# -*- coding: utf-8 -*-
"""L > 0 comme identite polynomiale.

L est affine decroissante en x = u_S^2, nulle en x_L.  den_m (numerateur de la
condition de concavite, positif sur l'ensemble admissible) est quadratique en x.
Il suffit de deux signes :
   den_m(x_L) < 0        -> x_L est hors de l'intervalle admissible
   den_m'(x_L) < 0       -> x_L est a DROITE du sommet, donc a droite de
                            l'intervalle ; l'admissible est donc sous x_L.
Methode du papier : substitution gamma = sigma + t, t > 0, et coefficients de
signe unique.
"""
import sympy as sp
g, s, x, t, m = sp.symbols('gamma sigma x t m', positive=True)
uSq = x; w = (g-s)/(2*(1+g))
# den_m en (sigma, x) : on remplace u_B^2 = w^2/x, u_B u_S = w, u_S^2 = x
den_m = (9*s**3 - 24*s**2*(w**2/x) - 46*s**2*w - 16*s**2*x + 84*s**2
         - 80*s*(w**2/x) - 200*s*w - 72*s*x + 240*s
         - 64*(w**2/x) - 192*w - 64*x + 192)
den_m = sp.together(den_m)
num_m = sp.expand(sp.numer(den_m))          # = x * den_m, donc meme signe (x>0)
xL = (3*s+4)*(3*g*s+8*g+8*s+16)/(8*s*(g+1))

for label, expr in (("den_m(x_L)",  num_m.subs(x, xL)),
                    ("d/dx den_m au point x_L", sp.diff(num_m, x).subs(x, xL))):
    e = sp.cancel(sp.together(expr))
    n_, d_ = sp.fraction(e)
    n_ = sp.expand(sp.factor(sp.expand(n_)).subs(g, s+t))
    d_ = sp.expand(sp.factor(sp.expand(d_)).subs(g, s+t))
    # after the substitution gamma = sigma + t the two parts may still carry a
    # monomial denominator; clear it, the sign is unaffected (sigma, t > 0).
    n_ = sp.expand(sp.numer(sp.cancel(sp.together(n_))))
    d_ = sp.expand(sp.numer(sp.cancel(sp.together(d_))))
    sn = set(sp.sign(c) for c in sp.Poly(n_, s, t).coeffs())
    sd = set(sp.sign(c) for c in sp.Poly(d_, s, t).coeffs())
    got = {(1,1):'>0',(-1,-1):'>0',(1,-1):'<0',(-1,1):'<0'}.get(
          (1 if sn=={1} else (-1 if sn=={-1} else 0),
           1 if sd=={1} else (-1 if sd=={-1} else 0)), '??')
    print("%-26s : num %s, den %s  ->  %s" % (label, sn, sd, got))
