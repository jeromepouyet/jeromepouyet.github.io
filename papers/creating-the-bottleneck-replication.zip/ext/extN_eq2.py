# -*- coding: utf-8 -*-
"""Etape 3 (corrigee) : equilibre de prix avec N fabricants, en sigma_N.

Ordre correct : on derive la FOC du rival deviant EN x, PUIS on impose la
symetrie x = p ; pour la firme 1 on impose d'abord que les N-1 rivaux sont
au meme prix p, puis on derive en p_1.
"""
import os
import sympy as sp, pickle, time
t0 = time.time()

N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
p1, x, p, b = sp.symbols('p_1 x p b', real=True)
MN = 1 - N*uB*uS

def D_of(pk, p1_, x_, p_):
    pbar = (p1_ + x_ + (N-2)*p_)/N
    return (v - (1+s)*pk + s*pbar - uB*a)/MN

# --- FOC du rival deviant (benefice percu b), puis symetrie x = p --------
Dx   = D_of(x, p1, x, p)
focx = sp.diff((x + b)*Dx, x)
focx = sp.simplify(focx.subs(x, p))          # symetrie entre les N-1 rivaux

# --- FOC de la firme 1 : les N-1 rivaux sont deja au prix p --------------
pbar1 = (p1 + (N-1)*p)/N
D1    = (v - (1+s)*p1 + s*pbar1 - uB*a)/MN
qS1   = (uS*(N*v - (p1 + (N-1)*p)) - a)/MN
foc1  = sp.diff((p1 + r)*D1 + a*qS1, p1)

sol = sp.solve([sp.Eq(foc1,0), sp.Eq(focx,0)], [p1, p], dict=True)[0]
p1I = sp.factor(sp.cancel(sp.together(sol[p1])))
pI  = sp.factor(sp.cancel(sp.together(sol[p])))
print("p_1^I =", p1I)
print("\np^I   =", pI)
print("[t=%.0fs]" % (time.time()-t0))

# --- verification a N = 2, b = r contre rep_core -------------------------
sig = s
c   = (2*v - r - a*(2*uB+uS) + 3*r)/(4+sig)
p1c = -r + c + (r - r - a*uS)/(4+3*sig)
p2c = -r + c + (r + a*uS - r)/(4+3*sig)
ok1 = sp.simplify(p1I.subs({N:2, b:r}) - p1c) == 0
ok2 = sp.simplify(pI .subs({N:2, b:r}) - p2c) == 0
print("\nN=2, b=r : p_1^I identique a rep_core :", ok1)
print("N=2, b=r : p_2^I identique a rep_core :", ok2)

pickle.dump({'p1I': sp.srepr(p1I), 'pI': sp.srepr(pI)},
            open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'wb'))
print("[t=%.0fs] sauvegarde" % (time.time()-t0))
