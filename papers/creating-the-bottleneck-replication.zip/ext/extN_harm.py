# -*- coding: utf-8 -*-
"""Le rival est-il lese exactement quand le fee monte ? (Prop. 3 generalisee)"""
import os
import sympy as sp, pickle
N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
b = sp.Symbol('b', real=True)
MN = 1 - N*uB*uS
AN = N*(s+2) - s ; BN = 2*N*(s+1) - s

d = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
p1I = sp.sympify(d['p1I']).subs(b, r); pI = sp.sympify(d['pI']).subs(b, r)
pbar = (p1I + (N-1)*pI)/N
Dp = sp.cancel((v - (1+s)*pI + s*pbar - uB*a)/MN)

F2 = uB*BN + s*uS
F3 = sp.expand(BN*(v+r) - a*F2)
print("marge du rival, p^I + r =", sp.factor(sp.cancel(sp.together(pI + r))))
print("\nF3 / (p^I + r) =", sp.simplify(sp.cancel(F3/(pI + r))))
print("\n=> F3 est-il proportionnel a la marge ? ",
      sp.simplify(sp.cancel(F3/(pI+r)) - sp.simplify(sp.cancel(F3/(pI+r)).subs({a:0,v:1,r:1}))*1) == 0
      or sp.simplify(sp.diff(sp.cancel(F3/(pI+r)), a)) == 0)

dpi = sp.factor(sp.cancel(sp.diff(sp.cancel((pI+r)*Dp), a)))
print("\nd(pi_rival)/da =", dpi)
print("\nforme annoncee : -2N*(N(s+1)-s)*F2*(p^I+r)*k / (M_N A_N^2 B_N^2) ?")
ratio = sp.simplify(sp.cancel(dpi / ((pI+r)*F2)))
print("  d(pi)/da / [(p^I+r) F2] =", sp.factor(ratio))
print("  signe de ce facteur : num et den")
nn, dd = sp.fraction(sp.together(ratio))
print("    num =", sp.factor(nn), "\n    den =", sp.factor(dd))

# dD_p/da a l'equilibre
dDp = sp.factor(sp.cancel(sp.diff(Dp, a)))
print("\ndD_rival/da =", dDp)
