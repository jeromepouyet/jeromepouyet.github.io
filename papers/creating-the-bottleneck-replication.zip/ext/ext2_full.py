# -*- coding: utf-8 -*-
"""Extension 2 : la carte complete + la mesure de la double marginalisation."""
import os
import sympy as sp, pickle, numpy as np
v, r, uB, uS, s = sp.symbols('v r u_B u_S sigma', positive=True)
a1, a2, p1, p2, Atot = sp.symbols('a_1 a_2 p_1 p_2 A', real=True)
M = 1 - 2*uB*uS; A = a1 + a2
D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*A)/(2*M)
D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*A)/(2*M)
qS = (uS*(2*v - p1 - p2) - A)/M
g  = (s + 2*uB*uS)/M
E = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ext2.pkl'),'rb'))
a2b=sp.sympify(E['a2b']); aM=sp.sympify(E['aM'])
P1b,P2b=sp.sympify(E['P1b']),sp.sympify(E['P2b'])
P1m,P2m=sp.sympify(E['P1m']),sp.sympify(E['P2m'])

def pack(pp1,pp2,aa1,aa2):
    sub={p1:pp1,p2:pp2,a1:aa1,a2:aa2}
    d1,d2,q=D1.subs(sub),D2.subs(sub),qS.subs(sub)
    VB=(v*(d1+d2)+uB*q*(d1+d2)-(2*(d1**2+d2**2)+g*(d1+d2)**2)/(4*(1+g))-pp1*d1-pp2*d2)
    VS=q**2/2
    Pi1=(pp1+r)*d1+aa1*q ; Pi2=(pp2+r)*d2+aa2*q
    return dict(d1=d1,d2=d2,q=q,VB=VB,VS=VS,Pi1=Pi1,Pi2=Pi2,W=VB+VS+Pi1+Pi2)

B = pack(P1b.subs({a1:0,a2:a2b}), P2b.subs({a1:0,a2:a2b}), 0, a2b)
Mg= pack(P1m.subs({a1:aM,a2:aM}), P2m.subs({a1:aM,a2:aM}), aM, aM)

# --- contrefactuel : fees COORDONNES (prix toujours en concurrence) ------
# NB: P1m, P2m are themselves functions of (a_1, a_2), so the two substitutions
# must be sequential -- a single dict leaves a_1, a_2 inside the inserted prices
# and Acoord then comes out symbolic (this was the TypeError at line 78).
_sub = {a1: Atot/2, a2: Atot/2}
P1c, P2c = P1m.subs(_sub), P2m.subs(_sub)
_pr = {p1: P1c, p2: P2c}
Pj = sp.together((P1c+r)*D1.subs(_pr).subs(_sub)
                 + (P2c+r)*D2.subs(_pr).subs(_sub)
                 + Atot*qS.subs(_pr).subs(_sub))
Acoord = sp.simplify(sp.solve(sp.Eq(sp.diff(Pj,Atot),0), Atot)[0])
assert not ({a1, a2} & Acoord.free_symbols), 'Acoord still symbolic in a_1,a_2'

args=(uB,uS,s,v,r)
L=lambda e: sp.lambdify(args,e,'numpy')
# second-order conditions of the two fee problems (each objective is
# quadratic in its own fee, so the condition does not depend on the fee):
# pre-merger, M_2's problem in a_2 at a_1 = 0; post-merger, each store's
# own-fee problem.
Pb2e = ((P2b+r)*D2.subs({p1:P1b,p2:P2b}) + a2*qS.subs({p1:P1b,p2:P2b})).subs(a1,0)
Pm1e = (P1m+r)*D1.subs({p1:P1m,p2:P2m}) + a1*qS.subs({p1:P1m,p2:P2m})
soc_b = sp.simplify(sp.diff(Pb2e,a2,2)); soc_m = sp.simplify(sp.diff(Pm1e,a1,2))
F={'a2b':L(a2b),'aM':L(aM),'Acoord':L(Acoord),'soc_b':L(soc_b),'soc_m':L(soc_m)}
for tag,d in (('b',B),('m',Mg)):
    for k in ('d1','d2','q','VB','VS','Pi1','Pi2','W'): F[k+tag]=L(d[k])
Ra=lambda S:(3*S**3+21*S**2+48*S+32)/(2*(S+2)*(3*S+4))

def scan(G):
    gr=np.arange(0.02,1.402,0.02); out=[]
    for x in gr:
        for y in gr:
            if 1-2*x*y<=0: continue
            S=G-2*x*y*(1+G)
            if S<0: continue
            try:
                vals={k:F[k](x,y,S,2.0,0.5) for k in F}
            except Exception: continue
            if min(vals['d1b'],vals['d2b'],vals['qb'],vals['d1m'],vals['d2m'],vals['qm'])<=0: continue
            out.append((x,y,S,vals))
    return out

print("second-order conditions of the two fee problems at the retained points:")
for G in (0.5,1.0,2.0,4.0,8.0,16.0):
    P=scan(G)
    bad=sum(1 for _,_,_,V in P if V['soc_b']>=0 or V['soc_m']>=0)
    print("  gamma=%-4g retained %4d, failing a second-order condition: %d" % (G,len(P),bad))

print("gamma  adm.   taxants  dW>0            dPi_2>0        dV_B>0         dV_S>0")
for G in (0.5,1.0,2.0,4.0,8.0,16.0):
    P=scan(G); n=len(P)
    if not n: continue
    tax=sum(1 for _,_,S,v_ in P if _/1 and 0)  # placeholder
    tax=0; dW=0; dP2=0; dVB=0; dVS=0; dWt=0
    for x,y,S,V in P:
        istax = x/y < Ra(S); tax+=istax
        if V['Wm']-V['Wb']>0: dW+=1; dWt+=istax
        if V['Pi2m']-V['Pi2b']>0: dP2+=1
        if V['VBm']-V['VBb']>0: dVB+=1
        if V['VSm']-V['VSb']>0: dVS+=1
    print("%-6g %-6d %-8d %-15s %-14s %-14s %-14s  dW>0: %d of %d taxing (%.1f%%), %d of %d subsidizing" % (G,n,tax,
      "%d (%.0f%%)"%(dW,100*dW/n), "%d (%.0f%%)"%(dP2,100*dP2/n),
      "%d (%.0f%%)"%(dVB,100*dVB/n), "%d (%.0f%%)"%(dVS,100*dVS/n),
      dWt, tax, 100.*dWt/max(tax,1), dW-dWt, n-tax))

# --- double marginalisation : voir ext2_dm.py, le script que le papier cite

# --- publication store by store (Refine 2, point 4) --------------------------
# The reduction to a total fee a = a_1 + a_2 presumes that the developer
# publishes on both stores: u_S n_B^k >= a_k for the store of each device
# (n_B^k = D_k), before the merger (store 2 alone charges a_2 = a2b, store 1
# charges nothing) and after it (both charge a^M).
print("\npublication store by store: slack u_S D_k - a_k at the two optima (min over the retained points)")
for G in (0.5,1.0,2.0,4.0,8.0,16.0):
    P=scan(G)
    sb = [0.5*0+y*V['d2b']-V['a2b'] for x,y,S,V in P]          # before: store 2
    sm = [min(y*V['d1m']-V['aM'], y*V['d2m']-V['aM']) for x,y,S,V in P]   # after: both stores
    fb = sum(1 for z in sb if z < 0); fm = sum(1 for z in sm if z < 0)
    print("  gamma=%-4g %4d points: before the merger min slack %+.3f (%d failures); after it min slack %+.3f (%d failures)"
          % (G, len(P), min(sb), fb, min(sm), fm))
