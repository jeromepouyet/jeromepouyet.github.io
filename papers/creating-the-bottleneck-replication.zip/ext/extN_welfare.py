# -*- coding: utf-8 -*-
"""Etape 8 : bien-etre total avec N fabricants.

Surplus des acheteurs a partir de l'utilite qui engendre la demande :
  U_B = sum_k (v + u_B n_S) q_k - (1/(2(1+gamma)))[ sum q_k^2 + (gamma/N)(sum q_k)^2 ]
(verifiee : sa derivee redonne p_k, et N=2 redonne l'utilite du papier).
"""
import os
import sympy as sp, pickle, time
t0=time.time()
N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
b = sp.Symbol('b', real=True)
MN = 1 - N*uB*uS
g  = (s + N*uB*uS)/MN                      # gamma en fonction de sigma_N

d = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
p1I = sp.sympify(d['p1I']).subs(b, r); pI = sp.sympify(d['pI']).subs(b, r)

pbar = (p1I + (N-1)*pI)/N
D1 = sp.cancel((v - (1+s)*p1I + s*pbar - uB*a)/MN)
Dp = sp.cancel((v - (1+s)*pI  + s*pbar - uB*a)/MN)
qS = sp.cancel((uS*(N*v - (p1I + (N-1)*pI)) - a)/MN)

sumq  = D1 + (N-1)*Dp
sumq2 = D1**2 + (N-1)*Dp**2
UB = (v + uB*qS)*sumq - (sumq2 + (g/N)*sumq**2)/(2*(1+g))
VB = sp.cancel(sp.together(UB - (p1I*D1 + (N-1)*pI*Dp)))
VS = qS**2/2
PiI = (p1I + r)*D1 + a*qS
Piriv = (pI + r)*Dp
W = sp.cancel(sp.together(VB + VS + PiI + (N-1)*Piriv))

# --- verification a N = 2 contre rep_core.surpluses ----------------------
VB2 = sp.simplify(VB.subs(N,2))
g2  = g.subs(N,2)
p1_2, p2_2 = p1I.subs(N,2), pI.subs(N,2)
D1_2, D2_2, q_2 = D1.subs(N,2), Dp.subs(N,2), qS.subs(N,2)
VB_core = (v*(D1_2+D2_2) + uB*q_2*(D1_2+D2_2)
           - (2*(D1_2**2+D2_2**2) + g2*(D1_2+D2_2)**2)/(4*(1+g2))
           - p1_2*D1_2 - p2_2*D2_2)
print("N=2 : V_B identique a rep_core.surpluses :", sp.simplify(VB2 - VB_core) == 0)
print("[t=%.0fs]" % (time.time()-t0))

# --- Delta W'(0) : le resultat au voisinage de la frontiere taxante ------
dW0 = sp.factor(sp.cancel(sp.diff(W, a).subs(a, 0)))
print("\nDelta W'(0) =", dW0)
nn, dd = sp.fraction(sp.together(dW0))
print("\n  numerateur :", sp.factor(sp.expand(nn)))
print("  denominateur :", sp.factor(sp.expand(dd)))

m = sp.Symbol('m', nonnegative=True)
for name, expr in (("num", nn), ("den", dd)):
    e = sp.expand(expr.subs(N, 2+m))
    P = sp.Poly(e, s, m, uB, uS, v, r)
    print("  signes des coefficients de %s apres N=2+m : %s" % (name, set(sp.sign(c) for c in P.coeffs())))
print("[t=%.0fs]" % (time.time()-t0))
pickle.dump({'W':sp.srepr(W),'dW0':sp.srepr(dW0)}, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'welfN.pkl'),'wb'))
