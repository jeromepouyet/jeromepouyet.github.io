# -*- coding: utf-8 -*-
"""Etape 4 : fee optimal, concavite, frontiere taxation/subvention, avec N."""
import os
import sympy as sp, pickle, time
t0=time.time()
N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
p1, p, b = sp.symbols('p_1 p b', real=True)
MN = 1 - N*uB*uS
d  = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
p1I = sp.sympify(d['p1I']); pI = sp.sympify(d['pI'])

AN = N*(s+2) - s          # generalise 4 + sigma
BN = 2*N*(s+1) - s        # generalise 4 + 3 sigma
print("A_N =", sp.factor(AN), " (N=2 ->", AN.subs(N,2), ")")
print("B_N =", sp.factor(BN), " (N=2 ->", BN.subs(N,2), ")")

# --- baseline : les rivaux au benefice complet, b = r --------------------
sub = {b: r}
P1 = sp.together(p1I.subs(sub)); P = sp.together(pI.subs(sub))
pbar = (P1 + (N-1)*P)/N
D1 = sp.cancel((v - (1+s)*P1 + s*pbar - uB*a)/MN)
qS = sp.cancel((uS*(N*v - (P1 + (N-1)*P)) - a)/MN)
PiI = sp.cancel(sp.together((P1 + r)*D1 + a*qS))

d2 = sp.factor(sp.cancel(sp.diff(PiI, a, 2)))
print("\nPi^I''(a) =", d2)

astar = sp.factor(sp.cancel(sp.solve(sp.Eq(sp.diff(PiI, a), 0), a)[0]))
print("\na**_N =", astar)
num, den = sp.fraction(sp.together(astar))
print("\n  numerateur :", sp.factor(sp.expand(num)))
print("  denominateur H_N :", sp.factor(sp.expand(den)))

# --- verification a N = 2 contre le papier ------------------------------
astar2 = sp.simplify(astar.subs(N,2))
paper = ((3*s+4)*(v+r)*((3*s*(s*(s+7)+16)+32)*uS - 2*(s+2)*(3*s+4)*uB)
         /((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
           - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS
           - 2*(s*(s*(7*s+40)+64)+32)*uS**2))
print("\nN=2 : a** identique au papier :", sp.simplify(astar2 - paper) == 0)
print("[t=%.0fs]" % (time.time()-t0))

pickle.dump({'astar':sp.srepr(astar),'PiI':sp.srepr(PiI),'d2':sp.srepr(d2)},
            open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'feeN.pkl'),'wb'))
