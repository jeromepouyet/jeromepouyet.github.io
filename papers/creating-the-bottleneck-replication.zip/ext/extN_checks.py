# -*- coding: utf-8 -*-
"""Etape 6 : les trois verifications structurelles.

(a) R_a^N est-il croissant en N, comme identite polynomiale ?
(b) la contrainte de participation force-t-elle encore beta >= 1 ?
(c) le nuisible-au-rival suit-il encore le signe du fee ?
"""
import os
import sympy as sp, pickle
N, v, r, a, uB, uS, s, m = sp.symbols('N v r a u_B u_S sigma m', positive=True)
p1, p, b = sp.symbols('p_1 p b', real=True)
MN = 1 - N*uB*uS

# ---------- (a) monotonie de R_a^N en N ---------------------------------
Ra = ((2*N**3*s**3 + 8*N**3*s**2 + 10*N**3*s + 4*N**3 - 5*N**2*s**3 - 13*N**2*s**2
       - 8*N**2*s + 4*N*s**3 + 4*N*s**2 - s**3 + s**2)
      / (2*(N*s + N - s)*(2*N*s + 2*N - s)))
print("R_a^N(0) =", sp.simplify(Ra.subs(s,0)))
print("R_a^N ~ ", sp.simplify(sp.limit(Ra/N, N, sp.oo)), "* N  quand N -> infini")

q = sp.numer(sp.together(sp.diff(Ra, N)))
q = sp.expand(sp.cancel(q/(s+1)))          # le facteur (sigma+1) > 0
qs = sp.expand(q.subs(N, 2+m))             # N = 2 + m, m >= 0
P = sp.Poly(qs, s, m)
signs = set(sp.sign(c) for c in P.coeffs())
print("\n(a) dR_a/dN : apres N = 2+m, tous les coefficients de meme signe ?", signs)
print("    -> R_a^N strictement croissant en N sur N>=2, sigma>=0 :", signs == {1})

# ---------- (b) participation : beta >= 1 ? -----------------------------
d = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
p1I = sp.sympify(d['p1I']); pI = sp.sympify(d['pI'])
pbar = (p1I + (N-1)*pI)/N
Dp   = sp.cancel((v - (1+s)*pI + s*pbar - uB*a)/MN)
prof = sp.cancel(sp.together((pI + b)*Dp))          # profit d'un rival a l'equilibre
dpb  = sp.factor(sp.cancel(sp.diff(prof, b)))
print("\n(b) d(profit du rival)/db =", dpb)
nn, dd = sp.fraction(sp.together(dpb))
nn2 = sp.expand(nn.subs({N: 2+m, b: r}))
dd2 = sp.expand(dd.subs({N: 2+m}))
print("    num (b=r, N=2+m) signes :", set(sp.sign(c) for c in sp.Poly(nn2, s,m,uB,uS,v,r).coeffs()))
print("    den (N=2+m)       signes :", set(sp.sign(c) for c in sp.Poly(dd2, s,m,uB,uS).coeffs()))

# ---------- (c) le rival est-il lese exactement quand le fee monte ? ----
Pi_riv = sp.cancel(sp.together(((pI + r)*Dp).subs(b, r)))
dpi_da = sp.factor(sp.cancel(sp.diff(Pi_riv, a)))
print("\n(c) d(pi_rival)/da =", dpi_da)
nn, dd = sp.fraction(sp.together(dpi_da))
print("    num signes (N=2+m) :", set(sp.sign(c) for c in sp.Poly(sp.expand(nn.subs(N,2+m)), s,m,uB,uS,v,r).coeffs()))
print("    den signes (N=2+m) :", set(sp.sign(c) for c in sp.Poly(sp.expand(dd.subs(N,2+m)), s,m,uB,uS).coeffs()))
