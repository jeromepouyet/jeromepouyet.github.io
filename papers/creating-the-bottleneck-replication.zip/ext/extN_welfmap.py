# -*- coding: utf-8 -*-
"""Etape 9 : (a) signe de Delta W'(0) ; (b) carte de bien-etre quand N grandit."""
import os
import sympy as sp, pickle, numpy as np, time
t0=time.time()
N, v, r, a, uB, uS, s = sp.symbols('N v r a u_B u_S sigma', positive=True)
D = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'welfN.pkl'),'rb'))
W   = sp.sympify(D['W']); dW0 = sp.sympify(D['dW0'])
A   = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'feeN.pkl'),'rb'))
astar = sp.sympify(A['astar']); d2 = sp.sympify(A['d2'])

args = (N, uB, uS, s, v, r)
fW    = sp.lambdify(args + (a,), W,     'numpy')
fdW0  = sp.lambdify(args,        dW0,   'numpy')
fastar= sp.lambdify(args,        astar, 'numpy')
fd2   = sp.lambdify(args,        d2,    'numpy')
print("lambdify ok [t=%.0fs]" % (time.time()-t0))

def Ra(sig,n):
    num=(2*n**3*sig**3+8*n**3*sig**2+10*n**3*sig+4*n**3-5*n**2*sig**3
         -13*n**2*sig**2-8*n**2*sig+4*n*sig**3+4*n*sig**2-sig**3+sig**2)
    return num/(2*(n*sig+n-sig)*(2*n*sig+2*n-sig))

G, V, R = 4.0, 2.0, 0.5
gr = np.arange(0.02, 1.402, 0.02)

print("\n(a) signe de Delta W'(0) sur l'ensemble admissible")
print("  %-4s %-12s %-12s" % ("N","points","dW'(0) < 0"))
for n in (2,3,5,10):
    tot=neg=0
    for x in gr:
        for y in gr:
            if 1-n*x*y <= 0: continue
            sig = G - n*x*y*(1+G)
            if sig < 0: continue
            if fd2(n,x,y,sig,V,R) >= 0: continue      # concavite
            tot += 1; neg += (fdW0(n,x,y,sig,V,R) < 0)
    print("  %-4d %-12d %-12s" % (n, tot, "%d (%.1f%%)"%(neg,100*neg/tot)))
print("[t=%.0fs]" % (time.time()-t0))

print("\n(b) carte de bien-etre : part de l'ensemble admissible ou Delta W > 0,")
print("    aux six gamma de la grille de reference ; 'decile' = points taxants dont")
print("    le fee est dans le premier decile de a**, et parmi eux ceux ou dW < 0")
print("  %-5s %-4s %-9s %-9s %-11s %-11s %-11s %-11s" % ("gamma","N","adm.","taxants","dW>0 total","dW>0 taxants","dW>0 subv.","decile: dW<0"))
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for n in (2,3,5,10):
        tot=tax=wp=wtax=wsub=0; taxpts=[]
        for x in gr:
            for y in gr:
                if 1-n*x*y <= 0: continue
                sig = G - n*x*y*(1+G)
                if sig < 0: continue
                if fd2(n,x,y,sig,V,R) >= 0: continue
                tot += 1
                ast = fastar(n,x,y,sig,V,R)
                dW  = fW(n,x,y,sig,V,R,ast) - fW(n,x,y,sig,V,R,0.0)
                istax = (x/y) < Ra(sig,n)
                tax += istax
                if istax: taxpts.append((ast, dW))
                if dW > 0:
                    wp += 1
                    if istax: wtax += 1
                    else: wsub += 1
        if taxpts:
            fees = np.array([t[0] for t in taxpts]); cut = np.percentile(fees, 10)
            dec = [t for t in taxpts if t[0] <= cut]; decneg = sum(1 for t in dec if t[1] < 0)
        else:
            dec, decneg = [], 0
        print("  %-5g %-4d %-9d %-9d %-11s %-11s %-11s %-11s" % (G,n,tot,tax,
            "%.1f%%"%(100*wp/tot), "%d/%d"%(wtax,tax), "%d/%d"%(wsub,tot-tax), "%d/%d"%(decneg,len(dec))))
print("[t=%.0fs]" % (time.time()-t0))
