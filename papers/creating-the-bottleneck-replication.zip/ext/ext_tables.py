# -*- coding: utf-8 -*-
"""Tableaux comparables au papier : memes gamma {1/2,1,2,4,8,16},
meme grille (pas 0.02 sur [0.02,1.40]), meme calibration v=2, r=1/2."""
import os
import sympy as sp, pickle, numpy as np
V, R = 2.0, 0.5
GS = [0.5, 1, 2, 4, 8, 16]
GR = np.arange(0.02, 1.402, 0.02)

# =============== EXTENSION 1 : N fabricants ==============================
Ns, uBs, uSs, ss, vs, rs = sp.symbols('N u_B u_S sigma v r', positive=True)
A1 = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'feeN.pkl'),'rb'))
W1 = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'welfN.pkl'),'rb'))
args1 = (Ns, uBs, uSs, ss, vs, rs)
fa  = sp.lambdify(args1, sp.sympify(A1['astar']), 'numpy')
fd2 = sp.lambdify(args1, sp.sympify(A1['d2']),    'numpy')
fW  = sp.lambdify(args1 + (sp.Symbol('a'),), sp.sympify(W1['W']), 'numpy')
b = sp.Symbol('b', real=True)
E1 = pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'eqN.pkl'),'rb'))
p1I = sp.sympify(E1['p1I']).subs(b, rs); pI = sp.sympify(E1['pI']).subs(b, rs)
MN = 1 - Ns*uBs*uSs; aa = sp.Symbol('a', real=True)
pbar = (p1I + (Ns-1)*pI)/Ns
Dp = sp.cancel((vs - (1+ss)*pI + ss*pbar - uBs*aa)/MN)
fDp = sp.lambdify(args1 + (aa,), Dp, 'numpy')
def RaN(S, n):
    num=(2*n**3*S**3+8*n**3*S**2+10*n**3*S+4*n**3-5*n**2*S**3-13*n**2*S**2
         -8*n**2*S+4*n*S**3+4*n*S**2-S**3+S**2)
    return num/(2*(n*S+n-S)*(2*n*S+2*n-S))

print("EXTENSION 1 — N fabricants : part de l'ensemble admissible ou Delta W > 0")
print("  %-7s %s" % ("gamma", "".join("%-13s"%("N=%d"%n) for n in (2,3,5,10))))
for G in GS:
    row=[]
    for n in (2,3,5,10):
        tot=wp=0
        for xx in GR:
            for yy in GR:
                if 1-n*xx*yy<=0: continue
                S=G-n*xx*yy*(1+G)
                if S<0: continue
                if fd2(n,xx,yy,S,V,R)>=0: continue
                ast=fa(n,xx,yy,S,V,R)
                if fDp(n,xx,yy,S,V,R,ast)<=0: continue
                tot+=1
                wp += (fW(n,xx,yy,S,V,R,ast)-fW(n,xx,yy,S,V,R,0.0))>0
        row.append("%.0f%% (%d)"%(100*wp/tot, tot) if tot else "-")
    print("  %-7s %s" % (G, "".join("%-13s"%c for c in row)))

# =============== EXTENSION 2 : M_2 integre ===============================
v_,r_,uB_,uS_,s_ = sp.symbols('v r u_B u_S sigma', positive=True)
a1_,a2_,p1_,p2_ = sp.symbols('a_1 a_2 p_1 p_2', real=True)
M_=1-2*uB_*uS_; A_=a1_+a2_
D1_=(2*v_-(2+s_)*p1_+s_*p2_-2*uB_*A_)/(2*M_)
D2_=(2*v_-(2+s_)*p2_+s_*p1_-2*uB_*A_)/(2*M_)
qS_=(uS_*(2*v_-p1_-p2_)-A_)/M_
g_=(s_+2*uB_*uS_)/M_
E2=pickle.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ext2.pkl'),'rb'))
a2b=sp.sympify(E2['a2b']); aM=sp.sympify(E2['aM'])
P1b,P2b=sp.sympify(E2['P1b']),sp.sympify(E2['P2b'])
P1m,P2m=sp.sympify(E2['P1m']),sp.sympify(E2['P2m'])
def pk(pp1,pp2,x1,x2):
    sub={p1_:pp1,p2_:pp2,a1_:x1,a2_:x2}
    d1,d2,q=D1_.subs(sub),D2_.subs(sub),qS_.subs(sub)
    VB=(v_*(d1+d2)+uB_*q*(d1+d2)-(2*(d1**2+d2**2)+g_*(d1+d2)**2)/(4*(1+g_))-pp1*d1-pp2*d2)
    return dict(d1=d1,d2=d2,q=q,VB=VB,VS=q**2/2,
                Pi2=(pp2+r_)*d2+x2*q, W=VB+q**2/2+(pp1+r_)*d1+x1*q+(pp2+r_)*d2+x2*q)
B=pk(P1b.subs({a1_:0,a2_:a2b}),P2b.subs({a1_:0,a2_:a2b}),0,a2b)
Mg=pk(P1m.subs({a1_:aM,a2_:aM}),P2m.subs({a1_:aM,a2_:aM}),aM,aM)
ar=(uB_,uS_,s_,v_,r_); LL=lambda e: sp.lambdify(ar,e,'numpy')
F={}
for tag,d in (('b',B),('m',Mg)):
    for k in ('d1','d2','q','VB','VS','Pi2','W'): F[k+tag]=LL(d[k])
Ra=lambda S:(3*S**3+21*S**2+48*S+32)/(2*(S+2)*(3*S+4))

print("\nEXTENSION 2 — M_2 integre : parts de l'ensemble admissible")
print("  %-7s %-9s %-9s %-9s %-9s %-9s" % ("gamma","adm.","dW>0","dPi_2>0","dV_B>0","dV_S>0"))
for G in GS:
    n=dW=dP=dB=dS=0
    for xx in GR:
        for yy in GR:
            if 1-2*xx*yy<=0: continue
            S=G-2*xx*yy*(1+G)
            if S<0: continue
            try: vv={k:F[k](xx,yy,S,V,R) for k in F}
            except Exception: continue
            if min(vv['d1b'],vv['d2b'],vv['qb'],vv['d1m'],vv['d2m'],vv['qm'])<=0: continue
            n+=1
            dW += vv['Wm']-vv['Wb']>0 ; dP += vv['Pi2m']-vv['Pi2b']>0
            dB += vv['VBm']-vv['VBb']>0 ; dS += vv['VSm']-vv['VSb']>0
    print("  %-7s %-9d %-9s %-9s %-9s %-9s" % (G,n,"%.0f%%"%(100*dW/n),
        "%.0f%%"%(100*dP/n),"%.0f%%"%(100*dB/n),"%.0f%%"%(100*dS/n)))
