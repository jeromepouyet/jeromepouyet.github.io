# -*- coding: utf-8 -*-
"""rep4_efficiency.py -- efficiency gains, coordination motives and porting
costs.  Replaces verify_two.py, oa_support.py, verifA.py and verifG.py.

Three premia are treated by one template.  An efficiency gain gives the
integrated platform a better per-user benefit r_0 > r; a coordination motive
gives every buyer an extra gross benefit alpha_B when both manufacturers run
the same system; a porting cost c gives the same lift through the application
stock, with c u_B in the role of alpha_B.  In each case the rival's hosted and
walk-off markups are linear in the fee with the SAME slope, so the fee cancels
from the participation constraint and the threshold share is a pure function of
the premium and of sigma.

The difference that matters: an efficiency gain accrues to a hosted rival
whatever the other manufacturer does, whereas a coordination premium requires
both manufacturers on the platform's system.  A lone adopter therefore gets no
premium, so under coordination motives joint refusal survives at every capped
package (a_kill <= 0), while under dominance it does not.  The separation
benchmark under a coordination motive is nonetheless distorted: the
independent platform prices the premium subject to the selection rule (the
compensated locus, test B.4 below) AND to joint adoption being an equilibrium
(a lone walker keeps the whole per-user benefit), a floor on the share that
this file does not treat; the full benchmark, its regimes and the merger's
increments against it are in rep34_coordination.py.  Block C below reads the
polar case u_S = 0 against the undistorted benchmark only.
"""
import numpy as np
import sympy as sp
from rep_core import V_DEF, R_DEF, sigma_of, Mof

V, R = V_DEF, R_DEF

def beta_bar_r0(sig, r0, r=R):
    """Rival's participation share under a merger-created efficiency gain."""
    return 1.0 - (1.0 - r/r0)*(8 + sig*(8+sig))/(8*(1+sig))

def beta_tilde(sig, aB, r=R):
    """Rival's participation share under a coordination motive alpha_B."""
    return 1.0 - (aB/r)*(4+3*sig)/(4*(1+sig))

def beta_tilde_porting(sig, c, uB, r=R):
    """Same threshold with the application gain c u_B in the role of alpha_B."""
    return beta_tilde(sig, c*uB, r)

# ------------------------------------------------------------------ symbolic
def symbolic():
    uB,uS,v,r,r0,g,aB = sp.symbols('u_B u_S v r r_0 gamma alpha_B', positive=True)
    a, beta = sp.Symbol('a'), sp.Symbol('beta')
    p1, p2 = sp.symbols('p1 p2'); S = sp.Symbol('sigma')
    s = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
    ok = lambda c: "PASS" if c else "**FAIL**"
    T  = lambda e: e.subs(S, s)

    def eq(Vint, b1, b2, a_, integrated=True, b2_margin=None):
        D1 = (2*Vint-(2+s)*p1+s*p2-2*uB*a_)/(2*M)
        D2 = (2*Vint-(2+s)*p2+s*p1-2*uB*a_)/(2*M)
        DS = (uS*(2*Vint-p1-p2)-a_)/M
        if integrated:
            obj = (p1+b1)*D1 + a_*DS + (b2_margin if b2_margin is not None else 0)*D2
            fo1 = sp.diff(obj, p1)
        else:
            fo1 = sp.diff((p1+b1)*D1, p1)
        sol = sp.solve([fo1, sp.diff((p2+b2)*D2, p2)], [p1, p2], dict=True)[0]
        return sol

    print("A. Participation thresholds\n")
    # --- efficiency gain r_0
    sH = eq(v, r0, beta*r0, a, True, r0-beta*r0)
    sW = eq(v, r0, r,       a, True, 0)
    m2H = sp.simplify(sH[p2] + beta*r0); m2W = sp.simplify(sW[p2] + r)
    slope = -(2*uB*(4+3*S)+2*S*uS)/((4+S)*(4+3*S))
    print("   1. hosted and walk-off markups share the fee slope        :",
          ok(sp.simplify(sp.diff(m2H,a)-T(slope)) == 0 and
             sp.simplify(sp.diff(m2W,a)-T(slope)) == 0))
    bb = sp.solve(sp.Eq(m2H, m2W), beta)
    print("   2. bar-beta(r_0) = 1-(1-r/r_0)(8+s(8+s))/(8(1+s))         :",
          ok(len(bb) == 1 and
             sp.simplify(bb[0]-T(1-(1-r/r0)*(8+S*(8+S))/(8*(1+S)))) == 0))
    print("      free of the fee, and decreasing in r_0                 :",
          ok(sp.simplify(sp.diff(sp.simplify(bb[0]), a)) == 0 and
             sp.simplify(sp.diff(sp.simplify(bb[0]), r0)
                         + r*T(8+S*(8+S))/(8*r0**2*(s+1))) == 0))
    # --- coordination motive alpha_B
    sC  = eq(v+aB, r, beta*r, a, True, r-beta*r)
    sCw = eq(v,    r, r,      a, True, 0)
    bt = sp.solve(sp.Eq(sp.simplify(sC[p2]+beta*r), sp.simplify(sCw[p2]+r)), beta)
    print("   3. beta-tilde = 1-(alpha_B/r)(4+3s)/(4(1+s))              :",
          ok(len(bt) == 1 and sp.simplify(bt[0]-T(1-(aB/r)*(4+3*S)/(4*(1+S)))) == 0))
    print("      free of the fee                                        :",
          ok(len(bt) == 1 and sp.simplify(sp.diff(sp.simplify(bt[0]), a)) == 0))

    print("\nB. The separation benchmark under a coordination motive\n")
    # --- compensated locus: both hosted (premium active) against joint refusal
    sB = eq(v+aB, beta*r, beta*r, a, False)
    sN = eq(v,    r,      r,      0, False)
    loc = sp.solve(sp.Eq(sp.simplify(sB[p1]+beta*r), sp.simplify(sN[p1]+r)), beta)
    print("   4. compensated locus  beta r = r - alpha_B + u_B a        :",
          ok(len(loc) == 1 and sp.simplify(loc[0]*r-(r-aB+uB*a)) == 0))
    # --- a_kill: a lone adopter earns no premium, so the baseline applies
    sD = eq(v, beta*r, r, a, False); sR = eq(v, r, r, 0, False)
    D1D = ((2*v-(2+s)*p1+s*p2-2*uB*a)/(2*M)).subs(sD)
    D1R = ((2*v-(2+s)*p1+s*p2)/(2*M)).subs(sR).subs(a, 0)
    roots = sp.solve(sp.Eq(sp.simplify((sD[p1]+beta*r)*D1D),
                           sp.simplify((sR[p1]+r)*D1R)), a)
    akill = (beta*r-r)*(8+S*(8+S))/(2*uB*(4+3*S))
    print("   5. a_kill = (beta r - r)Lambda/(2 u_B(4+3s)) <= 0 at beta<=1:",
          ok(any(sp.simplify(sp.factor(z-T(akill))) == 0 for z in roots)))

# ------------------------------------------------------------------- numeric
def polar_uS_zero(g=4.0, aB=0.2, v=V, r=R):
    """Polar case u_S = 0 under a coordination motive, against the UNDISTORTED
    benchmark: the share tilde-beta is set first, the fee is then optimal at
    that share, and every constituency weakly gains.  Against the corrected
    benchmark (rep34_coordination.py, block E) the rival, the buyers and
    welfare lose near the origin."""
    print("\nC. Polar case u_S = 0 under a coordination motive (alpha_B = %.2f, gamma = %.0f)" % (aB, g))
    sg = g                                             # u_S = 0 gives sigma = gamma
    bt = beta_tilde(sg, aB, r)
    print("   beta-tilde = %.4f (independent of u_B at u_S = 0)" % bt)
    print("   %-8s %-10s %-12s %-12s %-12s" % ("u_B","a-tilde","d pi_2","d V_B","d V_S"))
    for uB in (0.05, 0.2, 0.5, 0.8):
        def state(beta2, a_, Vint):
            A = np.array([[-2*(2+sg), sg], [sg, -2*(2+sg)]])
            rhs = np.array([-(2*Vint-2*uB*a_) + (2+sg)*r + 0.0 - sg*(r-beta2*r),
                            -(2*Vint-2*uB*a_) + (2+sg)*beta2*r])
            P = np.linalg.solve(A, rhs)
            D1 = (2*Vint-(2+sg)*P[0]+sg*P[1]-2*uB*a_)/2
            D2 = (2*Vint-(2+sg)*P[1]+sg*P[0]-2*uB*a_)/2
            q  = -a_                                    # u_S = 0
            return P, D1, D2, q
        def platform(a_):
            P, D1, D2, q = state(bt, a_, v+aB)
            return (P[0]+r)*D1 + a_*q + (r-bt*r)*D2
        xs = np.array([-1., 0., 1.]); c2, c1, c0 = np.polyfit(xs, [platform(t) for t in xs], 2)
        at = -c1/(2*c2)
        P, D1, D2, q = state(bt, at, v+aB)
        Pb, Db1, Db2, qb = state(1.0, 0.0, v)           # separation benchmark
        pi2, pi2b = (P[1]+bt*r)*D2, (Pb[1]+r)*Db2
        VB  = ((v+aB)*(D1+D2) + uB*q*(D1+D2)
               - (2*(D1**2+D2**2)+g*(D1+D2)**2)/(4*(1+g)) - P[0]*D1 - P[1]*D2)
        VBb = (v*(Db1+Db2) + uB*qb*(Db1+Db2)
               - (2*(Db1**2+Db2**2)+g*(Db1+Db2)**2)/(4*(1+g)) - Pb[0]*Db1 - Pb[1]*Db2)
        print("   %-8.2f %-10.4f %-+12.5f %-+12.5f %-+12.5f"
              % (uB, at, pi2-pi2b, VB-VBb, 0.5*q*q - 0.5*qb*qb))

if __name__ == "__main__":
    print("rep4_efficiency\n")
    symbolic()
    polar_uS_zero()
