# -*- coding: utf-8 -*-
"""rep30_soc_identity.py -- the second-order condition of the two-host program.

Two facts, both symbolic:

  (1) the Delta of Lemma B.1 (two-host program, Online Appendix B.7) is the
      SAME polynomial as the Delta_delta of Section B.5.4 (dominance), once
      gamma is written through sigma;
  (2) the identity proved there,
        (18 s^3+100 s^2+192 s+128) Delta
             = -2(s+4) N_2 + 2(13 s^3+64 s^2+112 s+64)(u_B-u_S)^2,
      has positive coefficients in both bracketed polynomials, so N_2 < 0
      implies Delta > 0.

This is Corollary B.3: the second-order condition of the two-host program
holds everywhere on the admissible set A* = {N_2 < 0, D_2(a**) > 0} on which
Section 4 is stated.  It is not implied by H > 0 alone: at sigma = 0,
H > 0 reads u_B^2 + 4 u_B u_S + u_S^2 < 4 while Delta > 0 reads
u_B^2 + 6 u_B u_S + u_S^2 < 4.

Run: python3 rep30_soc_identity.py    (a few seconds)
"""
import sympy as sp
uB,uS,g,s = sp.symbols('u_B u_S gamma sigma', positive=True)
# Delta of Lemma B.1 (two-host second-order condition)
Delta_2h = 2*(g+4) - (s+2)*(uB**2+uS**2) - 2*(2*g+s+8)*uB*uS
# Delta_delta of the dominance appendix
Delta_dom = 2*(s+4) - 8*uB*uS - (s+2)*(uB+uS)**2
# substitute gamma = (sigma + 2 uB uS)/(1 - 2 uB uS)
gam = (s + 2*uB*uS)/(1 - 2*uB*uS)
d1 = sp.simplify(sp.together(Delta_2h.subs(g, gam)))
print("Delta_2h(gamma->sigma) - Delta_dom  =", sp.simplify(d1 - Delta_dom))
# the concavity identity of the dominance appendix
N2 = (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
      + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))
P1 = 18*s**3+100*s**2+192*s+128
P2 = 2*(13*s**3+64*s**2+112*s+64)
print("identity residual:", sp.simplify(sp.expand(P1*Delta_dom + 2*(s+4)*N2 - P2*(uB-uS)**2)))
print("P1 coeffs:", sp.Poly(P1,s).all_coeffs(), " P2 coeffs:", sp.Poly(P2,s).all_coeffs())

# the sigma = 0 comparison quoted in the corollary
s0 = 0
H0 = sp.expand(((s0+4)**2*(3*s0+4)**2 - 2*(s0+2)*(3*s0+4)**2*uB**2
      - 2*(3*s0+4)*(s0*(7*s0+32)+32)*uB*uS
      - 2*(s0*(s0*(7*s0+40)+64)+32)*uS**2)/64)
D0 = sp.simplify(sp.factor(Delta_dom.subs(s, s0)))
print("at sigma=0:  H>0     <=>", sp.expand(-H0), "< 0")
print("             Delta>0 <=>", sp.expand(-D0/2), "< 0")
