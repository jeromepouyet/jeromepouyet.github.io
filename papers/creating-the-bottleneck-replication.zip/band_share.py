# -*- coding: utf-8 -*-
"""band_share.py -- the band of Proposition 6(i): its share of the admissible
set by gamma, the identity R_a - R_Phi, and its monotonicity in sigma.
Produces the three percentages quoted in Section 4 (gamma = 1, 4, 16)."""
import numpy as np
from rep_core import V_DEF, R_DEF, sigma_of, Mof, demands, prices_int, Hval, N2val
from rep1_frontiers import a_star
V, R = V_DEF, R_DEF
RA  = lambda s: (3*s*(s*(s+7)+16)+32)/(2*(s+2)*(3*s+4))
RPH = lambda s: (8+s*(8+s))/(4+3*s)
def adm(uB,uS,g):
    if Mof(uB,uS)<=0: return None
    s = sigma_of(uB,uS,g)
    if s<0 or Hval(uB,uS,s)<=0: return None
    if N2val(uB,uS,s)>=0: return None
    a = a_star(uB,uS,s); p1,p2 = prices_int(uB,uS,s,R,a)
    if demands(uB,uS,s,p1,p2,a)[1]<=0: return None
    return s
GR = np.arange(0.02,1.4001,0.002)
print("gamma   |A|    band   share    (band = R_Phi <= uB/uS < R_a)")
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    tot=band=tax=0
    for uB in GR:
        for uS in GR:
            s = adm(uB,uS,g)
            if s is None: continue
            tot+=1; r=uB/uS
            if r < RA(s): tax+=1
            if RPH(s) <= r < RA(s): band+=1
    print("%5.1f %6d %6d  %6.2f%%   (taxing %d = %.1f%%)"%(g,tot,band,100*band/tot,tax,100*tax/tot))
# monotonicity of the gap in sigma
import sympy as sp
sg = sp.symbols('sigma', nonnegative=True)
gap = sp.simplify(sp.Rational(1,1)*((3*sg*(sg*(sg+7)+16)+32)/(2*(sg+2)*(3*sg+4)) - (8+sg*(8+sg))/(4+3*sg)))
print("\nR_a - R_Phi =", sp.factor(sp.cancel(gap)))
d = sp.cancel(sp.together(sp.diff(gap, sg)))
n,dd = sp.fraction(d)
print("d/dsigma numerator coeffs :", set(np.sign(np.array(sp.Poly(sp.expand(n),sg).all_coeffs(),dtype=float))))
print("d/dsigma denominator coeffs:", set(np.sign(np.array(sp.Poly(sp.expand(dd),sg).all_coeffs(),dtype=float))))
