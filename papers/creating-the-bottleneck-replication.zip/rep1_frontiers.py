# -*- coding: utf-8 -*-
"""rep1_frontiers.py -- the admissible set, the psi-locus exclusion, and
interiority at the integrated optimum.  Replaces verifA2.py, verifC.py,
verifF.py and verifH.py (verifJ.py, which covers the same locus from the other
side, is unchanged and still runs).

Section A is symbolic and establishes the complements-range exclusion of
Proposition (complements)(i) as polynomial identities.  Section B is the
interiority and publication audit at a**.
"""
import numpy as np
import sympy as sp
from rep_core import (surpluses, prices_sep, V_DEF, R_DEF, sigma_of, Mof, demands, prices_int,
                      Hval, N2val)

V, R = V_DEF, R_DEF

def psi(s):
    """The locus u_B/u_S = psi(|sigma|) of the complements proposition."""
    return 2*s*(2-s)/((4-2*s)*(4-3*s))

def s_star(g):
    return 2*g/(3*g+2)

# ------------------------------------------------------------------ symbolic
def symbolic():
    g, s, rho, v, r = sp.symbols('gamma s rho v r', positive=True)
    a, p1, p2 = sp.symbols('a p1 p2')
    w = (g+s)/(2*(1+g)); sig = -s                     # complements: sigma = -s
    ok = lambda c: "PASS" if c else "**FAIL**"
    P = psi(s)
    # H on a sigma-slice: u_B^2 = w rho, u_B u_S = w, u_S^2 = w / rho
    A = -2*(sig+2)*(3*sig+4)**2*w
    B = (sig+4)**2*(3*sig+4)**2 - 2*(3*sig+4)*(sig*(7*sig+32)+32)*w
    C = -2*(sig*(sig*(7*sig+40)+64)+32)*w
    print("A. The psi-locus exclusion (complements range)\n")
    print("   1. H on the locus reduces to the printed factorization      :",
          ok(sp.simplify(A*P + B + C/P
                         - (s-4)**2*(s-1)*(3*s-4)*(s*(3*g+2)-2*g)/(s*(g+1))) == 0))
    print("      hence H(psi) < 0 iff s < s* = 2g/(3g+2)                  :",
          ok(sp.simplify(sp.factor((s*(3*g+2)-2*g)) - (3*g+2)*(s - s_star(g))) == 0))
    print("   2. H is concave in rho along a slice (C < 0)                :",
          ok(sp.simplify(sp.factor(C) - (g+s)*(7*s**3-40*s**2+64*s-32)/(g+1)) == 0))
    # H'(rho) = (A rho^2 - C)/rho^2, so the tangent slope at psi has the sign of
    # A psi^2 - C.  The appendix writes the same quantity; the printed order
    # C - A psi^2 is a sign slip.
    print("   3. H'(psi) prop. to A psi^2 - C = 4w(1-s)(3s^2-16s+16) > 0  :",
          ok(sp.simplify(A*P**2 - C - 4*w*(1-s)*(3*s**2-16*s+16)) == 0))
    # m_1(a**) H = (v+r)(3s-4) F(rho) / (rho (gamma+1)), F linear in rho
    uB = sp.sqrt(w*rho); uS = sp.sqrt(w/rho); M = 1-2*uB*uS
    D1 = (2*v-(2+sig)*p1+sig*p2-2*uB*a)/(2*M); D2 = (2*v-(2+sig)*p2+sig*p1-2*uB*a)/(2*M)
    DS = (uS*(2*v-p1-p2)-a)/M
    obj = (p1+r)*D1 + a*DS
    sol = sp.solve([sp.diff(obj,p1), sp.diff((p2+r)*D2,p2)], [p1,p2], dict=True)[0]
    astar = sp.simplify(sp.solve(sp.diff(sp.simplify(obj.subs(sol)), a), a)[0])
    m1 = sp.simplify((sol[p1]+r).subs(a, astar))
    H = (A*rho + B + C/rho)
    F = sp.simplify(sp.simplify(m1*H)*rho*(g+1)/((v+r)*(3*s-4)))
    print("   4. m_1(a**) H = (v+r)(3s-4) F(rho)/(rho(g+1)), F affine     :",
          ok(sp.degree(sp.Poly(sp.expand(F), rho)) == 1))
    print("      F(0)   = 2(g+s)(s^2-6s+6) > 0 on (0,1)                   :",
          ok(sp.simplify(F.subs(rho,0) - 2*(g+s)*(s**2-6*s+6)) == 0))
    print("      F(psi) = (3g+s)(4-s)(1-s) > 0 on (0,1)                   :",
          ok(sp.simplify(F.subs(rho,P) - (3*g+s)*(4-s)*(1-s)) == 0))

# ------------------------------------------------------------------- numeric
def a_star(uB, uS, sig, v=V, r=R):
    num = 2*(v+r)*((3*sig*(sig*(sig+7)+16)+32)*uS - 2*(sig+2)*(3*sig+4)*uB) \
          / ((sig+4)**2*(3*sig+4)*Mof(uB,uS))
    den = -2*Hval(uB,uS,sig)/((sig+4)**2*(3*sig+4)**2*Mof(uB,uS))
    return -num/den

def interiority(step=0.02, lo=0.02, hi=1.40, gammas=(0.5, 1.0, 2.0, 4.0, 8.0, 16.0)):
    print("\nB. Interiority and publication at the integrated optimum a**")
    gr = np.arange(lo, hi + step/2, step)          # reference grid
    tot = pubf = neg = badpos = 0; mins = 1e9; us_neg = []; us_bad = []
    for g in gammas:
        for uB in gr:
            for uS in gr:
                if Mof(uB,uS) <= 0: continue
                sig = sigma_of(uB,uS,g)
                if sig < 0 or Hval(uB,uS,sig) <= 0: continue   # baseline set A
                a = a_star(uB,uS,sig)
                p1, p2 = prices_int(uB, uS, sig, R, a)   # M2 outside: b2 = r
                D1, D2, q = demands(uB, uS, sig, p1, p2, a)
                tot += 1
                if min(D1,D2) <= 0 or q <= 0 or p2+R <= 0: badpos += 1; us_bad.append(uS)
                sl = uS*D1 - a
                if sl < 0: pubf += 1
                mins = min(mins, sl)
                if p1 + R < 0: neg += 1; us_neg.append(uS)
    print("   reference grid (step %.2f on [%.2f,%.2f]), H > 0 and sigma >= 0, gamma in %s: %d points"
          % (step, lo, hi, list(gammas), tot))
    print("   publication u_S n_B^I >= a**      : %d failures, minimal slack %.4f" % (pubf, mins))
    print("   rival's demand D_2(a**) > 0       : %d failures (these are what A removes), all with u_S >= %.2f"
          % (badpos, min(us_bad) if us_bad else float('nan')))
    print("   integrated firm's own margin < 0  : %d points (%.0f%%), all with u_S >= %.2f"
          % (neg, 100*neg/tot, min(us_neg) if us_neg else float('nan')))
    # the headline shares of Section 3 on A and on its positive-margin subset
    # (Refine 2, overall point 4): does retaining the loss-leader points move them?
    print("   headline shares on A, and on the subset where p_1^I + r >= 0:")
    print("   %-6s %6s %6s | %-27s | %-27s" % ("gamma", "|A|", "subset", "A: pi2>0  VB>0  VS>0  W>0", "subset: pi2>0 VB>0 VS>0 W>0"))
    for g in gammas:
        nA = np.zeros(4); nS = np.zeros(4); cA = cS = 0
        for uB in gr:
            for uS in gr:
                if Mof(uB,uS) <= 0: continue
                sig = sigma_of(uB,uS,g)
                if sig < 0 or Hval(uB,uS,sig) <= 0: continue
                a = a_star(uB,uS,sig)
                p1, p2 = prices_int(uB, uS, sig, R, a)
                D1, D2, q = demands(uB, uS, sig, p1, p2, a)
                if min(D1,D2) <= 0 or q <= 0 or p2+R <= 0: continue     # A
                VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
                q1, q2 = prices_sep(uB, uS, sig, R, R, 0.0)
                E1, E2, q0 = demands(uB, uS, sig, q1, q2, 0.0)
                VB0, VS0 = surpluses(uB, uS, g, q1, q2, E1, E2, q0)
                pi2, pi20 = (p2+R)*D2, (q2+R)*E2
                W = (p1+R)*D1 + a*q + pi2 + VB + VS; W0 = 2*pi20 + VB0 + VS0
                d = np.array([pi2-pi20 > 0, VB-VB0 > 0, VS-VS0 > 0, W-W0 > 0], float)
                nA += d; cA += 1
                if p1 + R >= 0: nS += d; cS += 1
        print("   %-6g %6d %6d | %5.0f%% %5.0f%% %5.0f%% %5.0f%%  | %5.0f%% %5.0f%% %5.0f%% %5.0f%%"
              % (g, cA, cS, *(100*nA/cA), *(100*nS/cS)))

def h_S(uB, g):
    """Frontier above which the developer gains from the merger."""
    return 0.5*(np.sqrt(2*(g+4) + (g+3)**2*uB**2) - (g+3)*uB)

def welfare_map(n=110, lo=0.02, hi=2.0):
    """Shares of the baseline admissible set A by configuration, as functions of
    product-market competition.  Supports the summary table, the impact figure,
    and the introduction's statement on the disconnect between harm to the rival
    and harm to consumers."""
    from rep_core import surpluses, prices_int, demands
    print("\nC. The welfare map across gamma, on the baseline set A")
    print("   %-7s %-8s %-8s %-8s %-9s %-11s %-8s"
          % ("gamma","points","both","neither","exactly 1","developer +","a** > 0"))
    gr = np.linspace(lo, hi, n)
    def st(uB, uS, g, a):
        sig = sigma_of(uB,uS,g); p1,p2 = prices_int(uB,uS,sig,R,a)
        D1,D2,q = demands(uB,uS,sig,p1,p2,a); VB,VS = surpluses(uB,uS,g,p1,p2,D1,D2,q)
        return D2, VB, (p2+R)*D2
    for g in (0.5,1.0,2.0,4.0,8.0,12.0,16.0):
        tot=both=none=one=dev=tax=0
        for uB in gr:
            for uS in gr:
                if Mof(uB,uS) <= 0: continue
                sig = sigma_of(uB,uS,g)
                if sig < 0 or Hval(uB,uS,sig) <= 0: continue
                a = a_star(uB,uS,sig)
                D2, VB, pi2 = st(uB,uS,g,a)
                if D2 <= 0: continue                       # the second condition of A
                _, VB0, pi20 = st(uB,uS,g,0.0)
                tot += 1
                hr, hc = pi2 < pi20, VB < VB0
                if hr and hc: both += 1
                elif not hr and not hc: none += 1
                else: one += 1
                if uS >= h_S(uB,g): dev += 1
                if a > 0: tax += 1
        print("   %-7.1f %-8d %-8s %-8s %-9s %-11s %-8s"
              % (g, tot, "%.0f%%"%(100*both/tot), "%.0f%%"%(100*none/tot),
                 "%.0f%%"%(100*one/tot), "%.1f%%"%(100*dev/tot), "%.0f%%"%(100*tax/tot)))

if __name__ == "__main__":
    print("rep1_frontiers\n")
    symbolic()
    interiority()
    welfare_map()
