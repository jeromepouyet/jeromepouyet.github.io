# -*- coding: utf-8 -*-
"""rep29_Wsep_monotone.py -- is separation welfare decreasing in the premium
for EVERY delta, or only at delta = 0?

Proposition B.4 signs dW_sep/ddelta at delta = 0 on the two limit branches.
Here W_sep is evaluated at the exact benchmark, the asymmetric programme of
rep5_dominance.benchmark_asym, along a fine grid in delta, and its
monotonicity is tested point by point.  (The symmetric programme sep_opt is
kept below for reference only.)
"""
from rep5_dominance import benchmark_asym
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
P = lambda *a: print(*a, flush=True)
P("="*74); P("rep29 -- W_sep decreasing in delta beyond delta = 0?"); P("="*74)

uB,uS,s,v,r,d,x,a,b,p1,p2 = sp.symbols('u_B u_S sigma v r delta x a b p_1 p_2', positive=True)
M=1-2*uB*uS; Lam=8+s*(8+s); kap=Lam/(2*uB*(4+3*s)); S=2+s; T=s+4-4*uB*uS; w=v+r-d
def dem(P1,P2,A): return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
                          (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),(uS*(2*v-P1-P2)-A)/M)
g_=(s+2*uB*uS)/M
def surp(P1,P2,D1,D2,Q):
    return (v*(D1+D2)+uB*Q*(D1+D2)-(2*(D1**2+D2**2)+g_*(D1+D2)**2)/(4*(1+g_))
            -P1*D1-P2*D2), Q**2/2
D1e,D2e,QSe=dem(p1,p2,a)
sep=sp.solve([sp.diff((p1+b)*D1e,p1),sp.diff((p2+b)*D2e,p2)],[p1,p2],dict=True)[0]
P1s,P2s=sp.cancel(sep[p1]),sp.cancel(sep[p2]); D1s,D2s,Qs=dem(P1s,P2s,a)
VBs,VSs=surp(P1s,P2s,D1s,D2s,Qs); pi1s=(P1s+b)*D1s
# NB: the platform's profit uses the true benefit r, the manufacturers the
# perceived benefit b = beta r; W = V_B + V_S + 2 pi + Pi.
Wsep = VBs+VSs+2*pi1s+2*(r-b)*D1s+a*Qs
fW = sp.lambdify((uB,uS,s,v,r,b,a), Wsep, 'numpy')

N=2*S*(d-x)*(w+x-uB*a)+2*uS*S*a*(w+x)-T*a**2
Nx,Na=sp.diff(N,x),sp.diff(N,a); f=lambda e: sp.lambdify((uB,uS,s,v,r,d),e,'numpy')
fasb=f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,0),0),a)[0]))
facp=f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,d),0),a)[0]))
fxst=f(sp.cancel(sp.solve(sp.Eq(sp.diff(sp.expand(N.subs(a,kap*x)),x),0),x)[0]))
_si=sp.solve([sp.Eq(Nx,0),sp.Eq(Na,0)],[x,a],dict=True)[0]
fxo,fao=f(sp.cancel(_si[x])),f(sp.cancel(_si[a])); fkap=f(kap)
fl1=sp.lambdify((uB,uS,s,v,r,d,x,a),Na,'numpy')
fl23=sp.lambdify((uB,uS,s,v,r,d,x,a),sp.cancel(sp.together(Nx+kap*Na)),'numpy')
fN=sp.lambdify((uB,uS,s,v,r,d,x,a),N,'numpy'); TOL=1e-9
def sep_opt(UB,US,SG,D):
    K=fkap(UB,US,SG,V,R,D); asb=fasb(UB,US,SG,V,R,D); acp=facp(UB,US,SG,V,R,D)
    xs=fxst(UB,US,SG,V,R,D); xo=fxo(UB,US,SG,V,R,D); ao=fao(UB,US,SG,V,R,D)
    L1=lambda X,A: fl1(UB,US,SG,V,R,D,X,A); L23=lambda X,A: fl23(UB,US,SG,V,R,D,X,A)
    c=[]
    if L1(0.,0.)>=-TOL and -L23(0.,0.)>=-TOL: c.append((0.,0.))
    if asb<=TOL and -L23(0.,asb)+K*L1(0.,asb)>=-TOL: c.append((0.,asb))
    if -TOL<=xs<=D+TOL and L1(xs,K*xs)>=-TOL: c.append((xs,K*xs))
    if L1(D,K*D)>=-TOL and L23(D,K*D)>=-TOL: c.append((D,K*D))
    if acp<=K*D+TOL and L23(D,acp)-K*L1(D,acp)>=-TOL: c.append((D,acp))
    if -TOL<=xo<=D+TOL and ao<=K*xo+TOL: c.append((xo,ao))
    if not c: return None
    vals=[fN(UB,US,SG,V,R,D,X,A) for X,A in c]
    X,A=c[int(np.argmax(vals))]
    return R-D+X, A

GRID=np.arange(0.02,1.4001,0.02)
DD=np.arange(0.0, 0.4801, 0.01)
P("\n  delta from 0 to 0.48 in steps of 0.01 (r = 0.5)")
P("  %-6s %6s | %-28s %-28s" % ("gamma","n","points where W_sep rises","largest rise"))
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    pts=[(x1,x2,sigma_of(x1,x2,G)) for x1 in GRID for x2 in GRID
         if Mof(x1,x2)>0 and sigma_of(x1,x2,G)>=0 and N2val(x1,x2,sigma_of(x1,x2,G))<0]
    bad=0; worst=0.0; worst_at=None; tot=0; notsub=0; regs={}
    for (X1,X2,SG) in pts:
        Wv=[]; Av=[]; Rg=[]
        for D in DD:
            o=benchmark_asym(X1,X2,G,D)
            if o is None: Wv.append(np.nan); Av.append(np.nan); Rg.append(None); continue
            Wv.append(o['W']); Av.append(o['a']); Rg.append(o['regime'])
        Wv=np.array(Wv); Av=np.array(Av); dv=np.diff(Wv)
        tot+=1
        up=dv[dv>1e-12]
        if up.size:
            bad+=1
            if up.max()>worst: worst=up.max(); worst_at=(X1,X2,SG)
            # is the benchmark subsidizing (a_sep < 0) at every premium where W_sep rises?
            idx=np.where(dv>1e-12)[0]
            if np.any(Av[1:][idx] >= 0):
                notsub+=1
                # the regime the benchmark enters where W_sep rises at a non-negative fee
                for i in idx:
                    if Av[i+1] >= 0:
                        k=Rg[i+1]; regs[k]=regs.get(k,0)+1
    P("  %-6g %6d | %-28s %-28s  rises at a non-negative fee: %d %s" % (G, tot, "%d (%.2f%%)"%(bad,100.*bad/tot),
      "%.2e at (%.2f,%.2f)"%(worst,worst_at[0],worst_at[1]) if worst_at else "none", notsub,
      ("(regime entered, by rise: %s)" % regs) if regs else ""))
P("\n  A point counts as a rise if W_sep increases between two consecutive")
P("  premia, by more than 1e-12 in absolute value.")
