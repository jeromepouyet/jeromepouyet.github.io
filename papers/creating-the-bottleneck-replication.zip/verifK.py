# -*- coding: utf-8 -*-
"""verifK.py -- The calibrated single-host path (Online Appendix, contracts;
revision of August 2026).

Structure on the path (beta = bar-beta(a)): D1 pinned at the benchmark level,
host profit pinned at pi-bench, Phi'' = 2 dq/da. First-order identities:
  dm2/da   = -4 u_B (sigma+1)/(sigma^2+8 sigma+8) < 0
  dq/da    = Phi''/2 < 0 wherever the calibrated problem is concave
  DVB'(0)  = -2 u_B (v+r)(sigma+1)(sigma+2)^2
             /[(sigma+4) M^2 (sigma^2+8 sigma+8)] < 0
  DW'(0)   = -2 u_B (v+r)(sigma+2) X /[(sigma+4) M^2 (sigma^2+8 sigma+8)],
             X > (sigma+1)(sigma+2)(1+2 u_S^2) > 0 using 2 u_B u_S < 1.
At a-hat: all four surplus changes negative at every admissible single-host
grid point (numeric block).
Run: python3 verifK.py   (a few minutes)
"""
import sympy as sp
import numpy as np

uB, uS, g, v, r = sp.symbols('u_B u_S gamma v r', positive=True)
a, p1, p2, be = sp.symbols('a p_1 p_2 beta')
sig = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
S = sp.Symbol('sigma')
_x,_y,_f = sp.symbols('_x _y _f')
Dk = (2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DSx = (uS*(2*v-_x-_y)-_f)/M
D1 = Dk.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
D2 = Dk.subs({_x:p2,_y:p1,_f:a}, simultaneous=True)
DSe = DSx.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
solh = sp.solve([sp.diff((p1+be*r)*D1, p1), sp.diff((p2+r)*D2, p2)],
                [p1,p2], dict=True)[0]
D1h = D1.subs(solh); D2h = D2.subs(solh); DSh = DSe.subs(solh)
Dbench = D1h.subs({be:1, a:0})
bb = sp.solve(sp.Eq(D1h, Dbench), be)[0]
sub = lambda e: e.subs(be, bb)
d1 = sub(D1h); d2 = sub(D2h); q = sub(DSh)
pr1 = sub(solh[p1]); pr2 = sub(solh[p2])
Phi = sub(-(be-1)*r*D1h + a*DSh)
gg = sp.solve(sp.Eq(S, sig), g)[0]
sform = lambda e: sp.factor(sp.cancel(sp.together(e).subs(g, gg)))

print("path structure:")
print("  D1 - Dbench on path:", sp.simplify(d1 - Dbench))
pihost = sp.expand((pr1+bb*r)*d1); pib = sp.expand(pihost.subs(a,0))
print("  host profit constant:", sp.simplify(pihost - pib))
print("  Phi'' - 2 dq/da:", sp.simplify(sp.diff(Phi,a,2) - 2*sp.diff(q,a)))
print("  bar-beta'(a) =", sform(sp.diff(bb, a)))
print("  dm2/da =", sform(sp.diff(pr2+r, a)))
print("  dq/da  =", sform(sp.diff(q, a)))
VB = (v*(d1+d2) + uB*q*(d1+d2) - (2*(d1**2+d2**2)+g*(d1+d2)**2)/(4*(1+g))
      - pr1*d1 - pr2*d2)
piO = (pr2+r)*d2
DW = VB - VB.subs(a,0) + (q**2 - (q.subs(a,0))**2)/2 + piO - piO.subs(a,0) + Phi
c1VB_claim = (-2*uB*(v+r)*(sig+1)*(sig+2)**2
              /((sig+4)*(1-2*uB*uS)**2*(sig**2+8*sig+8)))
Xbr = (2*sig**2*uS**2 + sig**2 - 14*sig*uB*uS + 6*sig*uS**2 + 10*sig
       - 16*uB*uS + 4*uS**2 + 10)
c1DW_claim = (-2*uB*(v+r)*(sig+2)*Xbr
              /((sig+4)*(1-2*uB*uS)**2*(sig**2+8*sig+8)))
print("  DVB'(0) residual:", sp.simplify(sp.cancel(sp.together(
      sp.diff(VB, a).subs(a,0) - c1VB_claim))))
print("  DW'(0) residual:", sp.simplify(sp.cancel(sp.together(
      sp.diff(DW, a).subs(a,0) - c1DW_claim))))
print("  exact positive decomposition of the X bracket:")
res = sp.simplify(sp.expand(Xbr - (sig+1)*(sig+2)*(1+2*uS**2) - (7*sig+8)*(1-2*uB*uS)))
print("    Xbr - (s+1)(s+2)(1+2uS^2) - (7s+8)(1-2uBuS) =", res)

# numeric block at a-hat
F = {nm: sp.lambdify((uB,uS,g,v,r,a), e, 'numpy') for nm,e in
     [('VB',VB),('q',q),('piO',piO),('Phi',Phi),('m2',pr2+r)]}
qp = sp.lambdify((uB,uS,g,v,r), sp.diff(q, a), 'numpy')
P0f = sp.lambdify((uB,uS,g,v,r), sp.diff(Phi,a).subs(a,0), 'numpy')
def N2(uB_,uS_,s):
    return (9*s**3*((uB_+uS_)**2-2)+5*s**2*(9*uB_**2+22*uB_*uS_+9*uS_**2-20)
            +16*s*(5*uB_**2+14*uB_*uS_+5*uS_**2-12)+16*((3*uB_+uS_)*(uB_+3*uS_)-8))
for gv in [1.0, 4.0]:
    neg = tot = 0
    for uBv in np.arange(0.02,1.42,0.02):
        for uSv in np.arange(0.02,1.42,0.02):
            if 2*uBv*uSv>=1: continue
            s = gv-2*uBv*uSv*(1+gv)
            if s<=0 or N2(uBv,uSv,s)>=0: continue
            if qp(uBv,uSv,gv,2.0,0.5) >= 0: continue
            P0 = P0f(uBv,uSv,gv,2.0,0.5)
            if P0 <= 0: continue
            ah = -P0/(2*qp(uBv,uSv,gv,2.0,0.5))
            A = (uBv,uSv,gv,2.0,0.5,ah); A0 = (uBv,uSv,gv,2.0,0.5,0.0)
            if F['q'](*A) <= 0 or F['m2'](*A) <= 0: continue
            tot += 1
            dvb = F['VB'](*A)-F['VB'](*A0)
            dvs = (F['q'](*A)**2-F['q'](*A0)**2)/2
            dpo = F['piO'](*A)-F['piO'](*A0)
            dw  = dvb+dvs+dpo+F['Phi'](*A)
            if dvb<0 and dvs<0 and dpo<0 and dw<0: neg += 1
    print(f"gamma={gv}: all four surplus changes negative at a-hat: {neg}/{tot}")

# ----------------------------------------------------------------------
# Participation bound for both-host pairs (cited in the OA caution):
# G(b1,b2,a) = consolidated pair surplus minus the two unilateral walk-off
# payoffs. G is strictly concave; its unconstrained maximum exceeds
# max(Phi(a-hat), 0) at every admissible point: the bound cannot replace
# the game-consistent search.
# ----------------------------------------------------------------------
def participation_bound_scan():
    b1s, b2s = sp.symbols('b_1 b_2')
    PI1 = (p1+r+b1s)*D1; PI2 = (p2+r+b2s)*D2
    solp = sp.solve([sp.diff(PI1,p1), sp.diff(PI2,p2)], [p1,p2], dict=True)[0]
    J = sp.expand((solp[p1]+r)*D1.subs(solp) + (solp[p2]+r)*D2.subs(solp)
                  + a*DSe.subs(solp))
    solw2 = sp.solve([sp.diff((p1+r)*D1,p1), sp.diff((p2+r+b2s)*D2,p2)],
                     [p1,p2], dict=True)[0]
    pw = sp.expand((solw2[p1]+r)*D1.subs(solw2))
    G = J - pw - pw.subs(b2s, b1s)
    Gf = sp.lambdify((uB,uS,g,v,r,b1s,b2s,a), G, 'numpy')
    def Gmax(uBv,uSv,gv):
        f = lambda b,a_: Gf(uBv,uSv,gv,2.0,0.5,b,b,a_)
        h = 1.0; f00 = f(0,0)
        gb=(f(h,0)-f(-h,0))/2; ga=(f(0,h)-f(0,-h))/2
        Hbb=f(h,0)-2*f00+f(-h,0); Haa=f(0,h)-2*f00+f(0,-h)
        Hba=(f(h,h)-f(h,-h)-f(-h,h)+f(-h,-h))/4
        Hm=np.array([[Hbb,Hba],[Hba,Haa]])
        if np.linalg.eigvalsh(Hm).max() >= 0: return None
        sol_=np.linalg.solve(Hm,-np.array([gb,ga]))
        return f00+gb*sol_[0]+ga*sol_[1]+0.5*sol_@Hm@sol_
    viol = tot = 0
    for gv in [4.0]:
        for uBv in np.arange(0.05,1.4,0.09):
            for uSv in np.arange(0.05,1.4,0.09):
                if 2*uBv*uSv>=1: continue
                s = gv-2*uBv*uSv*(1+gv)
                if s<=0 or N2(uBv,uSv,s)>=0: continue
                Gh = Gmax(uBv,uSv,gv)
                if Gh is None: continue
                qpv = qp(uBv,uSv,gv,2.0,0.5); P0 = P0f(uBv,uSv,gv,2.0,0.5)
                ph = 0.0 if (qpv>=0 or P0<=0) else -P0*P0/(4*qpv)
                tot += 1
                if Gh > max(ph,0.0)+1e-9: viol += 1
    print(f"participation bound: max G exceeds max(Phi(a-hat),0) at {viol}/{tot} admissible points")

participation_bound_scan()
