# -*- coding: utf-8 -*-
"""refine3.py -- Independent check of the Refine claims #32 (divide-and-rule vs
single-host, all constituencies) and #9 (polar case u_B = 0 sign expression).
Run: python3 refine3.py
"""
import sympy as sp

uB, uS, g, v, r = sp.symbols('u_B u_S gamma v r', positive=True)
a, p1, p2, be = sp.symbols('a p_1 p_2 beta')
sig = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
S = sp.Symbol('sigma')
_x, _y, _f = sp.symbols('_x _y _f')
Dk = (2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DSx = (uS*(2*v-_x-_y)-_f)/M
D1 = Dk.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
D2 = Dk.subs({_x: p2, _y: p1, _f: a}, simultaneous=True)
DSe = DSx.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
gg = sp.solve(sp.Eq(S, sig), g)[0]
sform = lambda e: sp.factor(sp.cancel(sp.together(e).subs(g, gg)))

def surpluses(pr1, pr2, d1, d2, q, mkt_a):
    """buyer surplus, developer surplus, welfare pieces at given equilibrium"""
    VB = (v*(d1+d2) + uB*q*(d1+d2) - (2*(d1**2+d2**2)+g*(d1+d2)**2)/(4*(1+g))
          - pr1*d1 - pr2*d2)
    VS = q**2/2
    return VB, VS

PT = {uB: sp.Rational(215, 1000), uS: sp.Rational(1106, 1000), g: 4,
      v: 2, r: sp.Rational(1, 2)}
num = lambda e: float(sp.N(e.subs(PT)))

# ---------- benchmark (separation): both at benefit r, a = 0
solb = sp.solve([sp.diff((p1+r)*D1, p1), sp.diff((p2+r)*D2, p2)], [p1, p2], dict=True)[0]
d1b = D1.subs(solb).subs(a, 0); d2b = D2.subs(solb).subs(a, 0); qb = DSe.subs(solb).subs(a, 0)
pi_bench = ((solb[p1]+r)*D1.subs(solb)).subs(a, 0)
VBb, VSb = surpluses(solb[p1].subs(a, 0), solb[p2].subs(a, 0), d1b, d2b, qb, 0)
Wb = VBb + VSb + 2*pi_bench          # platform earns zero under separation
print("benchmark:  pi_bench %.3f  apps %.3f  V_B %.3f  V_S %.3f  W %.3f"
      % (num(pi_bench), num(qb), num(VBb), num(VSb), num(Wb)))

# ---------- single-host calibrated package (host benefit beta*r, outsider r)
solh = sp.solve([sp.diff((p1+be*r)*D1, p1), sp.diff((p2+r)*D2, p2)], [p1, p2], dict=True)[0]
D1h, D2h, DSh = D1.subs(solh), D2.subs(solh), DSe.subs(solh)
bb = sp.solve(sp.Eq(D1h, D1h.subs({be: 1, a: 0})), be)[0]   # calibration: host demand pinned
sub = lambda e: e.subs(be, bb)
d1s, d2s, qs = sub(D1h), sub(D2h), sub(DSh)
pr1s, pr2s = sub(solh[p1]), sub(solh[p2])
Phi = sub(-(be-1)*r*D1h + a*DSh)
ahat = sp.cancel(-sp.diff(Phi, a).subs(a, 0)/sp.diff(Phi, a, 2))
print("\nsingle-host: a-hat = %.3f, Phi = %.3f  [paper: 2.31 / 7.26]"
      % (num(ahat), num(Phi.subs(a, ahat))))
host_s = sub((solh[p1]+be*r)*D1h)
out_s = (pr2s+r)*d2s
VBs, VSs = surpluses(pr1s, pr2s, d1s, d2s, qs, ahat)
Ws = VBs + VSs + host_s + out_s + Phi
at = lambda e: num(e.subs(a, ahat))
print("  host %.3f  outsider %.3f  apps %.3f  V_B %.3f  V_S %.3f  W %.3f"
      % (at(host_s), at(out_s), at(qs), at(VBs), at(VSs), at(Ws)))

# ---------- divide-and-rule pair (both hosted at benefit beta*r, beta > 1)
b_ = sp.Symbol('b')
sold = sp.solve([sp.diff((p1+b_)*D1, p1), sp.diff((p2+b_)*D2, p2)], [p1, p2], dict=True)[0]
d1d, d2d, qd = D1.subs(sold), D2.subs(sold), DSe.subs(sold)
pi_m = (sold[p1]+b_)*d1d
PId = (r-b_)*(d1d+d2d) + a*qd
VBd, VSd = surpluses(sold[p1], sold[p2], d1d, d2d, qd, a)
Wd = VBd + VSd + 2*pi_m + PId
DR = {b_: sp.Rational(203, 100)*sp.Rational(1, 2), a: sp.Rational(267, 100)}
nd = lambda e: float(sp.N(e.subs(DR).subs(PT)))
print("\nD&R (beta=2.03, a=2.67): platform %.3f  each manufacturer %.3f"
      % (nd(PId), nd(pi_m)), " [paper: 7.493 / 2.601]")
print("  apps %.3f  V_B %.3f  V_S %.3f  W %.3f  [paper: 3.96 / 8.98 / 7.84 / 29.5]"
      % (nd(qd), nd(VBd), nd(VSd), nd(Wd)))

print("\n--- comparison D&R vs single-host (lower = worse) ---")
rows = [("outsider / each manufacturer", at(out_s), nd(pi_m)),
        ("applications", at(qs), nd(qd)),
        ("buyer surplus", at(VBs), nd(VBd)),
        ("developer surplus", at(VSs), nd(VSd)),
        ("total welfare", at(Ws), nd(Wd))]
for nm, s_, d_ in rows:
    print("  %-30s single-host %8.3f   D&R %8.3f   %s"
          % (nm, s_, d_, "D&R lower" if d_ < s_ else "D&R HIGHER"))

# ======================================================================
# #9 -- polar case u_B = 0 with coordination motives: sign of Delta pi_2
# ======================================================================
print("\n=== #9: polar case u_B = 0, coordination motives ===")
aB = sp.Symbol('alpha_B', nonnegative=True)
# intercepts v + alpha_B on both devices when both run the platform's system
Dk2 = (2*(v+aB)-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DS2 = (uS*(2*(v+aB)-_x-_y)-_f)/M
D1c = Dk2.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
D2c = Dk2.subs({_x: p2, _y: p1, _f: a}, simultaneous=True)
DSc = DS2.subs({_x: p1, _y: p2, _f: a}, simultaneous=True)
PI_I = (p1+r)*D1c + (1-be)*r*D2c + a*DSc
PI_2 = (p2+be*r)*D2c
solc = sp.solve([sp.diff(PI_I, p1), sp.diff(PI_2, p2)], [p1, p2], dict=True)[0]
m2 = sp.simplify(solc[p2] + be*r)                 # rival markup
pi2 = sp.simplify(m2*D2c.subs(solc))
# polar case u_B = 0  (=> sigma = gamma, M = 1)
m2p = sp.simplify(m2.subs(uB, 0))
pi2p = sp.simplify(pi2.subs(uB, 0))
print("  pi_2 / markup^2 at u_B=0:", sp.simplify(pi2p/m2p**2))
paper = 3*(v+aB)*(1+g) - a*uS*g + r*(4*be-1)*(1+g)
print("  paper's expression at (alpha_B=0, beta=1, a=0):",
      sp.simplify(paper.subs({aB: 0, be: 1, a: 0})), " (should be 0 if it signed Delta pi_2)")
print("  paper's expression equals the markup itself, up to a positive factor?")
ratio = sp.simplify(sp.cancel(m2p/paper))
print("   m2/paper =", ratio)
# correct sign object: Delta pi_2 has the sign of m2(beta,a) - m2(1,0)
dm = sp.simplify(sp.factor(sp.expand(m2p - m2p.subs({be: 1, a: 0}))))
print("  m2(beta,a) - m2(1,0) =", dm)
refine_claim = (4+3*g)*aB - g*a*uS + 4*r*(1+g)*(be-1)
print("  residual vs Refine's proposal /(positive factor):",
      sp.simplify(sp.cancel(dm/refine_claim)))

# corrected object, and check that alpha_B cancels because the benchmark carries it too
dm_claim = 4*r*(1+g)*(be-1) - g*a*uS
print("  CORRECTED: m2(beta,a)-m2(1,0) equals 2*[4r(1+g)(beta-1) - g a u_S]/((g+4)(3g+4))?",
      sp.simplify(dm - 2*dm_claim/((g+4)*(3*g+4))) == 0)
print("  alpha_B present in the difference?", aB in dm.free_symbols)
# companion check: the Delta V_S expression of the same block
q_c = sp.simplify(DSc.subs(solc).subs(uB, 0))
dq = sp.simplify(sp.factor(sp.expand(q_c - q_c.subs({be: 1, a: 0}))))
VS_claim = a*(2*uS**2-4-g) + 2*r*uS*(be-1)*(1+g)
print("  Delta V_S sign object: q(beta,a)-q(1,0) =", dq)
print("   ratio to the paper's expression:", sp.simplify(sp.cancel(dq/VS_claim)))
