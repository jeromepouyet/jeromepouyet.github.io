# -*- coding: utf-8 -*-
"""verif_lump_game.py -- adversarial audit of rep17_lumpsum_numeric.game().

Independent re-implementation of the separation adoption game with lump sums,
written from the paper (Section 2 + Prop 1) rather than from rep17, plus a set
of targeted experiments.  Nothing here is imported by the package.
"""
import sys, os, itertools
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import sigma_of, Mof, Hval, demands, prices_sep, prices_int, V_DEF, R_DEF
import rep3_contracts as C
# --- rep17's game(), copied verbatim (importing rep17 would run its blocks) ---
def cfg17(uB, uS, sig, b1, b2, a):
    p1, p2 = prices_sep(uB, uS, sig, b1, b2, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    return [(p1+b1)*D1, (p2+b2)*D2, D1, D2, q, p1, p2]

def game17(uB, uS, g, b1, b2, t1, t2, a, pubrule=False):
    """b1,b2 in [0,1] are beta^1, beta^2;  t1,t2 in [0,1] the fraction of the
    allowed cap (1-beta^k) r D_k actually paid as a lump.  Returns the platform's
    profit at the selected adoption equilibrium, and that equilibrium."""
    sig = sigma_of(uB, uS, g)
    ae = a if a < 0 else 0.0                       # the fee dies under joint refusal
    P = {'AA': cfg17(uB,uS,sig, b1*R, b2*R, a), 'AR': cfg17(uB,uS,sig, b1*R, R, a),
         'RA': cfg17(uB,uS,sig, R, b2*R, a),    'RR': cfg17(uB,uS,sig, R, R, ae)}
    for k in P:
        if min(P[k][2], P[k][3], P[k][4]) <= 0: return None
    if pubrule and a > 0:
        # the fee is collected only if a developer that publishes on the platform's
        # system gains at least a:  u_S n_B^I >= a, with n_B^I the buyer stock on
        # the devices that host.  AA: D1+D2, AR: D1, RA: D2.
        if uS*(P['AA'][2]+P['AA'][3]) < a: return None
        if uS*P['AR'][2] < a: return None
        if uS*P['RA'][3] < a: return None
    L = {'AA': (t1*(1-b1)*R*P['AA'][2], t2*(1-b2)*R*P['AA'][3]),
         'AR': (t1*(1-b1)*R*P['AR'][2], 0.0),
         'RA': (0.0, t2*(1-b2)*R*P['RA'][3]), 'RR': (0.0, 0.0)}
    pi = {k: (P[k][0]+L[k][0], P[k][1]+L[k][1]) for k in P}   # the lump is RECEIVED
    NE = []
    for prof, d1, d2 in (('AA','RA','AR'),('AR','RR','AA'),('RA','AA','RR'),('RR','AR','RA')):
        if pi[d1][0] <= pi[prof][0]+1e-12 and pi[d2][1] <= pi[prof][1]+1e-12: NE.append(prof)
    if not NE: return None
    sel = max(NE, key=lambda k: pi[k][0]+pi[k][1])
    D1, D2, q = P[sel][2], P[sel][3], P[sel][4]
    val = {'AA': (1-b1)*R*D1-L['AA'][0] + (1-b2)*R*D2-L['AA'][1] + a*q,
           'AR': (1-b1)*R*D1-L['AR'][0] + a*q,
           'RA': (1-b2)*R*D2-L['RA'][1] + a*q,
           'RR': ae*q}[sel]
    return val, sel

# --- end copy ---

V, R = V_DEF, R_DEF
PROF = ('AA', 'AR', 'RA', 'RR')
# deviation targets: (profile, M1 deviates to, M2 deviates to)
DEV = {'AA': ('RA', 'AR'), 'AR': ('RR', 'AA'),
       'RA': ('AA', 'RR'), 'RR': ('AR', 'RA')}

def config(uB, uS, g, b1, b2, a_live):
    sig = sigma_of(uB, uS, g)
    p1, p2 = prices_sep(uB, uS, sig, b1, b2, a_live)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a_live)
    return dict(p1=p1, p2=p2, D1=D1, D2=D2, q=q,
                pi1=(p1+b1)*D1, pi2=(p2+b2)*D2, m1=p1+b1, m2=p2+b2)

def solve(uB, uS, g, beta1, beta2, t1, t2, a,
          tie='accept', margins=False, pubrule=False, verbose=False):
    """Full adoption game.  tie='accept' = paper's convention (indifferent
    manufacturer accepts);  tie='weak' = rep17's convention (indifference is
    never a profitable deviation, for either action)."""
    b = {'A': (beta1*R, beta2*R), 'R': (R, R)}
    Cf, L, nBI = {}, {}, {}
    for pr in PROF:
        b1 = beta1*R if pr[0] == 'A' else R
        b2 = beta2*R if pr[1] == 'A' else R
        live = (pr != 'RR') or (a < 0)          # fee/subsidy alive?
        Cf[pr] = config(uB, uS, g, b1, b2, a if live else 0.0)
        nBI[pr] = ((Cf[pr]['D1'] if pr[0] == 'A' else 0.0)
                   + (Cf[pr]['D2'] if pr[1] == 'A' else 0.0))
        L[pr] = (t1*(1-beta1)*R*Cf[pr]['D1'] if pr[0] == 'A' else 0.0,
                 t2*(1-beta2)*R*Cf[pr]['D2'] if pr[1] == 'A' else 0.0)
    for pr in PROF:
        c = Cf[pr]
        if min(c['D1'], c['D2'], c['q']) <= 0: return None
        if margins and min(c['m1'], c['m2']) <= 0: return None
    if pubrule and a > 0:
        for pr in ('AA', 'AR', 'RA'):
            if uS*nBI[pr] < a: return None
    pi = {pr: (Cf[pr]['pi1']+L[pr][0], Cf[pr]['pi2']+L[pr][1]) for pr in PROF}
    tol = 1e-12
    NE = []
    for pr in PROF:
        d1t, d2t = DEV[pr]
        g1 = pi[d1t][0] - pi[pr][0]; g2 = pi[d2t][1] - pi[pr][1]
        if tie == 'weak':
            ok1 = g1 <= tol; ok2 = g2 <= tol
        else:                                   # indifference -> accept
            ok1 = (g1 < -tol) or (abs(g1) <= tol and pr[0] == 'A')
            ok2 = (g2 < -tol) or (abs(g2) <= tol and pr[1] == 'A')
        if ok1 and ok2: NE.append(pr)
    if not NE: return None
    sel = max(NE, key=lambda k: pi[k][0]+pi[k][1])
    c = Cf[sel]
    val = (((1-beta1)*R*c['D1'] - L[sel][0]) if sel[0] == 'A' else 0.0) \
        + (((1-beta2)*R*c['D2'] - L[sel][1]) if sel[1] == 'A' else 0.0) \
        + (a*c['q'] if (sel != 'RR' or a < 0) else 0.0)
    return dict(val=val, sel=sel, NE=NE, pi=pi, C=Cf, L=L, nBI=nBI)

# ---------------------------------------------------------------- experiments
def dump(uB, uS, g, beta1, beta2, t1, t2, a):
    print("\n" + "="*84)
    print("BRUTE FORCE  (u_B,u_S,gamma)=(%g,%g,%g)   beta1=%g beta2=%g t1=%g t2=%g a=%g"
          % (uB, uS, g, beta1, beta2, t1, t2, a))
    sig = sigma_of(uB, uS, g)
    print("sigma=%.4f  M=%.4f  H=%.4g" % (sig, Mof(uB, uS), Hval(uB, uS, sig)))
    print("="*84)
    S = solve(uB, uS, g, beta1, beta2, t1, t2, a, tie='weak')
    if S is None:
        print("  rejected by the screens"); return None
    hdr = ("%-4s %-6s %-6s %-5s %8s %8s %8s %8s %8s %9s %9s %9s %9s" %
           ("prof","b1","b2","fee","p1","p2","D1","D2","q_S","pi1(noL)","L1","pi1","pi2"))
    print(hdr); print("-"*len(hdr))
    for pr in PROF:
        c = S['C'][pr]; live = (pr != 'RR') or (a < 0)
        b1 = beta1*R if pr[0]=='A' else R; b2 = beta2*R if pr[1]=='A' else R
        print("%-4s %-6.3f %-6.3f %-5s %8.4f %8.4f %8.4f %8.4f %8.4f %9.5f %9.5f %9.5f %9.5f"
              % (pr, b1, b2, "live" if live else "dead", c['p1'], c['p2'],
                 c['D1'], c['D2'], c['q'], c['pi1'], S['L'][pr][0],
                 S['pi'][pr][0], S['pi'][pr][1]))
    print("\n  margins p_k+b_k  :", ", ".join("%s (%+.4f,%+.4f)" %
          (pr, S['C'][pr]['m1'], S['C'][pr]['m2']) for pr in PROF))
    print("  publication rule u_S n_B^I >= a :", ", ".join(
          "%s %.4f%s a=%.3f" % (pr, uS*S['nBI'][pr],
          " >= " if uS*S['nBI'][pr] >= a else " <  ", a) for pr in PROF))
    for pr in PROF:
        d1t, d2t = DEV[pr]
        print("  %s : M1 -> %s  gain %+ .6f  |  M2 -> %s  gain %+ .6f"
              % (pr, d1t, S['pi'][d1t][0]-S['pi'][pr][0],
                 d2t, S['pi'][d2t][1]-S['pi'][pr][1]))
    joint = {k: S['pi'][k][0]+S['pi'][k][1] for k in PROF}
    print("  joint manufacturer profit :", ", ".join("%s %.6f" % (k, joint[k]) for k in PROF))
    print("  NE (rep17 tie-break, weak) :", S['NE'], " -> selected", S['sel'],
          " platform value %.6f" % S['val'])
    Sa = solve(uB, uS, g, beta1, beta2, t1, t2, a, tie='accept')
    print("  NE (paper tie-break)       :", Sa['NE'] if Sa else None,
          " -> selected", Sa['sel'] if Sa else None,
          " platform value %.6f" % Sa['val'] if Sa else "")
    print("  rep17.game() says          :", game17(uB, uS, g, beta1, beta2, t1, t2, a))
    # Pareto check between the selected profile and joint refusal
    if 'RR' in S['NE'] and S['sel'] != 'RR':
        d1 = S['pi'][S['sel']][0] - S['pi']['RR'][0]
        d2 = S['pi'][S['sel']][1] - S['pi']['RR'][1]
        print("  SELECTED vs RR : M1 %+.6f   M2 %+.6f   -> %s"
              % (d1, d2, "PARETO-DOMINATES RR" if min(d1,d2) > 0 else
                 "M1 STRICTLY PREFERS RR (rule overrides an individual preference)"
                 if d1 < 0 else "M2 strictly prefers RR"))
    return S

# ============================================================ vectorised sweep
def sweep_point(uB, uS, g, variant='base'):
    """Best platform profit over the code's own grid (beta1 in GB, a in GA,
    t1 in GT, beta2=1, t2=0) under one of several variants:
      base      : exactly rep17
      margins   : + rep3's p_k + b_k > 0 screen in all four profiles
      pubrule   : + u_S n_B^I >= a in AA, AR, RA
      accept    : paper's tie-break (indifferent manufacturer accepts)
      pareto    : the selected profile must not be ranked below another NE by
                  either manufacturer  (the paper's own gloss on the rule)
      all       : margins + pubrule + accept + pareto
    Returns (best value, argmax, diagnostic dict)."""
    sig = sigma_of(uB, uS, g)
    if Mof(uB, uS) <= 0 or sig < 0 or Hval(uB, uS, sig) <= 0: return None
    GB, GA, GT = R17.GB if False else np.arange(0.,1.0001,0.1), \
                 np.arange(0.02,2.001,0.04), np.array([0.,0.5,1.])
    B, A, T = np.meshgrid(GB, GA, GT, indexing='ij')
    B, A, T = B.ravel(), A.ravel(), T.ravel()
    def cf(b1, b2, a):
        den = (4+sig)*(4+3*sig); M = Mof(uB,uS)
        p1 = (-2*uB*a*(4+3*sig) + 2*V*(4+3*sig) - (2+sig)*(sig*b2 + 2*(2+sig)*b1))/den
        p2 = (-2*uB*a*(4+3*sig) + 2*V*(4+3*sig) - (2+sig)*(sig*b1 + 2*(2+sig)*b2))/den
        D1 = (2*V-(2+sig)*p1+sig*p2-2*uB*a)/(2*M)
        D2 = (2*V-(2+sig)*p2+sig*p1-2*uB*a)/(2*M)
        q  = (uS*(2*V-p1-p2)-a)/M
        return p1, p2, D1, D2, q, (p1+b1)*D1, (p2+b2)*D2
    z = np.zeros_like(B)
    Cf = {'AA': cf(B*R, R+z, A), 'AR': cf(B*R, R+z, A),
          'RA': cf(R+z, R+z, A), 'RR': cf(R+z, R+z, z)}
    nBI = {'AA': Cf['AA'][2]+Cf['AA'][3], 'AR': Cf['AR'][2],
           'RA': Cf['RA'][3], 'RR': z}
    L = {'AA': (T*(1-B)*R*Cf['AA'][2], z), 'AR': (T*(1-B)*R*Cf['AR'][2], z),
         'RA': (z, z), 'RR': (z, z)}
    ok = np.ones_like(B, dtype=bool)
    for k in PROF:
        c = Cf[k]
        ok &= (c[2] > 0) & (c[3] > 0) & (c[4] > 0)
        if variant in ('margins','all'):
            b1 = B*R if k[0]=='A' else R+z; b2 = R+z
            ok &= (c[0]+b1 > 0) & (c[1]+b2 > 0)
    if variant in ('pubrule','all'):
        for k in ('AA','AR','RA'): ok &= (uS*nBI[k] >= A)
    pi = {k: (Cf[k][5]+L[k][0], Cf[k][6]+L[k][1]) for k in PROF}
    tol = 1e-12; NE = {}
    for k in PROF:
        d1t, d2t = DEV[k]
        g1 = pi[d1t][0]-pi[k][0]; g2 = pi[d2t][1]-pi[k][1]
        if variant in ('accept','all','pareto'):
            o1 = (g1 < -tol) | ((np.abs(g1) <= tol) & (k[0]=='A'))
            o2 = (g2 < -tol) | ((np.abs(g2) <= tol) & (k[1]=='A'))
        else:
            o1 = g1 <= tol; o2 = g2 <= tol
        NE[k] = o1 & o2
    joint = {k: pi[k][0]+pi[k][1] for k in PROF}
    best = np.full(B.shape, -np.inf); pick = np.zeros(B.shape, dtype=int)
    for i, k in enumerate(PROF):
        take = NE[k] & (joint[k] > best + 1e-15)
        best = np.where(take, joint[k], best); pick = np.where(take, i, pick)
    anyNE = NE['AA']|NE['AR']|NE['RA']|NE['RR']
    val = np.full(B.shape, -np.inf); overr = np.zeros(B.shape, dtype=bool)
    for i, k in enumerate(PROF):
        v = ((1-B)*R*Cf[k][2]-L[k][0] if k[0]=='A' else z) \
          + (z if k[1]=='R' else (1-1.0)*R*Cf[k][3]-L[k][1]) \
          + (A*Cf[k][4] if k != 'RR' else z)
        val = np.where((pick == i) & anyNE & ok, v, val)
        # does the selected profile leave some manufacturer below another NE?
        for j, k2 in enumerate(PROF):
            if k2 == k: continue
            worse = NE[k2] & ((pi[k2][0] > pi[k][0]+1e-12) | (pi[k2][1] > pi[k][1]+1e-12))
            overr |= (pick == i) & anyNE & ok & worse
    if variant in ('pareto','all'):
        val = np.where(overr, -np.inf, val)
    i = int(np.argmax(val))
    if not np.isfinite(val[i]) or val[i] <= 1e-9: return 0.0, None, dict(overr=False)
    return float(val[i]), (round(float(B[i]),2), float(T[i]), round(float(A[i]),3),
                           PROF[pick[i]]), dict(overr=bool(overr[i]))

# ==============================================================================
if __name__ == "__main__":
    print("verif_lump_game -- adversarial audit of rep17_lumpsum_numeric.game()\n")
    # 0. the deviation table, from first principles
    gen = {p: (('R' if p[0]=='A' else 'A')+p[1], p[0]+('R' if p[1]=='A' else 'A'))
           for p in PROF}
    print("0. deviation targets match first principles :", gen == DEV)
    # 1. this file's game == rep17's game
    rng = np.random.default_rng(1); bad = tot = 0
    for _ in range(3000):
        u1, u2 = rng.uniform(0.05,1.4), rng.uniform(0.05,1.4)
        g = float(rng.choice([0.5,1.,2.,4.,8.,16.]))
        b1, b2 = float(rng.choice(np.arange(0,1.01,0.1))), float(rng.choice(np.arange(0,1.01,0.1)))
        t1, t2 = float(rng.choice([0,.5,1.])), float(rng.choice([0,.5,1.]))
        a = rng.uniform(-1.5, 2.0)
        m = solve(u1,u2,g,b1,b2,t1,t2,a,tie='weak'); o = game17(u1,u2,g,b1,b2,t1,t2,a)
        if (m is None) != (o is None): bad += 1; continue
        if m is None: continue
        tot += 1
        if abs(m['val']-o[0]) > 1e-11 or m['sel'] != o[1]: bad += 1
    print("1. independent re-implementation vs rep17 : %d mismatches / %d packages"
          % (bad, tot))
    # 2. the two reference points
    dump(0.05, 1.4, 4.0,  0.5, 1.0, 1.0, 0.0, 1.62)
    dump(0.2,  1.3, 16.0, 0.7, 1.0, 1.0, 0.0, 0.05)
    # 3. the argmax that survives the paper's own gloss on the selection rule
    dump(0.05, 1.4, 4.0,  0.7, 1.0, 1.0, 0.0, 0.26)
    # 4. variant maxima at the block-B argmaxes
    print("\n" + "="*84)
    print("VARIANT MAXIMA over rep17's own grid (beta^2 = 1, one-sided packages)")
    print("="*84)
    print("%-22s %-12s %-12s %-12s %-12s %-12s" %
          ("(u_B,u_S,gamma)","base","+margins","+pubrule","paper tie","Pareto-resp."))
    for pt in ((0.05,1.4,1.0),(0.05,1.4,2.0),(0.05,1.4,4.0),
               (0.05,1.4,8.0),(0.1,1.4,16.0),(0.2,1.3,16.0)):
        row = []
        for var in ('base','margins','pubrule','accept','pareto'):
            o = sweep_point(*pt, variant=var); row.append(o[0] if o else float('nan'))
        print("%-22s %-12.5f %-12.5f %-12.5f %-12.5f %-12.5f"
              % ("(%.2f,%.2f,%g)" % pt, *row))
