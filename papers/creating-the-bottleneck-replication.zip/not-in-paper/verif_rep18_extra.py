# -*- coding: utf-8 -*-
"""verif_rep18_extra.py -- follow-ups to verif_rep18.py (own code, primitives only):
  E1  single-host problem in (beta, a): concavity, the interior optimum, and whether it beats Pi^I
      where the participation constraint is slack (X1 'violations')
  E2  shape of the wedge: cone rho < R_p(sigma) versus the true region; the u_S ceiling at u_B -> 0
  E3  how thin is the platform's preference on the wedge (distribution of Phi/Pi^I - 1)
  E4  welfare decomposition on the wedge: who loses what, in units of the benchmark
"""
import sys, time
import numpy as np, sympy as sp
T0 = time.time()
def ok(c): return "CONFIRMED" if c else "**REFUTED**"

uB, uS, g, v, r = sp.symbols('u_B u_S gamma v r', positive=True)
a, b1, b2, p1, p2, s, beta = sp.symbols('a b1 b2 p1 p2 sigma beta')
sig_of = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*a)/(2*M)
D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*a)/(2*M)
q  = (uS*(2*v - p1 - p2) - a)/M
sep = sp.solve([sp.diff((p1+b1)*D1, p1), sp.diff((p2+b2)*D2, p2)], [p1, p2], dict=True)[0]
intg = sp.solve([sp.diff((p1 + r)*D1 + a*q + (r - b2)*D2, p1), sp.diff((p2+b2)*D2, p2)], [p1, p2], dict=True)[0]
Lam = 8 + s*(8+s); Tht = 3*s*(s*(s+7)+16) + 32
H = ((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2 - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS - 2*(s*(s*(7*s+40)+64)+32)*uS**2)
Phi_p0 = 2*(v+r)*(s+2)*(Lam*uS - (4+3*s)*uB)/(M*(s+4)*Lam)
Phi_pp = 2*(2*uB*uS*(5*s+6) - Lam)/(Lam*M)
PiI_p0 = 2*(v+r)*(Tht*uS - 2*(s+2)*(3*s+4)*uB)/((s+4)**2*(3*s+4)*M)
PiI_pp = -2*H/((s+4)**2*(3*s+4)**2*M)
bbar = 1 + 2*uB*a*(3*s+4)/(r*Lam)

# single-host platform profit in (beta, a), rival at r
Pi_s = sp.simplify(((1-beta)*r*D1.subs(sep) + a*q.subs(sep)).subs({b1: beta*r, b2: r}))
Hs = sp.hessian(Pi_s, (a, beta))
detH = sp.factor(sp.simplify(Hs.det())); Paa = sp.factor(sp.simplify(Hs[0, 0])); Pbb = sp.factor(sp.simplify(Hs[1, 1]))
print("E1. single-host profit Pi(beta, a): quadratic, Hessian")
print("    d2Pi/da2   =", Paa)
print("    d2Pi/dbeta2=", Pbb)
print("    det        =", detH)
crit = sp.solve([sp.diff(Pi_s, a), sp.diff(Pi_s, beta)], [a, beta], dict=True)[0]
a_int = sp.cancel(crit[a]); b_int = sp.cancel(crit[beta]); Pi_int = sp.cancel(Pi_s.subs(crit))
print("    interior a* =", sp.factor(a_int))
print("    interior beta* - 1 =", sp.factor(b_int - 1))
F = dict(
    P1sep=sp.lambdify((uB, uS, s, b1, b2, a, v), sep[p1], 'numpy'), P2sep=sp.lambdify((uB, uS, s, b1, b2, a, v), sep[p2], 'numpy'),
    P1int=sp.lambdify((uB, uS, s, b2, a, v, r), intg[p1], 'numpy'), P2int=sp.lambdify((uB, uS, s, b2, a, v, r), intg[p2], 'numpy'),
    Phi_p0=sp.lambdify((uB, uS, s, v, r), Phi_p0, 'numpy'), Phi_pp=sp.lambdify((uB, uS, s), Phi_pp, 'numpy'),
    PiI_p0=sp.lambdify((uB, uS, s, v, r), PiI_p0, 'numpy'), PiI_pp=sp.lambdify((uB, uS, s), PiI_pp, 'numpy'),
    Hv=sp.lambdify((uB, uS, s), H, 'numpy'), detH=sp.lambdify((uB, uS, s, r), detH, 'numpy'),
    a_int=sp.lambdify((uB, uS, s, v, r), a_int, 'numpy'), b_int=sp.lambdify((uB, uS, s, v, r), b_int, 'numpy'),
    Pi_int=sp.lambdify((uB, uS, s, v, r), Pi_int, 'numpy'), Pi_s=sp.lambdify((uB, uS, s, beta, a, v, r), Pi_s, 'numpy'),
    dPidb=sp.lambdify((uB, uS, s, beta, a, v, r), sp.diff(Pi_s, beta), 'numpy'),
)
VN, RN = 2.0, 0.5
def sig_n(x, y, gg): return gg - 2*x*y*(1+gg)
def Mn(x, y): return 1 - 2*x*y
def dem_n(x, y, sg, q1, q2, fee):
    Mv = Mn(x, y)
    return ((2*VN - (2+sg)*q1 + sg*q2 - 2*x*fee)/(2*Mv), (2*VN - (2+sg)*q2 + sg*q1 - 2*x*fee)/(2*Mv), (y*(2*VN - q1 - q2) - fee)/Mv)
def VB_n(x, y, gg, q1, q2, D1, D2, qq_):
    return (VN*(D1+D2) + x*qq_*(D1+D2) - (2*(D1**2+D2**2) + gg*(D1+D2)**2)/(4*(1+gg)) - q1*D1 - q2*D2)
def cfg_sep(x, y, gg, c1, c2, fee):
    sg = sig_n(x, y, gg)
    q1 = F['P1sep'](x, y, sg, c1, c2, fee, VN); q2 = F['P2sep'](x, y, sg, c1, c2, fee, VN)
    D1, D2, qq_ = dem_n(x, y, sg, q1, q2, fee)
    VB = VB_n(x, y, gg, q1, q2, D1, D2, qq_); VS = 0.5*qq_**2; pi1 = (q1+c1)*D1; pi2 = (q2+c2)*D2
    plat = (RN - c1)*D1 + (RN - c2)*D2 + fee*qq_
    return dict(p1=q1, p2=q2, D1=D1, D2=D2, q=qq_, VB=VB, VS=VS, pi1=pi1, pi2=pi2, plat=plat, W=VB+VS+pi1+pi2+plat,
                interior=(D1 > 0 and D2 > 0 and qq_ > 0 and q1+c1 > 0 and q2+c2 > 0))
def cfg_int(x, y, gg, c2, fee):
    sg = sig_n(x, y, gg)
    q1 = F['P1int'](x, y, sg, c2, fee, VN, RN); q2 = F['P2int'](x, y, sg, c2, fee, VN, RN)
    D1, D2, qq_ = dem_n(x, y, sg, q1, q2, fee)
    VB = VB_n(x, y, gg, q1, q2, D1, D2, qq_); VS = 0.5*qq_**2; firm = (q1+RN)*D1 + fee*qq_ + (RN - c2)*D2; pi2 = (q2+c2)*D2
    return dict(p1=q1, p2=q2, D1=D1, D2=D2, q=qq_, VB=VB, VS=VS, firm=firm, pi2=pi2, W=VB+VS+firm+pi2,
                interior=(D1 > 0 and D2 > 0 and qq_ > 0 and q1+RN > 0 and q2+c2 > 0))
def a_star_n(x, y, sg): return -F['PiI_p0'](x, y, sg, VN, RN)/F['PiI_pp'](x, y, sg)
def a_hat_n(x, y, sg):  return -F['Phi_p0'](x, y, sg, VN, RN)/F['Phi_pp'](x, y, sg)
def bbar_n(x, y, sg, fee): return 1 + 2*x*fee*(3*sg+4)/(RN*(8+sg*(8+sg)))
def Rp_n(sg): return (8+sg*(8+sg))/((2+sg)*(4+3*sg))
def RPhi_n(sg): return (8+sg*(8+sg))/(4+3*sg)
def admissible(x, y, gg):
    if Mn(x, y) <= 0: return None
    sg = sig_n(x, y, gg)
    if sg < 0 or F['Hv'](x, y, sg) <= 0: return None
    if cfg_int(x, y, gg, RN, a_star_n(x, y, sg))['D2'] <= 0: return None
    return sg

grid = np.round(np.arange(0.02, 1.4001, 0.02), 10)
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)

print("\nE1 (numerical). Where the participation constraint is slack at (beta_bar(a_hat), a_hat), the true")
print("    single-host optimum is the interior point (beta*, a*) if concave and feasible.  Does it beat Pi^I?")
print("    %-6s %-7s %-8s %-10s %-12s %-12s %-14s %-12s" % ("gamma", "unrav.", "slack", "det<=0", "int.feasible", "int>PiI", "int>PiI&interior", "new wedge pts"))
for gg in GAMMAS:
    n = slack = nd = feas = beat = beat_int = new = 0
    for x in grid:
        for y in grid:
            sg = admissible(x, y, gg)
            if sg is None: continue
            ah = a_hat_n(x, y, sg)
            if ah <= 0: continue
            n += 1
            aa = a_star_n(x, y, sg)
            PiI = F['PiI_p0'](x, y, sg, VN, RN)*aa + 0.5*F['PiI_pp'](x, y, sg)*aa**2 if aa > 0 else 0.0
            Phi = F['Phi_p0'](x, y, sg, VN, RN)*ah + 0.5*F['Phi_pp'](x, y, sg)*ah**2
            if F['dPidb'](x, y, sg, bbar_n(x, y, sg, ah), ah, VN, RN) < 0: continue
            slack += 1
            if F['detH'](x, y, sg, RN) <= 0: nd += 1; continue
            ai = F['a_int'](x, y, sg, VN, RN); bi = F['b_int'](x, y, sg, VN, RN)
            if not (ai > 0 and bi >= bbar_n(x, y, sg, ai)): continue
            feas += 1
            Pint = F['Pi_int'](x, y, sg, VN, RN)
            if Pint > PiI + 1e-12:
                beat += 1
                c = cfg_sep(x, y, gg, bi*RN, RN, ai)
                if c['interior']:
                    beat_int += 1
                    if Phi <= PiI + 1e-12: new += 1
    print("    %-6.3g %-7d %-8d %-10d %-12d %-12d %-14d %-12d" % (gg, n, slack, nd, feas, beat, beat_int, new))
print("    ('slack' = dPi/dbeta >= 0 at the calibrated optimum; 'new wedge pts' = points where the interior single-host")
print("     package beats Pi^I although Phi(a_hat) does not -- these would enlarge the region of the claim.)")

print("\nE2. Shape of the wedge versus the cone rho < R_p(sigma)")
print("    u_S ceiling at u_B -> 0 (exact, from the C2 inequality at u_B = 0):")
for gg in GAMMAS:
    Th = 3*gg*(gg*(gg+7)+16)+32
    num = gg**2*((2+gg)*(4+gg)*(4+3*gg) + Th); den = 2*(2+gg)**2*(7*gg**3+40*gg**2+64*gg+32)
    print("      gamma=%-4g  u_S < %.4f" % (gg, np.sqrt(num/den)))
print("    %-6s %-14s %-16s %-16s %-14s" % ("gamma", "cone pts in A", "cone & Phi>PiI", "cone & Phi<=PiI", "max u_S (cone&Phi>PiI)"))
for gg in GAMMAS:
    cone = win = 0; mx = 0
    for x in grid:
        for y in grid:
            sg = admissible(x, y, gg)
            if sg is None: continue
            if x/y >= Rp_n(sg): continue
            cone += 1
            ah = a_hat_n(x, y, sg); aa = a_star_n(x, y, sg)
            PiI = F['PiI_p0'](x, y, sg, VN, RN)*aa + 0.5*F['PiI_pp'](x, y, sg)*aa**2 if aa > 0 else 0.0
            Phi = F['Phi_p0'](x, y, sg, VN, RN)*ah + 0.5*F['Phi_pp'](x, y, sg)*ah**2 if ah > 0 else 0.0
            if Phi > PiI + 1e-12: win += 1; mx = max(mx, y)
    print("    %-6.3g %-14d %-16d %-16d %-14.2f" % (gg, cone, win, cone - win, mx))
print("    -> the cone rho < R_p is far larger than the wedge: the level of network effects (u_S) cuts it off.")

print("\nE3. Thinness of the platform's preference on the wedge: Phi(a_hat)/Pi^I - 1")
print("    %-6s %-8s %-10s %-10s %-10s %-10s" % ("gamma", "pts", "median", "p90", "max", "max (rho<Rp part)"))
for gg in GAMMAS:
    vals = []; vals_lo = []
    for x in grid:
        for y in grid:
            sg = admissible(x, y, gg)
            if sg is None: continue
            ah = a_hat_n(x, y, sg); aa = a_star_n(x, y, sg)
            if ah <= 0 or aa <= 0: continue
            PiI = F['PiI_p0'](x, y, sg, VN, RN)*aa + 0.5*F['PiI_pp'](x, y, sg)*aa**2
            Phi = F['Phi_p0'](x, y, sg, VN, RN)*ah + 0.5*F['Phi_pp'](x, y, sg)*ah**2
            if Phi > PiI + 1e-12:
                vals.append(Phi/PiI - 1)
                if x/y < Rp_n(sg): vals_lo.append(Phi/PiI - 1)
    vals = np.array(vals)
    print("    %-6.3g %-8d %-10.4f %-10.4f %-10.4f %-10.4f" % (gg, len(vals), np.median(vals), np.percentile(vals, 90), vals.max(), max(vals_lo)))

print("\nE4. Welfare decomposition on the wedge (rho < R_p part), medians in % of benchmark W_0: B minus C")
print("    %-6s %-8s %-10s %-10s %-10s %-10s %-10s %-10s" % ("gamma", "pts", "dVB", "dVS", "d(plat+M1)", "dM2", "dW", "dq/q0"))
for gg in GAMMAS:
    rows = []
    for x in grid:
        for y in grid:
            sg = admissible(x, y, gg)
            if sg is None: continue
            ah = a_hat_n(x, y, sg); aa = a_star_n(x, y, sg)
            if ah <= 0 or aa <= 0 or x/y >= Rp_n(sg): continue
            PiI = F['PiI_p0'](x, y, sg, VN, RN)*aa + 0.5*F['PiI_pp'](x, y, sg)*aa**2
            Phi = F['Phi_p0'](x, y, sg, VN, RN)*ah + 0.5*F['Phi_pp'](x, y, sg)*ah**2
            if Phi <= PiI + 1e-12: continue
            B = cfg_sep(x, y, gg, bbar_n(x, y, sg, ah)*RN, RN, ah); C = cfg_int(x, y, gg, RN, aa); b0 = cfg_sep(x, y, gg, RN, RN, 0.0)
            W0 = b0['W']
            rows.append([(B['VB']-C['VB'])/W0, (B['VS']-C['VS'])/W0, (B['plat']+B['pi1']-C['firm'])/W0, (B['pi2']-C['pi2'])/W0, (B['W']-C['W'])/W0, (B['q']-C['q'])/b0['q']])
    m = np.median(np.array(rows), axis=0)*100
    print("    %-6.3g %-8d %-+10.3f %-+10.3f %-+10.3f %-+10.3f %-+10.3f %-+10.3f" % (gg, len(rows), *m))
print("\n[%.0f s]" % (time.time() - T0))
