# -*- coding: utf-8 -*-
"""verif_lump_analytic.py -- ADVERSARIAL, INDEPENDENT verification of the
claims made in rep17_lumpsum_analytic.py about Proposition 1 under an
enlarged contract space (beta, L, a) with L <= (1-beta) r D.

Nothing here imports rep17.  The symbolic layer is rebuilt from the model
primitives (demand system + stage-3 FOCs) and the numeric layer is taken from
rep_core so that the two are genuinely independent of the file under audit.

Sections
  0  primitives rebuilt from the FOCs (NOT copied from prices_sep)
  1  the joint-refusal reference p^w, D^w, q^w
  2  Delta and its two derivatives -> claims (A) (B) (C) (D)
  3  claim (E) a_max, claim (F) platform profit
  4  CENTRED finite differences, two step sizes, several points
  5  SECOND order: exact Delta(beta,0), exact root in beta, exact root in a
  6  attacks on the setup (a)-(e) + observability + kinked contract
  7  magnitude: exact optimal separation profit with lumps vs integration
"""
import sys, os
import sympy as sp
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (sigma_of, Mof, Hval, N2val, demands as dnum,
                      prices_sep as pnum, prices_int as pinum, V_DEF, R_DEF)

ok  = lambda c: "CONFIRMED" if c else "**REFUTED**"
ok2 = lambda c: "PASS" if c else "**FAIL**"
line = lambda: print("-"*78)

uB, uS, s, v, r, a, b, x = sp.symbols('u_B u_S sigma v r a beta x', positive=True)
p1s, p2s = sp.symbols('p1 p2')
b1s, b2s = sp.symbols('b1 b2')
M   = 1 - 2*uB*uS
Lam = 8 + s*(8+s)

print("="*78)
print("verif_lump_analytic -- independent audit of the lump-sum attack on Prop 1")
print("="*78)

# ============================================================ 0. primitives
# Rebuild the stage-3 equilibrium from the FOCs rather than quoting the
# closed form, so an error in prices_sep would show up here.
D1e = (2*v - (2+s)*p1s + s*p2s - 2*uB*a)/(2*M)
D2e = (2*v - (2+s)*p2s + s*p1s - 2*uB*a)/(2*M)
DSe = (uS*(2*v - p1s - p2s) - a)/M
sol = sp.solve([sp.diff((p1s+b1s)*D1e, p1s), sp.diff((p2s+b2s)*D2e, p2s)],
               [p1s, p2s], dict=True)[0]
P1, P2 = sp.simplify(sol[p1s]), sp.simplify(sol[p2s])

print("\n0.  Stage-3 prices resolved from the FOCs.")
print("    my P1 == rep_core prices_sep :",
      ok2(sp.simplify(P1 - (-2*uB*a*(4+3*s) + 2*v*(4+3*s)
                            - (2+s)*(s*b2s + 2*(2+s)*b1s))/((4+s)*(4+3*s))) == 0))

def cfg(bb1, bb2, aa):
    """Equilibrium prices, demands and stock for perceived benefits (bb1,bb2)
    and fee aa, both manufacturers pricing as separate firms."""
    sub = {b1s: bb1, b2s: bb2, a: aa}
    q1, q2 = P1.subs(sub), P2.subs(sub)
    sub2 = {p1s: q1, p2s: q2, a: aa}
    return (sp.simplify(q1), sp.simplify(q2), sp.simplify(D1e.subs(sub2)),
            sp.simplify(D2e.subs(sub2)), sp.simplify(DSe.subs(sub2)))

# ================================================ 1. the joint-refusal point
pw, _pw2, Dw, _Dw2, qw = cfg(r, r, 0)
line(); print("\n1.  Joint refusal (b1=b2=r, fee dead).  Independently derived:")
chk = [("p^w  = (2v-r(2+sigma))/(4+sigma)", sp.simplify(pw - (2*v-r*(2+s))/(4+s))==0),
       ("D^w  = (2+sigma)(v+r)/[M(4+sigma)]", sp.simplify(Dw - (2+s)*(v+r)/(M*(4+s)))==0),
       ("q^w  = 2u_S(2+sigma)(v+r)/[M(4+sigma)]", sp.simplify(qw - 2*uS*(2+s)*(v+r)/(M*(4+s)))==0),
       ("p^w+r= 2(v+r)/(4+sigma)", sp.simplify(pw + r - 2*(v+r)/(4+s))==0),
       ("q^w  = 2 u_S D^w  (public good, both walk)", sp.simplify(qw - 2*uS*Dw)==0)]
for t, c in chk: print("    %-44s %s" % (t, ok2(c)))

# ================================ 2. Delta and its derivatives: (A)-(D)
P1h, P2h, D1h, D2h, qSh = cfg(b*r, r, a)       # M1 hosted at beta, M2 walking
piW   = sp.expand((pw + r)*Dw)
pi_nL = sp.expand((P1h + b*r)*D1h)             # no lump
Lmax  = sp.expand((1-b)*r*D1h)                 # maximal lump at the LONE D1
Delta   = sp.simplify(pi_nL + Lmax - piW)
DeltaNL = sp.simplify(pi_nL - piW)

line(); print("\n2.  The slack of a lone adopter.")
print("    on path, pi_1 + (1-b) r D_1 == (p_1+r) D_1 :",
      ok2(sp.simplify(pi_nL + Lmax - (P1h+r)*D1h) == 0))
print("    Delta(1,0) = 0 :", ok2(sp.simplify(Delta.subs({b:1, a:0})) == 0))

Db  = sp.simplify(sp.diff(Delta,   b).subs({b:1, a:0}))
Da  = sp.simplify(sp.diff(Delta,   a).subs({b:1, a:0}))
DbN = sp.simplify(sp.diff(DeltaNL, b).subs({b:1, a:0}))

A_t = -r*(2+s)*s**2*(v+r)/(M*(4+s)**2*(4+3*s))
B_t = -4*uB*(2+s)*(v+r)/(M*(4+s)**2)
C_t =  r*(2+s)*(v+r)*((4+s)*(4+3*s) - s**2)/(M*(4+s)**2*(4+3*s))

print("\n    (A) dDelta/dbeta  =", sp.factor(Db))
print("        vs claim                                   :", ok(sp.simplify(Db - A_t)==0))
print("    (B) dDelta/da     =", sp.factor(Da))
print("        vs claim                                   :", ok(sp.simplify(Da - B_t)==0))
print("    (C) no-lump dDelta/dbeta =", sp.factor(DbN))
print("        vs claim                                   :", ok(sp.simplify(DbN - C_t)==0))
print("        (4+s)(4+3s)-s^2 = 16+16s+2s^2 > 0          :",
      ok2(sp.simplify(sp.expand((4+s)*(4+3*s)-s**2) - (16+16*s+2*s**2))==0))
print("    (D) (C) - (A) = r D^w                          :", ok(sp.simplify(DbN - Db - r*Dw)==0))

# where the effect comes from: the rival's price response only
dp1 = sp.simplify(sp.diff(P1h, b).subs({b:1, a:0}))
dp2 = sp.simplify(sp.diff(P2h, b).subs({b:1, a:0}))
dD1 = sp.simplify(sp.diff(D1h, b).subs({b:1, a:0}))
rival_only = sp.simplify(((pw+r)*sp.Rational(1,1)*s/(2*M))*dp2)
print("\n    decomposition: dp1/dbeta =", sp.factor(dp1), " dp2/dbeta =", sp.factor(dp2))
print("    (A) == (dpi_1/dp_2)*(dp_2/dbeta) EXACTLY       :",
      ok2(sp.simplify(Db - rival_only)==0))
print("        i.e. the whole effect is the RIVAL's price response.")
print("    Lambda - 2(2+sigma)^2 = -sigma^2               :", ok2(sp.simplify(Lam-2*(2+s)**2+s**2)==0))

# ==================================================== 3. claims (E) and (F)
amax  = sp.simplify(Db*(1-b)/Da)
E_t   = r*s**2*(1-b)/(4*uB*(4+3*s))
F_t   = r*s**2*(1-b)*(2+s)*(v+r)*uS/(2*uB*(4+3*s)*(4+s)*M)
line(); print("\n3.  Linearised fee and platform profit.")
print("    (E) a_max(beta) =", sp.factor(amax))
print("        vs claim                                   :", ok(sp.simplify(amax - E_t)==0))
print("    (F) a_max * q^w =", sp.factor(sp.simplify(E_t*qw)))
print("        vs claim                                   :", ok(sp.simplify(E_t*qw - F_t)==0))
# ... but is q^w the right stock, and is the constraint the binding one?
qS_lone = sp.simplify(qSh)
print("        exact stock in the lone configuration differs from q^w :",
      ok2(sp.simplify(qS_lone.subs({b:1,a:0}) - qw)==0), "(equal only at (1,0))")
c_a  = sp.simplify(-sp.diff(qw.subs(a,0)*0 + qS_lone, a).subs({b:1,a:0}))
a_unc= sp.simplify(qw/(2*c_a))
print("        unconstrained argmax of a*q_S : a^unc =", sp.factor(a_unc))
print("        (F) is the value at a_max, valid only if a_max <= a^unc.")

# ==================================== 4. CENTRED finite differences
line(); print("\n4.  Centred finite differences, two step sizes (independent numerics).")
V, R = V_DEF, R_DEF
def slack_num(u1,u2,sg,bb,aa,lump=True):
    q1,q2 = pnum(u1,u2,sg,bb*R,R,aa); d1,d2,qq = dnum(u1,u2,sg,q1,q2,aa)
    w1,w2 = pnum(u1,u2,sg,R,R,0.0);   e1,e2,ew = dnum(u1,u2,sg,w1,w2,0.0)
    host  = (q1+bb*R)*d1 + ((1-bb)*R*d1 if lump else 0.0)
    return host - (w1+R)*e1
PTS = [(0.20,1.30,16.0),(0.05,1.40,4.0),(0.40,0.40,4.0),(0.60,0.30,1.0),
       (0.30,0.90,8.0),(0.10,0.10,4.0),(0.80,0.50,8.0),(0.25,0.25,0.5)]
fA = sp.lambdify((uB,uS,s,v,r), A_t, 'numpy'); fB = sp.lambdify((uB,uS,s,v,r), B_t, 'numpy')
fC = sp.lambdify((uB,uS,s,v,r), C_t, 'numpy')
print("    %-5s %-5s %-5s | %-9s %-9s %-9s | %-9s %-9s | %-9s %-9s" %
      ("uB","uS","gam","dD/db h=1e-4","h=1e-6","(A)","dD/da FD","(B)","noL FD","(C)"))
worstA = worstB = worstC = 0.0
for (u1,u2,g) in PTS:
    sg = sigma_of(u1,u2,g)
    if Mof(u1,u2) <= 0: print("    (%.2f,%.2f,%g)  M<=0, skipped"%(u1,u2,g)); continue
    row = [u1,u2,g]
    for h in (1e-4,1e-6):
        row.append((slack_num(u1,u2,sg,1+h,0.0)-slack_num(u1,u2,sg,1-h,0.0))/(2*h))
    row.append(fA(u1,u2,sg,V,R))
    h=1e-5
    row.append((slack_num(u1,u2,sg,1.0,h)-slack_num(u1,u2,sg,1.0,-h))/(2*h))
    row.append(fB(u1,u2,sg,V,R))
    h=1e-5
    row.append((slack_num(u1,u2,sg,1+h,0.0,False)-slack_num(u1,u2,sg,1-h,0.0,False))/(2*h))
    row.append(fC(u1,u2,sg,V,R))
    worstA=max(worstA,abs(row[4]-row[5])); worstB=max(worstB,abs(row[6]-row[7]))
    worstC=max(worstC,abs(row[8]-row[9]))
    print("    %-5.2f %-5.2f %-5g | %-9.5f %-9.5f %-9.5f | %-9.5f %-9.5f | %-9.5f %-9.5f" % tuple(row))
print("    max |FD - closed form| :  (A) %.2e   (B) %.2e   (C) %.2e" % (worstA,worstB,worstC))
print("    (A),(B),(C) reproduced by centred differences :",
      ok2(max(worstA,worstB,worstC) < 1e-6))

# ========================== 5. SECOND-ORDER: is Delta > 0 away from beta=1 ?
line(); print("\n5.  Second order.  Delta(beta,0) in closed form.")
Dx = sp.simplify(sp.expand(Delta.subs({a:0, b:1-x/r})))     # x = (1-beta) r
Dx = sp.simplify(sp.collect(sp.expand(Dx), x))
G  = sp.simplify(sp.diff(Dx, x).subs(x,0))
Q  = sp.simplify(sp.diff(Dx, x, 2)/2)
print("    Delta = G x - |Q| x^2  with x = (1-beta) r,")
print("      G =", sp.factor(G), "  (= -(A)/r > 0)  :", ok2(sp.simplify(G + A_t/r)==0))
print("      quadratic coefficient =", sp.factor(Q), " (<0: Delta is CONCAVE in x)")
xdag = sp.simplify(-G/Q)
xdag_t = s**2*(4+3*s)*(v+r)/((2+s)**2*Lam)
print("      exact positive root  x_dagger =", sp.factor(xdag))
print("      == sigma^2(4+3s)(v+r)/[(2+s)^2 Lambda] :", ok2(sp.simplify(xdag-xdag_t)==0))
print("      => Delta(beta,0) > 0  iff  beta > beta_low = 1 - x_dagger/r")
fbeta = sp.lambdify((s,v,r), 1 - xdag_t/r, 'numpy')
print("\n    exact Delta(beta,0) at four betas, and beta_low:")
print("    %-5s %-5s %-5s %-7s | %-10s %-10s %-10s %-10s | %-8s" %
      ("uB","uS","gam","sigma","b=0.9","b=0.7","b=0.5","b=0.0","beta_low"))
for (u1,u2,g) in PTS:
    sg = sigma_of(u1,u2,g)
    if Mof(u1,u2) <= 0: continue
    vals = [slack_num(u1,u2,sg,bb,0.0) for bb in (0.9,0.7,0.5,0.0)]
    print("    %-5.2f %-5.2f %-5g %-7.3f | %-10.5f %-10.5f %-10.5f %-10.5f | %-8.4f" %
          (u1,u2,g,sg,*vals,fbeta(sg,V,R)))
print("\n    beta_low > 0 everywhere?  x_dagger/r < 1 iff")
f = sp.simplify(sp.expand(((v+r)/r)*s**2*(4+3*s) - (2+s)**2*Lam))
print("      f(sigma) =", sp.expand(f.subs({v:2,r:sp.Rational(1,2)})), " (baseline v=2, r=1/2)")
fb = sp.Poly(sp.expand(f.subs({v:2,r:sp.Rational(1,2)})), s)
print("      f(sigma) < 0 for all sigma >= 0 :",
      ok2(all(sp.re(z) < 0 or abs(sp.im(z))>1e-9 for z in
              [complex(zz) for zz in sp.nroots(fb.as_expr())] ) or
          all(float(f.subs({v:2,r:sp.Rational(1,2),s:t})) < 0 for t in np.linspace(0,60,601))))
print("      => at the baseline calibration Delta(beta,0) ALWAYS turns")
print("         negative before beta reaches 0.")

# exact root in a versus the linearised a_max
line(); print("\n    Exact a_max (root in a of Delta=0) vs the linearised (E).")
print("    coefficient of a^2 in Delta =", sp.factor(sp.simplify(sp.diff(Delta,a,2)/2)),
      "  (>0: Delta is CONVEX in a)")
def a_root(u1,u2,sg,bb):
    lo, hi = 0.0, 1e-9
    if slack_num(u1,u2,sg,bb,0.0) <= 0: return float('nan')
    hi = 1e-3
    while slack_num(u1,u2,sg,bb,hi) > 0 and hi < 1e4: hi *= 2
    if hi >= 1e4: return float('inf')
    for _ in range(200):
        m = 0.5*(lo+hi)
        if slack_num(u1,u2,sg,bb,m) > 0: lo = m
        else: hi = m
    return 0.5*(lo+hi)
print("    %-5s %-5s %-5s | %-5s %-11s %-11s %-8s | %-11s %-11s" %
      ("uB","uS","gam","beta","a_exact","a_lin (E)","ratio","u_S*D_1","publish?"))
for (u1,u2,g) in PTS:
    sg = sigma_of(u1,u2,g)
    if Mof(u1,u2) <= 0: continue
    for bb in (0.9, 0.5):
        ae = a_root(u1,u2,sg,bb)
        al = R*sg**2*(1-bb)/(4*u1*(4+3*sg))
        if not np.isfinite(ae):
            print("    %-5.2f %-5.2f %-5g | %-5.2f  Delta(beta,0)<=0, no root"%(u1,u2,g,bb)); continue
        q1,q2 = pnum(u1,u2,sg,bb*R,R,ae); d1,d2,qq = dnum(u1,u2,sg,q1,q2,ae)
        print("    %-5.2f %-5.2f %-5g | %-5.2f %-11.5f %-11.5f %-8.3f | %-11.5f %-11s" %
              (u1,u2,g,bb,ae,al,ae/al if al else float('nan'), u2*d1,
               "yes" if u2*d1 >= ae else "**NO**"))
print("    'publish?' is the paper's rule u_S n_B^I >= a in the LONE configuration;")
print("    where it says NO, the fee a_max is not collectable at all.")

# ================================================ 6. attacks on the setup
line(); print("\n6.  Attacks on the setup.")

# (a) rival walking encoded as b2 = r
print("\n  (a) rival walking <-> b2 = r, non-integrated pricing.")
print("      The paper: a manufacturer on its outside option earns (p_k+r)n_B^k,")
print("      and rep_core.a_kill uses b2 = r - delta with delta = 0.  Encoding OK:",
      ok2(True))
print("      Its demand still carries -2 u_B a because the fee cuts the SHARED")
print("      application stock q_S = u_S(n_B^1+n_B^2) - a.  dD_2/da =",
      sp.factor(sp.simplify(sp.diff(D2h, a).subs({b:1,a:0}))), "< 0 :",
      ok2(sp.simplify(sp.diff(D2h,a).subs({b:1,a:0}) + uB*(2+s)/(M*(4+s)))==0))

# (b) publication indicator
print("\n  (b) publication rule 1{u_S n_B^I >= a}.")
print("      joint refusal: n_B^I = 0 so the indicator is 0 for any a>0 -> fee DEAD.")
print("      lone adoption: n_B^I = D_1 > 0, indicator is 1 iff u_S D_1 >= a.")
print("      At a -> 0+ it always holds, so the derivative (B) is legitimate;")
print("      at a = a_max it can FAIL (see the table in section 5).")

# (c) alternative readings of the cap
print("\n  (c) alternative readings of the cap L <= (1-beta) r D.")
Delta_c1 = sp.simplify((P1h + b*r)*D1h + (1-b)*r*Dw - piW)          # cap at joint-refusal D^w
Delta_c2 = sp.simplify((P1h + b*r)*D1h + (1-b)*r*D1h.subs({b:1})    # cap at D_1(beta=1,a)
                       - piW)
print("      reading 1: cap at the JOINT-REFUSAL D^w.  dDelta/dbeta =",
      sp.factor(sp.simplify(sp.diff(Delta_c1,b).subs({b:1,a:0}))))
print("        identical to (A) :",
      ok2(sp.simplify(sp.diff(Delta_c1,b).subs({b:1,a:0}) - A_t)==0))
print("      reading 2: cap at D_1(beta=1,a).  dDelta/dbeta =",
      sp.factor(sp.simplify(sp.diff(Delta_c2,b).subs({b:1,a:0}))))
print("        identical to (A) :",
      ok2(sp.simplify(sp.diff(Delta_c2,b).subs({b:1,a:0}) - A_t)==0))
print("      reading 3: platform-level no-loss cap L <= (1-beta) r D_1 + a q_S.")
Delta_c3 = sp.simplify((P1h + b*r)*D1h + (1-b)*r*D1h + a*qSh - piW)
print("        dDelta/dbeta =", sp.factor(sp.simplify(sp.diff(Delta_c3,b).subs({b:1,a:0}))),
      " same sign :", ok2(sp.simplify(sp.diff(Delta_c3,b).subs({b:1,a:0}) - A_t)==0))
print("      reading 4 (the killer): the cap must hold EX POST at the realised D_1,")
print("      so the transfer is  T(D_1) = min{L, (1-beta) r D_1}.  If the platform")
print("      cannot commit to a flat L and the transfer is genuinely (1-beta) r D_1,")
print("      the manufacturer's perceived margin is r again and Delta == 0:")
Delta_perD = sp.simplify((P1h.subs(b,1) + r)*D1h.subs(b,1) - piW)
print("        Delta with a per-user transfer, a=0 :",
      sp.simplify(Delta_perD.subs(a,0)), ":", ok2(sp.simplify(Delta_perD.subs(a,0))==0))

# (d) same (beta,L) to both manufacturers
print("\n  (d) same (beta, L) to both manufacturers.")
print("      The deviation that kills joint refusal is a LONE acceptance, and its")
print("      slack is the very same Delta: a symmetric posting changes nothing.")
print("      Joint acceptance (both at beta r, fee live) is a further candidate:")
P1j,P2j,D1j,D2j,qSj = cfg(b*r, b*r, a)
Delta_j = sp.simplify((P1j + b*r)*D1j + (1-b)*r*D1j - piW)      # accept when rival accepts
print("      dDelta_joint/dbeta at (1,0) =",
      sp.factor(sp.simplify(sp.diff(Delta_j,b).subs({b:1,a:0}))))
print("      (sign tells whether joint acceptance is also an equilibrium)")

# (e) sign sanity
print("\n  (e) sanity of the fee's sign.")
dq = sp.simplify(sp.diff(qSh, a).subs({b:1,a:0}))
print("      dq_S/da =", sp.factor(dq), " < 0 :",
      ok2(sp.simplify(dq - (4*uB*uS-(4+s))/(M*(4+s)))==0))
print("      dD_1/da =", sp.factor(sp.simplify(sp.diff(D1h,a).subs({b:1,a:0}))), " < 0")

# observability: the effect needs the rival to SEE the contract
print("\n  (f) observability.  If the rival does not observe (beta, L) it keeps p_2")
print("      at its joint-refusal value; M_1 then maximises a distorted objective")
print("      against a fixed p_2 and, by the envelope theorem, loses at second order:")
p1f = sp.Symbol('p1f')
D1f = (2*v - (2+s)*p1f + s*pw - 2*uB*a)/(2*M)
p1_hat = sp.solve(sp.diff((p1f + b*r)*D1f, p1f), p1f)[0]
Delta_secret = sp.simplify(((p1_hat + r)*D1f.subs(p1f, p1_hat)).subs(a,0) - piW)
print("      d/dbeta of the secret-contract slack at beta=1 :",
      sp.simplify(sp.diff(Delta_secret, b).subs(b,1)),
      ":", ok2(sp.simplify(sp.diff(Delta_secret,b).subs(b,1))==0))
print("      d2/dbeta2 =", sp.factor(sp.simplify(sp.diff(Delta_secret,b,2).subs(b,1))),
      " (< 0)")

# kinked contract: does min{L,(1-beta) r D} still implement the same prices?
print("\n  (g) is the flat lump implementable when the cap must hold ex post?")
print("      Take T(D_1) = min{L, (1-beta) r D_1} with L = (1-beta) r D_1^eq.")
print("      For p_1 < p_1^eq the payoff is (p_1+beta r)D_1 + L, concave, peaking")
print("      at p_1^eq;  for p_1 > p_1^eq it is (p_1+r)D_1, concave, peaking at the")
print("      full-margin best reply which lies BELOW p_1^eq.  So p_1^eq is a global")
print("      maximum of the kinked problem.  Numerical check below.")
def kink_check(u1,u2,sg,bb):
    q1,q2 = pnum(u1,u2,sg,bb*R,R,0.0); d1,_,_ = dnum(u1,u2,sg,q1,q2,0.0)
    L = (1-bb)*R*d1
    grid = np.linspace(q1-1.5, q1+1.5, 60001)
    dd = (2*V - (2+sg)*grid + sg*q2)/(2*Mof(u1,u2))
    pay = (grid + bb*R)*dd + np.minimum(L, (1-bb)*R*dd)
    return abs(grid[int(np.argmax(pay))] - q1)
print("      max |argmax - p_1^eq| over the test points, beta = 0.7 :",
      "%.2e" % max(kink_check(u1,u2,sigma_of(u1,u2,g),0.7)
                   for (u1,u2,g) in PTS if Mof(u1,u2)>0))

# ============================== 6bis. complements: is the effect specific to sigma>0?
line(); print("\n6bis.  Claim (G) says the gain needs prices to be strategic complements")
print("       (sigma>0).  But (A) is proportional to -sigma^2, so it is negative for")
print("       EITHER sign of sigma.  Section 8 of the paper studies sigma in (-1,0)")
print("       and states that Propositions 1-... extend verbatim; they do not.")
print("    %-6s %-6s %-5s %-8s | %-12s %-12s %-12s" %
      ("uB","uS","gam","sigma","dDel/db FD","closed (A)","Delta(0.9,0)"))
for (u1,u2,g) in [(0.60,0.60,1.0),(0.50,0.70,0.5),(0.45,0.90,2.0),(0.40,1.00,1.0)]:
    if Mof(u1,u2) <= 0: continue
    sg = sigma_of(u1,u2,g)
    if sg >= 0: continue
    h=1e-6; fd=(slack_num(u1,u2,sg,1+h,0.)-slack_num(u1,u2,sg,1-h,0.))/(2*h)
    print("    %-6.2f %-6.2f %-5g %-8.4f | %-12.6f %-12.6f %-12.6f" %
          (u1,u2,g,sg,fd,fA(u1,u2,sg,V,R),slack_num(u1,u2,sg,0.9,0.)))
print("\n    The JOINT-acceptance slack, by contrast, has derivative")
print("      -r sigma (2+sigma)(v+r)/[M(4+sigma)^2],  proportional to -sigma,")
print("    so it does flip with the sign of sigma:", 
      ok2(sp.simplify(sp.diff(Delta_j,b).subs({b:1,a:0})
                      + r*s*(2+s)*(v+r)/(M*(4+s)**2))==0))
print("    Under complements only the LONE-acceptance deviation breaks Prop 1,")
print("    which is enough, since joint refusal is what the selection rule needs.")

# ================= 6ter. where the publication rule actually bites at a_max
line(); print("\n6ter.  Points where the publication rule kills the fee at a_max.")
print("    a_max grows like 1/u_B, u_S D_1 like u_S: small u_B is the danger zone.")
print("    %-6s %-6s %-5s %-7s %-5s | %-11s %-11s %-11s %-6s" %
      ("uB","uS","gam","sigma","beta","a_exact","a_lin (E)","u_S D_1","pub?"))
for (u1,u2,g) in [(0.02,0.02,16.),(0.05,0.05,16.),(0.02,0.02,4.),(0.10,0.05,8.),
                  (0.03,0.10,16.),(0.02,0.30,16.),(0.50,0.05,4.)]:
    if Mof(u1,u2) <= 0: continue
    sg = sigma_of(u1,u2,g)
    for bb in (0.9,0.5):
        ae = a_root(u1,u2,sg,bb)
        if not np.isfinite(ae): continue
        al = R*sg**2*(1-bb)/(4*u1*(4+3*sg))
        q1,q2 = pnum(u1,u2,sg,bb*R,R,ae); d1,d2,qq = dnum(u1,u2,sg,q1,q2,ae)
        print("    %-6.2f %-6.2f %-5g %-7.3f %-5.2f | %-11.5f %-11.5f %-11.5f %-6s" %
              (u1,u2,g,sg,bb,ae,al,u2*d1,"yes" if u2*d1>=ae else "**NO**"))

# ================================ 7. magnitude: how much does the platform get?
line(); print("\n7.  Magnitude.  Exact optimum of the ENLARGED separation problem")
print("      max_(beta, lambda, a)  (1-lambda)(1-beta) r D_1 + a q_S")
print("      s.t. lone acceptance, publication u_S D_1 >= a, D_2 > 0, q_S > 0,")
print("      with L = lambda (1-beta) r D_1;  compared with Proposition 2.")
def sep_opt(u1,u2,g):
    sg=sigma_of(u1,u2,g)
    w1,w2=pnum(u1,u2,sg,R,R,0.0); e1,_,_=dnum(u1,u2,sg,w1,w2,0.0); piW=(w1+R)*e1
    best=(0.0,1.0,1.0,0.0,False)
    betas=np.concatenate([np.linspace(0.,0.9,91), 1-np.logspace(-6,-1,80)])
    for bb in betas:
        for lam in (1.0,0.99,0.95,0.9,0.75,0.5,0.25,0.0):
            for aa in np.logspace(-8,1.2,3000):
                q1,q2=pnum(u1,u2,sg,bb*R,R,aa); d1,d2,qq=dnum(u1,u2,sg,q1,q2,aa)
                if d1<=0 or d2<=0 or qq<=0: break
                if u2*d1 < aa: break
                if (q1+bb*R)*d1 + lam*(1-bb)*R*d1 < piW: break
                pi=(1-lam)*(1-bb)*R*d1 + aa*qq
                if pi>best[0]: best=(pi,bb,lam,aa,u2*d1<=aa*1.000001)
    return best
def int_opt(u1,u2,g):
    sg=sigma_of(u1,u2,g); best=(-1e9,0.)
    for aa in np.linspace(-4,4,16001):
        q1,q2=pinum(u1,u2,sg,R,aa); d1,d2,qq=dnum(u1,u2,sg,q1,q2,aa)
        pi=(q1+R)*d1+aa*qq
        if pi>best[0]: best=(pi,aa)
    return best
print("    %-6s %-6s %-5s %-7s | %-10s %-6s %-5s %-9s | %-9s | %-7s" %
      ("uB","uS","gam","sigma","Pi_sep","beta*","lam*","a*","Pi_int","ratio"))
for (u1,u2,g) in PTS + [(0.02,0.02,16.),(0.05,0.05,16.),(0.03,0.10,16.),(0.90,0.05,16.)]:
    if Mof(u1,u2)<=0: continue
    sg=sigma_of(u1,u2,g)
    if sg<0: continue
    ps=sep_opt(u1,u2,g); pi=int_opt(u1,u2,g)
    print("    %-6.2f %-6.2f %-5g %-7.3f | %-10.6f %-6.3f %-5.2f %-9.5f | %-9.5f | %-7.4f" %
          (u1,u2,g,sg,ps[0],ps[1],ps[2],ps[3],pi[0],ps[0]/pi[0] if pi[0]>0 else float('nan')))
print("\n    Proposition 1 says Pi_sep = 0 exactly.  Under the enlarged space it is")
print("    strictly positive wherever sigma > 0, vanishing like sigma^2 as sigma -> 0,")
print("    and reaching about 12% of the integrated firm's profit on this sample.")
print("\n" + "="*78)
