# Does the lump help the INTEGRATED firm too?  If it does, the enlargement is
# not a threat to the ranking, only to the level of the benchmark.
import sys, numpy as np, sympy as sp
sys.path.insert(0,'/root/vi2sm/replication')
from rep_core import sigma_of, Mof, Hval, demands, prices_int, prices_sep, V_DEF, R_DEF
import rep3_contracts as C
V,R=V_DEF,R_DEF

def int_cfg(uB,uS,sig,b2,a):
    p1,p2=prices_int(uB,uS,sig,b2,a,R,V); D1,D2,q=demands(uB,uS,sig,p1,p2,a)
    return p1,p2,D1,D2,q

def int_value(uB,uS,sig,b2,a,L2):
    """Integrated firm: owns M1, hosts M2 at perceived benefit b2 with a lump L2."""
    p1,p2,D1,D2,q=int_cfg(uB,uS,sig,b2,a)
    if min(D1,D2,q)<=0: return None
    return (p1+R)*D1 + a*q + (R-b2)*D2 - L2, (p2+b2)*D2 + L2, D1, D2, q

def m2_outside(uB,uS,sig,a):
    """M2 refuses: hosted nowhere, keeps r, and the integrated firm still runs its
    own store so the fee stays live on D1."""
    p1,p2,D1,D2,q=int_cfg(uB,uS,sig,R,a)
    return (p2+R)*D2, D1, D2, q

print("Integration WITH a lump to the hosted rival, against integration without.\n")
print("%-6s %-6s %-5s %-12s %-12s %-9s %-12s" %
      ("u_B","u_S","gam","int no lump","int + lump","gain %","argmax(b2,a)"))
GB=np.arange(0.0,1.0001,0.05); GA=np.arange(0.0,4.001,0.02)
for (u1,u2,g) in ((0.05,1.4,4.0),(0.05,1.4,16.0),(0.2,1.3,16.0),(0.4,0.4,4.0),
                  (0.3,0.9,8.0),(0.5,0.15,4.0),(0.9,0.25,8.0),(0.6,0.3,1.0)):
    if Mof(u1,u2)<=0: continue
    sig=sigma_of(u1,u2,g)
    if sig<0 or Hval(u1,u2,sig)<=0: print("  (%.2f,%.2f,%g) inadmissible"%(u1,u2,g)); continue
    base=0.0; bl=0.0; arg=None
    for b2 in GB:
        for a in GA:
            out=int_value(u1,u2,sig,b2*R,a,0.0)
            if out is None: continue
            piW,_,_,_=m2_outside(u1,u2,sig,a)
            # no lump: M2 must weakly prefer hosting
            if out[1] >= piW-1e-12 and out[0]>base: base=out[0]
            # with the maximal lump L2 = (1-b2) r D2, cap enforced at this config
            L=(1-b2)*R*out[3]
            o2=int_value(u1,u2,sig,b2*R,a,L)
            if o2 and o2[1] >= piW-1e-12 and o2[0]>bl: bl,arg=o2[0],(round(b2,2),round(a,3))
    print("%-6.2f %-6.2f %-5g %-12.5f %-12.5f %-9s %-12s" %
          (u1,u2,g,base,bl,"%+.1f%%"%(100*(bl-base)/base) if base>0 else "-",str(arg)))
