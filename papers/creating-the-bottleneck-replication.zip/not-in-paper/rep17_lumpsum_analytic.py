# -*- coding: utf-8 -*-
"""rep17_lumpsum_analytic.py -- what a lump-sum transfer does to Proposition 1.

Enlarged contract space: the platform posts (beta^k, L^k, a).  A manufacturer
that hosts receives beta^k r per own user PLUS a lump L^k >= 0, and the
economic restriction is that the total payment cannot exceed the revenue its
own users generate:

        beta^k r D_k + L^k  <=  r D_k        i.e.   L^k <= (1-beta^k) r D_k .

The question is whether Proposition 1 (the platform earns nothing under
separation) survives.  This file settles it analytically at the margin; the
companion rep17_lumpsum_numeric.py checks the global statement.

Notation as in rep_core: sigma, M = 1-2 u_B u_S, Lambda = 8 + sigma(8+sigma).
Reference configuration: joint refusal, both manufacturers at the full margin
r, the fee dead (a = 0).  Write p^w, D^w, q^w for that configuration.
"""
import sympy as sp

uB, uS, s, v, r, a, b = sp.symbols('u_B u_S sigma v r a beta', positive=True)
M = 1 - 2*uB*uS
Lam = 8 + s*(8+s)

# ---------------------------------------------------------------- primitives
def prices_sep(b1, b2, aa):
    den = (4+s)*(4+3*s)
    p1 = (-2*uB*aa*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*b2 + 2*(2+s)*b1))/den
    p2 = (-2*uB*aa*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*b1 + 2*(2+s)*b2))/den
    return sp.simplify(p1), sp.simplify(p2)

def demands(p1, p2, aa):
    D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*aa)/(2*M)
    D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*aa)/(2*M)
    qS = (uS*(2*v - p1 - p2) - aa)/M
    return sp.simplify(D1), sp.simplify(D2), sp.simplify(qS)

ok = lambda c: "PASS" if c else "**FAIL**"
print("="*74)
print("rep17_lumpsum_analytic  --  Proposition 1 with lump sums")
print("="*74)

# ------------------------------------------------ 0. the reference (RR, a=0)
pw1, pw2 = prices_sep(r, r, 0)
Dw1, Dw2, qw = demands(pw1, pw2, 0)
pw  = sp.simplify(pw1)
Dw  = sp.simplify(Dw1)
print("\n0.  Joint refusal, both at the full margin r, fee dead.")
print("    p^w  =", sp.simplify(pw), "   target (2v-r(2+s))/(4+s)")
print("       ", ok(sp.simplify(pw - (2*v-r*(2+s))/(4+s)) == 0))
print("    D^w  =", sp.simplify(Dw), "   target (2+s)(v+r)/(M(4+s))")
print("       ", ok(sp.simplify(Dw - (2+s)*(v+r)/(M*(4+s))) == 0))
print("    q^w  =", sp.simplify(qw), "   target 2u_S(2+s)(v+r)/(M(4+s))")
print("       ", ok(sp.simplify(qw - 2*uS*(2+s)*(v+r)/(M*(4+s))) == 0))
print("    p^w+r=", sp.simplify(pw+r), "   target 2(v+r)/(4+s)")
print("       ", ok(sp.simplify(pw+r - 2*(v+r)/(4+s)) == 0))

# ------------------------- 1. lone adopter at (beta, a), the other one walking
p1, p2 = prices_sep(b*r, r, a)
D1, D2, qS = demands(p1, p2, a)
pi1_noL  = sp.simplify((p1 + b*r)*D1)          # payoff with no lump
lump_max = sp.simplify((1-b)*r*D1)             # the largest lump allowed
pi1_L    = sp.simplify(pi1_noL + lump_max)
print("\n1.  With the maximal lump the hosted payoff collapses to the")
print("    full-margin profit evaluated at the HOSTED prices and the LIVE fee:")
print("       pi_1 + (1-beta) r D_1  =  (p_1 + r) D_1")
print("      ", ok(sp.simplify(pi1_L - (p1+r)*D1) == 0))

piW = sp.simplify((pw + r)*Dw)                 # payoff at joint refusal
Delta   = sp.simplify(pi1_L   - piW)           # slack of the lone adopter, with lump
DeltaNL = sp.simplify(pi1_noL - piW)           # slack without the lump
print("\n    Delta(beta,a) = 0 at (beta,a) = (1,0):", ok(sp.simplify(Delta.subs({b:1,a:0}))==0))

# ------------------------------------------------- 2. the two derivatives
Db = sp.simplify(sp.diff(Delta, b).subs({b:1, a:0}))
Da = sp.simplify(sp.diff(Delta, a).subs({b:1, a:0}))
Db_target = -r*(2+s)*s**2*(v+r)/(M*(4+s)**2*(4+3*s))
Da_target = -4*uB*(2+s)*(v+r)/(M*(4+s)**2)
print("\n2.  Derivatives of the slack at the reference point.")
print("    dDelta/dbeta = ", sp.factor(Db))
print("       target  -r(2+s)sigma^2(v+r) / [M(4+s)^2(4+3s)] :",
      ok(sp.simplify(Db - Db_target) == 0))
print("    dDelta/da    = ", sp.factor(Da))
print("       target  -4u_B(2+s)(v+r) / [M(4+s)^2] :",
      ok(sp.simplify(Da - Da_target) == 0))
print("\n    Both are strictly negative on the admissible set (sigma>0, M>0).")
print("    dDelta/dbeta < 0 means: LOWERING beta below 1, with the lump kept")
print("    maximal, STRICTLY RAISES the lone adopter's payoff.  Joint refusal")
print("    is therefore not an equilibrium and Proposition 1 fails.")

# --------------------------------------- 3. where the sign reversal comes from
DbNL = sp.simplify(sp.diff(DeltaNL, b).subs({b:1, a:0}))
DbNL_target = r*(2+s)*(v+r)*((4+s)*(4+3*s) - s**2)/(M*(4+s)**2*(4+3*s))
print("\n3.  Without the lump the same derivative is POSITIVE (Proposition 1).")
print("    dDelta^noL/dbeta =", sp.factor(DbNL))
print("       target  r(2+s)(v+r)[(4+s)(4+3s)-sigma^2] / [M(4+s)^2(4+3s)] :",
      ok(sp.simplify(DbNL - DbNL_target) == 0))
print("       (4+s)(4+3s) - sigma^2 = 16+16s+2s^2 > 0 :",
      ok(sp.simplify(sp.expand((4+s)*(4+3*s)-s**2) - (16+16*s+2*s**2)) == 0))
print("\n    Difference of the two derivatives = r D^w exactly:")
print("      ", ok(sp.simplify(DbNL - Db - r*Dw) == 0))
print("    The lump cancels the direct loss of margin r D^w and leaves the")
print("    pure strategic term -r(2+s)sigma^2(v+r)/[M(4+s)^2(4+3s)].")

# ------------------------------------------------ 4. the strategic term itself
dp1 = sp.simplify(sp.diff(p1, b).subs({b:1,a:0}))
dp2 = sp.simplify(sp.diff(p2, b).subs({b:1,a:0}))
dD1 = sp.simplify(sp.diff(D1, b).subs({b:1,a:0}))
print("\n4.  Reading of the strategic term (Bonanno-Vickers / Fershtman-Judd).")
print("    dp_1/dbeta =", sp.factor(dp1), "   < 0 : the hosted manufacturer prices HIGHER")
print("    dp_2/dbeta =", sp.factor(dp2), "   < 0 : the rival follows (strategic complements, sigma>0)")
print("    dD_1/dbeta =", sp.factor(dD1), "   > 0 : the hosted one loses share")
print("    Net on (p_1+r)D_1 :  D^w dp_1/dbeta + (p^w+r) dD_1/dbeta")
print("      = (v+r)/[M(4+s)] * [Lambda - 2(2+s)^2] / ... with Lambda - 2(2+s)^2 = -sigma^2 :",
      ok(sp.simplify(Lam - 2*(2+s)**2 + s**2) == 0))
print("    beta < 1 makes the manufacturer price as if its per-user revenue were")
print("    beta r while the lump leaves its total revenue unchanged: this is exactly")
print("    strategic delegation, and it is profitable whenever sigma is not zero.")

# ------------------------------------ 5. the fee the platform can then charge
amax = sp.simplify(Db*(1-b)/Da)
amax_t = r*s**2*(1-b)/(4*uB*(4+3*s))
print("\n5.  Largest fee compatible with lone acceptance, to first order.")
print("    a_max(beta) =", sp.factor(amax))
print("       target  r sigma^2 (1-beta) / [4 u_B (4+3 sigma)] :",
      ok(sp.simplify(amax - amax_t) == 0))
prof = sp.simplify(amax_t*qw)
prof_t = r*s**2*(1-b)*(2+s)*(v+r)*uS/(2*uB*(4+3*s)*(4+s)*M)
print("    platform profit  a_max q^w =", sp.factor(prof))
print("       target  r sigma^2 (1-beta)(2+s)(v+r) u_S / [2 u_B (4+3s)(4+s) M] :",
      ok(sp.simplify(prof - prof_t) == 0))
print("\n    Strictly positive, increasing in sigma^2 (hence in gamma) and in")
print("    u_S/u_B: the platform gains most where the market is developer-skewed,")
print("    which is exactly where the numerical search puts its argmax.")

# ------------------------------------------------------- 6. numerical sanity
print("\n6.  Numerical check of the closed forms at a few points.")
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import sigma_of, Mof, Hval, demands as dnum, prices_sep as pnum, V_DEF, R_DEF
V, R = V_DEF, R_DEF
print("    %-6s %-6s %-5s %-11s %-11s %-11s %-11s" %
      ("u_B","u_S","gam","dD/dbeta","closed form","a_max(0)","closed form"))
for (u1,u2,g) in ((0.2,1.3,16.0),(0.05,1.4,4.0),(0.4,0.4,4.0),(0.6,0.3,1.0),(0.3,0.9,8.0)):
    sg = sigma_of(u1,u2,g)
    if Mof(u1,u2) <= 0 or sg < 0 or Hval(u1,u2,sg) <= 0:
        print("    (%.2f,%.2f,%g) not admissible" % (u1,u2,g)); continue
    h = 1e-6
    def slack(bb, aa):
        q1,q2 = pnum(u1,u2,sg,bb*R,R,aa); d1,d2,qq = dnum(u1,u2,sg,q1,q2,aa)
        w1,w2 = pnum(u1,u2,sg,R,R,0.0);   e1,e2,ew = dnum(u1,u2,sg,w1,w2,0.0)
        return (q1+R)*d1 - (w1+R)*e1
    num = (slack(1.0,0.0) - slack(1.0-h,0.0))/h
    cls = float(Db_target.subs({s:sg, uB:u1, uS:u2, v:V, r:R}))
    am_n = cls*(1-0.0)/float(Da_target.subs({s:sg, uB:u1, uS:u2, v:V, r:R}))
    am_c = R*sg**2*1.0/(4*u1*(4+3*sg))
    print("    %-6.2f %-6.2f %-5g %-11.6f %-11.6f %-11.6f %-11.6f" %
          (u1,u2,g,num,cls,am_n,am_c))
print("\n" + "="*74)

# ============================================================================
# 7.  The exact slack (not just its derivative), and how far beta can be pushed
# ============================================================================
print("\n7.  Exact slack at a = 0, in the transfer x = (1-beta) r.")
x = sp.symbols('x', positive=True)
Dx = sp.expand(Delta.subs(a,0).subs(b, 1-x/r))
c0 = sp.simplify(Dx.coeff(x,0)); G = sp.simplify(Dx.coeff(x,1)); Q = sp.simplify(Dx.coeff(x,2))
print("    Delta(x,0) = G x + Q x^2, exactly (no higher term):",
      ok(sp.simplify(sp.expand(Dx) - (c0 + G*x + Q*x**2)) == 0), " and G x has no constant:", ok(c0==0))
print("    G =", sp.factor(G))
print("      target  sigma^2(2+s)(v+r)/[M(4+s)^2(4+3s)]  > 0 :",
      ok(sp.simplify(G - s**2*(2+s)*(v+r)/(M*(4+s)**2*(4+3*s))) == 0))
print("    Q =", sp.factor(Q))
print("      target  -(2+s)^3 Lambda/[M(4+s)^2(4+3s)^2]  < 0 :",
      ok(sp.simplify(Q + (2+s)**3*Lam/(M*(4+s)**2*(4+3*s)**2)) == 0))
xd = sp.simplify(-G/Q)
print("    Delta > 0 on 0 < x < x+, with")
print("      x+ =", sp.factor(xd))
print("      target  sigma^2(4+3s)(v+r)/[(2+s)^2 Lambda] :",
      ok(sp.simplify(xd - s**2*(4+3*s)*(v+r)/((2+s)**2*Lam)) == 0))
print("    So the acceptable shares are beta > beta_low = 1 - x+/r: the platform")
print("    does NOT push beta to zero.  At the baseline v=2, r=1/2,")
q = sp.together(xd.subs({v:2, r:sp.Rational(1,2)})/sp.Rational(1,2) - 1)
print("      x+/r - 1 has numerator", sp.expand(sp.numer(q)), "= -sigma^2(sigma^2-3sigma+24) -64sigma -32")
print("      and sigma^2 - 3 sigma + 24 > 0 (discriminant 9 - 96 < 0), so x+/r < 1")
print("      for every sigma >= 0 :",
      ok(sp.simplify(sp.expand(sp.numer(q)) + s**2*(s**2-3*s+24) + 64*s + 32) == 0))

# ============================================================================
# 8.  The repair: secret offers.  The whole break is the rival's price response
# ============================================================================
print("\n8.  Secret offers.  Suppose M_2 does not observe (beta^1, L^1) and, under")
print("    passive beliefs, holds its price at the joint-refusal value p^w.")
p = sp.symbols('p')
def D1of(p1,p2,aa): return (2*v-(2+s)*p1+s*p2-2*uB*aa)/(2*M)
pis = (p + b*r)*D1of(p, pw, 0)
p1s = sp.solve(sp.diff(pis,p), p)[0]
Ds  = sp.simplify((p1s + r)*D1of(p1s, pw, 0) - piW)
print("    exact slack =", sp.factor(Ds))
print("      target  -(1-beta)^2 r^2 (2+sigma)/(8M)  <= 0 :",
      ok(sp.simplify(Ds + (1-b)**2*r**2*(2+s)/(8*M)) == 0))
print("    Negative for every beta < 1, at every admissible point, and a > 0 only")
print("    makes it worse.  Proposition 1 holds verbatim once the offers are secret.")
print("    Under observed offers the loss of margin is refunded and what is left is")
print("    a FIRST-order gain; under secret offers it is a SECOND-order loss, because")
print("    the deviator is then simply maximising (p+r)D at the wrong price.")

print("\n    The identity behind this: with observed offers the entire derivative is")
print("    the rival's price response and nothing else --")
p1v, p2v = sp.symbols('p1v p2v')
piv = (p1v + r)*D1of(p1v, p2v, 0)
dpi_dp2 = sp.simplify(sp.diff(piv, p2v).subs({p1v:pw, p2v:pw}))
p1o, p2o = prices_sep(b*r, r, a)
dp2_db = sp.simplify(sp.diff(p2o, b).subs({b:1, a:0}))
print("       dDelta/dbeta = (dpi_1/dp_2)(dp_2/dbeta) :",
      ok(sp.simplify(Db - dpi_dp2*dp2_db) == 0))
print("       dpi_1/dp_2  =", sp.factor(dpi_dp2), "  (> 0: strategic complements)")
print("       dp_2/dbeta  =", sp.factor(dp2_db), "  (< 0 for sigma > 0)")
print("    The own-price and own-demand terms cancel by the envelope theorem.")
print("    The product is even in sigma, so the same failure occurs for complements")
print("    (sigma < 0), where both factors change sign.")
print("\n" + "="*74)
