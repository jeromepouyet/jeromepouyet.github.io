# -*- coding: utf-8 -*-
"""rep17_lumpsum_numeric.py -- the global statement behind rep17_lumpsum_analytic.

Enlarged contract space (beta^k, L^k, a) with the economic restriction
L^k <= (1-beta^k) r D_k.  The lump is paid only where the manufacturer hosts,
and it is capped by the revenue generated in THAT configuration.

Blocks
  B  global search on the admissible set A: can the platform earn > 0 ?
  C  the same restricted to u_B >= h_Phi(u_S), i.e. OUTSIDE the unraveling
     region of Proposition 6, and separately ON the band h_Phi <= u_B/u_S < h_a
  D  magnitude: the lump-sum profit under separation against the integration
     gain Pi^I of Section 3
  E  feasibility at the argmax: interiority, the publication rule
     u_S D_I >= a, and the equilibrium selected
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (sigma_of, Mof, Hval, demands, prices_sep, V_DEF, R_DEF)
import rep3_contracts as C
V, R = V_DEF, R_DEF

def cfg(uB, uS, sig, b1, b2, a):
    p1, p2 = prices_sep(uB, uS, sig, b1, b2, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    return [(p1+b1)*D1, (p2+b2)*D2, D1, D2, q, p1, p2]

def game(uB, uS, g, b1, b2, t1, t2, a, pubrule=False):
    """b1,b2 in [0,1] are beta^1, beta^2;  t1,t2 in [0,1] the fraction of the
    allowed cap (1-beta^k) r D_k actually paid as a lump.  Returns the platform's
    profit at the selected adoption equilibrium, and that equilibrium."""
    sig = sigma_of(uB, uS, g)
    ae = a if a < 0 else 0.0                       # the fee dies under joint refusal
    P = {'AA': cfg(uB,uS,sig, b1*R, b2*R, a), 'AR': cfg(uB,uS,sig, b1*R, R, a),
         'RA': cfg(uB,uS,sig, R, b2*R, a),    'RR': cfg(uB,uS,sig, R, R, ae)}
    for k in P:
        if min(P[k][2], P[k][3], P[k][4]) <= 0: return None
    if pubrule and a > 0:
        # the fee is collected only if a developer that publishes on the platform's
        # system gains at least a:  u_S n_B^I >= a, with n_B^I the buyer stock on
        # the devices that host.  AA: D1+D2, AR: D1, RA: D2.
        if uS*(P['AA'][2]+P['AA'][3]) < a: return None
        if uS*P['AR'][2] < a: return None
        if uS*P['RA'][3] < a: return None
    L = {'AA': (t1*(1-b1)*R*P['AA'][2], t2*(1-b2)*R*P['AA'][3]),
         'AR': (t1*(1-b1)*R*P['AR'][2], 0.0),
         'RA': (0.0, t2*(1-b2)*R*P['RA'][3]), 'RR': (0.0, 0.0)}
    pi = {k: (P[k][0]+L[k][0], P[k][1]+L[k][1]) for k in P}   # the lump is RECEIVED
    NE = []
    for prof, d1, d2 in (('AA','RA','AR'),('AR','RR','AA'),('RA','AA','RR'),('RR','AR','RA')):
        if pi[d1][0] <= pi[prof][0]+1e-12 and pi[d2][1] <= pi[prof][1]+1e-12: NE.append(prof)
    if not NE: return None
    sel = max(NE, key=lambda k: pi[k][0]+pi[k][1])
    D1, D2, q = P[sel][2], P[sel][3], P[sel][4]
    val = {'AA': (1-b1)*R*D1-L['AA'][0] + (1-b2)*R*D2-L['AA'][1] + a*q,
           'AR': (1-b1)*R*D1-L['AR'][0] + a*q,
           'RA': (1-b2)*R*D2-L['RA'][1] + a*q,
           'RR': ae*q}[sel]
    return val, sel

def adm(u1, u2, g):
    if Mof(u1,u2) <= 0: return None
    sig = sigma_of(u1,u2,g)
    if sig < 0 or Hval(u1,u2,sig) <= 0: return None
    return sig

GB  = np.arange(0.0, 1.0001, 0.1)
GA  = np.arange(0.02, 2.001, 0.04)
GT  = (0.0, 0.5, 1.0)
GRID = np.arange(0.05, 1.401, 0.05)

def best_at(u1, u2, g, pubrule=False):
    """Best platform profit over one-sided packages (beta^1, full range of lumps)."""
    loc = 0.0; arg = None
    for b1 in GB:
        for a in GA:
            for t1 in GT:
                o = game(u1,u2,g,b1,1.0,t1,0.0,a,pubrule)
                if o and o[0] > loc: loc, arg = o[0], (round(b1,2),t1,round(a,3),o[1])
    return loc, arg

# =============================================================== block B
print("="*78)
print("B.  Can the platform earn a positive profit on the admissible set?")
print("    One-sided packages, beta^2 = 1 (null contract to the other one).")
print("="*78)
print("%-6s %-8s %-9s %-13s %-30s %-5s" %
      ("gamma","points","pi>0","best","argmax (u_B,u_S,beta,t,a)","prof"))
ARG = {}
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    n = pos = 0; best = 0.0; bp = None
    for u1 in GRID:
        for u2 in GRID:
            if adm(u1,u2,g) is None: continue
            n += 1
            loc, arg = best_at(u1,u2,g)
            if loc > 1e-9:
                pos += 1
                if loc > best: best, bp = loc, (round(u1,2),round(u2,2))+arg
    ARG[g] = bp
    print("%-6.3g %-8d %-9s %-13.5f %-30s %-5s" %
          (g,n,"%d (%.0f%%)"%(pos,100.0*pos/max(n,1)),best,
           str(bp[:5]) if bp else "-", bp[5] if bp else "-"))
print("\n    A best value of zero everywhere would be Proposition 1.")

# =============================================================== block B'
print("\n" + "="*78)
print("B'. Same search with the publication rule imposed (u_S n_B^I >= a in every")
print("    configuration where the fee is meant to be live).")
print("="*78)
print("%-6s %-8s %-9s %-13s %-30s %-5s" %
      ("gamma","points","pi>0","best","argmax (u_B,u_S,beta,t,a)","prof"))
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    n = pos = 0; best = 0.0; bp = None
    for u1 in GRID:
        for u2 in GRID:
            if adm(u1,u2,g) is None: continue
            n += 1
            loc, arg = best_at(u1,u2,g,pubrule=True)
            if loc > 1e-9:
                pos += 1
                if loc > best: best, bp = loc, (round(u1,2),round(u2,2))+arg
    print("%-6.3g %-8d %-9s %-13.5f %-30s %-5s" %
          (g,n,"%d (%.0f%%)"%(pos,100.0*pos/max(n,1)),best,
           str(bp[:5]) if bp else "-", bp[5] if bp else "-"))

# =============================================================== block C
print("\n" + "="*78)
print("C.  Outside the unraveling region of Proposition 6 (u_B/u_S >= R_Phi),")
print("    and separately on the band R_Phi <= u_B/u_S < R_a where Proposition")
print("    6(i) says that no contract earns anything.")
print("="*78)
print("%-6s %-8s %-8s %-11s %-11s %-13s %-13s" %
      ("gamma","outside","of which","pi>0 out","pi>0 band","best outside","best on band"))
for g in (1.0,2.0,4.0,8.0,16.0):
    n = nb = po = pb = 0; bo = bb = 0.0; abo = abb = None
    for u1 in GRID:
        for u2 in GRID:
            sig = adm(u1,u2,g)
            if sig is None: continue
            if u1/u2 < C.R_Phi(sig): continue
            n += 1
            inband = (u1/u2 < C.R_a(sig))
            nb += inband
            loc, arg = best_at(u1,u2,g)
            if loc > 1e-9:
                po += 1
                if loc > bo: bo, abo = loc, (round(u1,2),round(u2,2))+arg
                if inband:
                    pb += 1
                    if loc > bb: bb, abb = loc, (round(u1,2),round(u2,2))+arg
    print("%-6.3g %-8d %-8d %-11s %-11s %-13.5f %-13.5f" %
          (g,n,nb,"%d"%po,"%d"%pb,bo,bb))
    if abb: print("        argmax on the band:", abb)

# =============================================================== block D
print("\n" + "="*78)
print("D.  Magnitude: the lump-sum profit under separation against the")
print("    integration gain Pi^I of Section 3, at the same point.")
print("="*78)
print("%-6s %-16s %-11s %-11s %-9s %-24s" %
      ("gamma","argmax (u_B,u_S)","lump sep.","Pi^I int.","ratio","median ratio on {pi>0}"))
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    bp = ARG.get(g)
    if not bp: print("%-6.3g  no positive point" % g); continue
    u1, u2 = bp[0], bp[1]
    sig = sigma_of(u1,u2,g)
    lump = best_at(u1,u2,g)[0]
    pii  = C.PiI_gain(u1,u2,sig)
    rats = []
    for x1 in np.arange(0.1,1.401,0.1):
        for x2 in np.arange(0.1,1.401,0.1):
            s2 = adm(x1,x2,g)
            if s2 is None: continue
            l2 = best_at(x1,x2,g)[0]
            if l2 <= 1e-9: continue
            p2 = C.PiI_gain(x1,x2,s2)
            if p2 > 1e-9: rats.append(l2/p2)
    print("%-6.3g %-16s %-11.5f %-11.5f %-9.3f %-24s" %
          (g,"(%.2f, %.2f)"%(u1,u2),lump,pii,lump/pii if pii>0 else float('nan'),
           "%.3f (n=%d)"%(np.median(rats),len(rats)) if rats else "-"))

# =============================================================== block E
print("\n" + "="*78)
print("E.  Feasibility at the argmax of block B.")
print("="*78)
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    bp = ARG.get(g)
    if not bp: continue
    u1,u2,b1,t1,a,prof = bp
    sig = sigma_of(u1,u2,g)
    P = {'AA':cfg(u1,u2,sig,b1*R,R,a),'AR':cfg(u1,u2,sig,b1*R,R,a),
         'RA':cfg(u1,u2,sig,R,R,a),'RR':cfg(u1,u2,sig,R,R,0.0)}
    print("\n  gamma=%g  (u_B,u_S)=(%.2f,%.2f)  beta=%.2f  t=%.1f  a=%.3f  -> %s, pi=%.5f"
          % (g,u1,u2,b1,t1,a,prof,best_at(u1,u2,g)[0]))
    print("    sigma=%.4f  M=%.4f  H=%.4g  u_B/u_S=%.3f  R_Phi=%.3f  R_a=%.3f"
          % (sig,Mof(u1,u2),Hval(u1,u2,sig),u1/u2,C.R_Phi(sig),C.R_a(sig)))
    for k in ('AA','AR','RA','RR'):
        print("    %-3s D1=%8.4f D2=%8.4f q_S=%8.4f p1=%8.4f p2=%8.4f"
              % (k,P[k][2],P[k][3],P[k][4],P[k][5],P[k][6]))
    print("    publication rule  u_S n_B^I >= a :  AR gives %.4f vs a=%.3f  -> %s"
          % (u2*P['AR'][2], a, "ok" if u2*P['AR'][2] >= a else "VIOLATED"))
print("\n" + "="*78)
