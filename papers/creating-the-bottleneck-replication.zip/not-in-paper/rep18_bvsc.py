# Quand la separation SANS plafond (B) bat-elle l'integration (C) pour la plateforme ?
# Les deux valeurs sont des formes fermees : Phi(a_hat) et PiI_gain, toutes deux
# des maxima de quadratiques concaves valant 0 en a=0.
import sys, numpy as np, sympy as sp
sys.path.insert(0,'/root/vi2sm/replication')
from rep_core import sigma_of, Mof, Hval, V_DEF, R_DEF
import rep3_contracts as C
V,R=V_DEF,R_DEF
Lam=lambda s: 8+s*(8+s)
Psi=lambda s: 3*s*(s*(s+7)+16)+32

print("1.  L'inegalite en forme fermee.\n")
uB,uS,s,g,v,r = sp.symbols('u_B u_S sigma gamma v r', positive=True)
M=1-2*uB*uS; L=8+s*(8+s); P=3*s*(s*(s+7)+16)+32
H=((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
   - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS - 2*(s*(s*(7*s+40)+64)+32)*uS**2)
Phi_p0 = 2*(v+r)*(s+2)*(L*uS-(4+3*s)*uB)/(M*(s+4)*L)
Phi_pp = -2*(g*(s+2)+2*(3*s+4))/L
PiI_p0 = 2*(v+r)*(P*uS-2*(s+2)*(3*s+4)*uB)/((s+4)**2*(3*s+4)*M)
PiI_pp = -2*H/((s+4)**2*(3*s+4)**2*M)
PhiHat = sp.simplify(Phi_p0**2/(-2*Phi_pp))
PiIHat = sp.simplify(PiI_p0**2/(-2*PiI_pp))
print("   Phi(a_hat) =", sp.factor(PhiHat))
print("   Pi^I       =", sp.factor(PiIHat))
diff = sp.simplify(sp.factor(sp.together(PhiHat - PiIHat)))
num  = sp.simplify(sp.numer(sp.together(PhiHat/PiIHat)))
print("\n   Phi(a_hat) > Pi^I  <=>")
tgtL = (s+2)**2*H*(L*uS-(4+3*s)*uB)**2
tgtR = M*L*(g*(s+2)+2*(3*s+4))*(P*uS-2*(s+2)*(3*s+4)*uB)**2
chk = sp.simplify(sp.expand(sp.together(PhiHat-PiIHat)*
      (M**2*(s+4)**2*L*(g*(s+2)+2*(3*s+4))*H) - sp.expand((v+r)**2*(tgtL-tgtR))))
print("      (2+s)^2 H (Lambda u_S - (4+3s) u_B)^2")
print("         >  M Lambda [gamma(2+s)+2(4+3s)] (Psi u_S - 2(2+s)(4+3s) u_B)^2")
print("   verification symbolique de l'equivalence :", "PASS" if chk==0 else "**FAIL** %s"%chk)
print("\n   avec Lambda = 8+s(8+s),  Psi = 3s(s(s+7)+16)+32,  H la concavite du")
print("   probleme a un instrument.  Ce n'est PAS une condition en ratio u_B/u_S :")
print("   H et M dependent de u_B et u_S separement.")

print("\n\n2.  Ou la condition est-elle satisfaite ?  (grille de reference, pas 0.02)\n")
grid=np.arange(0.02,1.4001,0.02)
print("%-6s %-9s %-12s %-12s %-30s %-26s" %
      ("gamma","admis.","B>C","dont bande","mediane (u_B,u_S) sur B>C","mediane u_B/u_S | R_Phi"))
for gg in (0.5,1.0,2.0,4.0,8.0,16.0):
    n=0; win=[]; band=0
    for x1 in grid:
        for x2 in grid:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,gg)
            if sg<0 or Hval(x1,x2,sg)<=0: continue
            n+=1
            ph=C.Phi(x1,x2,sg,gg,C.a_hat(x1,x2,sg,gg)) if C.Phi_prime0(x1,x2,sg)>0 else 0.0
            pi=C.PiI_gain(x1,x2,sg) if C.PiI_prime0(x1,x2,sg)>0 else 0.0
            if ph>pi+1e-12:
                win.append((x1,x2,x1/x2,C.R_Phi(sg)))
                if x1/x2>=C.R_Phi(sg): band+=1
    if win:
        w=np.array(win)
        print("%-6.3g %-9d %-12s %-12d %-30s %-26s" %
              (gg,n,"%d (%.1f%%)"%(len(win),100*len(win)/n),band,
               "(%.2f, %.2f)"%(np.median(w[:,0]),np.median(w[:,1])),
               "%.3f | %.3f"%(np.median(w[:,2]),np.median(w[:,3]))))
    else:
        print("%-6.3g %-9d %-12s" % (gg,n,"0 (0.0%)"))

print("\n\n3.  La forme de la region.  Pour chaque u_S, le seuil en u_B.\n")
for gg in (1.0,4.0,16.0):
    print("  gamma = %g" % gg)
    print("    %-8s %-12s %-12s %-12s %-10s" % ("u_S","u_B min","u_B max","R_Phi*u_S","largeur"))
    for x2 in (0.2,0.4,0.6,0.8,1.0,1.2,1.4):
        lo=hi=None
        for x1 in grid:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,gg)
            if sg<0 or Hval(x1,x2,sg)<=0: continue
            ph=C.Phi(x1,x2,sg,gg,C.a_hat(x1,x2,sg,gg)) if C.Phi_prime0(x1,x2,sg)>0 else 0.0
            pi=C.PiI_gain(x1,x2,sg) if C.PiI_prime0(x1,x2,sg)>0 else 0.0
            if ph>pi+1e-12:
                if lo is None: lo=x1
                hi=x1
        sg0=sigma_of(0.0,x2,gg)
        print("    %-8.2f %-12s %-12s %-12.3f %-10s" %
              (x2, "%.2f"%lo if lo else "-", "%.2f"%hi if hi else "-",
               C.R_Phi(sg0)*x2, "%.2f"%(hi-lo) if lo else "-"))
import sys, numpy as np, sympy as sp
sys.path.insert(0,'/root/vi2sm/replication')
from rep_core import sigma_of, Mof, Hval, demands, prices_sep, prices_int, surpluses, V_DEF, R_DEF
import rep3_contracts as C
V,R=V_DEF,R_DEF
Lam=lambda s: 8.0+s*(8.0+s)
Psi=lambda s: 3*s*(s*(s+7)+16)+32

# ---------------------------------------------------------------- 1. la limite
print("1.  La limite quand les effets de reseau s'evanouissent (u -> 0, ratio fixe).")
print("    La, sigma -> gamma, M -> 1, H -> (4+g)^2(4+3g)^2, et la condition DEVIENT")
print("    une condition en ratio rho = u_B/u_S :\n")
print("      (2+g)(4+g)(4+3g)[Lambda - (4+3g)rho]  >  sqrt(Lambda[g(2+g)+2(4+3g)])")
print("                                                * [Psi - 2(2+g)(4+3g)rho]\n")
print("    %-6s %-11s %-11s %-11s %-24s" % ("gamma","rho_min","rho_max","R_Phi","intervalle en rho"))
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    L=Lam(g); P=Psi(g)
    A=(2+g)*(4+g)*(4+3*g); B=np.sqrt(L*(g*(2+g)+2*(4+3*g)))
    f=lambda rho: A*(L-(4+3*g)*rho) - B*(P-2*(2+g)*(4+3*g)*rho)
    rs=np.linspace(0.0, L/(4+3*g), 20001)
    val=np.array([f(x) for x in rs]); pos=rs[val>0]
    print("    %-6.3g %-11s %-11s %-11.3f %-24s" %
          (g, "%.4f"%pos.min() if len(pos) else "-", "%.4f"%pos.max() if len(pos) else "-",
           L/(4+3*g), "%s"%("[%.3f, %.3f]"%(pos.min(),pos.max()) if len(pos) else "vide")))
print("\n    Donc a la limite : le contrat bat la fusion sur un intervalle de ratios")
print("    BORNE PAR LE BAS.  Il faut assez d'effet acheteurs pour que le contrat")
print("    gagne : a rho = 0 (marche purement developpeurs) la fusion l'emporte.")

# ------------------------------------------------- 2. l'effet de niveau
print("\n\n2.  Loin de l'origine la condition n'est plus un ratio : le niveau compte.")
print("    Pour rho fixe, le long du rayon u_S = t, u_B = rho t :\n")
print("    %-5s %-7s %-11s %-11s %-11s %-32s" %
      ("gam","rho","t min","t max","t = R_Phi?","Phi/Pi^I en t=0.05 / 0.3 / 0.8"))
for g in (1.0,4.0,16.0):
    for rho in (0.2,0.4,0.6):
        ts=np.arange(0.01,1.401,0.005); good=[]
        rat=[]
        for t in ts:
            x2=t; x1=rho*t
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,g)
            if sg<0 or Hval(x1,x2,sg)<=0: continue
            ph=C.Phi(x1,x2,sg,g,C.a_hat(x1,x2,sg,g)) if C.Phi_prime0(x1,x2,sg)>0 else 0.0
            pi=C.PiI_gain(x1,x2,sg) if C.PiI_prime0(x1,x2,sg)>0 else 0.0
            if pi>1e-12: rat.append((t,ph/pi))
            if ph>pi+1e-12: good.append(t)
        gv=lambda tt: next((v for (u,v) in rat if abs(u-tt)<0.004), float('nan'))
        print("    %-5g %-7.1f %-11s %-11s %-11s %-32s" %
              (g,rho,"%.3f"%min(good) if good else "-","%.3f"%max(good) if good else "-",
               "-", "%.3f / %.3f / %.3f"%(gv(0.05),gv(0.30),gv(0.80))))
print("\n    Le ratio Phi/Pi^I DECROIT avec le niveau des effets de reseau : le")
print("    contrat gagne quand ils sont faibles et perd quand ils sont forts.")

# --------------------------------------------- 3. impacts collectifs
print("\n\n3.  Ce qui se passe pour les autres parties la ou le contrat gagne.")
def sep_out(uB,uS,g,b1,a):
    sg=sigma_of(uB,uS,g)
    p1,p2=prices_sep(uB,uS,sg,b1*R,R,a); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
    VB,VS=surpluses(uB,uS,g,p1,p2,D1,D2,q,V)
    plat=(1-b1)*R*D1+a*q
    return VB,VS,plat,(p2+R)*D2,VB+VS+plat+(p1+b1*R)*D1+(p2+R)*D2
def int_out(uB,uS,g,b2,a):
    sg=sigma_of(uB,uS,g)
    p1,p2=prices_int(uB,uS,sg,b2*R,a,R,V); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
    VB,VS=surpluses(uB,uS,g,p1,p2,D1,D2,q,V)
    firm=(p1+R)*D1+a*q+(R-b2*R)*D2
    return VB,VS,firm,(p2+b2*R)*D2,VB+VS+firm+(p2+b2*R)*D2
def bench(uB,uS,g):
    sg=sigma_of(uB,uS,g)
    p1,p2=prices_sep(uB,uS,sg,R,R,0.0); D1,D2,q=demands(uB,uS,sg,p1,p2,0.0)
    VB,VS=surpluses(uB,uS,g,p1,p2,D1,D2,q,V)
    return VB,VS,0.0,(p2+R)*D2,VB+VS+(p1+R)*D1+(p2+R)*D2

grid=np.arange(0.02,1.4001,0.02)
print("\n    (variations en %% du benchmark A, sur les points ou Phi(a_hat) > Pi^I)")
print("    %-5s %-7s %-24s %-24s" % ("gam","points","contrat B vs benchmark","fusion C vs benchmark"))
print("    %-5s %-7s %-24s %-24s" % ("","","W / buyers / dev","W / buyers / dev"))
for g in (1.0,4.0,16.0):
    rows=[]
    for x1 in grid:
        for x2 in grid:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,g)
            if sg<0 or Hval(x1,x2,sg)<=0: continue
            if C.Phi_prime0(x1,x2,sg)<=0: continue
            ph=C.Phi(x1,x2,sg,g,C.a_hat(x1,x2,sg,g))
            pi=C.PiI_gain(x1,x2,sg) if C.PiI_prime0(x1,x2,sg)>0 else 0.0
            if ph<=pi+1e-12: continue
            aB=C.a_hat(x1,x2,sg,g); bB=C.bbar(x1,x2,sg,aB)/R*R
            aC=C.a_star(x1,x2,sg)
            b0=bench(x1,x2,g); sB=sep_out(x1,x2,g,C.bbar(x1,x2,sg,aB),aB); sC=int_out(x1,x2,g,1.0,aC)
            if min(sB[0],sC[0])<=0: continue
            rows.append([100*(sB[4]/b0[4]-1),100*(sB[0]/b0[0]-1),100*(sB[1]/b0[1]-1),
                         100*(sC[4]/b0[4]-1),100*(sC[0]/b0[0]-1),100*(sC[1]/b0[1]-1)])
    if not rows: print("    %-5g  aucun point"%g); continue
    m=np.median(np.array(rows),axis=0)
    print("    %-5g %-7d %-24s %-24s" %
          (g,len(rows),"%+.2f / %+.2f / %+.2f"%(m[0],m[1],m[2]),
           "%+.2f / %+.2f / %+.2f"%(m[3],m[4],m[5])))
import sys, numpy as np
sys.path.insert(0,'/root/vi2sm/replication')
from rep_core import sigma_of, Mof, Hval, demands, prices_sep, prices_int, surpluses, V_DEF, R_DEF
import rep3_contracts as C
V,R=V_DEF,R_DEF
def sep_out(uB,uS,g,b1,a):
    sg=sigma_of(uB,uS,g); p1,p2=prices_sep(uB,uS,sg,b1,R,a); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
    VB,VS=surpluses(uB,uS,g,p1,p2,D1,D2,q,V)
    return VB,VS,VB+VS+(1-b1/R)*R*D1+a*q+(p1+b1)*D1+(p2+R)*D2,(p2+R)*D2,min(D1,D2,q)
def int_out(uB,uS,g,a):
    sg=sigma_of(uB,uS,g); p1,p2=prices_int(uB,uS,sg,R,a,R,V); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
    VB,VS=surpluses(uB,uS,g,p1,p2,D1,D2,q,V)
    return VB,VS,VB+VS+(p1+R)*D1+a*q+(p2+R)*D2,(p2+R)*D2,min(D1,D2,q)
grid=np.arange(0.02,1.4001,0.02)
print("Sur les points ou le contrat sans plafond (B) bat la fusion (C) pour la")
print("plateforme : B est-il PIRE que C pour les autres parties ?\n")
print("%-6s %-8s %-13s %-13s %-13s %-13s" %
      ("gamma","points","W: B<C","buyers: B<C","dev: B<C","M2: B<C"))
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    n=0; c=[0,0,0,0]
    for x1 in grid:
        for x2 in grid:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,g)
            if sg<0 or Hval(x1,x2,sg)<=0: continue
            if C.Phi_prime0(x1,x2,sg)<=0: continue
            ph=C.Phi(x1,x2,sg,g,C.a_hat(x1,x2,sg,g))
            pi=C.PiI_gain(x1,x2,sg) if C.PiI_prime0(x1,x2,sg)>0 else 0.0
            if ph<=pi+1e-12: continue
            aB=C.a_hat(x1,x2,sg,g); aC=C.a_star(x1,x2,sg)
            B=sep_out(x1,x2,g,C.bbar(x1,x2,sg,aB)*R,aB); Cc=int_out(x1,x2,g,aC)
            if min(B[4],Cc[4])<=0: continue
            n+=1
            c[0]+= B[2]<Cc[2]-1e-12; c[1]+= B[0]<Cc[0]-1e-12
            c[2]+= B[1]<Cc[1]-1e-12; c[3]+= B[3]<Cc[3]-1e-12
    if n==0: print("%-6.3g %-8d  --"%(g,n)); continue
    print("%-6.3g %-8d %-13s %-13s %-13s %-13s" % (g,n,
        *["%d (%.0f%%)"%(x,100.0*x/n) for x in c]))
