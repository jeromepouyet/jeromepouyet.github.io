# -*- coding: utf-8 -*-
"""rep17_lumpsum_strict.py -- the lump-sum break, stripped of the selection rule.

Two adversarial audits (verif_lump_analytic.py, verif_lump_game.py) established
that the headline numbers of rep17_lumpsum_numeric.py lean on the joint-profit
selection rule in a way the proof of Proposition 1 explicitly disclaims: at most
of the argmax packages the Nash set is {AA, RR}, M1 strictly prefers RR, and the
rule picks AA anyway.  This file redoes everything on the SELECTION-FREE
statement:

    a package counts only if joint refusal is NOT a Nash equilibrium,
    and the platform is then credited with its WORST surviving equilibrium.

Nothing below depends on how ties or multiplicities are broken.

It also checks the one repair that kills the mechanism outright: SECRET offers.
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (sigma_of, Mof, Hval, demands, prices_sep, V_DEF, R_DEF)
import rep3_contracts as C
V, R = V_DEF, R_DEF

def cfg(uB,uS,sig,b1,b2,a):
    p1,p2 = prices_sep(uB,uS,sig,b1,b2,a); D1,D2,q = demands(uB,uS,sig,p1,p2,a)
    return [(p1+b1)*D1,(p2+b2)*D2,D1,D2,q,p1,p2]

def game(uB,uS,g,b1,b2,t1,t2,a,strict=True,pubrule=True):
    sig = sigma_of(uB,uS,g); ae = a if a<0 else 0.0
    P = {'AA':cfg(uB,uS,sig,b1*R,b2*R,a),'AR':cfg(uB,uS,sig,b1*R,R,a),
         'RA':cfg(uB,uS,sig,R,b2*R,a),   'RR':cfg(uB,uS,sig,R,R,ae)}
    for k in P:
        if min(P[k][2],P[k][3],P[k][4]) <= 0: return None
    # margins positive in every configuration (rep3_contracts._interior)
    if P['AA'][5]+b1*R<=0 or P['AA'][6]+b2*R<=0 or P['AR'][5]+b1*R<=0 or P['AR'][6]+R<=0 \
       or P['RA'][5]+R<=0 or P['RA'][6]+b2*R<=0 or P['RR'][5]+R<=0 or P['RR'][6]+R<=0:
        return None
    if pubrule and a > 0:
        if uS*(P['AA'][2]+P['AA'][3]) < a: return None
        if uS*P['AR'][2] < a: return None
        if uS*P['RA'][3] < a: return None
    L = {'AA':(t1*(1-b1)*R*P['AA'][2], t2*(1-b2)*R*P['AA'][3]),
         'AR':(t1*(1-b1)*R*P['AR'][2], 0.0),
         'RA':(0.0, t2*(1-b2)*R*P['RA'][3]), 'RR':(0.0,0.0)}
    pi = {k:(P[k][0]+L[k][0], P[k][1]+L[k][1]) for k in P}
    NE=[]
    for prof,d1,d2 in (('AA','RA','AR'),('AR','RR','AA'),('RA','AA','RR'),('RR','AR','RA')):
        if pi[d1][0] <= pi[prof][0]+1e-12 and pi[d2][1] <= pi[prof][1]+1e-12: NE.append(prof)
    if not NE: return None
    val = lambda k: {'AA':(1-b1)*R*P[k][2]-L[k][0]+(1-b2)*R*P[k][3]-L[k][1]+a*P[k][4],
                     'AR':(1-b1)*R*P[k][2]-L[k][0]+a*P[k][4],
                     'RA':(1-b2)*R*P[k][3]-L[k][1]+a*P[k][4],
                     'RR':ae*P[k][4]}[k]
    if strict:
        if 'RR' in NE: return None                # joint refusal survives: nothing granted
        return min(val(k) for k in NE), "/".join(sorted(NE))
    sel = max(NE, key=lambda k: pi[k][0]+pi[k][1])
    return val(sel), sel

def adm(u1,u2,g):
    if Mof(u1,u2) <= 0: return None
    sig = sigma_of(u1,u2,g)
    if sig < 0 or Hval(u1,u2,sig) <= 0: return None
    return sig

GB   = np.arange(0.0,1.0001,0.05)
GA   = np.arange(0.02,4.001,0.04)          # widened: the old grid stopped at 1.98
GT   = (0.0,0.25,0.5,0.75,1.0)
GRID = np.arange(0.05,1.401,0.05)

def best_at(u1,u2,g,strict=True):
    loc=0.0; arg=None
    for b1 in GB:
        for a in GA:
            for t1 in GT:
                o = game(u1,u2,g,b1,1.0,t1,0.0,a,strict=strict)
                if o and o[0] > loc: loc,arg = o[0],(round(b1,2),t1,round(a,3),o[1])
    return loc,arg

print("="*80)
print("A.  Selection-free statement: packages at which JOINT REFUSAL IS NOT AN")
print("    EQUILIBRIUM, the platform credited with its worst surviving one.")
print("="*80)
print("%-6s %-8s %-13s %-12s %-30s" % ("gamma","points","pi>0","best","argmax (u_B,u_S,beta,t,a)"))
ARG={}
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    n=pos=0; best=0.0; bp=None
    for u1 in GRID:
        for u2 in GRID:
            if adm(u1,u2,g) is None: continue
            n+=1
            loc,arg = best_at(u1,u2,g)
            if loc>1e-9:
                pos+=1
                if loc>best: best,bp=loc,(round(u1,2),round(u2,2))+arg
    ARG[g]=bp
    print("%-6.3g %-8d %-13s %-12.5f %-30s" %
          (g,n,"%d (%.0f%%)"%(pos,100.0*pos/max(n,1)),best,str(bp[:5]) if bp else "-"))

print("\n" + "="*80)
print("B.  Same, restricted to the region where Proposition 6 says no contract")
print("    earns anything: outside the unraveling region, and on the band.")
print("="*80)
print("%-6s %-9s %-9s %-11s %-11s %-12s %-12s" %
      ("gamma","outside","of which","pi>0 out","pi>0 band","best out","best band"))
for g in (1.0,2.0,4.0,8.0,16.0):
    n=nb=po=pb=0; bo=bb=0.0; abb=None
    for u1 in GRID:
        for u2 in GRID:
            sig = adm(u1,u2,g)
            if sig is None or u1/u2 < C.R_Phi(sig): continue
            n+=1; inband = u1/u2 < C.R_a(sig); nb+=inband
            loc,arg = best_at(u1,u2,g)
            if loc>1e-9:
                po+=1; bo=max(bo,loc)
                if inband:
                    pb+=1
                    if loc>bb: bb,abb = loc,(round(u1,2),round(u2,2))+arg
    print("%-6.3g %-9d %-9d %-11d %-11d %-12.5f %-12.5f" % (g,n,nb,po,pb,bo,bb))
    if abb: print("        argmax on the band:", abb)

print("\n" + "="*80)
print("C.  Magnitude against the integration gain Pi^I of Section 3.")
print("="*80)
print("%-6s %-16s %-11s %-11s %-8s %-22s %-22s" %
      ("gamma","argmax (u_B,u_S)","lump sep.","Pi^I","ratio","median ratio","max ratio"))
for g in (0.5,1.0,2.0,4.0,8.0,16.0):
    bp = ARG.get(g)
    rats=[]
    for x1 in np.arange(0.1,1.401,0.1):
        for x2 in np.arange(0.1,1.401,0.1):
            s2 = adm(x1,x2,g)
            if s2 is None: continue
            l2 = best_at(x1,x2,g)[0]
            if l2 <= 1e-9: continue
            p2 = C.PiI_gain(x1,x2,s2)
            if p2 > 1e-9: rats.append(l2/p2)
    if not bp:
        print("%-6.3g  no point where joint refusal breaks" % g); continue
    u1,u2 = bp[0],bp[1]; sig = sigma_of(u1,u2,g)
    lump = best_at(u1,u2,g)[0]; pii = C.PiI_gain(u1,u2,sig)
    print("%-6.3g %-16s %-11.5f %-11.5f %-8.3f %-22s %-22s" %
          (g,"(%.2f, %.2f)"%(u1,u2),lump,pii,lump/pii if pii>0 else float('nan'),
           "%.3f (n=%d)"%(np.median(rats),len(rats)) if rats else "-",
           "%.3f"%max(rats) if rats else "-"))

print("\n" + "="*80)
print("D.  The repair: SECRET offers.  M2 does not observe (beta^1, L^1) and,")
print("    under passive beliefs, holds its price at the joint-refusal value.")
print("    Does a lone acceptance still pay?")
print("="*80)

def best_response(uB,uS,sig,b,p_other,a):
    """M1's best price against a FIXED p2, at perceived per-user benefit b."""
    M = Mof(uB,uS)
    # pi = (p+b) (2v - (2+sig)p + sig p_other - 2 uB a)/(2M)
    num = 2*V - (2+sig)*(-b) + sig*p_other - 2*uB*a
    return (num/(2+sig) - b)/2.0 if False else \
           ( (2*V + sig*p_other - 2*uB*a) - (2+sig)*b ) / (2.0*(2+sig))

print("%-6s %-6s %-5s %-13s %-13s %-13s" %
      ("u_B","u_S","gam","slack beta=.9","slack beta=.5","slack beta=0"))
for (u1,u2,g) in ((0.05,1.4,4.0),(0.2,1.3,16.0),(0.4,0.4,4.0),(0.3,0.9,8.0),(0.65,0.2,4.0),(1.15,0.3,16.0)):
    sig = adm(u1,u2,g)
    if sig is None: print("    (%.2f,%.2f,%g) not admissible"%(u1,u2,g)); continue
    M = Mof(u1,u2)
    pw1,pw2 = prices_sep(u1,u2,sig,R,R,0.0)
    Dw1,_,_ = demands(u1,u2,sig,pw1,pw2,0.0)
    piW = (pw1+R)*Dw1
    row=[]
    for b in (0.9,0.5,0.0):
        p1 = best_response(u1,u2,sig,b*R,pw2,0.0)          # M2's price frozen at p^w
        D1,_,_ = demands(u1,u2,sig,p1,pw2,0.0)
        row.append((p1+R)*D1 - piW)                        # payoff + maximal lump, minus refusing
    print("%-6.2f %-6.2f %-5g %-13.3e %-13.3e %-13.3e" % (u1,u2,g,row[0],row[1],row[2]))
print("\n    Every entry negative: with the rival's price frozen, giving back the")
print("    margin as a lump leaves the deviator maximising (p+r)D at the WRONG")
print("    price.  The loss is second order in (1-beta) and Proposition 1 holds")
print("    verbatim.  The whole break runs through the rival's price response.")
print("\n" + "="*80)
