# Frais fixes sous séparation : ce que donne la vérification

Statut : vérifié analytiquement (identités exactes, sympy) et numériquement,
puis contre-audité par deux agents adverses indépendants qui ont réécrit les
dérivations depuis les primitives. Scripts :
`replication/rep17_lumpsum_analytic.py`, `rep17_lumpsum_numeric.py`,
`rep17_lumpsum_strict.py`, `rep17_lumpsum_integration.py`,
`replication/verif_lump_analytic.py`, `verif_lump_game.py`.

## L'espace de contrats testé

La plateforme poste (β^k, L^k, a). Un manufacturier hébergé reçoit β^k r par
utilisateur *plus* un forfait L^k ≥ 0, sous la restriction économique qui est
exactement la fermeture de « β ≤ 1 » sous les forfaits :

    β^k r D_k + L^k ≤ r D_k      c'est-à-dire     L^k ≤ (1−β^k) r D_k .

## Résultat principal : la proposition 1 tombe

Avec le forfait maximal, le paiement d'un manufacturier hébergé se réduit à
(p_k + r) D_k : le profit à pleine marge, évalué **aux prix d'hébergement** et
**redevance vive**. Soit Δ(β,a) l'écart entre ce montant et le profit de refus
conjoint. Alors Δ(1,0) = 0 et, en (1,0),

    ∂Δ/∂β = − r (2+σ) σ² (v+r) / [ M (4+σ)² (4+3σ) ]  <  0        (1)
    ∂Δ/∂a = − 4 u_B (2+σ) (v+r) / [ M (4+σ)² ]        <  0        (2)

alors que **sans** forfait la même dérivée vaut

    + r (2+σ)(v+r) [ (4+σ)(4+3σ) − σ² ] / [ M (4+σ)²(4+3σ) ]  >  0   (3)

et la différence (3) − (1) est exactement r D^w. Le forfait annule la perte
directe de marge et laisse un terme strictement négatif : baisser β sous 1
**augmente** le gain d'une adoption solitaire, le refus conjoint n'est plus un
équilibre, la proposition 1 tombe.

## D'où vient exactement la faille

Identité exacte :

    ∂Δ/∂β |_(1,0)  =  (∂π_1/∂p_2) · (dp_2/dβ)

Les termes de prix propre et de demande propre s'annulent par le théorème de
l'enveloppe. **Toute** la faille est la réponse en prix du rival. C'est de la
délégation stratégique au sens de Bonanno–Vickers (1988) / Fershtman–Judd
(1987) : β<1 fait tarifer M_1 comme si sa marge par utilisateur était βr, le
forfait lui rend l'argent, le rival suit, et la plateforme taxe le développeur
sur le profit d'industrie ainsi créé. Le terme est en −σ², donc **pair en σ** :
la faille vaut aussi pour les compléments (σ<0), donc aussi pour la section 8.

Forme exacte à a = 0, en x ≡ (1−β) r : Δ = G x + Q x² avec G > 0, Q < 0 et
racine x⁺ = σ²(4+3σ)(v+r)/[(2+σ)² Λ]. Au calibrage v=2, r=1/2 on a x⁺/r < 1
pour tout σ ≥ 0 (le numérateur de x⁺/r − 1 est −σ²(σ²−3σ+24) − 64σ − 32 < 0),
donc β ne descend jamais jusqu'à 0.

## La réparation en une ligne : offres secrètes

Si M_2 n'observe pas (β¹, L¹) et, sous croyances passives, garde son prix à sa
valeur de refus conjoint, alors, **exactement**,

    Δ^secret(β, 0)  =  − (1−β)² r² (2+σ) / (8 M)   ≤  0

pour tout β, en tout point admissible, et a > 0 ne fait qu'aggraver. La
proposition 1 tient **mot pour mot**. En offres publiques la perte de marge est
remboursée et il reste un gain du **premier** ordre ; en offres secrètes c'est
une perte du **second** ordre, parce que le déviant maximise alors (p+r)D au
mauvais prix.

## Ampleur, énoncé sans règle de sélection

Les chiffres bruts s'appuyaient sur la règle de sélection d'une manière que la
preuve de la proposition 1 récuse explicitement (« la règle ne retient jamais
une issue qu'un manufacturier classe en dessous d'un autre équilibre »).
Vérification : dans l'espace **originel** (β,a) cette phrase est exacte — 0 cas
sur ~333 000 paquets, à tout γ. Avec forfaits elle devient fausse (0,04 % à
γ=1 ; 1,09 % à γ=4 ; 2,15 % à γ=16). L'énoncé propre ne retient donc que les
paquets où le **refus conjoint n'est pas un équilibre du tout**, et crédite la
plateforme de son **pire** équilibre survivant :

| γ | points | π>0 | meilleur | médiane π/Π^I |
|---|---|---|---|---|
| 1/2 | 206 | 0 % | 0 | — |
| 1 | 282 | 0 % | 0 | — |
| 2 | 347 | 19 % | 0,305 | 0,052 |
| 4 | 392 | 45 % | 1,422 | 0,185 |
| 8 | 419 | ~72 % | 4,134 | 0,271 |
| 16 | 433 | 87 % | 7,529 | 0,406 |

La proposition 6(i) tombe aussi sur la bande, même sans règle de sélection :
2 points sur 5 à γ=4, 7 sur 8 à γ=8, 12 sur 14 à γ=16, mais avec des montants
minuscules (0,012 à 0,048).

## Le forfait sert aussi la firme intégrée

L'enrichissement de l'espace ne rend pas la fusion caduque : il donne un
instrument de coordination des prix aux **deux** arrangements. Firme intégrée
avec forfait au rival hébergé, contre sans : +10,2 % en (0,40 ; 0,40 ; γ=4),
+26,7 % en (0,50 ; 0,15 ; γ=4), +32,3 % en (0,90 ; 0,25 ; γ=8). En ces points
côté acheteurs, l'optimum intégré est (β²=0, a=0) : pure coordination de prix,
**aucune** redevance développeur.

## Conséquence pour la porte de sortie

Le point (b) du plan change de nature : ajouter F sous séparation n'est pas une
confirmation de la proposition 1, c'est un **second** résultat de dévissage, à
mécanisme nommé (délégation stratégique) et à réparation d'une ligne (offres
secrètes / bilatérales — Katz 1991, Caillaud–Jullien–Rey, McAfee–Schwartz).
Deux options défendables :
(i) énoncer la proposition 1 sur les **tarifs linéaires par utilisateur**, dans
    la tradition Ordover–Saloner–Salop et Chen, avec une remarque sur la rente
    de délégation d'ordre σ² qu'un forfait publiquement observé réintroduirait ;
(ii) supposer les offres secrètes/bilatérales, ce qui tue le mécanisme
    exactement et se dit en une ligne.

Note : le forfait serait également disponible à la firme intégrée (sections 4
et 5) et à la famille de réplication Φ(a), toutes énoncées sur (β,a) seuls.
La réparation ne peut donc pas être une note de bas de page à la proposition 1.
