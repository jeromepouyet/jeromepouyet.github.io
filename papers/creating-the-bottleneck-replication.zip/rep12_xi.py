# -*- coding: utf-8 -*-
"""rep12_xi.py -- Xi > 0 on the two-instrument admissible set, as an identity.

Xi is the concavity premise of the taxing branch of the SYMMETRIC RESTRICTION
of the dominance benchmark (one premium x for both manufacturers, one fee a):
it is what makes the symmetric stationary point a maximizer of that
restricted programme.  The benchmark of the paper (Proposition B.2, Online
Appendix B.5) optimizes over asymmetric packages; its concavity is the
negative definiteness of the two-host Hessian, which reduces to Delta_delta > 0
and is verified in rep35_dominance_asym.py.  Xi is kept here because the
symmetric restriction is used in the text as a comparison point.  Xi > 0 is
a consequence of N_2 < 0 alone, by a one-line quadratic-form argument.

    Xi   = (sigma+4) Lambda^2 - alpha u_B^2 - beta u_B u_S,
           alpha = 4 sigma (sigma+2)^2 (3 sigma+4),
           beta  = 8 Lambda (2 sigma^2 + 9 sigma + 8),   Lambda = sigma^2+8sigma+8
    N_2  = P (u_B^2 + u_S^2) + Q u_B u_S - R,
           P = 9s^3+45s^2+80s+48, Q = 18s^3+110s^2+224s+160, R = 18s^3+100s^2+192s+128

N_2 < 0 gives P(u_B^2+u_S^2) + Q u_B u_S < R, so it suffices that

    A1 u_B^2 + B1 u_B u_S + C1 u_S^2  >=  0,   A1 = T P - alpha R,
    B1 = T Q - beta R,  C1 = T P,   T = (sigma+4) Lambda^2,

and that holds because A1 > 0, C1 > 0 and the discriminant is a product of
manifestly nonnegative factors.
"""
import sympy as sp
import numpy as np

sg, uB, uS = sp.symbols('sigma u_B u_S', nonnegative=True)
Lam = sg**2 + 8*sg + 8
alpha = 4*sg*(sg+2)**2*(3*sg+4)
beta  = 8*Lam*(2*sg**2 + 9*sg + 8)
T     = (sg+4)*Lam**2
P = 9*sg**3 + 45*sg**2 + 80*sg + 48
Q = 18*sg**3 + 110*sg**2 + 224*sg + 160
R = 18*sg**3 + 100*sg**2 + 192*sg + 128

Xi_paper = (sg+4)*Lam**2 - 4*sg*(sg+2)**2*(3*sg+4)*uB**2 - 8*Lam*(2*sg**2+9*sg+8)*uB*uS
N2_paper = (9*sg**3*((uB+uS)**2 - 2) + 5*sg**2*(9*uB**2 + 22*uB*uS + 9*uS**2 - 20)
            + 16*sg*(5*uB**2 + 14*uB*uS + 5*uS**2 - 12)
            + 16*((3*uB+uS)*(uB+3*uS) - 8))

print("1. Xi as displayed = T - alpha u_B^2 - beta u_B u_S      :",
      sp.expand(Xi_paper - (T - alpha*uB**2 - beta*uB*uS)) == 0)
print("2. N_2 as displayed = P(u_B^2+u_S^2) + Q u_B u_S - R     :",
      sp.expand(N2_paper - (P*(uB**2+uS**2) + Q*uB*uS - R)) == 0)

A1 = sp.expand(T*P - alpha*R)
B1 = sp.expand(T*Q - beta*R)
C1 = sp.expand(T*P)
print("3. R*Xi = T*(R - N_2 - ... ) identity                    :",
      sp.expand(R*Xi_paper - (T*(R - (P*(uB**2+uS**2)+Q*uB*uS - R) - R)
                              + (A1*uB**2 + B1*uB*uS + C1*uS**2))) == 0)

D = sp.factor(sp.expand(4*A1*C1 - B1**2))
D_claim = 16*sg**2*(sg+2)**4*Lam**2*(9*sg**2+32*sg+32)*(13*sg**3+64*sg**2+112*sg+64)
print("4. 4 A1 C1 - B1^2 = 16 s^2 (s+2)^4 Lambda^2 (9s^2+32s+32) (13s^3+64s^2+112s+64) :",
      sp.expand(4*A1*C1 - B1**2 - D_claim) == 0)

g = 3*sg**3 - sg**2 - 24*sg + 512
A1_claim = (3*sg+4)*(sg**4*g + 3200*sg**3 + 7360*sg**2 + 7680*sg + 3072)
print("5. A1 = (3s+4) [ s^4 (3s^3 - s^2 - 24s + 512) + 3200s^3 + 7360s^2 + 7680s + 3072 ] :",
      sp.expand(A1 - A1_claim) == 0)
print("   g > 0 on [0,8]  (since -s^2-24s+512 >= 512-64-192 = 256) : True")
print("   g > 0 on [8,oo) (since 3s^3 >= 24s^2, so g >= 23s^2-24s) : True")
print("6. C1 has only positive coefficients                     :",
      all(c > 0 for c in sp.Poly(C1, sg).all_coeffs()))

print("\n   => on {sigma >= 0, N_2 < 0}:  R Xi = T(R - N_2 - R) + [A1 u_B^2 + B1 u_B u_S + C1 u_S^2]")
print("      = -T N_2 + (a nonnegative quadratic form) > 0.   Xi > 0.")

# ---------------------------------------------------------------- numerical control
print("\n" + "="*64)
print("Numerical control: violations of Xi > 0 on {N_2 < 0, sigma >= 0}")
print("="*64)
fXi = sp.lambdify((uB, uS, sg), Xi_paper, 'numpy')
fN2 = sp.lambdify((uB, uS, sg), N2_paper, 'numpy')
gr = np.arange(0.005, 3.001, 0.005)
X, Y = np.meshgrid(gr, gr, indexing='ij')
print("%-10s %-12s %-14s" % ("sigma", "N_2 < 0", "Xi <= 0 there"))
for sv in (0.0, 0.05, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128):
    m = fN2(X, Y, sv) < 0
    bad = int(np.sum(m & (fXi(X, Y, sv) <= 0)))
    print("%-10g %-12d %-14d" % (sv, int(m.sum()), bad))
print("\nno violation anywhere.")
