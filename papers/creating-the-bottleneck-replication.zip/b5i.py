# -*- coding: utf-8 -*-
"""b5i.py — Support for Online Appendix B.5, revision of August 2026.

(1) Symbolic verification of the rent-monotonicity part of the calibrated-package
    lemma (eq. P-concave of Appendix A.3): in the host-one configuration,
      d2P/dbeta2 = - r^2 (s+2)(8+s(8+s)) / [(s+4)(3s+4)(1-2 uB uS)],
      dP/dbeta |_{beta=betabar(a)} = - r (s+2) [(v+r) - a (uS-uB)] / [(s+4)(1-2 uB uS)].
(2) Grid check: ahat (uS-uB) <= v+r holds at the single-host optimum on the
    admissible set except at strongly developer-skewed points (uS >= 1.18 at
    gamma=4, v=2, r=1/2), all inside the divide-and-rule range.
(3) Divide-and-rule sweep (symmetric pairs, regime-aware payoffs, adoption game
    solved and selection rule applied at each package): the maximizer is interior
    at every admissible grid point; beyond the admissible set it drifts to
    (beta, a) ~ (9.3, 7.2) at (0.316, 1.194) — bounded, but far outside the
    model's meaningful range.
Run:  python3 b5i.py            (part 3 takes a few minutes)
"""
import numpy as np

g, v, r = 4.0, 2.0, 0.5

# ----------------------------------------------------------------------
# (1) symbolic verification
# ----------------------------------------------------------------------
def part1():
    import sympy as sp
    uB, uS, gam, vv, rr, a, beta, p1, p2 = sp.symbols(
        'u_B u_S gamma v r a beta p_1 p_2', positive=True)
    sig = sp.symbols('sigma')
    sigexpr = gam - 2*uB*uS*(1+gam); M = 1 - 2*uB*uS
    _x, _y, _f = sp.symbols('_x _y _f')
    Dk = ((2*vv-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)).subs(sig, sigexpr)
    DS = ((uS*(2*vv-_x-_y)-_f)/M).subs(sig, sigexpr)
    D1f = lambda pa, pb, fee: Dk.subs({_x: pa, _y: pb, _f: fee}, simultaneous=True)
    D2f = lambda pa, pb, fee: Dk.subs({_x: pb, _y: pa, _f: fee}, simultaneous=True)
    DSf = lambda pa, pb, fee: DS.subs({_x: pa, _y: pb, _f: fee}, simultaneous=True)
    pr1 = (p1+beta*rr)*D1f(p1, p2, a); pr2 = (p2+rr)*D2f(p1, p2, a)
    sol = sp.solve([sp.diff(pr1, p1), sp.diff(pr2, p2)], [p1, p2], dict=True)[0]
    D1e = D1f(sol[p1], sol[p2], a); DSe = DSf(sol[p1], sol[p2], a)
    P = sp.expand((1-beta)*rr*D1e + a*DSe)
    pib = sp.simplify(((2*vv-rr*(2+sigexpr))/(4+sigexpr)+rr)
                      * (2+sigexpr)*(vv+rr)/((4+sigexpr)*M))
    pi1 = sp.simplify((sol[p1]+beta*rr)*D1e)
    bb = [s0 for s0 in sp.solve(sp.Eq(pi1, pib), beta)
          if sp.simplify(s0.subs(a, 0)-1) == 0][0]
    d2 = sp.simplify(sp.diff(P, beta, 2))
    claim2 = (-rr**2*(sig+2)*(8+sig*(8+sig))/((sig+4)*(3*sig+4)*M)).subs(sig, sigexpr)
    slope = sp.simplify(sp.diff(P, beta).subs(beta, bb))
    claim1 = (-rr*(sig+2)*((vv+rr)-a*(uS-uB))/((sig+4)*M)).subs(sig, sigexpr)
    print("(1) d2P/dbeta2 residual:", sp.simplify(d2-claim2))
    print("(1) dP/dbeta|betabar residual:", sp.simplify(slope-claim1))

# ----------------------------------------------------------------------
# common tools
# ----------------------------------------------------------------------
def N2(uB, uS, s):
    return (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
            + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))

def phi_hat(uB, uS):
    s = g - 2*uB*uS*(1+g); M = 1-2*uB*uS
    Phipp = -2*(g*(s+2)+2*(3*s+4))/(8+s*(8+s))
    Phip0 = 2*(v+r)*(s+2)*((8+s*(8+s))*uS-(4+3*s)*uB)/(M*(s+4)*(8+s*(8+s)))
    if Phip0 <= 0: return 0.0, 0.0
    ah = -Phip0/Phipp
    return Phip0*ah + 0.5*Phipp*ah**2, ah

# ----------------------------------------------------------------------
# (2) the bound ahat (uS-uB) <= v+r on the admissible set
# ----------------------------------------------------------------------
def part2():
    viol = []
    for uB in np.arange(0.02, 1.42, 0.02):
        for uS in np.arange(0.02, 1.42, 0.02):
            if 2*uB*uS >= 1: continue
            s = g - 2*uB*uS*(1+g)
            if s <= 0 or N2(uB, uS, s) >= 0: continue
            val, ah = phi_hat(uB, uS)
            if ah <= 0: continue
            if ah*(uS-uB) >= (v+r): viol.append((round(uB, 2), round(uS, 2)))
    print(f"(2) bound fails at {len(viol)} admissible unraveling points; "
          f"min uS = {min(p[1] for p in viol)}, max uB = {max(p[0] for p in viol)}")

# ----------------------------------------------------------------------
# (3) divide-and-rule sweep with publication regimes
# ----------------------------------------------------------------------
def game_value(uB, uS, B, A):
    s = g - 2*uB*uS*(1+g); M = 1-2*uB*uS
    bb, aa = np.meshgrid(B, A, indexing='ij')
    m_b = 2*(v+r)/(4+s); D_b = (2+s)*m_b/(2*M); pi_b = m_b*D_b
    # (In,In) with publication / without
    m2 = 2*(v+bb*r-uB*aa)/(4+s); D2 = (2+s)*m2/(2*M); q2 = 2*uS*D2 - aa
    ok2P = (q2 >= 0) & (D2 > 0)
    m2N = 2*(v+bb*r)/(4+g); D2N = (2+g)*m2N/2
    ok2N = (2*uS*D2N < aa) & (D2N > 0)
    pi_II = np.where(ok2P, m2*D2, np.where(ok2N, m2N*D2N, np.nan))
    plat_II = np.where(ok2P, 2*(1-bb)*r*D2 + aa*q2,
                       np.where(ok2N, 2*(1-bb)*r*D2N, np.nan))
    # (In,Out) with publication
    def phat(bk, bl, fee):
        return (-2*uB*fee*(4+3*s)+2*v*(4+3*s)-(2+s)*(s*bl+2*(2+s)*bk))/((4+s)*(4+3*s))
    ph = phat(bb*r, r, aa); po = phat(r, bb*r, aa)
    mh = ph+bb*r; mo = po+r
    Dh = (2+s)*mh/(2*M); Do = (2+s)*mo/(2*M); q1 = uS*(Dh+Do)-aa
    ok1P = (uS*Dh >= aa) & (q1 >= 0) & (Dh > 0) & (Do > 0)
    # (In,Out) without publication: host has no apps, fork carries q = uS n_o
    DN = 1 - (1+g/2)*uB*uS
    if DN > 1e-9:
        d_nopo = -(1+g/2)/DN; d_noph = (g/2)/DN
        d_nhph = -(1+g/2) - (g/2)*uB*uS*d_noph
        d_nhpo = (g/2) - (g/2)*uB*uS*d_nopo
        C_o = v/DN; C_h = v - (g/2)*uB*uS*C_o
        A11, A12 = 2*d_nhph, d_nhpo; A21, A22 = d_noph, 2*d_nopo
        det = A11*A22 - A12*A21
        b1v = -C_h - bb*r*d_nhph; b2v = -C_o - r*d_nopo
        phN = (b1v*A22 - A12*b2v)/det; poN = (A11*b2v - b1v*A21)/det
        n_oN = C_o + d_noph*phN + d_nopo*poN
        n_hN = C_h + d_nhph*phN + d_nhpo*poN
        ok1N = (uS*n_hN < aa) & (n_hN > 0) & (n_oN > 0)
        pi_in_N = (phN+bb*r)*n_hN; pi_out_N = (poN+r)*n_oN
        plat_IO_N = (1-bb)*r*n_hN
    else:
        ok1N = np.zeros_like(bb, bool)
        pi_in_N = pi_out_N = plat_IO_N = np.full_like(bb, np.nan)
    pi_in = np.where(ok1P, mh*Dh, np.where(ok1N, pi_in_N, np.nan))
    pi_out = np.where(ok1P, mo*Do, np.where(ok1N, pi_out_N, np.nan))
    plat_IO = np.where(ok1P, (1-bb)*r*Dh + aa*q1, np.where(ok1N, plat_IO_N, np.nan))
    feas = ~np.isnan(pi_II) & ~np.isnan(pi_in)
    ne_II = feas & (pi_II >= pi_out)      # indifferent accepts
    ne_OO = feas & (pi_b > pi_in)
    ne_IO = feas & (pi_in >= pi_b) & (pi_out > pi_II)
    best = np.full(bb.shape, -np.inf); V = np.full(bb.shape, np.nan)
    for ne, jp, val in [(ne_II, 2*pi_II, plat_II),
                        (ne_IO, pi_in+pi_out, plat_IO),
                        (ne_OO, np.full(bb.shape, 2*pi_b), np.zeros_like(bb))]:
        take = ne & (jp > best + 1e-12)
        V = np.where(take, val, V); best = np.where(take, jp, best)
    return np.where(np.isfinite(best), V, np.nan)

def part3():
    B = np.arange(1.0, 20.001, 0.04); A = np.arange(0.02, 25.001, 0.04)
    V = game_value(0.215, 1.106, B, A)
    i, j = np.unravel_index(np.nanargmax(V), V.shape)
    print(f"(3) check (0.215,1.106): V*={np.nanmax(V):.3f} at ({B[i]:.2f},{A[j]:.2f}) "
          f"[expected ~7.49 at (2.03, 2.67)]")
    hits = []
    for uB in np.arange(0.05, 0.42, 0.05):
        for uS in np.arange(0.85, 1.50, 0.10):
            s = g - 2*uB*uS*(1+g)
            if s <= 0 or N2(uB, uS, s) >= 0: continue
            V = game_value(round(uB, 2), round(uS, 2), B, A)
            i, j = np.unravel_index(np.nanargmax(V), V.shape)
            interior = (B[i] < B[-1]-1.0) and (A[j] < A[-1]-1.0)
            print(f"    ({uB:.2f},{uS:.2f}): V*={np.nanmax(V):8.3f} at "
                  f"({B[i]:5.2f},{A[j]:5.2f}) interior={interior}")
            if not interior: hits.append((uB, uS))
    print("(3) boundary hits on admissible set:", hits if hits else "none")
    Bx = np.arange(1.0, 60.001, 0.1); Ax = np.arange(0.05, 80.001, 0.1)
    V = game_value(0.316, 1.194, Bx, Ax)
    i, j = np.unravel_index(np.nanargmax(V), V.shape)
    print(f"(3) beyond the admissible set, (0.316,1.194): V*={np.nanmax(V):.2f} "
          f"at ({Bx[i]:.1f},{Ax[j]:.1f}) — bounded, far outside the model's range")

if __name__ == "__main__":
    part1(); part2(); part3()
