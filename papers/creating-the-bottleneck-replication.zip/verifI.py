# -*- coding: utf-8 -*-
"""verifI.py -- Endpoint signs of h1 and h2 as polynomial identities
(Online Appendix, Geometry of the Frontiers; revision of August 2026).

Method: each quantity is a rational function of (sigma, gamma); substituting
gamma = sigma + t (t > 0 on the relevant domain) and expanding, every
numerator has coefficients of a single sign, and every denominator likewise:
the sign on {0 <= sigma < gamma} is an identity, not a grid check.
Run: python3 verifI.py   (about a minute)
"""
import sympy as sp

s, g, t, x = sp.symbols('sigma gamma t x', positive=True)

h1 = ((s+2)**3*(3*s+4)**3*(g-s)**3
 + 4*(g+1)*(s+2)*(3*s+4)*x**2*(
      g**2*(s*(s*(s*(23*s+183)+507)+584)+240)
    + g*(s*(s*(s*(s*(49-5*s)+562)+1618)+1840)+736)
    + s*(s*(s*(s*(37-4*s)+422)+1184)+1312)+512)
 - 4*(g+1)**2*x**3*(
      g*(3*s+4)*(s*(s+4)*(s*(19*s+65)+88)+128)
    - s*(s*(s+3)*(s+8)+16)*(3*s*(s*(s+6)+10)+16))
 - (g+1)*(s+2)**2*(3*s+4)**2*x*(g-s)*(
      3*g*(3*s*(s*(s+7)+16)+32)
    + s*(s*(s*(3*s+61)+288)+480)+256))
h2 = ((s+2)*(3*s+4)**2*(g-s)*(g*(s+2)-s*(2*s+7)-4)
 + 2*(g+1)**2*(s*(s+4)*(s*(19*s+65)+88)+128)*x**2
 - (g+1)*(3*s+4)*x*(g*(s+2)*(3*s*(3*s*(s+7)+46)+88)
    + s*(s*(s*(31*s+251)+720)+880)+384))
xlo  = (s+2)*(3*s+4)*(g-s)/((g+1)*(3*s*(s*(s+7)+16)+32))
xhi  = (s+2)*(g-s)/(2*(g+1))
xtil = (g*(s+2)+3*s+4)/(2*(g+1))

def identity_sign(name, expr, want):
    num, den = sp.fraction(sp.together(sp.expand(expr)))
    P = sp.expand(sp.factor(num).subs(g, s+t)); Q = sp.expand(sp.factor(den).subs(g, s+t))
    def side(cs): return 'pos' if all(c > 0 for c in cs) else ('neg' if all(c < 0 for c in cs) else 'MIXED')
    sp_, sq_ = side(sp.Poly(P, s, t).coeffs()), side(sp.Poly(Q, s, t).coeffs())
    got = {('pos','pos'):'>0',('neg','neg'):'>0',('pos','neg'):'<0',('neg','pos'):'<0'}.get((sp_,sq_),'??')
    print(f"  {name:14s} {got}  (want {want})  [{'IDENTITY' if got==want else 'FAIL'}]")
    return got == want

print("Endpoint identities on 0 <= sigma < gamma:")
h1p = sp.diff(h1, x)
ok = all([identity_sign("h1(x_a)",      h1.subs(x, xlo),  '<0'),
          identity_sign("h1(xbar_a)",   h1.subs(x, xhi),  '>0'),
          identity_sign("h1'(x_a)",     h1p.subs(x, xlo), '<0'),
          identity_sign("h1'(xbar_a)",  h1p.subs(x, xhi), '>0'),
          identity_sign("h2(x_a)",      h2.subs(x, xlo),  '<0'),
          identity_sign("h2(xtilde_a)", h2.subs(x, xtil), '<0'),
          identity_sign("xbar_a - x_a", xhi - xlo,        '>0')])
print("all identities:", ok)
