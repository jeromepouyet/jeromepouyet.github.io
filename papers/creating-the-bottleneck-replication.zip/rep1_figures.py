# -*- coding: utf-8 -*-
"""rep1_figures.py -- the two figures of the admissible set and the baseline
impact map.  Regenerates figB1-admissible.pdf and figB7-baseline.pdf.

figB1 now shows the two sets the paper keeps apart: the baseline set
A = {sigma >= 0, H > 0, D_2(a**) > 0}, on which the one-instrument propositions
live, and the strictly smaller {N_2 < 0} required by the two-instrument
sections.  The complements range keeps its own set (H > 0 plus full interiority
at a**, which reproduces the paper's count of 194 admissible points out of 438
at gamma = 4 on a step-0.02 grid over [0.02, 1.60]).

figB7-baseline maps the impact of integration at a** on the rival, buyers\nand the developer; figB7-dW is the total-welfare panel alone, which the paper\nprints beside the schematic of Figure 1.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_int,
                      surpluses, Hval, N2val)
from rep1_frontiers import a_star

V, R = V_DEF, R_DEF
HI, N = 1.6, 260

def state(uB, uS, g, a):
    sig = sigma_of(uB, uS, g)
    p1, p2 = prices_int(uB, uS, sig, R, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
    return p1, p2, D1, D2, q, VB, VS

def classify(uB, uS, g):
    """0 = inadmissible, 1 = A only, 2 = A and N_2 < 0, 3 = complements."""
    if Mof(uB, uS) <= 0: return 0
    sig = sigma_of(uB, uS, g)
    if Hval(uB, uS, sig) <= 0: return 0
    a = a_star(uB, uS, sig)
    p1, p2, D1, D2, q, _, _ = state(uB, uS, g, a)
    if sig >= 0:
        if D2 <= 0: return 0                          # the second condition of A
        return 2 if N2val(uB, uS, sig) < 0 else 1
    if sig <= -1: return 0
    # complements: full interiority, the integrated firm's own margin included
    if min(D1, D2) <= 0 or q <= 0 or p1 + R <= 0 or p2 + R <= 0: return 0
    return 3

def fig_admissible(path="figB1-admissible.pdf"):
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.0))
    gr = np.linspace(1e-3, HI, N)
    for ax, g in zip(axes, (1.0, 4.0)):
        Z = np.zeros((N, N))
        for i, uS in enumerate(gr):
            for j, uB in enumerate(gr):
                Z[i, j] = classify(uB, uS, g)
        cmap = matplotlib.colors.ListedColormap(
            ["white", "#cfe2f3", "#7fb3d5", "#f5b982"])
        ax.imshow(Z, origin="lower", extent=[0, HI, 0, HI], aspect="auto",
                  cmap=cmap, vmin=0, vmax=3, interpolation="nearest")
        xs = np.linspace(1e-3, HI, 600)
        ax.plot(xs, np.clip(g/(2*(1+g)*xs), 0, HI), color="k", lw=1.1)      # sigma = 0
        ax.plot(xs, np.clip(1/(2*xs), 0, HI), color="k", lw=0.9, ls=(0,(4,3)))  # 2 u_B u_S = 1
        ax.set_xlim(0, HI); ax.set_ylim(0, HI)
        ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$")
        ax.set_title(r"$\gamma = %g$" % g, fontsize=11)
        xa = 1.05 if g == 1 else 1.2
        ax.annotate(r"$\sigma = 0$", (xa, g/(2*(1+g)*xa)), fontsize=8,
                    xytext=(4, -12), textcoords="offset points")
        ax.annotate(r"$2u_Bu_S = 1$", (1.0, 0.5), fontsize=8,
                    xytext=(6, 6), textcoords="offset points")
    handles = [matplotlib.patches.Patch(fc="#cfe2f3", label=r"$\mathcal{A}$ (one instrument)"),
               matplotlib.patches.Patch(fc="#7fb3d5", label=r"$N_2<0$ (two instruments)"),
               matplotlib.patches.Patch(fc="#f5b982", label=r"complements")]
    axes[1].legend(handles=handles, fontsize=7.5, loc="upper right", framealpha=0.95)
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

def _impact_grids(g):
    """The four sign maps at a** on the baseline set A, as 0/1 arrays."""
    gr = np.linspace(1e-3, HI, N)
    Zs = [np.full((N, N), np.nan) for _ in range(4)]
    for i, uS in enumerate(gr):
        for j, uB in enumerate(gr):
            if classify(uB, uS, g) not in (1, 2): continue
            sig = sigma_of(uB, uS, g); a = a_star(uB, uS, sig)
            p1, p2, D1, D2, q, VB, VS = state(uB, uS, g, a)
            q0 = state(uB, uS, g, 0.0)
            pi2, pi20 = (p2+R)*D2, (q0[1]+R)*q0[3]
            W  = VB + VS + pi2 + (p1+R)*D1 + a*q
            W0 = q0[5] + q0[6] + pi20 + (q0[0]+R)*q0[2]
            for k, d in enumerate([pi2-pi20, VB-q0[5], VS-q0[6], W-W0]):
                Zs[k][i, j] = 1.0 if d > 0 else 0.0
    return Zs

def _panel(ax, Z, g, title):
    cmap = matplotlib.colors.ListedColormap(["#d62728", "#1f77b4"])
    ax.imshow(Z, origin="lower", extent=[0, HI, 0, HI], aspect="auto",
              cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
    xs = np.linspace(1e-3, HI, 600)
    ax.plot(xs, np.clip(g/(2*(1+g)*xs), 0, HI), color="k", lw=1.0)
    ax.set_xlim(0, HI); ax.set_ylim(0, HI)
    ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$"); ax.set_title(title, fontsize=11)

def fig_dW(path="figB7-dW.pdf", g=4.0):
    """The single panel that goes beside Figure 1 in the paper: the sign of the
    change in total welfare at a**, computed on the baseline set A."""
    Zs = _impact_grids(g)
    fig, ax = plt.subplots(1, 1, figsize=(4.0, 3.7))
    _panel(ax, Zs[3], g, "")
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

def fig_baseline(path="figB7-baseline.pdf", g=4.0):
    names = [r"$\Delta\pi_2$", r"$\Delta V_B$", r"$\Delta V_S$"]
    fig, axes = plt.subplots(1, 3, figsize=(10.0, 3.2))
    Zs = _impact_grids(g)
    for ax, Z, nm in zip(axes, Zs[:3], names):
        _panel(ax, Z, g, nm)
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

def fig_gamma(path="figB7-gamma.pdf", gammas=(2.0, 6.0, 10.0)):
    """Change in buyer surplus at a** across product-market competition, on the
    baseline set A."""
    fig, axes = plt.subplots(1, 3, figsize=(10.4, 3.2))
    gr = np.linspace(1e-3, HI, N)
    for ax, g in zip(axes, gammas):
        Z = np.full((N, N), np.nan)
        for i, uS in enumerate(gr):
            for j, uB in enumerate(gr):
                if classify(uB, uS, g) not in (1, 2): continue
                sig = sigma_of(uB, uS, g); a = a_star(uB, uS, sig)
                VB = state(uB, uS, g, a)[5]; VB0 = state(uB, uS, g, 0.0)[5]
                Z[i, j] = 1.0 if VB > VB0 else 0.0
        cmap = matplotlib.colors.ListedColormap(["#d62728", "#1f77b4"])
        ax.imshow(Z, origin="lower", extent=[0, HI, 0, HI], aspect="auto",
                  cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
        xs = np.linspace(1e-3, HI, 600)
        ax.plot(xs, np.clip(g/(2*(1+g)*xs), 0, HI), color="k", lw=1.0)
        ax.set_xlim(0, HI); ax.set_ylim(0, HI)
        ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$")
        ax.set_title(r"$\Delta V_B$, $\gamma = %g$" % g, fontsize=11)
    plt.tight_layout(); fig.savefig(path, bbox_inches="tight")
    print("written:", path)

if __name__ == "__main__":
    fig_admissible()
    fig_baseline()
    fig_dW()
    fig_gamma()
