# -*- coding: utf-8 -*-
"""rep8_adoption.py -- the adoption subgame under the cap, enumerated.

Supports the paragraph "The selection rule never overrides an individual
preference" in Appendix A.2.  That paragraph is analytic: it rests on the two
monotonicity facts and on the publication rule, not on a grid.  What follows is
a check of its three cases, not their source.

The subgame has four profiles.  Payoffs differ across them in two ways only:
the perceived per-user benefit of each manufacturer (beta^k r if it accepts, r
if it walks), and whether the fee is in force.  By the publication rule
q_S = u_S (n_B^1 + n_B^2) - a 1{u_S n_B^I >= a}, a tax dies when no device runs
the platform's system, while a subsidy is collected in every configuration.

Claims checked, for every (u_B, u_S) admissible at gamma = 4 and every
(beta, a) on the grids below:

  (1) beta < 1, either sign of a : joint refusal is the UNIQUE equilibrium;
  (2) beta = 1, a > 0            : the equilibria are joint acceptance and
                                   joint refusal, and every manufacturer
                                   strictly prefers joint refusal;
  (3) beta = 1, a < 0            : all four profiles are equilibria and all
                                   yield the same payoffs;
  (4) in no case does the joint-profit rule retain an equilibrium that some
      manufacturer ranks strictly below another equilibrium.

Run: python3 rep8_adoption.py    (a few seconds)
"""
import numpy as np
from rep_core import V_DEF, R_DEF, sigma_of, Mof, prices_sep, demands

V, R = V_DEF, R_DEF

def profiles(uB, uS, g, beta, a):
    """The four adoption profiles, as (pi_1, pi_2)."""
    sig = sigma_of(uB, uS, g)
    a_RR = a if a < 0 else 0.0            # a tax dies under joint refusal
    def cfg(b1, b2, fee):
        p1, p2 = prices_sep(uB, uS, sig, b1, b2, fee)
        D1, D2, _ = demands(uB, uS, sig, p1, p2, fee)
        return (p1 + b1) * D1, (p2 + b2) * D2
    return {'AA': cfg(beta*R, beta*R, a), 'AR': cfg(beta*R, R, a),
            'RA': cfg(R, beta*R, a),      'RR': cfg(R, R, a_RR)}

DEV = {'AA': ('RA', 'AR'), 'RR': ('AR', 'RA'),
       'AR': ('RR', 'AA'), 'RA': ('AA', 'RR')}

def equilibria(p, tol=1e-9):
    return [s for s, (d1, d2) in DEV.items()
            if p[s][0] >= p[d1][0] - tol and p[s][1] >= p[d2][1] - tol]

def run(g=4.0, step=0.10, hi=1.20,
        betas=(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0),
        fees=(-1.2, -0.8, -0.4, -0.1, 0.1, 0.4, 0.8, 1.2)):
    gr = np.arange(step, hi + step/2, step)
    n = {1: 0, 2: 0, 3: 0}
    bad = []
    for uB in gr:
        for uS in gr:
            if Mof(uB, uS) <= 0 or sigma_of(uB, uS, g) < 0:
                continue
            for beta in betas:
                for a in fees:
                    p = profiles(uB, uS, g, beta, a)
                    eq = set(equilibria(p))
                    if not eq:
                        bad.append(('no equilibrium', uB, uS, beta, a)); continue
                    if beta < 1 - 1e-9:
                        if eq != {'RR'}:
                            bad.append(('(1) fails', uB, uS, beta, a, sorted(eq)))
                        else:
                            n[1] += 1
                    elif a > 0:
                        strict = p['RR'][0] > p['AA'][0] + 1e-9 and p['RR'][1] > p['AA'][1] + 1e-9
                        if eq != {'AA', 'RR'} or not strict:
                            bad.append(('(2) fails', uB, uS, beta, a, sorted(eq), strict))
                        else:
                            n[2] += 1
                    else:
                        same = max(abs(p[s][i] - p['RR'][i]) for s in p for i in (0, 1))
                        if eq != {'AA', 'AR', 'RA', 'RR'} or same > 1e-9:
                            bad.append(('(3) fails', uB, uS, beta, a, sorted(eq), same))
                        else:
                            n[3] += 1
                    sel = max(eq, key=lambda s: p[s][0] + p[s][1])
                    for s in eq:
                        if p[s][0] > p[sel][0] + 1e-8 or p[s][1] > p[sel][1] + 1e-8:
                            bad.append(('(4) fails', uB, uS, beta, a, s, sel))
    print("The adoption subgame under the cap, gamma = %.0f" % g)
    print("  (1) beta < 1          : joint refusal unique at %d of %d configurations"
          % (n[1], n[1]))
    print("  (2) beta = 1, a > 0   : equilibria {AA, RR}, joint refusal strictly"
          " preferred, at %d" % n[2])
    print("  (3) beta = 1, a < 0   : all four equilibria, payoff-identical, at %d" % n[3])
    print("  (4) the joint-profit rule never retains an equilibrium a manufacturer"
          " ranks below another")
    print("  exceptions to (1)--(4): %d" % len(bad))
    for b in bad[:5]:
        print("     ", b)
    return bad

if __name__ == "__main__":
    run()
