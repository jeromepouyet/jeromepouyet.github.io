# -*- coding: utf-8 -*-
"""rep7_twostores.py -- driver for the integrated-rival extension of
Section "An Integrated Rival" and the corresponding Online Appendix section.

M_2 owns its operating system and its store, so the developer faces two fees
and, multi-homing, supplies q_S = u_S(n^1_B + n^2_B) - a_1 - a_2.  The demand
system is therefore the paper's at a = a_1 + a_2, and the two fees are
Cournot complements.

  ext/ext2_setup.py     the benchmark: I licenses to M_1 and earns zero, M_2
                        sets (p_2, a_2); recovers the paper's a** when M_2's
                        store is removed
  ext/ext2_merger.py    the post-merger symmetric equilibrium, and the
                        factorisation of the change in the total fee
  ext/ext2_Lproof3.py   L > 0 as a polynomial identity (the method of
                        verifI.py)
  ext/ext2_welfare.py   the four surplus changes
  ext/ext2_dm.py        the double-marginalisation ratio against the
                        coordinated-fee counterfactual
  ext/ext2_full.py      the grid pass
  ext/ext_tables.py     the table quoted in the paper

Run: python3 rep7_twostores.py            (several minutes in full)
     python3 rep7_twostores.py --table    (the table only, seconds)
"""
import os, subprocess, sys
FAILED = []

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.join(HERE, "ext")
FULL = ["ext2_setup.py", "ext2_merger.py", "ext2_Lproof3.py", "ext2_welfare.py",
        "ext2_dm.py", "ext2_full.py", "ext_tables.py"]

def run(name):
    print("\n" + "=" * 72 + "\n== %s\n" % name + "=" * 72)
    rc = subprocess.run([sys.executable, os.path.join(EXT, name)]).returncode
    if rc != 0:
        FAILED.append((name, rc))
        print('    ** %s exited with code %d **' % (name, rc))

if __name__ == "__main__":
    steps = ["ext_tables.py"] if "--table" in sys.argv else FULL
    for s in steps:
        run(s)
