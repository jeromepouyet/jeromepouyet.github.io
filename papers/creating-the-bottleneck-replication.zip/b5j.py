# -*- coding: utf-8 -*-
"""b5j.py — Support for the total-welfare proposition (Online Appendix B.2,
revision of August 2026).

(1) Symbolic: Delta W(a) = a (c1 + c2 a); component identity (c1, c2 as sums of
    the buyer, developer, rival and integrated-profit coefficients built from
    K, T, m2', H); closed form of c1 via N1; factorization of N1 along the
    locus a**=0 into strictly positive terms.
(2) Numerical: validation of Delta W(a**) at reference points; subsidy side
    (a**<0 implies Delta W>0 at every admissible grid point); taxing side
    (quartic in x = u_S^2, single crossing per slice, corner counts in gamma).
Run: python3 b5j.py   (a few minutes)
"""
import sympy as sp
import numpy as np

# ----------------------------------------------------------------------
# (1) symbolic block
# ----------------------------------------------------------------------
def symbolic():
    uB, uS, g, v, r, a, b2, p1, p2 = sp.symbols(
        'u_B u_S gamma v r a b_2 p_1 p_2', positive=True)
    sig = sp.symbols('sigma')
    sigexpr = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
    _x, _y, _f = sp.symbols('_x _y _f')
    Dk = ((2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)).subs(sig, sigexpr)
    DS = ((uS*(2*v-_x-_y)-_f)/M).subs(sig, sigexpr)
    D1f = lambda pa, pb, fee: Dk.subs({_x: pa, _y: pb, _f: fee}, simultaneous=True)
    D2f = lambda pa, pb, fee: Dk.subs({_x: pb, _y: pa, _f: fee}, simultaneous=True)
    DSf = lambda pa, pb, fee: DS.subs({_x: pa, _y: pb, _f: fee}, simultaneous=True)
    PI_I = (p1+r)*D1f(p1, p2, a) + a*DSf(p1, p2, a) + (r-b2)*D2f(p1, p2, a)
    PI_M2 = (p2+b2)*D2f(p1, p2, a)
    sol = sp.solve([sp.diff(PI_I, p1), sp.diff(PI_M2, p2)], [p1, p2], dict=True)[0]
    p1I = sol[p1].subs(b2, r); p2I = sol[p2].subs(b2, r)
    D1e = D1f(p1I, p2I, a); D2e = D2f(p1I, p2I, a); DSe = DSf(p1I, p2I, a)
    VB = (v*(D1e+D2e) + uB*DSe*(D1e+D2e)
          - (2*(D1e**2+D2e**2) + g*(D1e+D2e)**2)/(4*(1+g)) - p1I*D1e - p2I*D2e)
    W = sp.expand(VB + DSe**2/2 + (p1I+r)*D1e + a*DSe + (p2I+r)*D2e)
    DW = sp.expand(W - W.subs(a, 0))
    c1 = sp.simplify(sp.diff(DW, a).subs(a, 0))
    c2 = sp.simplify(sp.diff(DW, a, 2)/2)
    gsol = sp.solve(sp.Eq(sig, sigexpr), g)[0]
    N1 = ((sig+2)*((sig+6)*uB - 8*uB**2*uS - 2*uS**3)
          + 2*(sig**2+3*sig+4)*uB*uS**2 - 2*uS)
    c1_claim = (-2*(v+r)*N1/((sig+4)**2*(1-2*uB*uS)**2)).subs(sig, sigexpr)
    print("(1) c1 residual vs -2(v+r)N1/[(s+4)^2 M^2]:",
          sp.simplify(c1 - c1_claim))
    # component identity
    K = ((sig+2)**2*(3*sig+4)**2*uB**2
         + ((sig+2)*(sig*(sig+16)+16) - 2*uB*uS*(sig+1)*(sig+4)**2)*uS**2
         - 2*uB*uS*(sig+2)*(3*sig+4)**2)
    T = sig - 2*uS*(2*uB+uS) + 4
    H = ((sig+4)**2*(3*sig+4)**2 - 2*(sig+2)*(3*sig+4)**2*uB**2
         - 2*(3*sig+4)*(sig*(7*sig+32)+32)*uB*uS
         - 2*(sig*(sig*(7*sig+40)+64)+32)*uS**2)
    m2p = -(2*uB*(4+3*sig)+2*sig*uS)/((4+sig)*(4+3*sig))
    q_sum = (K/((sig+4)**2*(3*sig+4)**2*(1-2*uB*uS)**2)
             + T**2/(2*(sig+4)**2*(1-2*uB*uS)**2)
             + (2+sig)*m2p**2/(2*(1-2*uB*uS))
             - H/((sig+4)**2*(3*sig+4)**2*(1-2*uB*uS)))
    print("(1) c2 residual vs component sum:",
          sp.simplify(c2 - q_sum.subs(sig, sigexpr)))
    # factorization along a**=0
    xa = (sig+2)*(3*sig+4)*(g-sig)/((g+1)*(3*sig*(sig*(sig+7)+16)+32))
    N1u = sp.together(N1.subs(uB, (g-sig)/(2*(1+g)*uS)))
    num, _ = sp.fraction(N1u)
    Xs = sp.Symbol('x', positive=True)
    num_x = sp.expand(num.subs(uS, sp.sqrt(Xs)))
    fac = sp.factor(sp.simplify(num_x.subs(Xs, xa)))
    print("(1) N1 numerator along a**=0, factored:")
    sp.pprint(fac)
    # quartic in x = u_S^2: coefficient-sign identities via gamma = sigma + t
    t = sp.symbols('t', positive=True)
    uB_, uS_ = sp.symbols('uB_ uS_', positive=True)
    M_ = 1 - 2*uB_*uS_
    N1_ = ((sig+2)*((sig+6)*uB_ - 8*uB_**2*uS_ - 2*uS_**3)
           + 2*(sig**2+3*sig+4)*uB_*uS_**2 - 2*uS_)
    c1_ = -2*(r+v)*N1_/((sig+4)**2*M_**2)
    K_ = ((sig+2)**2*(3*sig+4)**2*uB_**2
          + ((sig+2)*(sig*(sig+16)+16) - 2*uB_*uS_*(sig+1)*(sig+4)**2)*uS_**2
          - 2*uB_*uS_*(sig+2)*(3*sig+4)**2)
    T_ = sig - 2*uS_*(2*uB_+uS_) + 4
    H_ = ((sig+4)**2*(3*sig+4)**2 - 2*(sig+2)*(3*sig+4)**2*uB_**2
          - 2*(3*sig+4)*(sig*(7*sig+32)+32)*uB_*uS_
          - 2*(sig*(sig*(7*sig+40)+64)+32)*uS_**2)
    m2p_ = -(2*uB_*(4+3*sig)+2*sig*uS_)/((4+sig)*(4+3*sig))
    c2_ = (K_/((sig+4)**2*(3*sig+4)**2*M_**2) + T_**2/(2*(sig+4)**2*M_**2)
           + (2+sig)*m2p_**2/(2*M_) - H_/((sig+4)**2*(3*sig+4)**2*M_))
    B_ = (3*sig*(sig*(sig+7)+16)+32)*uS_ - 2*(sig+2)*(3*sig+4)*uB_
    E_ = sp.together((c1_ + c2_*(3*sig+4)*(v+r)*B_/H_).subs(uB_, (g-sig)/(2*(g+1)*uS_)))
    numE, _ = sp.fraction(E_)
    numE = sp.expand(numE).subs(uS_**2, Xs)
    numE = sp.expand(numE.subs(uS_**4, Xs**2).subs(uS_**6, Xs**3).subs(uS_**8, Xs**4))
    px = sp.Poly(numE, Xs)
    qs = [sp.cancel(c/(r+v)) for c in px.all_coeffs()]   # q4..q0
    names = ['q4','q3','q2','q1','q0']; wants = ['neg','pos',None,'neg','pos']
    for nm, c, want in zip(names, qs, wants):
        if want is None: continue
        cs = sp.Poly(sp.expand(c.subs(g, sig+t)), sig, t).coeffs()
        got = 'pos' if all(x > 0 for x in cs) else ('neg' if all(x < 0 for x in cs) else 'MIXED')
        print(f"(1) quartic coefficient {nm}: {got} (want {want}) "
              f"[{'identity' if got == want else 'FAIL'}]")

# ----------------------------------------------------------------------
# (2) numerical block
# ----------------------------------------------------------------------
v, r = 2.0, 0.5
def N2(uB, uS, s):
    return (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
            + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))

def pieces(uB, uS, g):
    s = g - 2*uB*uS*(1+g); M = 1-2*uB*uS
    N1 = ((s+2)*((s+6)*uB - 8*uB**2*uS - 2*uS**3)
          + 2*(s**2+3*s+4)*uB*uS**2 - 2*uS)
    c1 = -2*(r+v)*N1/((s+4)**2*M**2)
    K = ((s+2)**2*(3*s+4)**2*uB**2
         + ((s+2)*(s*(s+16)+16) - 2*uB*uS*(s+1)*(s+4)**2)*uS**2
         - 2*uB*uS*(s+2)*(3*s+4)**2)
    T = s - 2*uS*(2*uB+uS) + 4
    H = ((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
         - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS - 2*(s*(s*(7*s+40)+64)+32)*uS**2)
    m2p = -(2*uB*(4+3*s)+2*s*uS)/((4+s)*(4+3*s))
    c2 = (K/((s+4)**2*(3*s+4)**2*M**2) + T**2/(2*(s+4)**2*M**2)
          + (2+s)*m2p**2/(2*M) - H/((s+4)**2*(3*s+4)**2*M))
    ast = (3*s+4)*(v+r)*((3*s*(s*(s+7)+16)+32)*uS - 2*(s+2)*(3*s+4)*uB)/H
    return c1, c2, ast, s

def numerical():
    print("\n(2) validation at reference points (gamma=4, v=2, r=1/2):")
    for (uB, uS, ref) in [(0.1, 0.1, -0.074), (0.5, 0.18, -0.231), (0.15, 1.0, -2.516)]:
        c1, c2, ast, s = pieces(uB, uS, 4.0)
        print(f"    ({uB},{uS}): DW(a**) = {ast*(c1+c2*ast):+.3f}  (expected {ref})")
    for g in [1.0, 4.0]:
        sub_pos = sub_tot = tax_pos = tax_tot = 0
        for uB in np.arange(0.02, 1.42, 0.02):
            for uS in np.arange(0.02, 1.42, 0.02):
                if 2*uB*uS >= 1: continue
                s = g - 2*uB*uS*(1+g)
                if s <= 0 or N2(uB, uS, s) >= 0: continue
                c1, c2, ast, _ = pieces(uB, uS, g)
                dw = ast*(c1+c2*ast)
                if ast < 0: sub_tot += 1; sub_pos += (dw > 0)
                else: tax_tot += 1; tax_pos += (dw > 0)
        print(f"    gamma={g}: subsidy side DW>0 at {sub_pos}/{sub_tot}; "
              f"taxing side DW>0 at {tax_pos}/{tax_tot}")
    # slices: single crossing of sign(DW(a**)) in x on the taxing range,
    # with crossing directions (ascending = welfare turns positive)
    tot_slices = tot_cross = tot_desc = tot_multi = 0
    for g in [0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 16.0]:
        bad = 0; slices = 0
        for s in np.linspace(0.05, g*0.98, 120):
            A4 = 4*(1+g)**2*(4+3*s)*(12+s*(11+3*s))
            B4 = -4*(1+g)*(128+g*(4+3*s)*(12+s*(11+3*s)) + s*(272+s*(212+s*(73+9*s))))
            C4 = (g-s)**2*(4+3*s)*(12+s*(11+3*s))
            disc = B4*B4-4*A4*C4
            if disc <= 0: continue
            xhi = (-B4+np.sqrt(disc))/(2*A4)
            xa = (s+2)*(3*s+4)*(g-s)/((g+1)*(3*s*(s*(s+7)+16)+32))
            lo = max((-B4-np.sqrt(disc))/(2*A4), xa)
            if lo >= xhi: continue
            xs = np.linspace(lo*1.001, xhi*0.999, 400)
            vals = []
            for x in xs:
                uS_ = np.sqrt(x); uB_ = (g-s)/(2*(1+g)*uS_)
                c1, c2, ast, _ = pieces(uB_, uS_, g)
                vals.append(ast*(c1+c2*ast))
            sgn = np.sign(vals)
            idx = np.where(sgn[1:]*sgn[:-1] < 0)[0]
            slices += 1
            tot_cross += len(idx)
            tot_desc += int(np.sum([vals[i+1] < vals[i] for i in idx]))
            if len(idx) > 1: bad += 1
        tot_slices += slices; tot_multi += bad
        print(f"    gamma={g}: {slices} taxing slices, multi-crossings: {bad}")
    print(f"    total: {tot_slices} slices, {tot_cross} crossings, "
          f"{tot_desc} descending, {tot_multi} multi-crossing slices")

if __name__ == "__main__":
    symbolic(); numerical()
