# -*- coding: utf-8 -*-
"""rep6_manufacturers.py -- driver for the N-manufacturer extension of
Section "More Manufacturers" and the corresponding Online Appendix section.

Each step lives in ext/ and carries its own check against the two-manufacturer
model of the paper.  Run in this order (the symbolic steps cache their result,
so a rerun of the later steps is cheap):

  ext/extN_demand.py    the demand system in sigma_N, and M_N q_S
  ext/extN_eq2.py       the stage-3 equilibrium; checked against
                        rep_core.prices_int at N = 2
  ext/extN_fee.py       a**(N) and the second-order condition; checked against
                        equation (astar) at N = 2
  ext/extN_frontier.py  R_a^N, its value N at sigma = 0, its limit, and the
                        polynomial identity for d R_a^N / d N > 0
  ext/extN_harm.py      the generalisation of Proposition 3
  ext/extN_checks.py    admissible-set counts against A at each gamma
  ext/extN_welfare.py   total welfare with N manufacturers
  ext/extN_welfmap.py   the welfare map by (gamma, N)
  ext/ext_tables.py     the table quoted in the paper

Run: python3 rep6_manufacturers.py            (about ten minutes in full)
     python3 rep6_manufacturers.py --table    (the table only, seconds)
"""
import os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.join(HERE, "ext")
FULL = ["extN_demand.py", "extN_eq2.py", "extN_fee.py", "extN_frontier.py",
        "extN_harm.py", "extN_checks.py", "extN_welfare.py", "extN_welfmap.py",
        "ext_tables.py"]

def run(name):
    print("\n" + "=" * 72 + "\n== %s\n" % name + "=" * 72)
    subprocess.run([sys.executable, os.path.join(EXT, name)], check=False)

if __name__ == "__main__":
    steps = ["ext_tables.py"] if "--table" in sys.argv else FULL
    for s in steps:
        run(s)
