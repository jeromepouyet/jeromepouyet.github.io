# -*- coding: utf-8 -*-
"""rep9_dnr.py -- the both-host reduction behind Proposition 6.

The unrestricted contract space has four families.  Subsidy packages, capped
packages and single-host packages are settled analytically in Appendix A.3.
This script establishes the reduction that settles the fourth, rebate pairs,
and checks it.

On the both-host configuration the platform's profit

    Pi(beta^1, beta^2, a) = sum_k (1 - beta^k) r D_k + a q_S

evaluated at the stage-3 equilibrium is a quadratic polynomial.  What follows
is derived symbolically, not fitted:

  (A) the critical point of Pi is unique, and it is symmetric: the identity
      beta^{1,dagger} - beta^{2,dagger} = 0 holds in the primitives, so
      restricting attention to symmetric pairs costs nothing;

  (B) at the symmetric critical point,

          a^dagger = (v+r)(sigma+2)(u_S - u_B) / Delta,
          Psi      = (v+r)^2 (sigma+2)       / Delta,

      with the same Delta, and Delta > 0 is equivalent to the second-order
      condition (on the symmetric restriction beta^1 = beta^2 the Hessian
      determinant is 4 r^2 (sigma+2) Delta over positive factors; the full
      3x3 Hessian is block-diagonal in (a, beta^1+beta^2, beta^1-beta^2)
      with a negative antisymmetric eigenvalue, test 8);

  (C) hence sign(a^dagger) = sign(u_S - u_B).  Where u_B >= u_S the interior
      candidate calls for a subsidy, so no rebate pair with a > 0 can be
      optimal there;

  (D) in the region of Proposition 6(i), u_B >= h_Phi(u_S) implies
      u_B/u_S >= R_Phi(sigma) >= 2 > 1, so (C) applies: the interior optimum
      of the both-host program is not a taxing pair.  This places the
      interior optimum, not the family: the exclusion of both-host packages
      rests on the selection rule and is a grid finding
      (rep33_bothhost_grid.py);

  (E) in the region of Proposition 6(ii) the sign condition is necessary but
      not sufficient, and the partition between the single-host optimum
      Phi(a_hat) and Psi is the sign of an explicit difference of two closed
      forms, computed here on the reference grid.

Run: python3 rep9_dnr.py       (about five minutes, the six gamma of the reference grid)
"""
import numpy as np
import sympy as sp

from rep_core import (V_DEF, R_DEF, sigma_of, Mof, Hval, N2val, prices_int,
                      prices_sep, demands)
from rep1_frontiers import a_star
from rep3_contracts import a_hat, Phi

V, R, G = V_DEF, R_DEF, 4.0
R_PHI = lambda s: (8 + s*(8+s)) / (4 + 3*s)

# ----------------------------------------------------------------- symbolic
uB, uS, v, r, g, S = sp.symbols('u_B u_S v r gamma sigma', positive=True)
a, b1, b2 = sp.symbols('a beta1 beta2')
p1, p2 = sp.symbols('p1 p2')

def _derive():
    s = g - 2*uB*uS*(1+g)
    M = 1 - 2*uB*uS
    D1 = (2*v - (2+s)*p1 + s*p2 - 2*uB*a) / (2*M)
    D2 = (2*v - (2+s)*p2 + s*p1 - 2*uB*a) / (2*M)
    DS = (uS*(2*v - p1 - p2) - a) / M
    sol = sp.solve([sp.diff((p1 + b1*r)*D1, p1), sp.diff((p2 + b2*r)*D2, p2)],
                   [p1, p2], dict=True)[0]
    d1, d2, qs = D1.subs(sol), D2.subs(sol), DS.subs(sol)
    Pi = (1 - b1)*r*d1 + (1 - b2)*r*d2 + a*qs
    return Pi

def symbolic():
    print("Symbolic layer\n")
    Pi = _derive()

    deg = sp.Poly(sp.expand(sp.numer(sp.together(Pi))), a, b1, b2).total_degree()
    print("  1. Pi is a quadratic polynomial in (beta^1, beta^2, a) : %s"
          % (sp.simplify(sp.diff(Pi, a, 3)) == 0
             and sp.simplify(sp.diff(Pi, b1, 3)) == 0))

    crit = sp.solve([sp.numer(sp.together(sp.diff(Pi, x))) for x in (a, b1, b2)],
                    [a, b1, b2], dict=True)
    print("  2. the critical point is unique                       : %s" % (len(crit) == 1))
    c = crit[0]
    print("  3. it is symmetric, beta^1 - beta^2 = 0 identically   : %s"
          % (sp.simplify(c[b1] - c[b2]) == 0))

    ad = sp.cancel(c[a])
    num, Delta = sp.fraction(sp.together(ad))
    Psi = sp.cancel(sp.simplify(Pi.subs(c)))
    nP, dP = sp.fraction(sp.together(Psi))

    tgt_num = (v + r)*(S + 2)*(uS - uB)
    sub = {S: g - 2*uB*uS*(1+g)}
    print("  4. a_dagger numerator = (v+r)(sigma+2)(u_S-u_B)       : %s"
          % (sp.simplify(sp.expand(num - tgt_num.subs(sub))) == 0))
    print("  5. Psi = (v+r)^2 (sigma+2) / Delta, same Delta        : %s"
          % (sp.simplify(sp.cancel(Psi - ((v+r)**2*(S+2)).subs(sub)/Delta)) == 0))

    Pis = Pi.subs({b2: b1})
    H = sp.Matrix([[sp.diff(Pis, x, y) for y in (a, b1)] for x in (a, b1)])
    det = sp.cancel(sp.simplify(H.det()))
    ratio = sp.cancel(sp.simplify(det / Delta))
    print("  6. det Hessian = 4 r^2 (sigma+2) Delta over positives : %s"
          % (sp.simplify(sp.cancel(ratio - (4*r**2*(S+2)).subs(sub)
                / ((2*uB*uS-1)**2*(2*g*uB*uS-g+2*uB*uS-4)**2))) == 0))
    disp = (2*(g+4) - (S+2)*(uB**2+uS**2) - 2*(2*g+S+8)*uB*uS).subs(sub)
    print("  7. Delta = 2(gamma+4) - (sigma+2)(u_B^2+u_S^2)"
          " - 2(2 gamma+sigma+8) u_B u_S : %s"
          % (sp.simplify(sp.expand(Delta - disp)) == 0))
    # The full 3x3 Hessian in (a, beta^1, beta^2).  By symmetry it is
    # block-diagonal in the directions (a, beta^1+beta^2, beta^1-beta^2); the
    # antisymmetric direction carries a negative eigenvalue, and the symmetric
    # block is the 2x2 Hessian of test 6 up to positive factors, so Delta > 0
    # is the second-order condition of the three-instrument problem.
    H3 = sp.Matrix([[sp.diff(Pi, x, y) for y in (a, b1, b2)] for x in (a, b1, b2)])
    H3 = H3.applyfunc(lambda e: sp.cancel(sp.simplify(e)))
    Mm = 1 - 2*uB*uS
    blockdiag = (sp.simplify(H3[0,1] - H3[0,2]) == 0
                 and sp.simplify(H3[1,1] - H3[2,2]) == 0)
    anti = sp.cancel(sp.simplify((H3[1,1] - H3[1,2]).subs({g: (S+2*uB*uS)/Mm})))
    anti_ok = sp.simplify(anti + 2*r**2*(S+1)*(S+2)/((3*S+4)*Mm)) == 0
    det3 = sp.cancel(sp.simplify(H3.det()))
    det3_ok = sp.simplify(sp.cancel(det3 / Delta)
              + (4*r**4*(S+1)*(S+2)**2).subs(sub)
                / ((2*g*uB*uS-g+2*uB*uS-4)**2*(3*g-6*g*uB*uS-6*uB*uS+4)*Mm**3)) == 0
    print("  8. the 3x3 Hessian is block-diagonal in (a, b1+b2, b1-b2)  : %s"
          % blockdiag)
    print("     antisymmetric eigenvalue = -2 r^2 (sigma+1)(sigma+2)"
          " / ((3 sigma+4) M) < 0 : %s" % anti_ok)
    print("     det (3x3) = -4 r^4 (sigma+1)(sigma+2)^2 Delta over positives"
          " : %s" % det3_ok)
    return sp.lambdify((uB, uS, v, r, g), ad, 'numpy'), \
           sp.lambdify((uB, uS, v, r, g), c[b1], 'numpy'), \
           sp.lambdify((uB, uS, v, r, g), Psi, 'numpy'), \
           sp.lambdify((uB, uS, v, r, g), Delta, 'numpy')

# ---------------------------------------------------------------- numerical
def _cfg(x, y, sg, c1, c2, fee):
    q1, q2 = prices_sep(x, y, sg, c1, c2, fee)
    Da, Db, q = demands(x, y, sg, q1, q2, fee)
    return (q1 + c1)*Da, (q2 + c2)*Db

def _admissible(x, y, gg):
    if Mof(x, y) <= 0: return None
    sg = sigma_of(x, y, gg)
    if sg < 0 or Hval(x, y, sg) <= 0: return None
    if N2val(x, y, sg) >= 0: return None
    aa = a_star(x, y, sg)
    q1, q2 = prices_int(x, y, sg, R, aa)
    if demands(x, y, sg, q1, q2, aa)[1] <= 0: return None
    return sg                                  # the set A of Sections 3-4 (chantier 18)

def grid(f_a, f_b, f_P, f_D, gg=G, step=0.02, hi=1.40):
    gr = np.arange(step, hi + step/2, step)
    part1 = dict(n=0, badDelta=0, aneg=0, positive=0)
    part2 = dict(n=0, uBgeuS=0, dnr=0, us=[])
    for x in gr:
        for y in gr:
            sg = _admissible(x, y, gg)
            if sg is None: continue
            ad = float(f_a(x, y, V, R, gg)); Delta = float(f_D(x, y, V, R, gg))
            bd = float(f_b(x, y, V, R, gg)); Ps = float(f_P(x, y, V, R, gg))
            if x/y >= R_PHI(sg):                       # ---- Proposition 6(i)
                part1['n'] += 1
                if Delta <= 0: part1['badDelta'] += 1
                if ad <= 0: part1['aneg'] += 1; continue
                piRR = _cfg(x, y, sg, R, R, 0.0)[0]
                host = _cfg(x, y, sg, bd*R, R, ad); both = _cfg(x, y, sg, bd*R, bd*R, ad)
                if bd > 1 and host[0] > piRR and both[0] >= host[1] and Ps > 0:
                    part1['positive'] += 1
            else:                                      # ---- Proposition 6(ii)
                part2['n'] += 1
                if x >= y: part2['uBgeuS'] += 1; continue
                piRR = _cfg(x, y, sg, R, R, 0.0)[0]
                host = _cfg(x, y, sg, bd*R, R, ad); both = _cfg(x, y, sg, bd*R, bd*R, ad)
                feas = ad > 0 and bd > 1 and host[0] > piRR and both[0] >= host[1]
                SH = Phi(x, y, sg, gg, max(a_hat(x, y, sg, gg), 0.0))
                if feas and Ps > SH:
                    part2['dnr'] += 1; part2['us'].append(y)
    print("\nGrid check, gamma = %g, step %.2f on [%.2f, %.2f]" % (gg, step, step, hi))
    print("  Proposition 6(i), region u_B >= h_Phi : %d admissible points" % part1['n'])
    print("     Delta <= 0 (second-order condition fails)      : %d" % part1['badDelta'])
    print("     a_dagger <= 0, so the family is empty          : %d" % part1['aneg'])
    print("     rebate pairs with a strictly positive profit   : %d" % part1['positive'])
    print("  Proposition 6(ii), region u_B < h_Phi : %d admissible points" % part2['n'])
    print("     u_B >= u_S, single-host optimal analytically   : %d  (%.0f%%)"
          % (part2['uBgeuS'], 100*part2['uBgeuS']/part2['n']))
    print("     divide-and-rule strictly better                : %d" % part2['dnr'])
    if part2['us']:
        print("     it wins only for u_S in [%.2f, %.2f]" % (min(part2['us']), max(part2['us'])))

if __name__ == "__main__":
    print("rep9_dnr -- the both-host reduction (v = 2, r = 1/2)\n")
    f_a, f_b, f_P, f_D = symbolic()
    for gg in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        grid(f_a, f_b, f_P, f_D, gg=gg)
