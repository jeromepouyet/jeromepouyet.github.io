# -*- coding: utf-8 -*-
"""rep27_slopes_closed.py -- B: closed forms for the delta-slopes.

Two targets, in order of importance:

 (1) dW_sep/ddelta at delta = 0 in the FLOOR cell.  There separation is
     (beta r = r - delta, a = 0): the platform takes delta per user in shares
     and posts no fee.  The derivative of welfare is the pure
     double-marginalization statement of this model -- an upstream margin added
     on top of the manufacturers' existing markup -- and it should be provably
     negative.  This is what licenses the name Ordover-Saloner-Salop.

 (2) dG/ddelta at delta = 0 in the FLOOR cell.  Numerically it is positive at
     most of the cell, not all of it (rep25).  If it factors, the missing
     frontier is explicit and the cell splits in two.

The floor cell is u_B/u_S >= R_Phi, the taxing frontier of the asymmetric
benchmark (rep35); its taxing-branch counterpart, dW_sep/ddelta on b_1 = r,
b_2 = r - delta, a = kappa delta, is derived and signed in rep35 (test 5).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
P = lambda *a: print(*a, flush=True)
P("="*78); P("rep27 (B) -- closed forms of the slopes"); P("="*78)

uB,uS,s,v,r,d,p1,p2,b,b2,a = sp.symbols('u_B u_S sigma v r delta p_1 p_2 b b_2 a', positive=True)
M=1-2*uB*uS; Lam=8+s*(8+s)
def dem(P1,P2,A): return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
                          (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),(uS*(2*v-P1-P2)-A)/M)
g_=(s+2*uB*uS)/M
def surp(P1,P2,D1,D2,Q):
    return (v*(D1+D2)+uB*Q*(D1+D2)-(2*(D1**2+D2**2)+g_*(D1+D2)**2)/(4*(1+g_))
            -P1*D1-P2*D2), Q**2/2
D1e,D2e,QSe=dem(p1,p2,a)
sep=sp.solve([sp.diff((p1+b)*D1e,p1),sp.diff((p2+b)*D2e,p2)],[p1,p2],dict=True)[0]

# ---------------- (1) the floor cell, separation side ----------------
P("\n (1) dW_sep/ddelta at delta = 0, FLOOR cell (beta r = r-delta, a = 0)")
bv = r-d
P1 = sp.cancel(sep[p1].subs({b:bv, a:0})); P2 = sp.cancel(sep[p2].subs({b:bv, a:0}))
D1,D2,Q = dem(P1,P2,0); VB,VS = surp(P1,P2,D1,D2,Q)
pi = (P1+bv)*D1
Wsep = sp.cancel(sp.together(VB+VS+2*pi+2*d*D1))
dW = sp.factor(sp.cancel(sp.diff(Wsep, d).subs(d, 0)))
P("     dW_sep/ddelta|_0 = "); P("       ", sp.simplify(dW))
num, den = sp.fraction(sp.cancel(dW))
P("     numerator   :", sp.factor(sp.expand(num)))
P("     denominator :", sp.factor(sp.expand(den)))

# the pieces, to name the mechanism
P("\n     decomposition at delta = 0 (all evaluated at beta = 1, a = 0):")
for nm, e in (("d(D1)/ddelta", sp.diff(D1,d).subs(d,0)),
              ("markup p1+beta r", sp.cancel((P1+bv).subs(d,0))),
              ("d(VB)/ddelta", sp.diff(VB,d).subs(d,0)),
              ("d(VS)/ddelta", sp.diff(VS,d).subs(d,0)),
              ("d(2 pi)/ddelta", sp.diff(2*pi,d).subs(d,0)),
              ("d(platform 2 delta D1)/ddelta", sp.diff(2*d*D1,d).subs(d,0))):
    P("       %-28s = %s" % (nm, sp.factor(sp.cancel(e))))

# ---------------- (2) the floor cell, the private gain ----------------
P("\n (2) dG/ddelta at delta = 0, FLOOR cell")
objI=(p1+r)*D1e+a*QSe+(r-b2)*D2e
inte=sp.solve([sp.diff(objI,p1),sp.diff((p2+b2)*D2e,p2)],[p1,p2],dict=True)[0]
PiIs=sp.cancel(sp.together(objI.subs(inte)))
a_of=sp.cancel(sp.solve(sp.Eq(sp.diff(PiIs,a),0),a)[0])
bb2 = r - d*Lam/(8*(1+s))
Gint = sp.cancel(PiIs.subs({b2:bb2, a:a_of.subs(b2,bb2)}))
Gsep = sp.cancel(sp.together(2*d*D1 + pi))          # platform + M1 under separation
dG = sp.cancel(sp.diff(Gint-Gsep, d).subs(d, 0))
nG, dGd = sp.fraction(sp.cancel(dG))
nGf, dGf = sp.factor(sp.expand(nG)), sp.factor(sp.expand(dGd))
P("     numerator   :", nGf)
P("     denominator :", dGf)
sp.pprint  # noqa
# is the denominator signed on the admissible set?
P("\n     sign test on the reference grid (step 0.02, N_2<0):")
fn = sp.lambdify((uB,uS,s,v,r), nG, 'numpy')
fd = sp.lambdify((uB,uS,s,v,r), dGd, 'numpy')
fRd = lambda sg: (8+sg*(8+sg))/(3*sg+4)      # R_Phi: the floor cell is u_B/u_S >= R_Phi (rep35)
GRID=np.arange(0.02,1.4001,0.02)
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    pts=[(x1,x2,sigma_of(x1,x2,G)) for x1 in GRID for x2 in GRID
         if Mof(x1,x2)>0 and sigma_of(x1,x2,G)>=0 and N2val(x1,x2,sigma_of(x1,x2,G))<0]
    fl=[(x1,x2,sg) for (x1,x2,sg) in pts if x1/x2>=fRd(sg)]
    A=np.array(fl)
    nv=np.asarray(fn(A[:,0],A[:,1],A[:,2],V,R)); dv=np.asarray(fd(A[:,0],A[:,1],A[:,2],V,R))
    P("       gamma=%-3g floor cell n=%4d | num>0 %5.1f%%  den>0 %5.1f%%  ratio>0 %5.1f%%"
      % (G,len(fl),100*np.mean(nv>0),100*np.mean(dv>0),100*np.mean(nv/dv>0)))
