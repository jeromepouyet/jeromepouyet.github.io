# -*- coding: utf-8 -*-
"""rep25_sign_uniformity.py -- A: are the delta-slopes uniform in sign inside
each of the three cells?

The headline of the section -- dG/ddelta changes sign on the benchmark's
taxing frontier while dW/ddelta does not -- is a proposition only if the signs
are uniform within a cell.  This script computes the slope at delta = 0 exactly
(symbolic derivative, lambdified) and reports the sign split, cell by cell,
gamma by gamma.

The separation benchmark is the asymmetric programme (rep35): as delta -> 0
its taxing branch is x_1 = delta, x_2 = 0, a = kappa delta, i.e. b_1 = r, b_2 =
r - delta, on u_B/u_S < R_Phi = Lambda/(3 sigma + 4); its floor branch is
(r - delta, r - delta, 0) beyond.  M1, the favored manufacturer, is the merger
partner, so the private gain uses pi_1.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
print("="*78, flush=True)
print("rep25 (A) -- sign uniformity of the delta-slopes inside each cell")
print("="*78, flush=True)

uB, uS, s, v, r, d, p1, p2, b, b2, a = sp.symbols(
    'u_B u_S sigma v r delta p_1 p_2 b b_2 a', positive=True)
b1 = sp.Symbol('b_1', positive=True)
M = 1-2*uB*uS; Lam = 8+s*(8+s); kap = Lam/(2*uB*(4+3*s))
def dem(P1,P2,A): return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
                          (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),
                          (uS*(2*v-P1-P2)-A)/M)
g_=(s+2*uB*uS)/M
def surp(P1,P2,D1,D2,Q):
    return (v*(D1+D2)+uB*Q*(D1+D2)-(2*(D1**2+D2**2)+g_*(D1+D2)**2)/(4*(1+g_))
            -P1*D1-P2*D2), Q**2/2
D1e,D2e,QSe = dem(p1,p2,a)
sep  = sp.solve([sp.diff((p1+b1)*D1e,p1), sp.diff((p2+b)*D2e,p2)],[p1,p2],dict=True)[0]
objI = (p1+r)*D1e + a*QSe + (r-b2)*D2e
inte = sp.solve([sp.diff(objI,p1), sp.diff((p2+b2)*D2e,p2)],[p1,p2],dict=True)[0]

def out_sep(b1v,b2v,av):
    """Separation at benefits (b_1, b_2) and fee a; M1 is the favored one."""
    P1=sp.cancel(sep[p1].subs({b1:b1v,b:b2v,a:av})); P2=sp.cancel(sep[p2].subs({b1:b1v,b:b2v,a:av}))
    D1,D2,Q=dem(P1,P2,av); VB,VS=surp(P1,P2,D1,D2,Q)
    pi1,pi2=(P1+b1v)*D1,(P2+b2v)*D2; Pi=(r-b1v)*D1+(r-b2v)*D2+av*Q
    return dict(G=Pi+pi1, W=VB+VS+pi1+pi2+Pi, pi2=pi2, VB=VB, VS=VS, a=av,
                Wonly=VB+VS+pi1+pi2+Pi)
def out_int(b2v,av):
    P1=sp.cancel(inte[p1].subs({b2:b2v,a:av})); P2=sp.cancel(inte[p2].subs({b2:b2v,a:av}))
    D1,D2,Q=dem(P1,P2,av); VB,VS=surp(P1,P2,D1,D2,Q)
    pi2=(P2+b2v)*D2; Pi=(P1+r)*D1+av*Q+(r-b2v)*D2
    return dict(G=Pi, W=VB+VS+pi2+Pi, pi2=pi2, VB=VB, VS=VS, a=av,
                Wonly=VB+VS+pi2+Pi)
PiIs=sp.cancel(sp.together(objI.subs(inte)))
a_of=sp.cancel(sp.solve(sp.Eq(sp.diff(PiIs,a),0),a)[0])
phi =sp.cancel(sp.together(sp.diff(PiIs,b2).subs(a,a_of)))
b2st=sp.cancel(sp.solve(sp.Eq(phi,0),b2)[0])
bb2 = r - d*Lam/(8*(1+s))
SEP={'tax':out_sep(r,r-d,kap*d), 'floor':out_sep(r-d,r-d,sp.Integer(0))}
INT={'part':out_int(bb2,a_of.subs(b2,bb2)), 'cap':out_int(r,a_of.subs(b2,r))}
OBJ=('G','W','pi2','VB','VS','a')

print("\n  differentiating and lambdifying ...", flush=True)
SLOPE={}                       # slope of the INCREMENT, per cell
for si in ('tax','floor'):
    for ii in ('cap','part'):
        SLOPE[(si,ii)]={X: sp.lambdify((uB,uS,s,v,r),
                          sp.diff(INT[ii][X]-SEP[si][X], d).subs(d,0), 'numpy')
                        for X in OBJ}
# the two sides separately, for the decomposition of the welfare slope
SIDE={'sep_tax'  : sp.lambdify((uB,uS,s,v,r), sp.diff(SEP['tax']['W'],  d).subs(d,0),'numpy'),
      'sep_floor': sp.lambdify((uB,uS,s,v,r), sp.diff(SEP['floor']['W'],d).subs(d,0),'numpy'),
      'int_part' : sp.lambdify((uB,uS,s,v,r), sp.diff(INT['part']['W'], d).subs(d,0),'numpy'),
      'int_cap'  : sp.lambdify((uB,uS,s,v,r), sp.diff(INT['cap']['W'],  d).subs(d,0),'numpy')}
fb2s=sp.lambdify((uB,uS,s,v,r,d), b2st,'numpy')
fRd = lambda sg: (8+sg*(8+sg))/(3*sg+4)      # R_Phi: the asymmetric benchmark's taxing frontier
print("  done", flush=True)

GRID=np.arange(0.02,1.4001,0.01)
def cells(G):
    o=[]
    for x1 in GRID:
        for x2 in GRID:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,G)
            if sg<0 or N2val(x1,x2,sg)>=0: continue
            si='tax' if x1/x2<fRd(sg) else 'floor'
            ii='cap' if fb2s(x1,x2,sg,V,R,0.0)>=R else 'part'
            o.append((x1,x2,sg,si,ii))
    return o

print("\n  share of points with slope > 0, by cell (step 0.01)")
print("  %-6s %-16s %6s | %s" % ("gamma","cell","n",
      "  ".join("%7s" % X for X in OBJ)), flush=True)
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    C=cells(G)
    for si,ii in (('tax','cap'),('tax','part'),('floor','part'),('floor','cap')):
        sub=[(x1,x2,sg) for (x1,x2,sg,A_,B_) in C if A_==si and B_==ii]
        if not sub: continue
        arr=np.array(sub)
        line="  %-6g (%-5s,%-5s) %6d |" % (G,si,ii,len(sub))
        for X in OBJ:
            val=SLOPE[(si,ii)][X](arr[:,0],arr[:,1],arr[:,2],V,R)
            line+="  %6.1f%%" % (100.*np.mean(np.asarray(val)>0))
        print(line, flush=True)

print("\n  B-preview: the welfare slope, split between the two sides (gamma=4)")
C=cells(4.0)
for si,ii in (('tax','cap'),('tax','part'),('floor','part')):
    sub=np.array([(x1,x2,sg) for (x1,x2,sg,A_,B_) in C if A_==si and B_==ii])
    if not len(sub): continue
    ws=np.asarray(SIDE['sep_'+si](sub[:,0],sub[:,1],sub[:,2],V,R))
    wi=np.asarray(SIDE['int_'+ii](sub[:,0],sub[:,1],sub[:,2],V,R))
    print("    (%-5s,%-5s) n=%5d | dW_sep/dd median %+8.3f (<0 at %5.1f%%)"
          "  dW_int/dd median %+8.3f (<0 at %5.1f%%)"
          % (si,ii,len(sub), np.median(ws), 100.*np.mean(ws<0),
             np.median(wi), 100.*np.mean(wi<0)), flush=True)
