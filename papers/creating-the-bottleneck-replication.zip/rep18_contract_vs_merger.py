# -*- coding: utf-8 -*-
"""rep18_contract_vs_merger.py -- contract or merger?  The comparison behind
the new Section 4.

Without the cap beta <= 1 the platform can earn under separation (Proposition 6).
This script asks the question the referee's point 2 actually raises: does the
platform then still WANT the merger, and what happens to everyone else where it
does not.

Objects (all closed forms, Appendix A.3 / OA B):
  Phi(a_hat)  best single-host package,  Phi(a_hat) = Phi'(0)^2 / (-2 Phi'')
  Pi^I        integration gain,          Pi^I       = Pi^I'(0)^2 / (-2 Pi^I'')
  Psi_pair    best two-host package at its interior optimum (rep9_dnr)

Symbolic layer (sympy, exact):
  A1  the two closed forms
  A2  Phi(a_hat) > Pi^I  <=>  (2+s)^2 H (Lambda u_S - (4+3s) u_B)^2
                              >  M Lambda [g(2+s)+2(4+3s)] (Theta u_S - 2(2+s)(4+3s) u_B)^2
  A3  its limit as network effects vanish is the ratio condition u_B/u_S < R_p,
      R_p = Lambda/[(2+s)(4+3s)] = R_Phi/(2+s)
  A4  R_p is also the threshold at which, at the same fee, the compensated host
      prices ABOVE the integrated firm
  A5  the chain R_p < R_J < R_Phi < R_a, gaps as polynomial identities

Numerical layer (reference grid, step 0.02 on [0.02,1.40], admissible set A):
  B1  where Phi(a_hat) > Pi^I (single host), and where Psi_pair > Pi^I (two hosts)
  B2  on the union, the ranking of the two arrangements for welfare, buyers, the
      developer and the rival, against the common benchmark
  B3  magnitudes
"""
import sys, os, numpy as np, sympy as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (N2val, sigma_of, Mof, Hval, demands, prices_sep, prices_int,
                      surpluses, V_DEF, R_DEF)
import rep3_contracts as C
V, R = V_DEF, R_DEF
ok = lambda c: "PASS" if c else "**FAIL**"

# =============================================================== symbolic
uB, uS, s, g, v, r, a = sp.symbols('u_B u_S sigma gamma v r a', positive=True)
M   = 1 - 2*uB*uS
Lam = 8 + s*(8+s)
Tht = 3*s*(s*(s+7)+16) + 32                       # the bracket of Pi^I'(0); R_a = Tht/(2(2+s)(4+3s))
H   = ((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
       - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS - 2*(s*(s*(7*s+40)+64)+32)*uS**2)
Phi_p0 = 2*(v+r)*(s+2)*(Lam*uS - (4+3*s)*uB)/(M*(s+4)*Lam)
Phi_pp = -2*(g*(s+2) + 2*(3*s+4))/Lam
PiI_p0 = 2*(v+r)*(Tht*uS - 2*(s+2)*(3*s+4)*uB)/((s+4)**2*(3*s+4)*M)
PiI_pp = -2*H/((s+4)**2*(3*s+4)**2*M)
PhiHat = sp.simplify(Phi_p0**2/(-2*Phi_pp))
PiIHat = sp.simplify(PiI_p0**2/(-2*PiI_pp))

print("="*78)
print("A.  Symbolic layer")
print("="*78)
print("\nA1. Closed forms.")
tP = (v+r)**2*(s+2)**2*(Lam*uS-(4+3*s)*uB)**2/(M**2*(s+4)**2*Lam*(g*(s+2)+2*(3*s+4)))
tI = (v+r)**2*(Tht*uS-2*(s+2)*(3*s+4)*uB)**2/(M*(s+4)**2*H)
print("    Phi(a_hat) = (v+r)^2 (2+s)^2 (Lambda u_S-(4+3s)u_B)^2 / [M^2 (4+s)^2 Lambda (g(2+s)+2(4+3s))] :",
      ok(sp.simplify(PhiHat - tP) == 0))
print("    Pi^I       = (v+r)^2 (Theta u_S-2(2+s)(4+3s)u_B)^2 / [M (4+s)^2 H] :",
      ok(sp.simplify(PiIHat - tI) == 0))

print("\nA2. The inequality.")
LHS = (s+2)**2*H*(Lam*uS-(4+3*s)*uB)**2
RHS = M*Lam*(g*(s+2)+2*(3*s+4))*(Tht*uS-2*(s+2)*(3*s+4)*uB)**2
common = M**2*(s+4)**2*Lam*(g*(s+2)+2*(3*s+4))*H/(v+r)**2
print("    (Phi(a_hat) - Pi^I) * [M^2 (4+s)^2 Lambda (g(2+s)+2(4+3s)) H / (v+r)^2]  =  LHS - RHS :",
      ok(sp.simplify(sp.expand((PhiHat-PiIHat)*common) - sp.expand(LHS-RHS)) == 0))
print("    The multiplier is positive on A (M>0, H>0), so")
print("      Phi(a_hat) > Pi^I  <=>  (2+s)^2 H (Lambda u_S-(4+3s)u_B)^2")
print("                              > M Lambda [g(2+s)+2(4+3s)] (Theta u_S-2(2+s)(4+3s)u_B)^2")

print("\nA3. The limit as network effects vanish at a fixed ratio (sigma -> gamma, M -> 1,")
print("    H -> (4+s)^2 (4+3s)^2).")
print("    identity  s(2+s) + 2(4+3s) = Lambda :", ok(sp.simplify(s*(2+s)+2*(4+3*s) - Lam) == 0))
print("    identity  Theta - 2 Lambda = (1+s)(4+3s)(4+s) :",
      ok(sp.simplify(Tht - 2*Lam - (1+s)*(4+3*s)*(4+s)) == 0))
rho = sp.symbols('rho', positive=True)
lim = sp.simplify(((s+2)**2*(s+4)**2*(3*s+4)**2*(Lam-(4+3*s)*rho)**2
                   - Lam*Lam*(Tht-2*(s+2)*(3*s+4)*rho)**2))
roots = sp.solve(sp.factor(lim), rho)
Rp = Lam/((2+s)*(4+3*s))
print("    roots of the limiting condition in rho :", [sp.factor(x) for x in roots])
print("    the root inside (0, R_Phi) is R_p = Lambda/[(2+s)(4+3s)] :",
      ok(any(sp.simplify(x - Rp) == 0 for x in roots)))
print("    and the condition holds for rho < R_p (check at rho = 0):",
      ok(sp.simplify(lim.subs(rho, 0)).subs(s, 1) > 0))
print("    R_p = R_Phi/(2+s) :", ok(sp.simplify(Rp - C_RPhi) == 0) if False else
      ok(sp.simplify(Rp - Lam/(4+3*s)/(2+s)) == 0))

print("\nA4. R_p is the price threshold.  At the SAME fee a, host compensated at")
print("    beta_bar(a), against the integrated firm with M_2 on its outside option:")
bb  = 1 + a*2*uB*(3*s+4)/(r*Lam)                 # beta_bar(a), Appendix A.3
den = (4+s)*(4+3*s)
p1B = (-2*uB*a*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*r + 2*(2+s)*bb*r))/den
cI  = (2*v - r - a*(2*uB+uS) + 3*r)/(4+s)
p1C = -r + cI + (r - r - a*uS)/(4+3*s)
dp  = sp.factor(sp.simplify(p1B - p1C))
tgt = 4*a*(2+s)*(Lam*uS - (2+s)*(4+3*s)*uB)/((4+s)*(4+3*s)*Lam)
print("    p_1^contract - p_1^integrated = 4a(2+s)[Lambda u_S - (2+s)(4+3s) u_B] / [(4+s)(4+3s)Lambda] :",
      ok(sp.simplify(dp - tgt) == 0))
print("    so p_1^contract > p_1^integrated  <=>  u_B/u_S < R_p.   Same threshold.")
K   = Lam*uS - (2+s)*(4+3*s)*uB
p2B = (-2*uB*a*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*bb*r + 2*(2+s)*r))/den
p2C = -r + cI + (r + a*uS - r)/(4+3*s)
qB  = (uS*(2*v - p1B - p2B) - a)/M; qC = (uS*(2*v - p1C - p2C) - a)/M
print("    The rival's price and the application stock carry the SAME factor K:")
print("      p_2^B - p_2^C = 2 a sigma K / [(4+s)(4+3s)Lambda] :",
      ok(sp.simplify(p2B - p2C - 2*a*s*K/((4+s)*(4+3*s)*Lam)) == 0))
print("      q_S^B - q_S^C = -2 a u_S K / [(4+s) M Lambda] :",
      ok(sp.simplify(qB - qC + 2*a*uS*K/((4+s)*M*Lam)) == 0))
print("    So at every common fee the two arrangements produce the SAME market")
print("    outcome iff K = 0, i.e. on the locus u_B/u_S = R_p.  There the calibrated")
print("    contract is an exact copy of integration, fee by fee:")
PhiA = (1-bb)*r*(2*v-(2+s)*p1B+s*p2B-2*uB*a)/(2*M) + a*qB
D1C  = (2*v-(2+s)*p1C+s*p2C-2*uB*a)/(2*M); D2C = (2*v-(2+s)*p2C+s*p1C-2*uB*a)/(2*M)
PiIa = (p1C+r)*D1C + a*qC                        # M_2 at r: no licensing margin
PiI0 = PiIa.subs(a, 0)
onloc = {uB: Lam*uS/((2+s)*(4+3*s))}
print("      Phi(a) = Pi^I(a) - Pi^I(0) identically in a on the locus :",
      ok(sp.simplify((PhiA - (PiIa - PiI0)).subs(onloc)) == 0))
print("    Hence a_hat = a**, Phi(a_hat) = Pi^I and all surpluses coincide on the locus;")
print("    the platform's preference and the welfare ranking both change sign across it.")

print("\nA5. The chain R_p < R_J < R_Phi < R_a.")
RJ = (4+s)/4; RPhi = Lam/(4+3*s); Ra = Tht/(2*(s+2)*(3*s+4))
print("    R_J - R_p   =", sp.factor(sp.simplify(RJ-Rp)),   " >= 0, = 0 at s=0")
print("    R_Phi - R_J =", sp.factor(sp.simplify(RPhi-RJ)), " > 0")
print("    R_a - R_Phi =", sp.factor(sp.simplify(Ra-RPhi)), " >= 0, = 0 at s=0")
print("    at s = 0 :  R_p = R_J = %s,  R_Phi = R_a = %s" % (Rp.subs(s,0), RPhi.subs(s,0)))
print("\n    %-7s %-9s %-9s %-9s %-9s" % ("sigma","R_p","R_J","R_Phi","R_a"))
for x in (0,1,2,4,8,16):
    print("    %-7g %-9.4f %-9.4f %-9.4f %-9.4f" %
          (x, float(Rp.subs(s,x)), float(RJ.subs(s,x)), float(RPhi.subs(s,x)), float(Ra.subs(s,x))))

# =============================================================== two-host closed forms
import rep9_dnr as D9
_Pi = D9._derive()
_crit = sp.solve([sp.numer(sp.together(sp.diff(_Pi, x))) for x in (D9.a, D9.b1, D9.b2)],
                 [D9.a, D9.b1, D9.b2], dict=True)[0]
f_ad = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_crit[D9.a]), 'numpy')
f_bd = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_crit[D9.b1]), 'numpy')
f_Ps = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_Pi.subs(_crit)), 'numpy')

# =============================================================== numerical
def adm(x, y, gg):
    """The admissible set A of Sections 3-4: M>0, sigma>=0, H>0, D_2(a**)>0."""
    if Mof(x, y) <= 0: return None
    sg = sigma_of(x, y, gg)
    if sg < 0 or Hval(x, y, sg) <= 0: return None
    if N2val(x, y, sg) >= 0: return None
    aa = C.a_star(x, y, sg)
    q1, q2 = prices_int(x, y, sg, R, aa)
    if demands(x, y, sg, q1, q2, aa)[1] <= 0: return None
    return sg

def cfg_sep(x, y, sg, c1, c2, fee):
    p1, p2 = prices_sep(x, y, sg, c1, c2, fee); D1, D2, q = demands(x, y, sg, p1, p2, fee)
    return dict(p1=p1, p2=p2, D1=D1, D2=D2, q=q, pi1=(p1+c1)*D1, pi2=(p2+c2)*D2)

def outcome_sep(x, y, gg, c1, c2, fee, plat):
    """Welfare objects on a separation configuration; plat = platform profit."""
    sg = sigma_of(x, y, gg); c = cfg_sep(x, y, sg, c1, c2, fee)
    VB, VS = surpluses(x, y, gg, c['p1'], c['p2'], c['D1'], c['D2'], c['q'], V)
    W = VB + VS + plat + c['pi1'] + c['pi2']
    return dict(W=W, VB=VB, VS=VS, pi1=c['pi1'], pi2=c['pi2'], q=c['q'], ok=min(c['D1'],c['D2'],c['q'])>0)

def outcome_int(x, y, gg, fee):
    sg = sigma_of(x, y, gg)
    p1, p2 = prices_int(x, y, sg, R, fee, R, V); D1, D2, q = demands(x, y, sg, p1, p2, fee)
    VB, VS = surpluses(x, y, gg, p1, p2, D1, D2, q, V)
    firm = (p1+R)*D1 + fee*q; pi2 = (p2+R)*D2
    return dict(W=VB+VS+firm+pi2, VB=VB, VS=VS, pi2=pi2, q=q, ok=min(D1,D2,q)>0)

def best_contract(x, y, gg, sg):
    """Value and description of the best unrestricted contract."""
    ph = C.Phi(x, y, sg, gg, C.a_hat(x, y, sg, gg)) if C.Phi_prime0(x, y, sg) > 0 else 0.0
    best, kind = ph, 'single'
    # two hosts: interior optimum, feasibility as in rep9_dnr
    ad = float(f_ad(x, y, V, R, gg)); bd = float(f_bd(x, y, V, R, gg)); Ps = float(f_Ps(x, y, V, R, gg))
    if ad > 0 and bd > 1 and Ps > best:
        piRR = cfg_sep(x, y, sg, R, R, 0.0)['pi1']
        host = cfg_sep(x, y, sg, bd*R, R, ad); both = cfg_sep(x, y, sg, bd*R, bd*R, ad)
        if host['pi1'] > piRR and both['pi1'] >= host['pi2'] and min(both['D1'],both['D2'],both['q']) > 0:
            best, kind = Ps, 'pair'
    return best, kind, ph, (ad, bd, Ps)

print("\n" + "="*78)
print("B.  Numerical layer (reference grid, step 0.02, admissible set A)")
print("="*78)
grid = np.arange(0.02, 1.4001, 0.02)
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)

def evaluate(x, y, gg):
    """Everything about one admissible point, or None."""
    sg = adm(x, y, gg)
    if sg is None: return None
    pii = C.PiI_gain(x, y, sg) if C.PiI_prime0(x, y, sg) > 0 else 0.0
    best, kind, ph, (ad, bd, Ps) = best_contract(x, y, gg, sg)
    b0 = outcome_sep(x, y, gg, R, R, 0.0, 0.0)
    aC = C.a_star(x, y, sg); oC = outcome_int(x, y, gg, aC)
    q1C, _ = prices_int(x, y, sg, R, aC, R, V)
    if kind == 'single':
        aB = C.a_hat(x, y, sg, gg); bB = C.bbar(x, y, sg, aB); c = cfg_sep(x, y, sg, bB*R, R, aB)
        oB = outcome_sep(x, y, gg, bB*R, R, aB, (1-bB)*R*c['D1'] + aB*c['q'])
    else:
        c = cfg_sep(x, y, sg, bd*R, bd*R, ad)
        oB = outcome_sep(x, y, gg, bd*R, bd*R, ad, (1-bd)*R*(c['D1']+c['D2']) + ad*c['q'])
    return dict(sg=sg, pii=pii, best=best, kind=kind, prefers=(best > pii + 1e-12),
                ok=(b0['ok'] and oB['ok'] and oC['ok']), b0=b0, oB=oB, oC=oC,
                p1B=c['p1'], p1C=q1C, rho=x/y, Rp=C.R_Phi(sg)/(2+sg), onband=(x/y >= C.R_Phi(sg)))

PTS = {gg: [] for gg in GAMMAS}
NADM = {}
for gg in GAMMAS:
    n = 0
    for x in grid:
        for y in grid:
            e = evaluate(x, y, gg)
            if e is None: continue
            n += 1
            if e['prefers'] and e['ok']: PTS[gg].append((x, y, e))
    NADM[gg] = n

print("\nB1. Where does the platform prefer the contract to the merger?\n")
print("%-6s %-8s %-15s %-15s %-15s %-8s" % ("gamma","admiss.","single host","two hosts","union","on band"))
for gg in GAMMAS:
    P = PTS[gg]; n = NADM[gg]
    s1 = sum(1 for p in P if p[2]['kind']=='single'); s2 = len(P) - s1
    print("%-6.3g %-8d %-15s %-15s %-15s %-8d" %
          (gg, n, "%d (%.1f%%)"%(s1,100*s1/n), "%d (%.1f%%)"%(s2,100*s2/n),
           "%d (%.1f%%)"%(len(P),100*len(P)/n), sum(1 for p in P if p[2]['onband'])))
print("\n    Never on the band, where the contract earns nothing.  The merger is")
print("    preferred everywhere else: on 85 to 95% of the admissible set.")

print("\n    Shape, gamma = 4 and 16: for each u_S the u_B range of each part.")
for gg in (4.0, 16.0):
    print("    gamma = %g" % gg)
    print("      %-6s %-24s %-24s" % ("u_S","single host: u_B in","two hosts: u_B in"))
    for y in (0.1,0.2,0.3,0.4,0.5,0.6,0.8,1.0,1.2,1.4):
        S1 = [p[0] for p in PTS[gg] if abs(p[1]-y) < 1e-9 and p[2]['kind']=='single']
        S2 = [p[0] for p in PTS[gg] if abs(p[1]-y) < 1e-9 and p[2]['kind']=='pair']
        f = lambda S: "[%.2f, %.2f] (%d)"%(min(S),max(S),len(S)) if S else "-"
        print("      %-6.2f %-24s %-24s" % (y, f(S1), f(S2)))

print("\nB2. Single-host part: the ranking of the two arrangements for welfare,")
print("    buyers and the developer is the ranking of the host's price, and that")
print("    is u_B/u_S < R_p.  Exact agreement, point by point.\n")
print("%-6s %-7s %-12s %-12s %-12s %-12s | %-12s %-12s %-12s" %
      ("gamma","points","W: B<C","buyers B<C","dev B<C","rival B<C","rho<R_p","W<=>rho<R_p","W<=>p1B>p1C"))
for gg in GAMMAS:
    P = [p for p in PTS[gg] if p[2]['kind']=='single']
    if not P: print("%-6.3g  none" % gg); continue
    n = len(P); f = lambda c_: "%d (%.0f%%)"%(c_,100.0*c_/n)
    W  = sum(e['oB']['W']  < e['oC']['W']  for _,_,e in P)
    VB = sum(e['oB']['VB'] < e['oC']['VB'] for _,_,e in P)
    VS = sum(e['oB']['VS'] < e['oC']['VS'] for _,_,e in P)
    RV = sum(e['oB']['pi2'] < e['oC']['pi2'] for _,_,e in P)
    rp = sum(e['rho'] < e['Rp'] for _,_,e in P)
    ag = sum((e['oB']['W'] < e['oC']['W']) == (e['rho'] < e['Rp']) for _,_,e in P)
    ag2= sum((e['oB']['W'] < e['oC']['W']) == (e['p1B'] > e['p1C']) for _,_,e in P)
    print("%-6.3g %-7d %-12s %-12s %-12s %-12s | %-12s %-12s %-12s" % (gg,n,f(W),f(VB),f(VS),f(RV),f(rp),f(ag),f(ag2)))
print("\n    Below R_p the compensated host prices above the integrated level, the")
print("    rival follows, the application stock shrinks: the contract is worse than")
print("    the merger for everyone but the rival.  The part of the region above R_p")
print("    sits at STRONG network effects (u_B u_S close to 1/2, sigma near 0), the")
print("    mirror image of the cone across the locus, and there the reverse holds.")

print("\n    The identity W_B < W_C  <=>  rho < R_p holds on ALL interior points where")
print("    both instruments are active (a_hat > 0 and a** > 0), not only where the")
print("    platform prefers the contract; and the stakes are small:")
print("    %-6s %-8s %-12s %-12s %-12s %-14s %-26s %-26s" % ("gamma","points","W<=>rho<R_p","VB<=>rho<R_p","VS<=>rho<R_p","rival<=>rho>R_p","Phi(a_hat)/Pi^I - 1: med/max","|W_B-W_C|/W_0: med/max"))
for gg in GAMMAS:
    n = ag = agB = agS = agR = 0; rat = []; wg = []
    for x in grid:
        for y in grid:
            e = evaluate(x, y, gg)
            if e is None or not e['ok'] or e['kind'] != 'single': continue
            if C.Phi_prime0(x, y, e['sg']) <= 0 or C.PiI_prime0(x, y, e['sg']) <= 0: continue
            n += 1; below = (e['rho'] < e['Rp'])
            ag  += ((e['oB']['W']  < e['oC']['W'])  == below)
            agB += ((e['oB']['VB'] < e['oC']['VB']) == below)
            agS += ((e['oB']['VS'] < e['oC']['VS']) == below)
            agR += ((e['oB']['pi2'] > e['oC']['pi2']) == below)
            wg.append(abs(e['oB']['W'] - e['oC']['W'])/e['b0']['W'])
            if e['prefers']: rat.append(e['best']/e['pii'] - 1)
    f = lambda c_: "%d (%.0f%%)"%(c_,100.0*c_/max(n,1))
    print("    %-6.3g %-8d %-12s %-12s %-12s %-14s %-26s %-26s" %
          (gg, n, f(ag), f(agB), f(agS), f(agR),
           "%.2f%% / %.2f%%"%(100*np.median(rat),100*max(rat)) if rat else "-",
           "%.3f%% / %.3f%%"%(100*np.median(wg),100*max(wg))))
print("    (the rival's ranking is exact on the preferred region, block B2, and not on the whole domain)")

print("\nB3. Two-host part.  The interior pair optimum beats Pi^I only at contract")
print("    values outside the model's economic range: enormous shares and fees and")
print("    NEGATIVE device prices (v = 2).  Reported for the record, not used.\n")
print("%-6s %-7s %-12s %-12s %-12s %-14s %-14s" %
      ("gamma","points","p_1 < 0","p_2 < 0","beta_dag med","a_dag med","M1 above bench"))
for gg in GAMMAS:
    P = [p for p in PTS[gg] if p[2]['kind']=='pair']
    if not P: print("%-6.3g  none" % gg); continue
    n = len(P); f = lambda c_: "%d (%.0f%%)"%(c_,100.0*c_/n)
    bds = []; ads = []; p1n = p2n = m1 = 0
    for x, y, e in P:
        ad, bd, Ps = best_contract(x, y, gg, e['sg'])[3]
        c = cfg_sep(x, y, e['sg'], bd*R, bd*R, ad)
        bds.append(bd); ads.append(ad); p1n += c['p1'] < 0; p2n += c['p2'] < 0
        m1 += e['oB']['pi1'] > e['b0']['pi1']
    print("%-6.3g %-7d %-12s %-12s %-12.1f %-14.1f %-14s" % (gg,n,f(p1n),f(p2n),np.median(bds),np.median(ads),f(m1)))
print("\n    Every such point has negative device prices.  The comparison of the")
print("    two arrangements is therefore the single-host one.")

print("\nB4. Magnitudes by part (medians, % of the benchmark; B = contract, C = merger).\n")
print("%-6s %-7s %-7s %-19s %-19s %-19s %-19s" % ("gamma","part","points","W: B / C","buyers: B / C","developer: B / C","rival: B / C"))
for gg in GAMMAS:
    for kind in ('single',):
        P = [p for p in PTS[gg] if p[2]['kind']==kind]
        if not P: continue
        m = lambda key, arr: np.median([100*(e[arr][key]/e['b0'][key]-1) for _,_,e in P])
        print("%-6.3g %-7s %-7d %-19s %-19s %-19s %-19s" %
              (gg, kind, len(P), "%+.2f / %+.2f"%(m('W','oB'),m('W','oC')), "%+.2f / %+.2f"%(m('VB','oB'),m('VB','oC')),
               "%+.2f / %+.2f"%(m('VS','oB'),m('VS','oC')), "%+.2f / %+.2f"%(m('pi2','oB'),m('pi2','oC'))))

print("\nB5. Coalition check: at the single-host optimum the outsider's profit is")
print("    below its benchmark everywhere, so a platform merging with M_1 compares")
print("    Pi^I with Phi(a_hat) (M_1 as host, held at its benchmark), not with more.")
for gg in (1.0, 4.0, 16.0):
    n = bad = 0
    for x in grid:
        for y in grid:
            sg = adm(x, y, gg)
            if sg is None or C.Phi_prime0(x, y, sg) <= 0: continue
            aB = C.a_hat(x, y, sg, gg); bB = C.bbar(x, y, sg, aB)
            c = cfg_sep(x, y, sg, bB*R, R, aB); b0 = cfg_sep(x, y, sg, R, R, 0.0)
            if min(c['D1'],c['D2'],c['q']) <= 0: continue
            n += 1; bad += (c['pi2'] >= b0['pi2'] - 1e-12)
    print("    gamma = %-4g  unraveling points %-5d  rival at or above benchmark: %d" % (gg, n, bad))
print("\n" + "="*78)
