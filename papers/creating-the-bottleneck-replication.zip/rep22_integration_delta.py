# -*- coding: utf-8 -*-
"""rep22_integration_delta.py -- the INTEGRATED firm's problem under dominance,
solved in closed form for an ARBITRARY premium delta.

Appendix B.3 of the paper characterizes the integrated two-instrument policy by
a continuity argument valid for small gains ("the geometry below is established
on that range").  That argument is not needed.  The objective is a strictly
concave quadratic in (b2, a) on the admissible set {N_2 < 0}; the fee-only
maximizer a(b2) is affine in b2; the reduced derivative phi(b2) is therefore
affine and has a unique root b2*, and the solution is the clamp

        b2** = median{ bbar2(delta), b2*, r },     a** = a(b2**).

Everything is closed form, for every delta at which bbar2 >= 0.

Run: python3 rep22_integration_delta.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import (sigma_of, Mof, N2val, demands, prices_int, V_DEF, R_DEF)

V, R = V_DEF, R_DEF
ok = lambda c: "PASS" if c else "**FAIL**"
print("="*72); print("rep22 -- integration under dominance, arbitrary delta"); print("="*72)

uB, uS, s, v, r, d, a, b2 = sp.symbols('u_B u_S sigma v r delta a b_2', positive=True)
M = 1 - 2*uB*uS
p1, p2 = sp.symbols('p1 p2')
D1 = (2*v-(2+s)*p1+s*p2-2*uB*a)/(2*M)
D2 = (2*v-(2+s)*p2+s*p1-2*uB*a)/(2*M)
DS = (uS*(2*v-p1-p2)-a)/M
obj = (p1+r)*D1 + a*DS + (r-b2)*D2
sol = sp.solve([sp.diff(obj,p1), sp.diff((p2+b2)*D2,p2)], [p1,p2], dict=True)[0]
PiI = sp.simplify(obj.subs(sol))

print("\n 1. Pi^I is a quadratic in (b2, a)          :",
      ok(sp.simplify(sp.diff(PiI, b2, 3)) == 0 and sp.simplify(sp.diff(PiI, a, 3)) == 0
         and sp.simplify(sp.diff(PiI, b2, 2, a, 1)) == 0))

Haa = sp.simplify(sp.diff(PiI, a, 2))
Hbb = sp.simplify(sp.diff(PiI, b2, 2))
Hab = sp.simplify(sp.diff(PiI, a, 1, b2, 1))
detH = sp.simplify(Haa*Hbb - Hab**2)
N2 = (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
      + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))
print(" 2. det Hessian = -4(s+1)N_2/[(s+4)^2(3s+4)^2 M^2] :",
      ok(sp.simplify(detH + 4*(s+1)*N2/((s+4)**2*(3*s+4)**2*M**2)) == 0))
print("    => N_2 < 0 is exactly strict concavity in (b2,a); no smallness needed.")

# ---- the fee-only maximizer, affine in b2 ---------------------------
a_of_b = sp.simplify(sp.solve(sp.Eq(sp.diff(PiI, a), 0), a)[0])
print("\n 3. a(b2) is affine in b2                   :",
      ok(sp.simplify(sp.diff(a_of_b, b2, 2)) == 0))
print("    a(b2) = %s" % sp.simplify(sp.collect(sp.expand(a_of_b), b2)))

phi = sp.simplify(sp.diff(PiI, b2).subs(a, a_of_b))
print(" 4. phi(b2) = dPi/db2 | a=a(b2) is affine    :",
      ok(sp.simplify(sp.diff(phi, b2, 2)) == 0))
print("    phi' = det H / Pi_aa < 0  (phi strictly decreasing) :",
      ok(sp.simplify(sp.diff(phi, b2) - detH/Haa) == 0))

bstar = sp.simplify(sp.solve(sp.Eq(phi, 0), b2)[0])
print(" 5. unique root b2* in closed form           : PASS")
bbar = r*(1 - (d/r)*(8+s*(8+s))/(8*(1+s)))

fa   = sp.lambdify((uB,uS,s,v,r,d,b2), a_of_b, 'numpy')
fb   = sp.lambdify((uB,uS,s,v,r,d), bstar, 'numpy')
fbb  = sp.lambdify((uB,uS,s,v,r,d), bbar, 'numpy')
fPi  = sp.lambdify((uB,uS,s,v,r,d,b2,a), PiI, 'numpy')
fN2  = sp.lambdify((uB,uS,s), N2, 'numpy')

def solve_int(UB, US, SG, D):
    bb  = fbb(UB,US,SG,V,R,D)
    lo  = max(bb, 0.0)
    bs  = fb(UB,US,SG,V,R,D)
    B   = min(max(bs, lo), R)
    lab = 'cap' if B >= R-1e-12 else ('participation' if B <= lo+1e-12 else 'interior')
    return lab, B, fa(UB,US,SG,V,R,D,B), bb

def brute_int(UB, US, SG, D, n=3000):
    bb = max(fbb(UB,US,SG,V,R,D), 0.0)
    B  = np.linspace(bb, R, n)
    A  = fa(UB,US,SG,V,R,D,B)
    P  = fPi(UB,US,SG,V,R,D,B,A)
    k  = int(np.argmax(P))
    return P[k], B[k]

print("\n" + "="*72)
print(" 6. closed form against brute force, and regime shares")
print("="*72)
GRID = np.arange(0.02, 1.4001, 0.02)
worst = 0.0
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.05, 0.10, 0.20, 0.30, 0.40):
        c = {}; tot = 0; neg = 0
        for UB in GRID:
            for US in GRID:
                if Mof(UB,US) <= 0: continue
                SG = sigma_of(UB,US,G)
                if SG < 0 or fN2(UB,US,SG) >= 0: continue
                tot += 1
                lab, B, A, bb = solve_int(UB,US,SG,D)
                if bb < 0: neg += 1
                c[lab] = c.get(lab,0)+1
                if (UB*100) % 20 < 1e-9 and (US*100) % 20 < 1e-9:
                    vb, _ = brute_int(UB,US,SG,D)
                    vk = fPi(UB,US,SG,V,R,D,B,A)
                    worst = max(worst, (vb-vk)/max(1e-12, abs(vk)))
        print("  gamma=%-4g delta=%.2f n=%5d | " % (G,D,tot) +
              " ".join("%-13s %5.1f%%" % (k, 100.*c.get(k,0)/tot)
                       for k in ('cap','interior','participation')) +
              " | bbar<0 at %5.1f%%" % (100.*neg/tot))
print("\n    largest relative shortfall vs brute force: %.2e" % worst,
      "  ", ok(worst < 1e-8))

# =====================================================================
# PART 3 -- two caveats of Appendix B.3 that the closed form removes
# =====================================================================
print("\n" + "="*72)
print(" 7. the regime b2* does not depend on delta; only bbar does")
print("="*72)
print("    b2* free of delta                        :",
      ok(d not in sp.simplify(bstar).free_symbols))
print("    => the frontier {b2* = r} (cap) is a FIXED curve in (uB,uS);")
print("       delta moves only the participation frontier {b2* = bbar(delta)}.")
print("       This is why the 'cap' column above is constant in delta.")

print("\n 8. the case bbar(delta) < 0 (excluded in the paper) is covered too")
fD2 = sp.lambdify((uB,uS,s,v,r,d,b2,a), sp.simplify(D2.subs(sol)), 'numpy')
fDS = sp.lambdify((uB,uS,s,v,r,d,b2,a), sp.simplify(DS.subs(sol)), 'numpy')
fD1 = sp.lambdify((uB,uS,s,v,r,d,b2,a), sp.simplify(D1.subs(sol)), 'numpy')
#    Interiority and publication at the integrated optimum, at every delta of
#    the list (Refine 2, point 9): positive demands and application stock, and
#    u_S n_B^I >= a** where n_B^I = D_1 is the integrated device's demand.
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.05, 0.10, 0.20, 0.30, 0.40, 0.45):
        tot = negb = zero = badD = badP = 0; minP = np.inf
        for UB in GRID:
            for US in GRID:
                if Mof(UB,US) <= 0: continue
                SG = sigma_of(UB,US,G)
                if SG < 0 or fN2(UB,US,SG) >= 0: continue
                tot += 1
                lab, B, A, bb = solve_int(UB,US,SG,D)
                if bb < 0:
                    negb += 1
                    if B <= 1e-12: zero += 1
                d1 = fD1(UB,US,SG,V,R,D,B,A)
                if min(d1, fD2(UB,US,SG,V,R,D,B,A),
                       fDS(UB,US,SG,V,R,D,B,A)) <= 0: badD += 1
                slack = US*d1 - A
                minP = min(minP, slack)
                if slack < 0: badP += 1
        print("    gamma=%-3g delta=%.2f : bbar<0 at %5.1f%%, of which the"
              " zero-share corner binds at %d; demands non-positive at %d;"
              " publication fails at %d (min slack %+.3f)"
              % (G, D, 100.*negb/tot, zero, badD, badP, minP))
print("    => where bbar < 0 the constraint is simply absent and the clamp")
print("       returns min{b2*, r}: no separate 'fourth regime' is needed.")
