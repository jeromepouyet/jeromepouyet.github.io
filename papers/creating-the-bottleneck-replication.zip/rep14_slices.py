# -*- coding: utf-8 -*-
"""rep14_slices.py -- the slice statistics of Online Appendix B.2, at the
resolution b5j.py actually uses (120 slices per gamma), plus the sign
cross-check against a direct evaluation of Delta W(a**) on the reference grid.
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from b5j import pieces
from rep_core import (sigma_of, Mof, Hval, demands, prices_int, surpluses,
                      V_DEF, R_DEF)
from rep1_frontiers import a_star
V, R = V_DEF, R_DEF
NS = 120                                    # b5j.py:152

def slice_count(g, ns=NS):
    """slices carrying a sign change of Delta W(a**) on the taxing range."""
    n = pos = 0
    for s in np.linspace(0.05, g*0.98, ns):
        A4 = 4*(1+g)**2*(4+3*s)*(12+s*(11+3*s))
        B4 = -4*(1+g)*(128+g*(4+3*s)*(12+s*(11+3*s)) + s*(272+s*(212+s*(73+9*s))))
        C4 = (g-s)**2*(4+3*s)*(12+s*(11+3*s))
        disc = B4*B4 - 4*A4*C4
        if disc <= 0: continue
        xhi = (-B4+np.sqrt(disc))/(2*A4)
        xa = (s+2)*(3*s+4)*(g-s)/((g+1)*(3*s*(s*(s+7)+16)+32))
        lo = max((-B4-np.sqrt(disc))/(2*A4), xa)
        if lo >= xhi: continue
        n += 1
        xs = np.linspace(lo*1.001, xhi*0.999, 400)
        vals = []
        for x in xs:
            uS_ = np.sqrt(x); uB_ = (g-s)/(2*(1+g)*uS_)
            c1, c2, ast, _ = pieces(uB_, uS_, g)
            vals.append(ast*(c1+c2*ast))
        if np.any(np.array(vals) > 0): pos += 1
    return n, pos

print("Welfare-positive part of the taxing region, by gamma")
print("(slices carrying a positive value, at b5j.py's own 120 slices per gamma)\n")
print("%-8s %-12s %-14s %-12s" % ("gamma", "slices", "with dW > 0", "at 80 slices"))
for g in (0.5, 1.0, 2.0, 4.0, 5.0, 6.0, 8.0, 10.0, 16.0):
    n, p = slice_count(g)
    n80, p80 = slice_count(g, 80)
    print("%-8g %-12d %-14d %-12d" % (g, n, p, p80))

# ------------------------------------------------------ the sign cross-check
print("\n" + "="*62)
print("Sign agreement: the quartet-based sign against direct evaluation")
print("="*62)
def dW_direct(uB, uS, g, a):
    sig = sigma_of(uB, uS, g)
    def W(av):
        p1, p2 = prices_int(uB, uS, sig, R, av)
        D1, D2, q = demands(uB, uS, sig, p1, p2, av)
        VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
        return VB + VS + (p1+R)*D1 + av*q + (p2+R)*D2
    return W(a) - W(0.0)

agree = tot = 0
for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    gr = np.arange(0.02, 1.402, 0.02)
    for u1 in gr:
        for u2 in gr:
            if Mof(u1, u2) <= 0: continue
            sig = sigma_of(u1, u2, g)
            if sig < 0 or Hval(u1, u2, sig) <= 0: continue
            a = a_star(u1, u2, sig)
            p1, p2 = prices_int(u1, u2, sig, R, a)
            if demands(u1, u2, sig, p1, p2, a)[1] <= 0: continue
            if a <= 0: continue                          # taxing points only
            c1, c2, ast, _ = pieces(u1, u2, g)
            tot += 1
            if np.sign(ast*(c1+c2*ast)) == np.sign(dW_direct(u1, u2, g, a)):
                agree += 1
print("  taxing points of A at the six gamma  : %d" % tot)
print("  signs agree                           : %d" % agree)

