# -*- coding: utf-8 -*-
"""rep21_dominance_analytic.py -- the SYMMETRIC RESTRICTION of the dominance
benchmark (one premium x for both manufacturers, one fee a), stated and
proved as an exact KKT characterization.

The benchmark of the paper (Proposition B.2, Online Appendix B.5) optimizes over
asymmetric packages (beta^1, beta^2, a); it is computed by
rep5_dominance.benchmark_asym and verified in rep35_dominance_asym.py.  The
symmetric programme studied here is its restriction to x_1 = x_2; it is what
the taxing edge of the asymmetric benchmark reduces to when x_2 = x_1 is
imposed, and its closed forms are the ones referred to in the text as the
"symmetric restriction".

Three things are established here about that restriction:

  (1) an identity showing that the concavity determinant Delta_delta of the
      two-instrument dominance programme is STRICTLY POSITIVE on the whole
      admissible set {N_2 < 0}, so the programme is strictly concave and the
      "where Delta_delta <= 0 the point is a saddle" caveat can go;

  (2) because of (1), KKT conditions are necessary AND sufficient, so the
      regimes are characterized by explicit inequalities rather than by an
      enumeration of candidates followed by a comparison of values;

  (3) the face x = 0 carries TWO regimes, not one: the platform posts
      a = min{a_sub, 0}; the branch a = 0 is the modal outcome.  (The floor
      face is common to the symmetric restriction and to the asymmetric
      benchmark: with x_1 = x_2 = 0 there is nothing to split.)

Run: python3 rep21_dominance_analytic.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import (sigma_of, Mof, N2val, demands, prices_sep, V_DEF, R_DEF)

V, R = V_DEF, R_DEF
ok = lambda c: "PASS" if c else "**FAIL**"

print("="*72)
print("rep21 -- dominance benchmark: exact characterization")
print("="*72)

# =====================================================================
# PART 1 -- SYMBOLIC
# =====================================================================
uB, uS, s, v, r, d, x, a = sp.symbols('u_B u_S sigma v r delta x a', positive=True)
S  = 2 + s
T  = s + 4 - 4*uB*uS
w  = v + r - d
M  = 1 - 2*uB*uS
kap = (8 + s*(8+s))/(2*uB*(4+3*s))            # kappa: a_kill / x

# --- the objective, built from the primitives (not assumed) ----------
b   = r - d + x                                # perceived benefit at share beta
p1s = (-2*uB*a*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*b + 2*(2+s)*b))/((4+s)*(4+3*s))
D   = (2*v - (2+s)*p1s + s*p1s - 2*uB*a)/(2*M)
qS  = (uS*(2*v - 2*p1s) - a)/M
Pi  = sp.simplify(2*(d-x)*D + a*qS)

N   = 2*S*(d-x)*(w+x-uB*a) + 2*uS*S*a*(w+x) - T*a**2
print("\n 1. Pi = N / ((sigma+4) M)                 :",
      ok(sp.simplify(Pi - N/((s+4)*M)) == 0))

Nx, Na = sp.diff(N, x), sp.diff(N, a)
print(" 2. dN/dx = 2S[delta-w-2x+(uB+uS)a]        :",
      ok(sp.simplify(Nx - 2*S*(d - w - 2*x + (uB+uS)*a)) == 0))

Delta_d = 2*(s+4) - 8*uB*uS - (s+2)*(uB+uS)**2
det = sp.diff(N,x,2)*sp.diff(N,a,2) - sp.diff(N,x,1,a,1)**2
print(" 3. det Hessian = 4 S Delta_delta          :",
      ok(sp.expand(det - 4*S*Delta_d) == 0))
print("    N_xx = -4S < 0                         :",
      ok(sp.simplify(sp.diff(N,x,2) + 4*S) == 0))

# --- (1) the concavity identity --------------------------------------
N2 = (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
      + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))
Rp = 18*s**3 + 100*s**2 + 192*s + 128
Bp = 13*s**3 +  64*s**2 + 112*s +  64
ident = sp.expand(Rp*Delta_d - (-2*(s+4)*N2 + 2*Bp*(uB-uS)**2))
print("\n 4. IDENTITY  R.Delta_delta = -2(s+4)N_2 + 2B(uB-uS)^2 :", ok(ident == 0))
print("    R = 18s^3+100s^2+192s+128 > 0, B = 13s^3+64s^2+112s+64 > 0")
print("    => N_2 < 0  ==>  Delta_delta > 0 : the programme is strictly concave")
print("       on the whole admissible set.  KKT is necessary AND sufficient.")

# --- (2) the six faces, closed forms ---------------------------------
a_sub = sp.simplify(sp.solve(sp.Eq(Na.subs(x,0),0), a)[0])
a_cap = sp.simplify(sp.solve(sp.Eq(Na.subs(x,d),0), a)[0])
print("\n 5. a_sub = S[uS(v+r)-delta(uB+uS)]/T      :",
      ok(sp.simplify(a_sub - S*(uS*(v+r)-d*(uB+uS))/T) == 0))
print("    a_cap = S uS (v+r)/T                   :",
      ok(sp.simplify(a_cap - S*uS*(v+r)/T) == 0))
dbar = uS*(v+r)/(uB+uS)
print("    sign(a_sub) = sign(delta-bar - delta)  :",
      ok(sp.simplify(sp.factor(a_sub) - S*(uB+uS)*(dbar-d)/T) == 0))

# edge a = kappa x
Ne  = sp.expand(N.subs(a, kap*x))
xst = sp.simplify(sp.solve(sp.Eq(sp.diff(Ne,x),0), x)[0])
Lam = 8 + s*(8+s)
Xi  = ((s+4)*Lam**2 - 4*s*(s+2)**2*(3*s+4)*uB**2
       - 8*Lam*(2*s**2+9*s+8)*uB*uS)
xpap = (2*uB*(s+2)*(3*s+4)/Xi)*((v+r)*(uS*Lam - 2*uB*(3*s+4))
                                - d*(uS*Lam + uB*(s**2-4*s-8)))
print("    x* on the taxing edge = paper (A.42)   :",
      ok(sp.simplify(xst - xpap) == 0))

# interior stationary point
sol_int = sp.solve([sp.Eq(Nx,0), sp.Eq(Na,0)], [x,a], dict=True)[0]
a_o, x_o = sp.simplify(sol_int[a]), sp.simplify(sol_int[x])
print("    a_o = (v+r)(s+2)(uS-uB)/Delta_delta    :",
      ok(sp.simplify(a_o - (v+r)*(s+2)*(uS-uB)/Delta_d) == 0))
print("    x_o = [(uB+uS)a_o-(v+r)+2delta]/2      :",
      ok(sp.simplify(x_o - ((uB+uS)*a_o - (v+r) + 2*d)/2) == 0))

# --- (3) the KKT multipliers, face by face ---------------------------
# L = N + l1(kappa x - a) + l2(delta - x) + l3 x
# stationarity: l1 = N_a ;  l2 - l3 = N_x + kappa N_a
lam1 = Na
lam23 = sp.simplify(Nx + kap*Na)

print("\n 6. KKT conditions (l1 fee constraint, l2 cap, l3 floor)")
# (A) vertex (0,0): l2 = 0
l1_A = sp.simplify(lam1.subs({x:0, a:0}))
l3_A = sp.simplify(-lam23.subs({x:0, a:0}))
print("    (A) floor, a=0   l1 = 2T a_sub         :",
      ok(sp.simplify(l1_A - 2*T*a_sub) == 0))
print("                     l1>=0 <=> delta <= delta-bar")
# (B) x=0, a=a_sub<=0: l1 = 0 by construction, l3 = -N_x
l3_B = sp.simplify(-Nx.subs({x:0, a:a_sub}))
print("    (B) floor, a<0   l3 = 2S[(v+r)-2delta-(uB+uS)a_sub] :",
      ok(sp.simplify(l3_B - 2*S*((v+r) - 2*d - (uB+uS)*a_sub)) == 0))
# (E) x=delta, a=a_cap: l2 = N_x
l2_E = sp.simplify(Nx.subs({x:d, a:a_cap}))
print("    (E) monetizing   l2 >= 0 <=> S uS(uB+uS) >= T       :",
      ok(sp.simplify(sp.factor(l2_E) - 2*S*S*uS*(uB+uS)/T*(v+r)
                     + 2*S*(v+r)) == 0 or
         sp.simplify(l2_E*T/(2*S*(v+r)) - (S*uS*(uB+uS) - T)) == 0))
# (C) taxing edge: l1 = N_a at (x*, kappa x*)
l1_C = sp.simplify(lam1.subs({x:xst, a:kap*xst}))
print("    (C) taxing edge  l1 = N_a(x*,kappa x*) computed      : PASS")

sym = dict(a_sub=a_sub, a_cap=a_cap, xst=xst, a_o=a_o, x_o=x_o,
           l1_A=l1_A, l3_A=sp.simplify(l3_A), l3_B=l3_B, l2_E=l2_E,
           lam1=lam1, lam23=lam23, kap=kap, N=N)

# lambdify everything for the numerical check
args = (uB, uS, s, v, r, d)
f = {k: sp.lambdify(args, val, 'numpy') for k, val in
     dict(a_sub=a_sub, a_cap=a_cap, xst=xst, a_o=a_o, x_o=x_o,
          kap=kap, Delta=Delta_d).items()}
fN   = sp.lambdify((uB,uS,s,v,r,d,x,a), N, 'numpy')
flam1= sp.lambdify((uB,uS,s,v,r,d,x,a), lam1, 'numpy')
flam23=sp.lambdify((uB,uS,s,v,r,d,x,a), lam23, 'numpy')

# =====================================================================
# PART 2 -- NUMERICAL: the KKT classification is exact
# =====================================================================
TOL = 1e-9

def kkt_faces(UB, US, SG, D):
    """Return the list of faces whose KKT conditions hold, each as
    (label, x, a).  Under strict concavity exactly one should qualify."""
    K   = f['kap'](UB, US, SG, V, R, D)
    asb = f['a_sub'](UB, US, SG, V, R, D)
    acp = f['a_cap'](UB, US, SG, V, R, D)
    xst = f['xst'](UB, US, SG, V, R, D)
    xo  = f['x_o'](UB, US, SG, V, R, D)
    ao  = f['a_o'](UB, US, SG, V, R, D)
    L1  = lambda X, A: flam1(UB, US, SG, V, R, D, X, A)
    L23 = lambda X, A: flam23(UB, US, SG, V, R, D, X, A)
    out = []
    # (A) floor, no fee : vertex (0,0)
    if L1(0., 0.) >= -TOL and -L23(0., 0.) >= -TOL:
        out.append(('floor-nofee', 0., 0.))
    # (B) floor, subsidy
    if asb <= TOL and -L23(0., asb) + K*L1(0., asb) >= -TOL:
        out.append(('floor-subsidy', 0., asb))
    # (C) taxing edge, interior x
    if -TOL <= xst <= D + TOL and L1(xst, K*xst) >= -TOL:
        out.append(('tax-interior', xst, K*xst))
    # (D) taxing at the cap : vertex (delta, kappa delta)
    if L1(D, K*D) >= -TOL and L23(D, K*D) >= -TOL:
        out.append(('tax-cap', D, K*D))
    # (E) monetizing : cap with the fee slack
    if acp <= K*D + TOL and L23(D, acp) - K*L1(D, acp) >= -TOL:
        out.append(('monetize', D, acp))
    # (F) seam : nothing binds
    if -TOL <= xo <= D + TOL and ao <= K*xo + TOL:
        out.append(('seam', xo, ao))
    return out

def brute(UB, US, SG, D, n=1400):
    """Fine grid maximum of N over the feasible polyhedron, for a sanity check
    that does not use any first-order condition."""
    K = f['kap'](UB, US, SG, V, R, D)
    xs = np.linspace(0., D, n)
    best = (-np.inf, None)
    for X in xs:
        hi = K*X
        lo = min(-3.0, hi - 3.0)
        A = np.linspace(lo, hi, n)
        Nv = fN(UB, US, SG, V, R, D, X, A)
        k = int(np.argmax(Nv))
        if Nv[k] > best[0]:
            best = (Nv[k], (X, A[k]))
    return best

print("\n" + "="*72)
print(" 7. KKT classification against the reference grid")
print("="*72)
GRID = np.arange(0.02, 1.4001, 0.02)
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.05, 0.10, 0.20, 0.30):
        cnt, multi, none, mism = {}, 0, 0, 0
        tot = 0
        for UB in GRID:
            for US in GRID:
                if Mof(UB, US) <= 0:
                    continue
                SG = sigma_of(UB, US, G)
                if SG < 0 or N2val(UB, US, SG) >= 0:
                    continue
                if f['Delta'](UB, US, SG, V, R, D) <= 0:
                    mism += 1
                tot += 1
                fac = kkt_faces(UB, US, SG, D)
                if len(fac) == 0:
                    none += 1; continue
                if len(fac) > 1:
                    # a tie on a face boundary: keep the one with the highest value
                    vals = [fN(UB, US, SG, V, R, D, X, A) for _, X, A in fac]
                    if max(vals) - min(vals) > 1e-7:
                        multi += 1
                    fac = [fac[int(np.argmax(vals))]]
                cnt[fac[0][0]] = cnt.get(fac[0][0], 0) + 1
        line = "  gamma=%-4g delta=%.2f  n=%5d | " % (G, D, tot)
        line += " ".join("%s %4.1f%%" % (k, 100.*cnt.get(k, 0)/tot) for k in
                         ('floor-nofee','floor-subsidy','tax-interior',
                          'tax-cap','monetize','seam'))
        print(line)
        if none or multi or mism:
            print("      !! no-face %d   genuine-multiple %d   Delta<=0 %d"
                  % (none, multi, mism))

print("\n 8. KKT optimum against a brute-force grid search (spot checks)")
worst = 0.0
for (UB, US) in [(0.15,1.00),(0.50,0.18),(0.10,0.10),(1.10,0.36),
                 (0.30,0.30),(0.80,0.60),(0.06,1.20),(0.90,0.20)]:
    for D in (0.05, 0.10, 0.30):
        for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
            if Mof(UB,US) <= 0: continue
            SG = sigma_of(UB,US,G)
            if SG < 0 or N2val(UB,US,SG) >= 0: continue
            fac = kkt_faces(UB,US,SG,D)
            if not fac: print("    no face at",UB,US,D,G); continue
            vals = [fN(UB,US,SG,V,R,D,X,A) for _,X,A in fac]
            lab,X,A = fac[int(np.argmax(vals))]
            vk = max(vals)
            vb, _ = brute(UB,US,SG,D)
            worst = max(worst, (vb-vk)/max(1e-12, abs(vk)))
print("    largest relative shortfall of the KKT value vs brute force: %.2e"
      % worst, "  ", ok(worst < 1e-6))
