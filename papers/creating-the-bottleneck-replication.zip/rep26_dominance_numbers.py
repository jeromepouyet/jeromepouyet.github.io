# -*- coding: utf-8 -*-
"""rep26_dominance_numbers.py -- D: regenerate EVERY number the dominance
appendix quotes, on ONE stated grid, with the corrected solvers.

Reference grid: step 0.02 over [0.02, 1.40], screened on {M > 0, sigma >= 0,
N_2 < 0} -- the two-instrument admissible set, which is what both dominance
programmes need.  The separation benchmark is the asymmetric programme of
rep5_dominance.benchmark_asym (one manufacturer bought, the other held at its
floor); the symmetric programme sep_opt below is kept for reference.  M1 is
the favored manufacturer and the rival M2 the one held at the floor.
"""
from rep5_dominance import benchmark_asym
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
P = lambda *a, **k: print(*a, flush=True, **k)
P("="*78); P("rep26 (D) -- every number of the dominance appendix, regenerated"); P("="*78)

uB,uS,s,v,r,d,x,a,b,b2,p1,p2 = sp.symbols(
    'u_B u_S sigma v r delta x a b b_2 p_1 p_2', positive=True)
M=1-2*uB*uS; Lam=8+s*(8+s); kap=Lam/(2*uB*(4+3*s)); S=2+s; T=s+4-4*uB*uS; w=v+r-d
def dem(P1,P2,A): return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
                          (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),(uS*(2*v-P1-P2)-A)/M)
g_=(s+2*uB*uS)/M
def surp(P1,P2,D1,D2,Q):
    return (v*(D1+D2)+uB*Q*(D1+D2)-(2*(D1**2+D2**2)+g_*(D1+D2)**2)/(4*(1+g_))
            -P1*D1-P2*D2), Q**2/2
D1e,D2e,QSe=dem(p1,p2,a)
sep =sp.solve([sp.diff((p1+b)*D1e,p1),sp.diff((p2+b)*D2e,p2)],[p1,p2],dict=True)[0]
objI=(p1+r)*D1e+a*QSe+(r-b2)*D2e
inte=sp.solve([sp.diff(objI,p1),sp.diff((p2+b2)*D2e,p2)],[p1,p2],dict=True)[0]
P1s,P2s=sp.cancel(sep[p1]),sp.cancel(sep[p2]); D1s,D2s,Qs=dem(P1s,P2s,a)
VBs,VSs=surp(P1s,P2s,D1s,D2s,Qs); pi1s=(P1s+b)*D1s; Pis=2*(r-b)*D1s+a*Qs
fS={k:sp.lambdify((uB,uS,s,v,r,b,a),e,'numpy') for k,e in
    dict(Pi=Pis,pi1=pi1s,W=VBs+VSs+2*pi1s+Pis,D1=D1s,qS=Qs).items()}
P1i,P2i=sp.cancel(inte[p1]),sp.cancel(inte[p2]); D1i,D2i,Qi=dem(P1i,P2i,a)
VBi,VSi=surp(P1i,P2i,D1i,D2i,Qi); pi2i=(P2i+b2)*D2i
PiI=(P1i+r)*D1i+a*Qi+(r-b2)*D2i
fI={k:sp.lambdify((uB,uS,s,v,r,b2,a),e,'numpy') for k,e in
    dict(Pi=PiI,pi2=pi2i,W=VBi+VSi+pi2i+PiI).items()}
# --- exact separation optimum (KKT) ---
N=2*S*(d-x)*(w+x-uB*a)+2*uS*S*a*(w+x)-T*a**2
Nx,Na=sp.diff(N,x),sp.diff(N,a); f=lambda e: sp.lambdify((uB,uS,s,v,r,d),e,'numpy')
fasb=f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,0),0),a)[0]))
facp=f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,d),0),a)[0]))
fxst=f(sp.cancel(sp.solve(sp.Eq(sp.diff(sp.expand(N.subs(a,kap*x)),x),0),x)[0]))
_si=sp.solve([sp.Eq(Nx,0),sp.Eq(Na,0)],[x,a],dict=True)[0]
fxo,fao=f(sp.cancel(_si[x])),f(sp.cancel(_si[a])); fkap=f(kap)
fl1=sp.lambdify((uB,uS,s,v,r,d,x,a),Na,'numpy')
fl23=sp.lambdify((uB,uS,s,v,r,d,x,a),sp.cancel(sp.together(Nx+kap*Na)),'numpy')
fN=sp.lambdify((uB,uS,s,v,r,d,x,a),N,'numpy'); TOL=1e-9
def sep_opt(UB,US,SG,D):
    K=fkap(UB,US,SG,V,R,D); asb=fasb(UB,US,SG,V,R,D); acp=facp(UB,US,SG,V,R,D)
    xs=fxst(UB,US,SG,V,R,D); xo=fxo(UB,US,SG,V,R,D); ao=fao(UB,US,SG,V,R,D)
    L1=lambda X,A: fl1(UB,US,SG,V,R,D,X,A); L23=lambda X,A: fl23(UB,US,SG,V,R,D,X,A)
    c=[]
    if L1(0.,0.)>=-TOL and -L23(0.,0.)>=-TOL: c.append(('floor-nofee',0.,0.))
    if asb<=TOL and -L23(0.,asb)+K*L1(0.,asb)>=-TOL: c.append(('floor-sub',0.,asb))
    if -TOL<=xs<=D+TOL and L1(xs,K*xs)>=-TOL: c.append(('tax-int',xs,K*xs))
    if L1(D,K*D)>=-TOL and L23(D,K*D)>=-TOL: c.append(('tax-cap',D,K*D))
    if acp<=K*D+TOL and L23(D,acp)-K*L1(D,acp)>=-TOL: c.append(('monetize',D,acp))
    if -TOL<=xo<=D+TOL and ao<=K*xo+TOL: c.append(('seam',xo,ao))
    if not c: return None
    vals=[fN(UB,US,SG,V,R,D,X,A) for _,X,A in c]
    lab,X,A=c[int(np.argmax(vals))]
    return lab, R-D+X, A
PiIs=sp.cancel(sp.together(objI.subs(inte)))
a_of=sp.cancel(sp.solve(sp.Eq(sp.diff(PiIs,a),0),a)[0])
phi=sp.cancel(sp.together(sp.diff(PiIs,b2).subs(a,a_of)))
fb2s=f(sp.cancel(sp.solve(sp.Eq(phi,0),b2)[0]))
fab2=sp.lambdify((uB,uS,s,v,r,d,b2),a_of,'numpy'); fbb=f(r-d*Lam/(8*(1+s)))
def int_opt(UB,US,SG,D):
    lo=max(fbb(UB,US,SG,V,R,D),0.0); B=min(max(fb2s(UB,US,SG,V,R,D),lo),R)
    return B, fab2(UB,US,SG,V,R,D,B)
Ra=lambda S_: (3*S_**3+21*S_**2+48*S_+32)/(2*(S_+2)*(3*S_+4))
Rd=lambda S_: (8+S_*(8+S_))/(2*(3*S_+4))
GRID=np.arange(0.02,1.4001,0.02)
def adm(G):
    o=[]
    for x1 in GRID:
        for x2 in GRID:
            if Mof(x1,x2)<=0: continue
            sg=sigma_of(x1,x2,G)
            if sg<0 or N2val(x1,x2,sg)>=0: continue
            o.append((x1,x2,sg))
    return o

P("\n[1] admissible points on the reference grid (step 0.02, N_2 < 0)")
A_={}
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    A_[G]=adm(G); P("    gamma=%-3g : %5d" % (G,len(A_[G])))

P("\n[2] regime shares of the separation benchmark (asymmetric programme)")
BA={}
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.1,0.2,0.3):
        c={}
        for (x1,x2,sg) in A_[G]:
            o=benchmark_asym(x1,x2,G,D); BA[(G,D,x1,x2)]=o
            if o: c[o['regime']]=c.get(o['regime'],0)+1
        n=len(A_[G])
        P("    gamma=%-3g delta=%.1f | "%(G,D)+" ".join(
          "%s %4.1f%%"%(k,100.*c.get(k,0)/n) for k in
          ('floor','floor-subsidy','edge','cap-corner','seam','cap-both','cap-both-corner','edge-two','cap-corner-two','cap','cap-two','one-interior','sym-edge')))

P("\n[3] the band R_Phi < uB/uS < R_a (only integration taxes), and where the benchmark already taxes")
RPhi=lambda S_: (8+S_*(8+S_))/(3*S_+4)
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    n=len(A_[G]); band=sum(1 for (x1,x2,sg) in A_[G] if RPhi(sg)<x1/x2<Ra(sg))
    below=sum(1 for (x1,x2,sg) in A_[G] if x1/x2<Ra(sg))
    diag=sum(1 for (x1,x2,sg) in A_[G] if x2<=x1<Ra(sg)*x2)
    diagtax=sum(1 for (x1,x2,sg) in A_[G] if x2<=x1<RPhi(sg)*x2)
    P("    gamma=%-3g : uB/uS < R_a at %4d ; of these the benchmark taxes as delta -> 0 (uB/uS < R_Phi) at %4d (%4.1f%%);"
      " on {u_S <= u_B < h(u_S)}: %d points, benchmark taxes at %d (%4.1f%%)"
      % (G,below,below-band,100.*(below-band)/below, diag, diagtax, 100.*diagtax/max(diag,1)))

P("\n[4] delta > delta-bar (the subsidizing corner), reference grid")
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.1,0.2,0.3):
        k=sum(1 for (x1,x2,sg) in A_[G] if D>x2*(V+R)/(x1+x2))
        P("    gamma=%-3g delta=%.1f : %4d of %d points (%4.1f%%)"
          % (G,D,k,len(A_[G]),100.*k/len(A_[G])))

P("\n[5] a_sep <= a**(delta) in the taxing range")
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for D in (0.1,0.2,0.3):
        bad=tot=0
        for (x1,x2,sg) in A_[G]:
            o=BA[(G,D,x1,x2)]
            if not o: continue
            as_=o['a']
            if as_<=1e-12: continue
            tot+=1; B,ai=int_opt(x1,x2,sg,D)
            if as_>ai+1e-9: bad+=1
        P("    gamma=%-3g delta=%.1f : %d taxing points, a_sep > a** at %d (%.1f%%)"
          % (G,D,tot,bad,100.*bad/max(tot,1)))

P("\n[6] the three reference points: merger increments (gamma=4)")
P("    %-12s %-18s %8s %8s %8s %8s" % ("(uB,uS)","","0.0","0.1","0.2","0.3"))
for (x1,x2) in ((0.1,0.1),(0.5,0.18),(0.15,1.0)):
    sg=sigma_of(x1,x2,4.); rows={'fee a**-a_sep':[], 'rival dpi_2':[], 'welfare dW':[]}
    for D in (0.0,0.1,0.2,0.3):
        o=benchmark_asym(x1,x2,4.,D); B,ai=int_opt(x1,x2,sg,D)
        rows['fee a**-a_sep'].append(ai-o['a'])
        rows['rival dpi_2'].append(fI['pi2'](x1,x2,sg,V,R,B,ai) - o['pi2'])
        rows['welfare dW'].append(fI['W'](x1,x2,sg,V,R,B,ai) - o['W'])
    for k,vv in rows.items():
        P("    %-12s %-18s %8.3f %8.3f %8.3f %8.3f"
          % ("(%.2f,%.2f)"%(x1,x2) if k.startswith('fee') else "", k, *vv))

P("\n[7] share of admissible points at which the merger REDUCES welfare")
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    line="    gamma=%-3g :" % G
    for D in (0.0,0.1,0.2,0.3):
        k=n=0
        for (x1,x2,sg) in A_[G]:
            o=BA.get((G,D,x1,x2)) if D>0 else benchmark_asym(x1,x2,G,D)
            if not o: continue
            B,ai=int_opt(x1,x2,sg,D); n+=1
            if fI['W'](x1,x2,sg,V,R,B,ai) < o['W']: k+=1
        line+="  delta=%.1f : %5.1f%%" % (D,100.*k/n)
    P(line)
