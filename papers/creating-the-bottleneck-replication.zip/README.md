# Replication package

*Creating the Bottleneck: Vertical Integration in Platform Markets*
Jerome Pouyet and Thomas Tregouet

Python 3 with numpy, sympy, scipy and matplotlib.  Baseline calibration
throughout: v = 2, r = 1/2, and gamma as stated in each claim.

## Start here

    python3 rep_core.py

`rep_core.py` is the shared core: the stage-4 demand system, the stage-3
pricing equilibria under separation and under integration, the surplus
objects, the admissible set (H > 0 for the one-instrument problem, N_2 < 0
for the two-instrument problems), and the fee at which a lone adopter is
just indifferent.  Running it executes sixteen checks of these objects
against the closed forms printed in the paper.  **Nothing else in the
package should be trusted unless every line reports PASS.**

Two modelling conventions the code makes explicit, because they are what
make the adoption game well posed.  Under joint refusal no device runs the
platform's system, so a positive developer fee cannot be collected; a
subsidy, by contrast, is paid in every configuration, since the developer
publishes on the platform's store regardless.  This asymmetry is what
generates a_kill.  Among the equilibria of the adoption game the one
maximizing the manufacturers' joint profit is played, ties going to
adoption (Section 2.3 of the paper); `rep3_contracts.game()` implements the
tie this way.

## One grid

Every count in the paper is taken on the reference grid, step 0.02 on
[0.02, 1.40]^2 at v = 2, r = 1/2 and gamma in {1/2, 1, 2, 4, 8, 16}, unless
the passage says otherwise (the deep sweeps of `b5i.py` and the coarsened
game-consistent searches of `rep2_statistics.py` are illustrations at
gamma = 4; the complements range uses the wider grid [0.02, 1.60]^2 at the
same six gamma).  Scripts whose loops ran on a subset of these values before
September 8, 2026 now run on all six.

## The two extensions (`ext/`)

The scripts of Online Appendices B.8 (more manufacturers) and B.9 (an
integrated rival) live in `ext/`, and the paper cites them by that path.
They store their symbolic equilibria in pickles (`eqN.pkl`, `feeN.pkl`,
`welfN.pkl`, `ext2.pkl`), shipped with the package; `extN_eq2.py` and
`ext2_merger.py` regenerate them.

## The blocks

| file | what it supports |
|---|---|
| `rep1_frontiers.py` | admissible set, psi-locus exclusion (complements), interiority and publication at a\*\*, the headline shares on the positive-margin subset of A |
| `rep1_figures.py` | regenerates `figB1-admissible.pdf`, `figB7-baseline.pdf`, `figB7-gamma.pdf` |
| `rep2_statistics.py` | the residual quantitative statements: region-wide contract search, the divide-and-rule switch, the complements counts and the sign of total welfare there, the developer frontier, uniform posting |
| `band_share.py` | the band of Proposition 6(i): its share of the admissible set by gamma, the identity R_a - R_Phi and its monotonicity |
| `rep6_manufacturers.py` | the N-manufacturer extension: demand and equilibrium in sigma_N, the factors A_N and B_N, R_a^N and its monotonicity in N, the welfare table (drives `ext/extN_*.py`) |
| `rep7_twostores.py` | the integrated-rival extension: the two-store setup, the invariance of the frontier, L > 0, double marginalisation, the surplus table (drives `ext/ext2_*.py`) |
| `rep8_adoption.py` | the adoption subgame under the cap: enumerates the four profiles, their Nash equilibria and what the selection rule retains. A check on the analytic argument of Appendix A.2, not its source |
| `rep9_dnr.py` | the both-host reduction behind Proposition 6: Pi is quadratic, its critical point unique and symmetric, the closed forms a-dagger, Psi and Delta, the 3x3 Hessian (block-diagonal, Delta > 0 its second-order condition), and the sign rule that places the family's interior optimum on u_B >= u_S; grid on the admissible set A |
| `rep18_contract_vs_merger.py` | Propositions B.5 and B.6: the closed forms of the two gains, the inequality (B.37), its limit u_B/u_S < R_p, the common factor K in prices and application stock, the exact copy on K = 0, the chain R_p < 1 < R_Phi < R_a; then on the reference grid the region where separation is preferred, the welfare/buyer/developer/rival rankings against the sign of K, the magnitudes, and the two-host points (negative prices) |
| `rep18b_welfare_factor.py` | Proposition B.6: K divides the welfare difference exactly (one large symbolic expansion, about ten minutes), and the cofactor is negative at every grid point where both instruments are active |
| `rep18_figure.py` | regenerates Figure 2 (three panels) |
| `rep19_remark_table.py` | the two-host package on its own domain (the remark of Section 4) and Table B.1 |
| `rep10_interior.py` | the seam of the dominant-platform benchmark (Proposition B.2): the unconstrained stationary point is symmetric, so it is the same for the asymmetric programme and for its symmetric restriction; the closed forms a-circ and x-circ, Delta-delta as the second-order condition, the strip where the point is feasible, and the margin by which it beats the constrained candidates of the symmetric restriction |
| `rep11_welfare_sub.py` | Proposition 5(i) on the subsidizing side, counted on A rather than on the two-instrument set: 3,726 points over the six gamma, no exception |
| `rep12_xi.py` | Xi > 0 as an identity: the concavity premise of the taxing branch of the symmetric restriction of the dominance programme (one premium for both manufacturers); the quadratic-form certificate against N_2 < 0. The concavity of the benchmark itself is Delta_delta > 0 (`rep35`, test 1) |
| `rep13_prop8_sub.py` | the subsidizing halves of Proposition B.1(ii)-(iii) are analytic on the complements range: the three sign steps, plus the grid control |
| `rep14_slices.py` | the slice statistics of Online Appendix B.2 at b5j.py's own 120 slices per gamma, and the sign cross-check against direct evaluation on the whole taxing part of A |
| `rep3_contracts.py` | the contract space: calibrated single-host path, the wedge, the game-consistent search over posted packages, publication at the single-host package (block H) |
| `rep3_symbolic.py` | the twenty-two closed forms of the contract block (about ten minutes) |
| `rep4_efficiency.py` | efficiency gains, coordination motives, porting costs: the three participation thresholds and the polar case u_S = 0 against the undistorted benchmark |
| `rep4_figures.py` | regenerates `figB7-efficiency.pdf`; the coordination shares against the undistorted benchmark (quoted in B.11 for comparison with the efficiency case) |
| `rep34_coordination.py` | the separation benchmark under a coordination motive (B.6), corrected for the adoption constraint: the floor beta_NE on which a lone walker is indifferent, the selection floor (compensated locus), their crossing a_x, the corrected a-tilde = 0 frontier, the porting isomorphism (symbolic); the benchmark on the reference grid at the six gamma and alpha_B in {0.2, 0.4} (six regimes, subsidies), a brute-force check against the enumerated adoption game, the merger's increments against the undistorted and the corrected benchmarks, the private gain, the polar rows; regenerates `figB7-coordination.pdf` (Figure OA-10) |
| `rep5_dominance.py` | the dominant-platform benchmark of Proposition B.2 (`benchmark_asym`: asymmetric packages (beta^1, beta^2, a), exact enumeration of the active sets of the concave quadratic on the polyhedron P_delta, regime labels), the integrated firm's problem, the merger increments, Table B.3 at the reference points, the grid statistics (the welfare-loss shares by gamma and delta); `benchmark` is kept as the symmetric restriction |
| `rep5_figure.py` | regenerates `figB7-dominant.pdf` (Figure OA-3) from `benchmark_asym` |
| `verifI.py`, `verifJ.py` | geometry of the frontiers; the psi-locus from the other side |
| `verifK.py` | the calibrated path: surplus signs at a-hat, and the participation bound |
| `verifL.py` | the subsidizing branch under dominance |
| `b5i.py`, `b5j.py` | the platform's take off the participation constraint; the total-welfare proposition |
| `refine3.py`, `refine4.py` | two-host against single-host; interiority in the complements range |
| `rep15_magnitudes.py` | how much integration gains or costs each party, relative to the separation benchmark |
| `rep20_dominance_regimes.py`, `rep20_figure.py` | the three regimes of the symmetric restriction of the dominance programme, and the figure that draws them (exploratory; not cited) |
| `rep21_dominance_analytic.py` | the symmetric restriction of the dominance programme (x_1 = x_2) as an exact KKT characterization: Delta_delta > 0 on the admissible set, the regimes by inequalities, the two floor branches a = min{a_sub, 0}. Kept as a comparison point; the benchmark of the paper is asymmetric (`rep35`) |
| `rep22_integration_delta.py` | the integrated firm's problem under dominance, in closed form for an arbitrary premium; interiority and publication at its optimum at every premium of the list (test 8) |
| `rep23_local_delta.py` | the merger's impact under dominance near delta = 0, where the two sides collapse onto the baseline: the increments and their delta-slopes by cell, the separation side on the asymmetric taxing branch (favored manufacturer at the cap, the other at its floor, fee kappa delta) |
| `rep24_merger_incentive.py` | does dominance make the merger more or less attractive, privately and socially, against the asymmetric benchmark: the private gain G is positive at every admissible point for every delta up to 0.45, its median U-shaped in delta, and the share of points at which welfare rises by gamma and delta |
| `rep25_sign_uniformity.py` | are the delta-slopes uniform in sign inside each of the three cells (asymmetric taxing branch on the separation side): the share of points with a positive slope, by gamma, cell and variable |
| `rep26_dominance_numbers.py` | regenerates every number the dominance appendix quotes, on one stated grid: regime shares of the asymmetric benchmark (floor, taxing edge, cap corner, seam, residual faces), the band R_Phi < u_B/u_S < R_a and the share of {u_S <= u_B < h-underline} at which the benchmark taxes, a_sep against a**, the subsidizing corner |
| `rep27_slopes_closed.py` | closed forms for the delta-slopes at delta = 0 (the (tax, cap) cell with the asymmetric taxing branch; the floor cell), their signs, and the frontier R_Phi at which the separation side switches |
| `rep28_containment.py` | the cell (floor, cap) is empty, as an identity: the integration cap frontier lies inside the separation taxing frontier R_Phi (and inside R_delta of the symmetric restriction) |
| `rep29_Wsep_monotone.py` | is separation welfare decreasing in the premium for every delta, or only at delta = 0: the points at which W_sep rises, split between the subsidizing corner and the entries into the residual faces or along the taxing edge, by gamma and delta |
| `rep30_soc_identity.py` | the second-order condition of the two-host program: Delta is the same polynomial as Delta_delta, and N_2 < 0 implies Delta > 0 |
| `verifI.py`, `verifJ.py` | endpoint signs of h1 and h2 as polynomial identities; the psi-locus exclusion |
| `verifK.py` | the compensating single-host path |
| `verifL.py` | a dominant platform: the benchmark can subsidize |
| `rep31_microfoundation.py` | existence of a two-segment single-homing calibration interior at the model's prices, at each outcome and common to both |
| `rep32_buyer_region.py` | the region left open by Proposition 4(i), and how little of it lies beyond the dividing curve |
| `rep33_bothhost_grid.py` | Proposition 6 on the grid: no package hosting both manufacturers that the selection rule retains beats the single-host package on A* with u_B >= u_S (the six gamma of the reference grid, a <= 4); the exclusion rests on the selection rule inside the swept wedge, and the bounds of the sweep are certified: outside the wedge the exact maximum of the (concave) both-host profit on each of the two remaining convex regions falls short of the single-host value at every point |
| `rep35_dominance_asym.py` | the asymmetric dominance benchmark of Proposition B.2: symbolic (the Hessian and its reduction to Delta_delta > 0, the taxing-edge closed form x_1^* and its sign as delta -> 0, the frontier R_Phi, the cap-corner derivative in x_2, a_cap^a = a_sub(delta/2), the welfare slope of Proposition B.4 with the factor script-B, the three-cell corollary; seven tests); block B, the regimes on the reference grid at the six gamma and delta in {0.1, 0.2, 0.3} and the comparison with the symmetric restriction (shares beaten, gains, fees); block C, the brute-force check against the enumerated adoption game over symmetric and asymmetric packages on the coarsened grid (446 points, three premia, 1,338 point-premium pairs); block D, the numbers of Section 5.2 |

## Where each number comes from

| claim in the paper | script |
|---|---|
| admissible sets, psi-locus, interiority at a\*\* | `rep1_frontiers.py` |
| the single-homing construction is interior at the model's prices | `rep31_microfoundation.py` |
| the open region of Proposition 4(i) and the buyers' dividing curve | `rep32_buyer_region.py` |
| Proposition 6: both-host packages excluded on A* with u_B >= u_S, 10.6 million packages over the six gamma, and the certificate of the sweep's bounds | `rep33_bothhost_grid.py` |
| Figures B.1, B.2, B.6 | `rep1_figures.py` |
| complements counts (1,144/1,747 to 42/121 over the six gamma, alignment table of B.3) | `rep2_statistics.py` |
| total welfare on the complements set (exceptions at 41 and 2 taxing points at gamma = 1/2 and 1, none beyond) | `rep2_statistics.py` |
| the band of Proposition 6(i): share of A by gamma, and the identity R_a - R_Phi | `band_share.py` |
| N manufacturers: R_a^N(0) = N, dR_a^N/dN > 0, the welfare table by (gamma, N); welfare at subsidizing points and in the lowest fee decile at the six gamma | `rep6_manufacturers.py`, `ext/extN_welf2.py` |
| integrated rival: frontier invariance, L > 0, the 1.47 double-marginalisation ratio, the surplus table, the second-order conditions and publication store by store at the six gamma | `rep7_twostores.py`, `ext/ext2_full.py`, `ext/ext2_dm.py` |
| the selection rule never overrides an individual preference (Appendix A.2) | `rep8_adoption.py` |
| the both-host reduction, Lemma B.1, and the single-host / two-host partition (29 to 213 of 847 to 2,103 points per gamma; 162 of 1,692 at gamma = 4) | `rep9_dnr.py` |
| Propositions B.5 and B.6: (B.37), R_p, K, the exact copy, the shares 4.9-11.3% and 97-74%, the median 0.1-0.7% | `rep18_contract_vs_merger.py` |
| Proposition B.6: K divides W_sep - W_int exactly; cofactor negative at 847-2,103 points per gamma | `rep18b_welfare_factor.py` |
| Figure OA-5 | `rep18_figure.py` |
| the two-host remark (ranges over the six gamma: manufacturers and buyers gain at 76 to 97%, developer loses at 75 to 100%, welfare falls at 35 to 72%, negative prices at 0 to 100%, fee 1.1 to 1.7 times a-hat at the median; the integration-gain check) and Table B.1 | `rep19_remark_table.py` |
| Table B.2 | `rep18_contract_vs_merger.py` |
| the seam of Proposition B.2: the unconstrained symmetric stationary point | `rep10_interior.py` |
| Proposition 5(i) checked on A (3,726 subsidizing points over the six gamma) | `rep11_welfare_sub.py`, `rep14_slices.py` |
| Xi > 0 on {N_2 < 0} as an identity (symmetric restriction) | `rep12_xi.py` |
| Proposition B.1(ii)-(iii), subsidizing side, analytic | `rep13_prop8_sub.py` |
| the B.2 slice counts and the sign cross-check | `rep14_slices.py` |
| developer frontier h-bar_S: share of A, containment of x-tilde_a | `rep2_statistics.py` |
| the band in which only integration taxes (32%) | `rep2_statistics.py` |
| B.5 at the six gamma: the asymmetric benchmark, its concavity, the taxing edge, R_Phi, the game check on the coarsened grid, the comparison with the symmetric restriction (rep35); regime shares, the band, the share of {u_S <= u_B < h-underline} at which the benchmark taxes, a_sep against a** and the subsidizing corner (rep26); rival demand under delta and publication (rep22); cells and slopes (rep23, rep25, rep27), the empty cell (rep28); the seam (rep10); W_sep in delta with the subsidy check (rep29); the private gain and the welfare share (rep24); Table B.3 and the welfare-loss shares (rep5); the symmetric restriction (rep21, rep12) | `rep35_dominance_asym.py`, `rep22` to `rep29`, `rep10_interior.py`, `rep5_dominance.py` |
| region-wide contract search; the divide-and-rule switch; uniform posting | `rep2_statistics.py` |
| the contract space: calibrated path, wedge, reference-point and band searches | `rep3_contracts.py` |
| the twenty-two closed forms of the contract block | `rep3_symbolic.py` |
| efficiency gains, coordination motives, porting costs: thresholds | `rep4_efficiency.py` |
| Figure OA-9 (efficiency gains); coordination shares against the undistorted benchmark | `rep4_figures.py` |
| B.6: the corrected coordination benchmark, its regime table, the floor gap (eq. floor-gap), the merger's increments at the six gamma, the polar rows; Figure OA-10 | `rep34_coordination.py` |
| dominant platform: benchmark (asymmetric), increments, Table B.3, welfare-loss shares by gamma and delta, Section 5.2 | `rep5_dominance.py`, `rep35_dominance_asym.py` |
| Figure OA-3 (welfare against the dominance benchmark) | `rep5_figure.py` |
| frontier geometry; the psi-locus from the other side | `verifI.py`, `verifJ.py` |
| surplus signs at a-hat; the participation bound | `verifK.py` |
| the subsidizing branch under dominance | `verifL.py` |
| the deep sweep (beta <= 20, a <= 25); the welfare proposition | `b5i.py`, `b5j.py` |
| two-host against single-host; interiority in the complements range | `refine3.py`, `refine4.py` |

Grid shares reported in the paper are shares of grid points on a declared
grid, not probabilities over a distribution of parameters.

## How results are established

Wherever a claim can be settled as a polynomial identity it is, and the
script says so.  Claims that remain computational state their grid and their
domain, both in the paper and in the script's output.  The
dominant-platform benchmark is solved exactly, by enumerating the active
sets of a concave quadratic on the polyhedron P_delta in (x_1, x_2, a): the
benchmark optimizes over asymmetric packages, one manufacturer being held at
its floor on the taxing edge and at the cap corner, and its taxing branch is
in closed form (`rep35_dominance_asym.py`, `rep5_dominance.benchmark_asym`).
Its concavity is Delta_delta > 0, an identity on the admissible set.  The
symmetric restriction (one premium for both manufacturers) is kept as a
comparison point (`rep21_dominance_analytic.py`, `rep12_xi.py`); the seam,
the unconstrained stationary point, is common to both and
`rep10_interior.py` gives it in closed form.

## Not in the paper

`not-in-paper/` holds two verified explorations that the paper does not
use, kept because a referee may ask.  `rep17_lumpsum_*.py` and
`verif_lump_*.py` add a lump-sum transfer to the contract space under the
same economic restriction as the cap (total payment at most the revenue
generated): with publicly observed contracts Proposition 1 then fails
through a strategic-delegation channel, and holds verbatim under secret
offers (`README-lump-sums.md`).  `verif_rep18*.py` and `rep18_bvsc.py` are
the independent re-derivations behind Propositions B.5 and B.6.
