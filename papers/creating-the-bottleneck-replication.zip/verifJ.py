# -*- coding: utf-8 -*-
"""verifJ.py -- The psi-locus exclusion is analytic (Proposition on the
complements range, part (i); revision of August 2026).

On a sigma-slice (sigma = -s fixed, s in (0,1)), u_B u_S = w = (gamma+s)/(2(1+gamma))
is fixed and the slice is parameterized by rho = u_B/u_S. Claims verified:
(1) m1(a**) * H = (v+r)(3s-4) F(rho)/(rho (gamma+1)) with F LINEAR in rho,
    F(0) = 2(gamma+s)(s^2-6s+6) > 0, F(psi) = (3 gamma + s)(4-s)(1-s) > 0
    (psi = s/(4-3s)); hence m1(a**) H < 0 on the whole segment rho <= psi:
    every such point fails concavity (H <= 0) or interiority (m1 < 0).
(2) Concavity side: H is concave in rho on the slice and
    H'(psi) = (C - A psi^2)/psi^2 with C - A psi^2 = 4 w (1-s)(3s^2-16s+16) > 0,
    so for s < s* (where H(psi) < 0) the tangent bound gives H < 0 on the
    entire segment.
Run: python3 verifJ.py   (a few minutes)
"""
import sympy as sp
import numpy as np

uB, uS, g, v, r = sp.symbols('u_B u_S gamma v r', positive=True)
a, p1, p2 = sp.symbols('a p_1 p_2')
sig = g - 2*uB*uS*(1+g); M = 1 - 2*uB*uS
_x,_y,_f = sp.symbols('_x _y _f')
Dk = (2*v-(2+sig)*_x+sig*_y-2*uB*_f)/(2*M)
DS = (uS*(2*v-_x-_y)-_f)/M
D1 = Dk.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
D2 = Dk.subs({_x:p2,_y:p1,_f:a}, simultaneous=True)
DSe = DS.subs({_x:p1,_y:p2,_f:a}, simultaneous=True)
sol = sp.solve([sp.diff((p1+r)*D1 + a*DSe, p1), sp.diff((p2+r)*D2, p2)],
               [p1,p2], dict=True)[0]
m1 = sp.simplify(sol[p1] + r)
S = sp.Symbol('sigma')
H = ((S+4)**2*(3*S+4)**2 - 2*(S+2)*(3*S+4)**2*uB**2
     - 2*(3*S+4)*(S*(7*S+32)+32)*uB*uS - 2*(S*(S*(7*S+40)+64)+32)*uS**2)
B = (3*S*(S*(S+7)+16)+32)*uS - 2*(S+2)*(3*S+4)*uB
ast = ((3*S+4)*(v+r)*B/H).subs(S, sig)
num, den = sp.fraction(sp.together(m1.subs(a, ast) * H.subs(S, sig)))

rho, w_, s_ = sp.symbols('rho w s', positive=True)
def slice_sub(e):
    p = sp.Poly(sp.expand(e), uB, uS); out = 0
    for mono, c in zip(p.monoms(), p.coeffs()):
        mB, mS = mono; k = min(mB, mS); rB, rS = mB-k, mS-k
        assert rB % 2 == 0 and rS % 2 == 0
        out += c * w_**k * (rho*w_)**(rB//2) * (w_/rho)**(rS//2)
    return sp.together(out)
full = sp.together(slice_sub(num)/slice_sub(sp.expand(den)))
full = sp.together(full.subs(w_, (g+s_)/(2*(1+g))))
n2, d2 = sp.fraction(full)
claim = (r+v)*(3*s_-4)*( 2*(g+s_)*(s_**2-6*s_+6)
        + rho*(3*s_-4)*( -g*s_+3*g+s_**2-7*s_+8 ) )/(rho*(g+1))
print("(1) residual of the displayed factorization:",
      sp.simplify(sp.factor(n2)/sp.factor(d2) - claim))
F = 2*(g+s_)*(s_**2-6*s_+6) + rho*(3*s_-4)*(-g*s_+3*g+s_**2-7*s_+8)
print("    F(0) - 2(g+s)(s^2-6s+6):", sp.simplify(F.subs(rho,0) - 2*(g+s_)*(s_**2-6*s_+6)))
print("    F(psi) - (3g+s)(4-s)(1-s):",
      sp.simplify(sp.together(F.subs(rho, s_/(4-3*s_))) - (3*g+s_)*(4-s_)*(1-s_)))
# (2) concavity-side identity
w2 = sp.Symbol('w', positive=True)
A_ = 2*(2-s_)*(4-3*s_)**2*w2          # (sigma+2)(3sigma+4)^2 at sigma=-s times w... build directly:
A_ = 2*((-s_)+2)*((3*(-s_)+4)**2)*w2
C_ = 2*((-s_)*((-s_)*(7*(-s_)+40)+64)+32)*w2
psi = s_/(4-3*s_)
print("(2) C - A psi^2 - 4w(1-s)(3s^2-16s+16):",
      sp.simplify(C_ - A_*psi**2 - 4*w2*(1-s_)*(3*s_**2-16*s_+16)))
# numeric confirmation
lam = sp.lambdify((rho, s_, g), (claim/(r+v)).subs({v:2.0, r:0.5})*(2.5), 'numpy')
bad = tot = 0
for gv in [0.2,0.5,1,2,4,8,20]:
    for sv in np.linspace(1e-3,0.999,80):
        for fr in np.linspace(0.01,1.0,25):
            if lam(fr*sv/(4-3*sv), sv, gv) >= 0: bad += 1
            tot += 1
print(f"numeric: m1(a**) H >= 0 on the segment at {bad}/{tot} points")
