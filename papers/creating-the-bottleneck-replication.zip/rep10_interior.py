# -*- coding: utf-8 -*-
"""rep10_interior.py -- the interior stationary point of the dominant-platform
benchmark (Proposition B.2, Online Appendix B.5).

The separation programme under dominance is

    max  Pi(x,a) = 2 (delta - x) A (w + x - u_B a) + a [ 2 u_S A (w + x) - B a ]
    s.t. 0 <= x <= delta,   a <= kappa x,

with x = beta r - (r - delta), w = v + r - delta, M = 1 - 2 u_B u_S,
A = (sigma+2)/((sigma+4) M), B = (sigma+4-4 u_B u_S)/((sigma+4) M).

This script derives the interior stationary point in closed form and verifies
that it is a genuine fifth active set, missing from the proof's enumeration.
"""
import sympy as sp
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

uB, uS, sig, dl, v, r, x, a = sp.symbols('u_B u_S sigma delta v r x a', positive=True)

M = 1 - 2*uB*uS
A = (sig + 2)/((sig + 4)*M)
B = (sig + 4 - 4*uB*uS)/((sig + 4)*M)
w = v + r - dl

Pi = 2*(dl - x)*A*(w + x - uB*a) + a*(2*uS*A*(w + x) - B*a)
Pi = sp.expand(Pi)

print("1. Pi is a quadratic polynomial in (x, a)                 :",
      sp.Poly(Pi, x, a).total_degree() == 2)

sol = sp.solve([sp.diff(Pi, x), sp.diff(Pi, a)], [x, a], dict=True)
print("2. the interior stationary point is unique                :", len(sol) == 1)
s = sol[0]
a0 = sp.simplify(s[a]); x0 = sp.simplify(s[x])

# the claimed closed forms
Delta_d = 2*(sig + 4) - 8*uB*uS - (sig + 2)*(uB + uS)**2
a0_claim = (v + r)*(sig + 2)*(uS - uB)/Delta_d
x0_claim = ((uB + uS)*a0_claim - (v + r) + 2*dl)/2

print("3. a0 = (v+r)(sigma+2)(u_S-u_B)/Delta_delta               :",
      sp.simplify(a0 - a0_claim) == 0)
print("4. x0 = [ (u_B+u_S) a0 - (v+r) + 2 delta ] / 2            :",
      sp.simplify(x0 - x0_claim) == 0)

H = sp.Matrix([[sp.diff(Pi, x, 2), sp.diff(Pi, x, a)],
               [sp.diff(Pi, a, x), sp.diff(Pi, a, 2)]])
detH = sp.simplify(H.det())
detH_claim = 4*(sig + 2)*Delta_d/((sig + 4)**2 * M**2)
print("5. det H = 4(sigma+2) Delta_delta / [(sigma+4)^2 M^2]     :",
      sp.simplify(detH - detH_claim) == 0)
print("6. Pi_xx = -4(sigma+2)/[(sigma+4) M] < 0 over positives   :",
      sp.simplify(H[0, 0] + 4*(sig + 2)/((sig + 4)*M)) == 0)
print("7. Delta_delta free of delta, v and r                     :",
      Delta_d.free_symbols == {uB, uS, sig})
print("8. 0 < x0 < delta  <=>  (v+r) - 2 delta < (u_B+u_S) a0 < v+r :",
      sp.simplify(2*x0_claim - ((uB + uS)*a0_claim - (v + r) + 2*dl)) == 0)

print("\nDelta_delta =", sp.expand(Delta_d))
print("a0          =", sp.simplify(a0_claim))

# ------------------------------------------------------------------ grid check
print("\n" + "="*66)
print("How often the interior point is the optimum (reference grid)")
print("="*66)
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
from rep5_dominance import benchmark, kappa
V, R = V_DEF, R_DEF

def interior(uBv, uSv, sg, dlv):
    Dd = 2*(sg + 4) - 8*uBv*uSv - (sg + 2)*(uBv + uSv)**2
    if Dd <= 0: return None
    av = (V + R)*(sg + 2)*(uSv - uBv)/Dd
    xv = ((uBv + uSv)*av - (V + R) + 2*dlv)/2
    return xv, av, Dd

print("\n%-7s %-7s %-9s %-11s %-11s %-9s" %
      ("gamma", "delta", "admiss.", "interior", "share", "max gap"))
for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for dlv in (0.2, 0.3):
        gr = np.arange(0.02, 1.402, 0.02)
        n = k = 0; gap = 0.0; agree = 0
        for u1 in gr:
            for u2 in gr:
                if Mof(u1, u2) <= 0: continue
                sg = sigma_of(u1, u2, g)
                if sg < 0 or N2val(u1, u2, sg) >= 0: continue
                n += 1
                b = benchmark(u1, u2, g, dlv)
                if b is None: continue
                xb = b[7]; ab = b[2]; kp = kappa(u1, sg)
                if 1e-7 < xb < dlv - 1e-7 and ab < kp*xb - 1e-7:
                    k += 1
                    it = interior(u1, u2, sg, dlv)
                    if it is not None:
                        d = max(abs(it[0] - xb), abs(it[1] - ab))
                        gap = max(gap, d)
                        if d < 1e-7: agree += 1
        print("%-7g %-7.1f %-9d %-11s %-11s %-9.2e" %
              (g, dlv, n, "%d (%d ok)" % (k, agree), "%.2f%%" % (100*k/n), gap))

# ------------------------------------------------- where the interior regime sits
print("\n" + "="*66)
print("Concavity of the benchmark programme, and where the strip sits")
print("="*66)
for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    gr = np.arange(0.02, 1.402, 0.02)
    n = bad = 0
    for u1 in gr:
        for u2 in gr:
            if Mof(u1, u2) <= 0: continue
            sg = sigma_of(u1, u2, g)
            if sg < 0 or N2val(u1, u2, sg) >= 0: continue
            n += 1
            if 2*(sg+4) - 8*u1*u2 - (sg+2)*(u1+u2)**2 <= 0: bad += 1
    print("  gamma=%-5g admissible %-6d points with Delta_delta <= 0 : %d" % (g, n, bad))

print("\nThe strip at gamma = 4, delta = 0.3 :")
gr = np.arange(0.02, 1.402, 0.02); rows = []
for u1 in gr:
    for u2 in gr:
        if Mof(u1, u2) <= 0: continue
        sg = sigma_of(u1, u2, g=4.0) if False else sigma_of(u1, u2, 4.0)
        if sg < 0 or N2val(u1, u2, sg) >= 0: continue
        b = benchmark(u1, u2, 4.0, 0.3)
        if b is None: continue
        xb, ab = b[7], b[2]; kp = kappa(u1, sg)
        if 1e-7 < xb < 0.3 - 1e-7 and ab < kp*xb - 1e-7:
            rows.append((u1, u2, b[1], ab, kp*xb, (u1+u2)*ab, xb))
print("  %-6s %-6s %-8s %-9s %-9s %-11s" % ("u_B","u_S","beta","a","a_kill","(uB+uS) a"))
for u1,u2,bt,ab,ak,su,xb in rows[:4] + rows[-3:]:
    print("  %-6.2f %-6.2f %-8.4f %-9.4f %-9.4f %-11.4f" % (u1,u2,bt,ab,ak,su))
print("  ... %d points; v+r = %.2f, (v+r)-2delta = %.2f" % (len(rows), 2.5, 2.5-0.6))
print("  u_S > u_B at %d of %d ; a > 0 at %d of %d"
      % (sum(1 for q in rows if q[1] > q[0]), len(rows),
         sum(1 for q in rows if q[3] > 0), len(rows)))
print("  (u_B+u_S) a in [%.4f, %.4f]" % (min(q[5] for q in rows), max(q[5] for q in rows)))

# --------------------------------- the four listed sets against the interior one
print("\n" + "="*66)
print("The four active sets of the printed proof, against the interior point")
print("="*66)
from rep5_dominance import _bench_value, _bench_objects
from rep_core import prices_sep
def feasible(u1, u2, sg, dlv, xv, av):
    if xv < -1e-9 or xv > dlv + 1e-9: return False
    if av > kappa(u1, sg)*xv + 1e-9: return False
    b, D, qS = _bench_objects(u1, u2, sg, dlv, xv, av)
    if D <= 0 or qS <= 0: return False
    p1, p2 = prices_sep(u1, u2, sg, b, b, av)
    return p1 + b > 0

def best_of_four(u1, u2, sg, dlv):
    """x = 0 edge, a = kappa x edge, x = delta edge, and the two vertices."""
    kp = kappa(u1, sg); best = None
    def a_free(xf):                       # stationary in a on a fixed-x edge
        Mv = Mof(u1, u2); Av = (sg+2)/((sg+4)*Mv); Bv = (sg+4-4*u1*u2)/((sg+4)*Mv)
        wv = V + R - dlv
        return (-2*(dlv-xf)*Av*u1 + 2*u2*Av*(wv+xf))/(2*Bv)
    cands = [(0.0, a_free(0.0)), (dlv, a_free(dlv)), (0.0, 0.0), (dlv, kp*dlv)]
    xs = np.array([0.0, 1.0, 2.0])
    ys = np.array([_bench_value(u1, u2, sg, dlv, t, kp*t) for t in xs])
    c2, c1, _ = np.polyfit(xs, ys, 2)
    if abs(c2) > 1e-14:
        xst = min(max(-c1/(2*c2), 0.0), dlv); cands.append((xst, kp*xst))
    for (xv, av) in cands:
        if not feasible(u1, u2, sg, dlv, xv, av): continue
        val = _bench_value(u1, u2, sg, dlv, xv, av)
        if best is None or val > best: best = val
    return best

print("\n%-7s %-7s %-9s %-13s %-13s" % ("gamma","delta","interior","min gain","max gain"))
for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    for dlv in (0.2, 0.3):
        gr = np.arange(0.02, 1.402, 0.02); gains = []
        for u1 in gr:
            for u2 in gr:
                if Mof(u1, u2) <= 0: continue
                sg = sigma_of(u1, u2, g)
                if sg < 0 or N2val(u1, u2, sg) >= 0: continue
                it = interior(u1, u2, sg, dlv)
                if it is None: continue
                xv, av, _ = it
                if not (1e-7 < xv < dlv - 1e-7 and av < kappa(u1, sg)*xv - 1e-7): continue
                if not feasible(u1, u2, sg, dlv, xv, av): continue
                vi = _bench_value(u1, u2, sg, dlv, xv, av)
                v4 = best_of_four(u1, u2, sg, dlv)
                if v4 is not None: gains.append((vi - v4)/abs(v4))
        if gains:
            print("%-7g %-7.1f %-9d %-13.2e %-13.2e"
                  % (g, dlv, len(gains), min(gains), max(gains)))
