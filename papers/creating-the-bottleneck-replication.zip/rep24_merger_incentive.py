# -*- coding: utf-8 -*-
"""rep24_merger_incentive.py -- does dominance make the merger MORE or LESS
attractive, privately and socially?

The merged entity is the platform TOGETHER WITH M1, so the private gain is

    G(delta) = Pi^I(delta) - [ Pi^plat_sep(delta) + pi_1^sep(delta) ] ,

not Pi^I - Pi^plat_sep.  Welfare is compared with the same convention.

Both optima are the exact ones: the separation benchmark is the asymmetric
programme of rep5_dominance.benchmark_asym (the platform buys one
manufacturer's adoption and holds the other at its floor; M1 is the favored
manufacturer, so the private gain uses its separation profit), the integrated
policy the clamp of rep22.  The symmetric programme of the earlier text
(sep_opt below) is kept for comparison and no longer used in the tables.
"""
from rep5_dominance import benchmark_asym
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF
V, R = V_DEF, R_DEF
ok = lambda c: "PASS" if c else "**FAIL**"
print("="*74, flush=True)
print("rep24 -- the private gain and the welfare effect, as delta grows")
print("="*74, flush=True)

uB, uS, s, v, r, d, x, a, b, b2, p1, p2 = sp.symbols(
    'u_B u_S sigma v r delta x a b b_2 p_1 p_2', positive=True)
M = 1 - 2*uB*uS; Lam = 8+s*(8+s); kap = Lam/(2*uB*(4+3*s))
S = 2+s; T = s+4-4*uB*uS; w = v+r-d
def dem(P1,P2,A): return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
                          (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),
                          (uS*(2*v-P1-P2)-A)/M)
g_ = (s+2*uB*uS)/M
def surp(P1,P2,D1,D2,Q):
    return (v*(D1+D2)+uB*Q*(D1+D2)-(2*(D1**2+D2**2)+g_*(D1+D2)**2)/(4*(1+g_))
            -P1*D1-P2*D2), Q**2/2
D1e,D2e,QSe = dem(p1,p2,a)
sep  = sp.solve([sp.diff((p1+b)*D1e,p1), sp.diff((p2+b)*D2e,p2)],[p1,p2],dict=True)[0]
objI = (p1+r)*D1e + a*QSe + (r-b2)*D2e
inte = sp.solve([sp.diff(objI,p1), sp.diff((p2+b2)*D2e,p2)],[p1,p2],dict=True)[0]

# ---------- separation: everything as a function of (b, a) ----------
P1s, P2s = sp.cancel(sep[p1]), sp.cancel(sep[p2])
D1s,D2s,Qs = dem(P1s,P2s,a); VBs,VSs = surp(P1s,P2s,D1s,D2s,Qs)
pi1s = (P1s+b)*D1s; Pis = 2*(r-b)*D1s + a*Qs
Ws  = VBs+VSs+2*pi1s+Pis
fSEP = {k: sp.lambdify((uB,uS,s,v,r,b,a), e, 'numpy') for k,e in
        dict(Pi=Pis, pi1=pi1s, W=Ws, VB=VBs, VS=VSs, D1=D1s, qS=Qs).items()}
# ---------- integration: everything as a function of (b2, a) ----------
P1i, P2i = sp.cancel(inte[p1]), sp.cancel(inte[p2])
D1i,D2i,Qi = dem(P1i,P2i,a); VBi,VSi = surp(P1i,P2i,D1i,D2i,Qi)
pi2i = (P2i+b2)*D2i; PiI = (P1i+r)*D1i + a*Qi + (r-b2)*D2i
Wi = VBi+VSi+pi2i+PiI
fINT = {k: sp.lambdify((uB,uS,s,v,r,b2,a), e, 'numpy') for k,e in
        dict(Pi=PiI, pi2=pi2i, W=Wi, VB=VBi, VS=VSi, D1=D1i, qS=Qi).items()}

# ---------- exact separation optimum (KKT, rep21) ----------
N = 2*S*(d-x)*(w+x-uB*a) + 2*uS*S*a*(w+x) - T*a**2
Nx, Na = sp.diff(N,x), sp.diff(N,a)
f = lambda e: sp.lambdify((uB,uS,s,v,r,d), e, 'numpy')
fasb = f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,0),0),a)[0]))
facp = f(sp.cancel(sp.solve(sp.Eq(Na.subs(x,d),0),a)[0]))
fxst = f(sp.cancel(sp.solve(sp.Eq(sp.diff(sp.expand(N.subs(a,kap*x)),x),0),x)[0]))
_si  = sp.solve([sp.Eq(Nx,0),sp.Eq(Na,0)],[x,a],dict=True)[0]
fxo, fao = f(sp.cancel(_si[x])), f(sp.cancel(_si[a]))
fkap = f(kap)
fl1  = sp.lambdify((uB,uS,s,v,r,d,x,a), Na, 'numpy')
fl23 = sp.lambdify((uB,uS,s,v,r,d,x,a), sp.cancel(sp.together(Nx+kap*Na)), 'numpy')
fN   = sp.lambdify((uB,uS,s,v,r,d,x,a), N, 'numpy')
TOL = 1e-9
def sep_opt(UB,US,SG,D):
    K=fkap(UB,US,SG,V,R,D); asb=fasb(UB,US,SG,V,R,D); acp=facp(UB,US,SG,V,R,D)
    xs=fxst(UB,US,SG,V,R,D); xo=fxo(UB,US,SG,V,R,D); ao=fao(UB,US,SG,V,R,D)
    L1=lambda X,A: fl1(UB,US,SG,V,R,D,X,A); L23=lambda X,A: fl23(UB,US,SG,V,R,D,X,A)
    c=[]
    if L1(0.,0.)>=-TOL and -L23(0.,0.)>=-TOL: c.append((0.,0.))
    if asb<=TOL and -L23(0.,asb)+K*L1(0.,asb)>=-TOL: c.append((0.,asb))
    if -TOL<=xs<=D+TOL and L1(xs,K*xs)>=-TOL: c.append((xs,K*xs))
    if L1(D,K*D)>=-TOL and L23(D,K*D)>=-TOL: c.append((D,K*D))
    if acp<=K*D+TOL and L23(D,acp)-K*L1(D,acp)>=-TOL: c.append((D,acp))
    if -TOL<=xo<=D+TOL and ao<=K*xo+TOL: c.append((xo,ao))
    if not c: return None
    vals=[fN(UB,US,SG,V,R,D,X,A) for X,A in c]
    X,A = c[int(np.argmax(vals))]
    return R-D+X, A                      # (b = beta r, a)
# ---------- exact integration optimum (clamp, rep22) ----------
PiIs   = sp.cancel(sp.together(objI.subs(inte)))
a_of_b2= sp.cancel(sp.solve(sp.Eq(sp.diff(PiIs,a),0),a)[0])
phi    = sp.cancel(sp.together(sp.diff(PiIs,b2).subs(a,a_of_b2)))
fb2s   = f(sp.cancel(sp.solve(sp.Eq(phi,0),b2)[0]))
fab2   = sp.lambdify((uB,uS,s,v,r,d,b2), a_of_b2, 'numpy')
fbbar  = f(r - d*Lam/(8*(1+s)))
def int_opt(UB,US,SG,D):
    lo = max(fbbar(UB,US,SG,V,R,D), 0.0)
    B  = min(max(fb2s(UB,US,SG,V,R,D), lo), R)
    return B, fab2(UB,US,SG,V,R,D,B)

print("\n  solvers built", flush=True)
GRID = np.arange(0.02, 1.4001, 0.02)
DLIST = [0.0,0.02,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45]
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    pts=[]
    for X1 in GRID:
        for X2 in GRID:
            if Mof(X1,X2)<=0: continue
            SG=sigma_of(X1,X2,G)
            if SG<0 or N2val(X1,X2,SG)>=0: continue
            pts.append((X1,X2,SG))
    print("\n  gamma = %g   (%d admissible points)" % (G, len(pts)), flush=True)
    print("   delta   median G   min G     G<=0    median dW    dW>0     median da")
    for D in DLIST:
        Gv=[]; Wv=[]; av=[]
        for (X1,X2,SG) in pts:
            bA = benchmark_asym(X1,X2,G,D)
            if bA is None: continue
            b2i, ai = int_opt(X1,X2,SG,D)
            gain = fINT['Pi'](X1,X2,SG,V,R,b2i,ai) - (bA['Pi'] + bA['pi1'])
            dW = fINT['W'](X1,X2,SG,V,R,b2i,ai) - bA['W']
            Gv.append(gain); Wv.append(dW); av.append(ai-bA['a'])
        Gv=np.array(Gv); Wv=np.array(Wv); av=np.array(av)
        print("   %.2f   %8.4f  %8.4f  %5.1f%%   %8.4f   %5.1f%%   %8.4f"
              % (D, np.median(Gv), Gv.min(), 100.*np.mean(Gv<=0),
                 np.median(Wv), 100.*np.mean(Wv>0), np.median(av)), flush=True)
