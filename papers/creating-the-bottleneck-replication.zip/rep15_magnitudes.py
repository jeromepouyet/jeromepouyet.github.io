# -*- coding: utf-8 -*-
"""rep15_magnitudes.py -- how much integration gains or costs each party,
relative to the separation benchmark, across gamma; and the same for the best
unrestricted contract on the region where the benchmark unravels.

All changes are reported as percentages of the benchmark level of the same
object, so that they are comparable across gamma.
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (sigma_of, Mof, Hval, demands, prices_int, prices_sep,
                      surpluses, V_DEF, R_DEF)
import rep3_contracts as C
V, R = V_DEF, R_DEF
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)

def sep(uB,uS,g,sig,b1,b2,a):
    p1,p2 = prices_sep(uB,uS,sig,b1,b2,a)
    D1,D2,q = demands(uB,uS,sig,p1,p2,a)
    VB,VS = surpluses(uB,uS,g,p1,p2,D1,D2,q)
    return VB,VS,(p1+b1)*D1,(p2+b2)*D2,D1,D2,q

def integ(uB,uS,g,sig,a):
    p1,p2 = prices_int(uB,uS,sig,R,a)
    D1,D2,q = demands(uB,uS,sig,p1,p2,a)
    VB,VS = surpluses(uB,uS,g,p1,p2,D1,D2,q)
    return VB,VS,(p1+R)*D1+a*q,(p2+R)*D2,D1,D2,q

def pct(x, lo, hi):
    return "%+6.1f  [%+6.1f, %+6.1f]" % (np.median(x), np.percentile(x,lo), np.percentile(x,hi))

print("Integration against the separation benchmark, on the admissible set A.")
print("Median change and the 10th-90th percentile range, in per cent of the")
print("benchmark level of the same object.\n")
hdr = "%-6s %-7s %-24s %-24s %-24s %-24s %-24s" % ("gamma","points","merged firm",
       "rival profit","buyer surplus","developer surplus","total welfare")
print(hdr); print("-"*len(hdr))
store = {}
for g in GAMMAS:
    gr = np.arange(0.02,1.402,0.02)
    dI=[];d2=[];dB=[];dS=[];dW=[];pos={k:0 for k in "rbsw"}
    for u1 in gr:
        for u2 in gr:
            if Mof(u1,u2)<=0: continue
            sig=sigma_of(u1,u2,g)
            if sig<0 or Hval(u1,u2,sig)<=0: continue
            a=C.a_star(u1,u2,sig)
            p1,p2=prices_int(u1,u2,sig,R,a)
            if demands(u1,u2,sig,p1,p2,a)[1]<=0: continue
            b=sep(u1,u2,g,sig,R,R,0.0); m=integ(u1,u2,g,sig,a)
            Wb=b[0]+b[1]+b[2]+b[3]; Wm=m[0]+m[1]+m[2]+m[3]
            dI.append(100*(m[2]-b[2])/b[2])
            d2.append(100*(m[3]-b[3])/b[3]); dB.append(100*(m[0]-b[0])/b[0])
            dS.append(100*(m[1]-b[1])/b[1]); dW.append(100*(Wm-Wb)/Wb)
            pos['r'] += m[3]>b[3]; pos['b'] += m[0]>b[0]
            pos['s'] += m[1]>b[1]; pos['w'] += Wm>Wb
    n=len(d2); store[g]=(n,pos)
    print("%-6.3g %-7d %-24s %-24s %-24s %-24s %-24s" % (g,n,pct(dI,10,90),pct(d2,10,90),
                                     pct(dB,10,90),pct(dS,10,90),pct(dW,10,90)))
print("\nshare of points at which each party gains:")
print("%-6s %-9s %-9s %-11s %-9s" % ("gamma","rival","buyers","developer","welfare"))
for g in GAMMAS:
    n,p = store[g]
    print("%-6.3g %-9s %-9s %-11s %-9s" % (g,"%3.0f%%"%(100*p['r']/n),"%3.0f%%"%(100*p['b']/n),
                                           "%3.0f%%"%(100*p['s']/n),"%3.0f%%"%(100*p['w']/n)))

print("\n" + "="*96)
print("The best unrestricted contract, on the region where the benchmark unravels")
print("="*96)
print(hdr); print("-"*len(hdr))
for g in GAMMAS:
    gr = np.arange(0.02,1.402,0.02)
    d2=[];dB=[];dS=[];dW=[]
    for u1 in gr:
        for u2 in gr:
            if Mof(u1,u2)<=0: continue
            sig=sigma_of(u1,u2,g)
            if sig<0 or Hval(u1,u2,sig)<=0: continue
            a=C.a_star(u1,u2,sig)
            p1,p2=prices_int(u1,u2,sig,R,a)
            if demands(u1,u2,sig,p1,p2,a)[1]<=0: continue
            if u1/u2 >= C.R_Phi(sig): continue
            ah=C.a_hat(u1,u2,sig,g)
            if ah<=0: continue
            bh=C.bbar(u1,u2,sig,ah)
            if bh<=1: continue
            b=sep(u1,u2,g,sig,R,R,0.0); c=sep(u1,u2,g,sig,bh*R,R,ah)
            if min(c[4],c[5],c[6])<=0: continue
            plat=(1-bh)*R*c[4]+ah*c[6]
            Wb=b[0]+b[1]+b[2]+b[3]; Wc=c[0]+c[1]+c[2]+c[3]+plat
            d2.append(100*(c[3]-b[3])/b[3]); dB.append(100*(c[0]-b[0])/b[0])
            dS.append(100*(c[1]-b[1])/b[1]); dW.append(100*(Wc-Wb)/Wb)
    print("%-6.3g %-7d %-24s %-24s %-24s %-24s %-24s" % (g,len(d2),"       (zero by Prop. 1)",
                                     pct(d2,10,90),pct(dB,10,90),pct(dS,10,90),pct(dW,10,90)))
