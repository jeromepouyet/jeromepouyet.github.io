# -*- coding: utf-8 -*-
"""rep32_buyer_region.py -- the region left open by the sufficient conditions
of Proposition 4(i), and how much of it the dividing curve cuts off.

Proposition 4(i) gives two sufficient conditions for the merger to raise buyer
surplus: a subsidized developer (u_B > h_low(u_S), i.e. a** < 0) or
u_S >= hbar_B(u_B), i.e. (sigma+2) u_B - u_S <= 0.  Appendix A.2 factorizes

    Delta V_B(a) = [K_B / ((s+4)^2 (3s+4)^2 M^2)] * a * (a - a_B),
    a_B = 2 (s+2)(3s+4)^2 (v+r) [ (s+2) u_B - u_S ] / K_B,    K_B > 0,

so buyers gain iff a (a - a_B) > 0.  Both sufficient conditions make that
product positive.  What is left open is the set where a** > 0 and
(sigma+2) u_B - u_S > 0; there buyers gain iff a** > a_B, which is the
dividing curve of Online Appendix B.2.

This script reports, on the reference grid:
  (1) the share of the admissible set A that the open region covers,
  (2) the share of the open region on which buyers actually gain,
  (3) a check of the factorization against a direct computation of buyer
      surplus under separation and under integration,
  (4) a check that within the taxing region the sign of Delta V_B changes
      once and only once along each column u_B = constant, so that the
      dividing curve is a graph over u_B.  (4) is a grid finding and the
      paper does not rely on it; Online Appendix B.2 proves uniqueness of
      the root at fixed sigma, which is a different slicing.
"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, Hval,
                      demands, prices_int, prices_sep, surpluses)

V, R = V_DEF, R_DEF
STEP, LO, HI = 0.02, 0.02, 1.40
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)


def a_star(uB, uS, sig, v=V, r=R):
    num = 2*(v+r)*((3*sig*(sig*(sig+7)+16)+32)*uS - 2*(sig+2)*(3*sig+4)*uB) \
          / ((sig+4)**2*(3*sig+4)*Mof(uB, uS))
    den = -2*Hval(uB, uS, sig)/((sig+4)**2*(3*sig+4)**2*Mof(uB, uS))
    return -num/den


def Kval(uB, uS, sig):
    return ((sig+2)**2*(3*sig+4)**2*uB**2
            + ((sig+2)*(sig*(sig+16)+16) - 2*uB*uS*(sig+1)*(sig+4)**2)*uS**2
            - 2*uB*uS*(sig+2)*(3*sig+4)**2)


def a_B(uB, uS, sig, v=V, r=R):
    return 2*(sig+2)*(3*sig+4)**2*(v+r)*((sig+2)*uB - uS)/Kval(uB, uS, sig)


def main():
    gr = np.arange(LO, HI + STEP/2, STEP)
    print("Reference grid: step %.2f on [%.2f,%.2f]^2, v = %.1f, r = %.2f,"
          % (STEP, LO, HI, V, R))
    print("admissible set A = {sigma >= 0, H > 0, D_2(a**) > 0}.\n")
    print("gamma |   |A| | open region      | buyers gain there | K_B > 0 fails")
    mismatch = notgraph = 0
    for g in GAMMAS:
        tot = op = win = 0
        badK = 0
        for uB in gr:
            column = []
            for uS in gr:
                if Mof(uB, uS) <= 0:
                    continue
                sig = sigma_of(uB, uS, g)
                if sig < 0 or Hval(uB, uS, sig) <= 0:
                    continue
                a = a_star(uB, uS, sig)
                p1, p2 = prices_int(uB, uS, sig, R, a)
                D1, D2, qS = demands(uB, uS, sig, p1, p2, a)
                if min(D1, D2) <= 0 or qS <= 0:
                    continue
                tot += 1
                if Kval(uB, uS, sig) <= 0:
                    badK += 1
                pred = a*(a - a_B(uB, uS, sig))
                # (3) direct surplus comparison
                q1, q2 = prices_sep(uB, uS, sig, R, R, 0.0)
                E1, E2, q0 = demands(uB, uS, sig, q1, q2, 0.0)
                VBi, _ = surpluses(uB, uS, g, p1, p2, D1, D2, qS)
                VBs, _ = surpluses(uB, uS, g, q1, q2, E1, E2, q0)
                dVB = VBi - VBs
                if abs(dVB) > 1e-9 and np.sign(dVB) != np.sign(pred):
                    mismatch += 1
                if a > 0:
                    column.append(np.sign(pred))
                    if (sig+2)*uB - uS > 0:
                        op += 1
                        if dVB > 0:
                            win += 1
            # (4) one sign change per column, from minus to plus
            if column:
                ch = sum(1 for i in range(1, len(column))
                         if column[i] != column[i-1])
                if ch > 1 or (ch == 1 and column[0] > 0):
                    notgraph += 1
        print("%5.1f | %5d | %5d (%4.1f%% of A) | %4d (%4.1f%%)      | %d"
              % (g, tot, op, 100*op/tot, win, 100*win/max(op, 1), badK))
    print("\n(3) sign(Delta V_B) from the factorization against the direct"
          " surplus computation: %d mismatches." % mismatch)
    print("(4) columns u_B = constant with more than one sign change in the"
          " taxing region, or with the wrong order: %d." % notgraph)


if __name__ == "__main__":
    main()
