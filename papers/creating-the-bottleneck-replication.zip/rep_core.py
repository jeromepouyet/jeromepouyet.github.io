# -*- coding: utf-8 -*-
"""rep_core.py -- shared core of the replication package for
"Creating the Bottleneck: Vertical Integration in Platform Markets".

Everything the other scripts use lives here: the stage-4 demand system, the
stage-3 pricing equilibria, the platform's and the integrated firm's payoffs,
the admissible set, and the enumeration of adoption equilibria with the
selection rule.

Running this file executes a self-test that checks every object against the
closed forms printed in the paper.  Nothing downstream should be trusted
unless `python3 rep_core.py` reports PASS on every line.

Notation follows the paper: sigma = gamma - 2 u_B u_S (1+gamma),
M = 1 - 2 u_B u_S > 0 (the contraction condition), v the stand-alone value,
r the per-user benefit, a the developer fee, b_k = beta^k r the perceived
per-user benefit of manufacturer k, q_S = D_S the application stock.

Baseline calibration of the paper: v = 2, r = 1/2, gamma = 4.
"""
import numpy as np

V_DEF, R_DEF, G_DEF = 2.0, 0.5, 4.0

# ----------------------------------------------------------------- primitives
def sigma_of(uB, uS, g):
    return g - 2.0*uB*uS*(1.0+g)

def Mof(uB, uS):
    return 1.0 - 2.0*uB*uS

def demands(uB, uS, sig, p1, p2, a, v=V_DEF):
    """Stage-4 fixed point: buyer demands on each device and the application
    stock.  Equations (D_k) and (D_S) of the paper."""
    M = Mof(uB, uS)
    D1 = (2*v - (2+sig)*p1 + sig*p2 - 2*uB*a)/(2*M)
    D2 = (2*v - (2+sig)*p2 + sig*p1 - 2*uB*a)/(2*M)
    qS = (uS*(2*v - p1 - p2) - a)/M
    return D1, D2, qS

def prices_sep(uB, uS, sig, b1, b2, a, v=V_DEF):
    """Both manufacturers non-integrated: equation (prices-sep)."""
    den = (4+sig)*(4+3*sig)
    p1 = (-2*uB*a*(4+3*sig) + 2*v*(4+3*sig) - (2+sig)*(sig*b2 + 2*(2+sig)*b1))/den
    p2 = (-2*uB*a*(4+3*sig) + 2*v*(4+3*sig) - (2+sig)*(sig*b1 + 2*(2+sig)*b2))/den
    return p1, p2

def prices_int(uB, uS, sig, b2, a, r=R_DEF, v=V_DEF):
    """Integrated firm (objective (p1+r)D1 + a D_S + (r-b2) D2) facing a hosted
    M2 at perceived benefit b2: equations (p1I) and (p2I)."""
    c = (2*v - r - a*(2*uB+uS) + 3*b2)/(4+sig)
    p1 = -b2 + c + (b2 - r - a*uS)/(4+3*sig)
    p2 = -b2 + c + (r + a*uS - b2)/(4+3*sig)
    return p1, p2

# ------------------------------------------------------------------- surpluses
def surpluses(uB, uS, g, p1, p2, D1, D2, qS, v=V_DEF):
    VB = (v*(D1+D2) + uB*qS*(D1+D2)
          - (2*(D1**2+D2**2) + g*(D1+D2)**2)/(4*(1+g))
          - p1*D1 - p2*D2)
    return VB, 0.5*qS*qS

# --------------------------------------------------------------- admissibility
def Hval(uB, uS, sig):
    """Concavity of the one-instrument problem: H > 0.  Equation (Hdef)."""
    return ((sig+4)**2*(3*sig+4)**2
            - 2*(sig+2)*(3*sig+4)**2*uB**2
            - 2*(3*sig+4)*(sig*(7*sig+32)+32)*uB*uS
            - 2*(sig*(sig*(7*sig+40)+64)+32)*uS**2)

def N2val(uB, uS, sig):
    """Concavity of the two-instrument problem: N_2 < 0."""
    return (9*sig**3*((uB+uS)**2 - 2)
            + 5*sig**2*(9*uB**2 + 22*uB*uS + 9*uS**2 - 20)
            + 16*sig*(5*uB**2 + 14*uB*uS + 5*uS**2 - 12)
            + 16*((3*uB+uS)*(uB+3*uS) - 8))

def admissible(uB, uS, g, two_instrument=True):
    """The concavity part of the paper's admissible set: M > 0 and H > 0 for
    A (Section 3), M > 0 and N_2 < 0 for A* (Sections 4 and 5, where the
    platform chooses the share alongside the fee); N_2 < 0 implies H > 0.
    Callers add sigma >= 0 (Assumption 1) where the substitutes range is
    meant.  The two remaining conditions of Appendix A.1, a positive rival
    demand and publication on the platform's store at a**, are tested in
    rep1_frontiers.py; on the reference grid the first binds only on A at
    strongly developer-skewed points and the second never binds."""
    if Mof(uB, uS) <= 0:
        return False
    sig = sigma_of(uB, uS, g)
    if two_instrument:
        return N2val(uB, uS, sig) < 0
    return Hval(uB, uS, sig) > 0

# ------------------------------------------------- configurations of the game
def config(uB, uS, g, b1, b2, a, integrated=False, r=R_DEF, v=V_DEF):
    """Evaluate one adoption configuration.

    integrated=False: both manufacturers price as standalone firms at perceived
    benefits (b1, b2).  integrated=True: M1 belongs to the platform and M2 is
    hosted at perceived benefit b2 (set b2 = r for an M2 on its outside option,
    which kills the licensing margin).
    """
    sig = sigma_of(uB, uS, g)
    if integrated:
        p1, p2 = prices_int(uB, uS, sig, b2, a, r, v)
    else:
        p1, p2 = prices_sep(uB, uS, sig, b1, b2, a, v)
    D1, D2, qS = demands(uB, uS, sig, p1, p2, a, v)
    pi1 = (p1 + b1)*D1
    pi2 = (p2 + b2)*D2
    return dict(p1=p1, p2=p2, D1=D1, D2=D2, qS=qS, pi1=pi1, pi2=pi2)

def a_kill(uB, sig, b, r, dl):
    """Fee at which a lone adopter is just indifferent, given that the other
    manufacturer refuses and the platform then collects no fee (no device runs
    its system).  Proposition on a dominant platform."""
    return (b - (r - dl))*(8 + sig*(8 + sig))/(2*uB*(4 + 3*sig))

# ==============================================================================
if __name__ == "__main__":
    import sympy as sp
    ok = lambda c: "PASS" if c else "**FAIL**"
    print("rep_core self-test: closed forms against the paper\n")

    uB, uS, g, v, r, a, dl, s = sp.symbols('u_B u_S gamma v r a delta sigma', positive=True)
    b1, b2, b = sp.symbols('b1 b2 b')
    p1, p2 = sp.symbols('p1 p2')
    M = 1 - 2*uB*uS
    D1 = (2*v-(2+s)*p1+s*p2-2*uB*a)/(2*M)
    D2 = (2*v-(2+s)*p2+s*p1-2*uB*a)/(2*M)
    DS = (uS*(2*v-p1-p2)-a)/M

    # (1) demand gradients
    print(" 1. dD/dp_k, dD/dp_l, dD/da, dDS/dp, dDS/da :", ok(all([
        sp.simplify(sp.diff(D1,p1) + (2+s)/(2*M))==0,
        sp.simplify(sp.diff(D1,p2) - s/(2*M))==0,
        sp.simplify(sp.diff(D1,a) + uB/M)==0,
        sp.simplify(sp.diff(DS,p1) + uS/M)==0,
        sp.simplify(sp.diff(DS,a) + 1/M)==0])))

    # (2) best response R_k
    BR = sp.solve(sp.diff((p1+b1)*D1, p1), p1)[0]
    BRp = (2*(v-b1) + s*(p2-b1) - 2*uB*a)/(2*(2+s))
    print(" 2. best response R_k                      :", ok(sp.simplify(BR-BRp)==0))

    # (3) separation prices
    sol = sp.solve([sp.diff((p1+b1)*D1,p1), sp.diff((p2+b2)*D2,p2)], [p1,p2], dict=True)[0]
    php = (-2*uB*a*(4+3*s) + 2*v*(4+3*s) - (2+s)*(s*b2 + 2*(2+s)*b1))/((4+s)*(4+3*s))
    print(" 3. separation prices (prices-sep)          :", ok(sp.simplify(sol[p1]-php)==0))

    # (4) symmetric demand and stock at b1=b2=b
    Dsym = sp.simplify(D1.subs(sol).subs({b1:b, b2:b}))
    qsym = sp.simplify(DS.subs(sol).subs({b1:b, b2:b}))
    print(" 4. D = (s+2)(v+b-uB a)/((s+4)M)            :",
          ok(sp.simplify(Dsym - (s+2)*(v+b-uB*a)/((s+4)*M))==0))
    print("    qS = [2uS(s+2)(v+b) - a(s+4-4uBuS)]/..  :",
          ok(sp.simplify(qsym - (2*uS*(s+2)*(v+b) - a*(s+4-4*uB*uS))/((s+4)*M))==0))

    # (5) integrated prices
    obj = (p1+r)*D1 + a*DS + (r-b2)*D2          # integrated firm: chooses p1 only
    soli = sp.solve([sp.diff(obj,p1), sp.diff((p2+b2)*D2,p2)], [p1,p2], dict=True)[0]
    c = (2*v - r - a*(2*uB+uS) + 3*b2)/(4+s)
    p1p = -b2 + c + (b2 - r - a*uS)/(4+3*s)
    p2p = -b2 + c + (r + a*uS - b2)/(4+3*s)
    print(" 5. integrated prices (p1I),(p2I)           :",
          ok(sp.simplify(soli[p1]-p1p)==0 and sp.simplify(soli[p2]-p2p)==0))

    # (6) H, N2, d2pi/dbeta2
    PiI = sp.simplify(obj.subs(soli))
    d2a = sp.simplify(sp.diff(PiI, a, 2))
    Hp = ((s+4)**2*(3*s+4)**2 - 2*(s+2)*(3*s+4)**2*uB**2
          - 2*(3*s+4)*(s*(7*s+32)+32)*uB*uS
          - 2*(s*(s*(7*s+40)+64)+32)*uS**2)
    print(" 6. d2Pi/da2 = -2H/[(s+4)^2(3s+4)^2 M]      :",
          ok(sp.simplify(d2a + 2*Hp/((s+4)**2*(3*s+4)**2*M))==0))
    beta = sp.Symbol('beta')
    PiB = sp.simplify(PiI.subs(b2, beta*r))
    d2b = sp.simplify(sp.diff(PiB, beta, 2))
    print("    d2Pi/dbeta2                             :",
          ok(sp.simplify(d2b + 4*(s+1)*(s+2)*(s*(9*s+32)+32)*r**2/((s+4)**2*(3*s+4)**2*M))==0))
    det = sp.simplify(sp.diff(PiB,a,2)*sp.diff(PiB,beta,2) - sp.diff(PiB,a,1,beta,1)**2)
    N2p = (9*s**3*((uB+uS)**2-2) + 5*s**2*(9*uB**2+22*uB*uS+9*uS**2-20)
           + 16*s*(5*uB**2+14*uB*uS+5*uS**2-12) + 16*((3*uB+uS)*(uB+3*uS)-8))
    print("    det Hessian = -4r^2(s+1)N2/[...M^2]     :",
          ok(sp.simplify(det + 4*r**2*(s+1)*N2p/((s+4)**2*(3*s+4)**2*M**2))==0))

    # (7) a_kill : lone adopter vs joint refusal (no fee collected under refusal)
    pi1s = sp.simplify((sol[p1]+b1)*D1.subs(sol))
    dev  = pi1s.subs({b1:b, b2:r-dl})
    noda = pi1s.subs({b1:r-dl, b2:r-dl, a:0})
    roots = sp.solve(sp.Eq(sp.numer(sp.together(sp.simplify(dev-noda))), 0), a)
    akp = (b-(r-dl))*(8+s*(8+s))/(2*uB*(4+3*s))
    print(" 7. a_kill                                  :",
          ok(any(sp.simplify(sp.factor(z-akp))==0 for z in roots)))

    # (8) subsidy branch: a_sub and the frontier delta-bar
    Pi_sub = sp.simplify((2*(r-b)*Dsym + a*qsym).subs(b, r-dl))
    a_sub = sp.simplify(sp.solve(sp.diff(Pi_sub, a), a)[0])
    asp = (s+2)*(uS*(v+r) - dl*(uB+uS))/(s+4-4*uB*uS)
    print(" 8. a_sub                                   :", ok(sp.simplify(a_sub-asp)==0))
    print("    Pi'' = 2 dq_S/da  (envelope)            :",
          ok(sp.simplify(sp.diff(Pi_sub,a,2) - 2*sp.diff(qsym.subs(b,r-dl),a))==0))

    # (9) bar-beta(delta): rival participation against the integrated firm
    pi2_host = sp.simplify(((soli[p2]+b2)*D2.subs(soli)))
    p1w,p2w = sp.symbols('p1w p2w')
    D1w = (2*v-(2+s)*p1w+s*p2w-2*uB*a)/(2*M); D2w = (2*v-(2+s)*p2w+s*p1w-2*uB*a)/(2*M)
    DSw = (uS*(2*v-p1w-p2w)-a)/M
    objw = (p1w+r)*D1w + a*DSw                       # M2 outside: no licensing margin
    solw = sp.solve([sp.diff(objw,p1w), sp.diff((p2w+(r-dl))*D2w,p2w)],[p1w,p2w],dict=True)[0]
    pi2_walk = sp.simplify((solw[p2w]+(r-dl))*D2w.subs(solw))
    bb = sp.solve(sp.Eq(pi2_host, pi2_walk), b2)
    bbar_paper = r*(1 - (dl/r)*(8+s*(8+s))/(8*(1+s)))
    print(" 9. bar-beta(delta) (rival participation)   :",
          ok(any(sp.simplify(sp.factor(z-bbar_paper))==0 for z in bb)))
    # the equation is quadratic in b2; the second root is the degenerate one at
    # which the rival's demand (hence both profits) vanishes.
    free = [z for z in bb if a not in sp.simplify(z).free_symbols]
    deg  = [z for z in bb if a in sp.simplify(z).free_symbols]
    D2h  = sp.simplify(D2.subs(soli))
    print("    the matching root is free of the fee a  :", ok(len(free)==1))
    D2w_ = sp.simplify(D2w.subs(solw))
    print("    the other root is spurious (D2 mirrored):",
          ok(len(deg)==1 and sp.simplify(D2h.subs(b2,deg[0]) + D2w_.subs(b2,deg[0]))==0))

    # (10) numeric layer agrees with the symbolic layer
    rng = np.random.default_rng(0); bad = 0
    for _ in range(400):
        u1, u2 = rng.uniform(0.02,0.9), rng.uniform(0.02,0.9)
        if Mof(u1,u2) <= 0.05: continue
        gg = rng.choice([1.0,4.0,8.0]); sg = sigma_of(u1,u2,gg)
        bb1, bb2, aa = rng.uniform(0,0.5), rng.uniform(0,0.5), rng.uniform(-1,1)
        P = prices_sep(u1,u2,sg,bb1,bb2,aa)
        f = sp.lambdify((uB,uS,s,b1,b2,a,v), sol[p1], 'numpy')
        if abs(P[0] - f(u1,u2,sg,bb1,bb2,aa,V_DEF)) > 1e-10: bad += 1
        Pi = prices_int(u1,u2,sg,bb2,aa)
        fi = sp.lambdify((uB,uS,s,b2,a,r,v), soli[p1], 'numpy')
        if abs(Pi[0] - fi(u1,u2,sg,bb2,aa,R_DEF,V_DEF)) > 1e-10: bad += 1
    print("10. numeric layer == symbolic layer         :", ok(bad==0), f"({bad} mismatches)")
