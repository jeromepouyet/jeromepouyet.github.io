# -*- coding: utf-8 -*-
"""rep5_figure.py -- Figure "welfare effect of integration against the
dominant-platform benchmark" (Online Appendix, Simulations).

Regenerates figB7-dominant.pdf at the premia used in the revised text.
Blue: the merger raises total welfare.  Red: it lowers it.  White: outside the
admissible set (sigma < 0, or N_2 >= 0, or no interior solution).
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rep_core import Mof, sigma_of, N2val
from rep5_dominance import benchmark_asym, integrated

G = 4.0
DELTAS = (0.0, 0.15, 0.3)
NGRID = 130
LO, HI = 0.005, 1.6

def panel(ax, dl):
    gr = np.linspace(LO, HI, NGRID)
    Z = np.full((NGRID, NGRID), np.nan)
    for i, uS in enumerate(gr):
        for j, uB in enumerate(gr):
            if Mof(uB, uS) <= 0: continue
            sig = sigma_of(uB, uS, G)
            if sig < 0 or N2val(uB, uS, sig) >= 0: continue
            s = benchmark_asym(uB, uS, G, dl); i2 = integrated(uB, uS, G, dl)
            if s is None or i2 is None: continue
            Z[i, j] = 1.0 if (i2[6] - s['W']) > 0 else 0.0
    cmap = matplotlib.colors.ListedColormap(["#d62728", "#1f77b4"])
    ax.imshow(Z, origin="lower", extent=[LO, HI, LO, HI], aspect="auto",
              cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
    xs = np.linspace(LO, HI, 400)
    ax.plot(xs, np.clip(G/(2*(1+G)*xs), 0, HI), color="k", lw=1.0)   # sigma = 0
    ax.plot([0, HI], [0, HI], color="k", lw=0.6, ls=(0, (3, 3)))     # u_S = u_B
    ax.set_xlim(0, HI); ax.set_ylim(0, HI)
    ax.set_xlabel(r"$u_B$"); ax.set_ylabel(r"$u_S$")
    ax.set_title(r"$\Delta W$, $\delta = %.2f$" % dl, fontsize=10)

if __name__ == "__main__":
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.4))
    for ax, dl in zip(axes, DELTAS):
        panel(ax, dl); print("panel delta = %.2f done" % dl, flush=True)
    plt.tight_layout()
    fig.savefig("figB7-dominant.pdf", bbox_inches="tight")
    print("written: figB7-dominant.pdf")
    # share of the admissible grid on which welfare falls, same grid as the figure
    for dl in DELTAS:
        neg = tot = 0
        gr = np.linspace(LO, HI, NGRID)
        for uS in gr:
            for uB in gr:
                if Mof(uB,uS) <= 0: continue
                sig = sigma_of(uB,uS,G)
                if sig < 0 or N2val(uB,uS,sig) >= 0: continue
                s = benchmark_asym(uB,uS,G,dl); i2 = integrated(uB,uS,G,dl)
                if s is None or i2 is None: continue
                tot += 1
                if i2[6]-s['W'] < 0: neg += 1
        print("  delta=%.2f : W falls at %d/%d = %.0f%% of the figure grid" %
              (dl, neg, tot, 100*neg/tot))
