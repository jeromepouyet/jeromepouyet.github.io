# -*- coding: utf-8 -*-
"""rep11_welfare_sub.py -- Proposition 5(i) on the set A.

Online Appendix B.2 reports, as a check on an analytic result, that Delta W > 0
at every subsidizing admissible point.  The count is taken here on A itself,
A = {2 u_B u_S < 1, sigma >= 0, H > 0, D_2(a**) > 0}, on the reference grid
(step 0.02 over [0.02, 1.40]) at v = 2, r = 1/2.  b5j.py runs the same sweep on
the strictly smaller two-instrument set {N_2 < 0}, which is why its total is
1,326 rather than 1,413.
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (sigma_of, Mof, Hval, N2val, demands, prices_int,
                      surpluses, V_DEF, R_DEF)
from rep1_frontiers import a_star

V, R = V_DEF, R_DEF

def welfare(uB, uS, g, a):
    sig = sigma_of(uB, uS, g)
    p1, p2 = prices_int(uB, uS, sig, R, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
    return VB + VS + (p1 + R)*D1 + a*q + (p2 + R)*D2

def sweep(g, screen):
    gr = np.arange(0.02, 1.402, 0.02)
    n = sub = pos = 0
    for u1 in gr:
        for u2 in gr:
            if Mof(u1, u2) <= 0: continue
            sig = sigma_of(u1, u2, g)
            if sig < 0: continue
            if screen == 'A':
                if Hval(u1, u2, sig) <= 0: continue
                a = a_star(u1, u2, sig)
                p1, p2 = prices_int(u1, u2, sig, R, a)
                if demands(u1, u2, sig, p1, p2, a)[1] <= 0: continue
            else:                                   # the two-instrument set
                if N2val(u1, u2, sig) >= 0: continue
                a = a_star(u1, u2, sig)
            n += 1
            if a < 0:
                sub += 1
                if welfare(u1, u2, g, a) - welfare(u1, u2, g, 0.0) > 0: pos += 1
    return n, sub, pos

print("Proposition 5(i): Delta W > 0 on the subsidizing side\n")
print("%-6s %-8s %-9s %-14s %-9s" % ("gamma", "set", "points", "subsidizing", "dW > 0"))
tot = {}
for screen, label in [('A', 'A'), ('N2', '{N_2<0}')]:
    t = 0
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        n, sub, pos = sweep(g, screen)
        print("%-6g %-8s %-9d %-14d %-9d" % (g, label, n, sub, pos))
        t += pos
    tot[label] = t
print("\ntotal on A       : %d  (the figure reported in B.2)" % tot['A'])
print("total on {N_2<0} : %d  (what b5j.py sweeps)" % tot['{N_2<0}'])
print("\nno exception on either set.")
