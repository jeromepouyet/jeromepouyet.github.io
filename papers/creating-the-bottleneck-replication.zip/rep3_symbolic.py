# -*- coding: utf-8 -*-
"""rep3_symbolic.py -- the symbolic layer of the contract-space block.

Regenerates every closed form the appendix displays from the primitives of the
model and checks it against the printed expression.  Sixteen checks; about ten
minutes.  Run it as `python3 rep3_symbolic.py`, or through
`python3 rep3_contracts.py --symbolic`.
"""
import sympy as sp

uB, uS, v, r, g = sp.symbols('u_B u_S v r gamma', positive=True)
a = sp.Symbol('a')
b1, b2 = sp.symbols('b1 b2')
p1, p2 = sp.symbols('p1 p2')
beta1, beta2, beta = sp.symbols('beta1 beta2 beta')
S = sp.Symbol('sigma')                     # only for writing the target forms

s = g - 2*uB*uS*(1+g)                      # sigma, in terms of the primitives
M = 1 - 2*uB*uS
D1 = (2*v-(2+s)*p1+s*p2-2*uB*a)/(2*M)
D2 = (2*v-(2+s)*p2+s*p1-2*uB*a)/(2*M)
DS = (uS*(2*v-p1-p2)-a)/M
sol = sp.solve([sp.diff((p1+b1)*D1, p1), sp.diff((p2+b2)*D2, p2)], [p1, p2], dict=True)[0]
P1, P2 = sol[p1], sol[p2]
d1, d2, qs = D1.subs(sol), D2.subs(sol), DS.subs(sol)
pi1, pi2 = (P1+b1)*d1, (P2+b2)*d2
pibench = sp.simplify(pi1.subs({b1: r, b2: r, a: 0}))
host = {b1: beta1*r, b2: r}                 # host-one
both = {b1: beta1*r, b2: beta2*r}           # both-host

ok = lambda c: "PASS" if c else "**FAIL**"
def T(e): return e.subs(S, s)               # write a sigma-form target in primitives
n = [0]
def check(label, cond):
    n[0] += 1; print("%2d. %-46s %s" % (n[0], label, ok(cond)))

print("rep3_symbolic -- closed forms of the contract-space block\n")

# --- outcome equivalence at beta^2 = 1
check("pi2_both(b1,1,a) = pi_walk(b1,a)",
      sp.simplify(pi2.subs({b1: beta1*r, b2: r}) - pi2.subs(host)) == 0)
check("host and platform profits agree at beta^2 = 1",
      sp.simplify(pi1.subs(both).subs(beta2,1) - pi1.subs(host)) == 0 and
      sp.simplify((((1-beta1)*r*d1+(1-beta2)*r*d2+a*qs).subs(both).subs(beta2,1))
                  - ((1-beta1)*r*d1+a*qs).subs(host)) == 0)

# --- the rival's markup rises in its own share, at a rate free of (beta^1, a)
dm2 = sp.simplify(sp.diff(sp.simplify((P2+b2).subs(both)), beta2))
check("dm2/dbeta2 = r(8+s(8+s))/((4+s)(4+3s))",
      sp.simplify(dm2 - T(r*(8+S*(8+S))/((4+S)*(4+3*S)))) == 0)
check("  and it is independent of beta^1 and of a",
      sp.simplify(sp.diff(dm2, beta1)) == 0 and sp.simplify(sp.diff(dm2, a)) == 0)

# --- the calibrated share
roots = sp.solve(sp.Eq(sp.simplify(pi1.subs(host)), pibench), beta1)
good = [z for z in roots if sp.simplify(sp.simplify(z).subs(a, 0) - 1) == 0]
check("bar-beta exists and bar-beta(0) = 1", len(good) == 1)
bbar = sp.simplify(good[0])
check("bar-beta is affine in a", sp.simplify(sp.diff(bbar, a, 2)) == 0)
check("bar-beta' = 2uB(3s+4)/(r(s^2+8s+8))",
      sp.simplify(sp.diff(bbar, a) - T(2*uB*(3*S+4)/(r*(S**2+8*S+8)))) == 0)

pth = lambda e: e.subs(host).subs(beta1, bbar)
Phi = sp.simplify(pth((P1+r)*d1 + a*qs) - pibench)
check("Phi(0) = 0", sp.simplify(Phi.subs(a, 0)) == 0)
Phi2 = sp.simplify(sp.diff(Phi, a, 2))
check("Phi'' = -2[g(s+2)+2(3s+4)]/(8+s(8+s))",
      sp.simplify(Phi2 - T(-2*(g*(S+2)+2*(3*S+4))/(8+S*(8+S)))) == 0)
check("Phi'' = 2 dq_S/da along the path",
      sp.simplify(Phi2 - 2*sp.diff(pth(qs), a)) == 0)
Phi1 = sp.simplify(sp.diff(Phi, a).subs(a, 0))
check("Phi'(0), closed form",
      sp.simplify(Phi1 - T(2*(v+r)*(S+2)*((8+S*(8+S))*uS-(4+3*S)*uB)
                           / ((1-2*uB*uS)*(S+4)*(8+S*(8+S))))) == 0)
check("a-hat = -Phi'(0)/Phi'', closed form",
      sp.simplify(-Phi1/Phi2 - T((v+r)*(S+2)*((8+S*(8+S))*uS-(4+3*S)*uB)
                                 / ((1-2*uB*uS)*(S+4)*(g*(S+2)+2*(3*S+4))))) == 0)

# --- surplus gradients along the calibrated path
check("dm2/da = -4uB(s+1)/(s^2+8s+8)",
      sp.simplify(sp.diff(sp.simplify(pth(P2+b2)), a) - T(-4*uB*(S+1)/(S**2+8*S+8))) == 0)
VB = (v*(d1+d2) + uB*qs*(d1+d2) - (2*(d1**2+d2**2)+g*(d1+d2)**2)/(4*(1+g)) - P1*d1 - P2*d2)
check("DV_B'(0), closed form",
      sp.simplify(sp.diff(sp.simplify(pth(VB)), a).subs(a, 0)
                  - T(-2*uB*(v+r)*(S+1)*(S+2)**2
                      / ((S+4)*(1-2*uB*uS)**2*(S**2+8*S+8)))) == 0)
check("DV_S'(0) = q^bench dq_S/da",
      sp.simplify(sp.diff(pth(qs)**2/2, a).subs(a, 0)
                  - sp.simplify(qs.subs({b1: r, b2: r, a: 0}))*sp.diff(pth(qs), a)) == 0)
W = pth(VB) + pth(qs)**2/2 + pth((P1+r)*d1) + pth((P2+r)*d2) + pth(a*qs)
dW = sp.together(sp.diff(W, a).subs(a, 0)
                 - T(-2*uB*(v+r)*(S+2)*((S+1)*(S+2)*(1+2*uS**2)+(7*S+8)*(1-2*uB*uS))
                     / ((S+4)*(1-2*uB*uS)**2*(S**2+8*S+8))))
check("DW'(0), closed form", sp.simplify(sp.numer(dW)) == 0)

# --- the platform's take off the participation constraint
P = sp.simplify(((1-beta)*r*d1 + a*qs).subs({b1: beta*r, b2: r}))
check("P(beta,a) is strictly concave in beta",
      sp.simplify(sp.diff(P, beta, 2)
                  + T(r**2*(S+2)*(S**2+8*S+8)/((1-2*uB*uS)*(S+4)*(3*S+4)))) == 0)
bb = sp.simplify([z for z in sp.solve(sp.Eq(sp.simplify(pi1.subs({b1: beta*r, b2: r})), pibench), beta)
                  if sp.simplify(sp.simplify(z).subs(a, 0) - 1) == 0][0])
check("dP/dbeta at bar-beta prop. to -[(v+r)-a(uS-uB)]",
      sp.simplify(sp.diff(P, beta).subs(beta, bb)
                  + T(r*(S+2)/((S+4)*(1-2*uB*uS)))*((v+r)-a*(uS-uB))) == 0)

# --- the both-host consolidated surplus and the three ratio frontiers
sym = {b1: beta*r, b2: beta*r}
J = sp.simplify(((P1+r)*d1 + (P2+r)*d2 + a*qs).subs(sym))
check("dJ/dbeta at beta=1, and the threshold a_J",
      sp.simplify(sp.diff(J, beta).subs(beta, 1)
                  - T(2*r*(S+2)*(S*(uB+uS)+4*uS)/((1-2*uB*uS)*(S+4)**2))
                    *(a - (v+r)*s/(s*(uB+uS)+4*uS))) == 0)
check("J'(0) at beta=1, closed form",
      sp.simplify(sp.diff(J, a).subs({beta: 1, a: 0})
                  - T(2*(v+r)*(S+2)/((1-2*uB*uS)*(S+4)**2))
                    *((4+g)*uS - (4+2*(1+g)*uS**2)*uB)) == 0)
z = sp.Symbol('sigma', nonnegative=True)
RJ, RP, RA = (4+z)/4, (8+z*(8+z))/(4+3*z), (3*z*(z*(z+7)+16)+32)/(2*(z+2)*(3*z+4))
check("R_Phi - R_J = (s^2+16s+16)/(4(3s+4)) > 0",
      sp.simplify(RP - RJ - (z**2+16*z+16)/(4*(3*z+4))) == 0)
check("R_a - R_Phi = s^2(s+1)/(2(s+2)(3s+4)) >= 0",
      sp.simplify(RA - RP - z**2*(z+1)/(2*(z+2)*(3*z+4))) == 0)
