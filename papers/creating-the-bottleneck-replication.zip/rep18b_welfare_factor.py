# -*- coding: utf-8 -*-
"""rep18b_welfare_factor.py -- the welfare ranking of contract and merger.

Companion to rep18_contract_vs_merger.py.  Establishes symbolically that
K = Lambda u_S - (2+sigma)(4+3sigma) u_B divides EXACTLY the welfare difference
W(contract at a_hat) - W(integration at a**), and checks the sign of the
cofactor on the reference grid.  Runtime about ten minutes (one large
expansion).
"""
import sympy as sp, numpy as np, time, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
t0 = time.time()
uB,uS,s,g,v,r,a = sp.symbols('u_B u_S sigma gamma v r a', positive=True)
M=1-2*uB*uS; Lam=8+s*(8+s); Tht=3*s*(s*(s+7)+16)+32
H=((s+4)**2*(3*s+4)**2-2*(s+2)*(3*s+4)**2*uB**2-2*(3*s+4)*(s*(7*s+32)+32)*uB*uS-2*(s*(s*(7*s+40)+64)+32)*uS**2)
K=Lam*uS-(2+s)*(4+3*s)*uB
def dem(p1,p2,aa):
    return ((2*v-(2+s)*p1+s*p2-2*uB*aa)/(2*M),(2*v-(2+s)*p2+s*p1-2*uB*aa)/(2*M),(uS*(2*v-p1-p2)-aa)/M)
def psep(b1,b2,aa):
    den=(4+s)*(4+3*s)
    return ((-2*uB*aa*(4+3*s)+2*v*(4+3*s)-(2+s)*(s*b2+2*(2+s)*b1))/den,
            (-2*uB*aa*(4+3*s)+2*v*(4+3*s)-(2+s)*(s*b1+2*(2+s)*b2))/den)
def pint(b2,aa):
    c=(2*v-r-aa*(2*uB+uS)+3*b2)/(4+s)
    return (-b2+c+(b2-r-aa*uS)/(4+3*s), -b2+c+(r+aa*uS-b2)/(4+3*s))
def VB(p1,p2,D1,D2,q):
    return v*(D1+D2)+uB*q*(D1+D2)-(2*(D1**2+D2**2)+g*(D1+D2)**2)/(4*(1+g))-p1*D1-p2*D2
gsub={g:(s+2*uB*uS)/M}                       # gamma as a function of sigma on the plane
bb=1+a*2*uB*(3*s+4)/(r*Lam)
Phi_p0=2*(v+r)*(s+2)*(Lam*uS-(4+3*s)*uB)/(M*(s+4)*Lam); Phi_pp=-2*(g*(s+2)+2*(3*s+4))/Lam
ah=(-Phi_p0/Phi_pp).subs(gsub)
p1B,p2B=psep(bb.subs(a,ah)*r, r, ah); D1B,D2B,qB=dem(p1B,p2B,ah)
WB=(VB(p1B,p2B,D1B,D2B,qB)+qB**2/2+(p1B+r)*D1B+(p2B+r)*D2B+ah*qB).subs(gsub)
PiI_p0=2*(v+r)*(Tht*uS-2*(s+2)*(3*s+4)*uB)/((s+4)**2*(3*s+4)*M); PiI_pp=-2*H/((s+4)**2*(3*s+4)**2*M)
ast=-PiI_p0/PiI_pp
p1C,p2C=pint(r,ast); D1C,D2C,qC=dem(p1C,p2C,ast)
WC=(VB(p1C,p2C,D1C,D2C,qC)+qC**2/2+(p1C+r)*D1C+ast*qC+(p2C+r)*D2C).subs(gsub)
num,den=sp.fraction(sp.together(WB-WC))
print("assembled (%.0fs); expanding the numerator ..." % (time.time()-t0)); t0=time.time()
num=sp.expand(num)
print("  %d terms (%.0fs)" % (len(num.args), time.time()-t0)); t0=time.time()
q_,rem=sp.div(sp.Poly(num,uB,uS), sp.Poly(sp.expand(K),uB,uS))
print("K divides the numerator of W_B - W_C exactly :", "PASS" if rem.is_zero else "**FAIL**")
cof=q_.as_expr()
den_f=sp.factor(den)
print("denominator :", den_f)
print("  (a product of squares and of (sigma+1)(sigma+4)^4(3sigma+4)^2 : positive on A)")
# sign of the cofactor on the reference grid
from rep_core import N2val, sigma_of, Mof, Hval, demands, prices_int, V_DEF, R_DEF
import rep3_contracts as C
fc=sp.lambdify((uB,uS,s,v,r), cof, 'numpy')
grid=np.arange(0.02,1.4001,0.02)
print("\nSign of the cofactor where both instruments are active (a_hat>0, a**>0), reference grid:")
print("  %-6s %-8s %-10s %-10s" % ("gamma","points","cof < 0","cof >= 0"))
for gg in (0.5,1.0,2.0,4.0,8.0,16.0):
    n=neg=0
    for x in grid:
        for y in grid:
            if Mof(x,y)<=0: continue
            sg=sigma_of(x,y,gg)
            if sg<0 or Hval(x,y,sg)<=0: continue
            if N2val(x,y,sg)>=0: continue
            aa=C.a_star(x,y,sg); q1,q2=prices_int(x,y,sg,R_DEF,aa)
            if demands(x,y,sg,q1,q2,aa)[1]<=0: continue
            if C.Phi_prime0(x,y,sg)<=0 or C.PiI_prime0(x,y,sg)<=0: continue
            n+=1; neg+= float(fc(x,y,sg,V_DEF,R_DEF))<0
    print("  %-6.3g %-8d %-10d %-10d" % (gg,n,neg,n-neg))
print("\nHence W_B < W_C  <=>  K > 0  <=>  u_B/u_S < R_p(sigma), on the stated domain.")
