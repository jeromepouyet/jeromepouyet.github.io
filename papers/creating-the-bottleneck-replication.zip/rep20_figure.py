import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.colors
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from rep_core import sigma_of
import rep3_contracts as C
gr=np.load('/tmp/map9_grid.npy'); LO,HI=gr[0],gr[-1]; G=4.0
# palette of the paper's own figures
GREY="#e6e6e6"; SAND="#f3d9a4"; AMBER="#d9962a"; GREEN="#7bb26a"; INK="#222222"
cmap=matplotlib.colors.ListedColormap([GREEN,GREY,SAND,AMBER])
fig,axes=plt.subplots(1,2,figsize=(11.4,5.9))
X,Y=np.meshgrid(gr,gr)
RA=np.full_like(X,np.nan)
for i,x in enumerate(gr):
    for j,y in enumerate(gr):
        sg=sigma_of(x,y,G)
        if sg>=0: RA[j,i]=x/y-C.R_a(sg)
for ax,d,tag in zip(axes,(0.1,0.3),('a','b')):
    Z=np.load('/tmp/map9_%s.npy'%str(d).replace('.','p'))
    ax.imshow(Z,origin="lower",extent=[LO,HI,LO,HI],cmap=cmap,vmin=-0.5,vmax=3.5,
              interpolation="nearest")
    ax.plot([LO,HI],[LO,HI],color=INK,lw=0.8,ls=":")
    ax.contour(X,Y,RA,levels=[0.0],colors=INK,linewidths=1.1,linestyles="dashed")
    ax.set_title(r"(%s)  $\delta = %.1f$"%(tag,d),fontsize=13)
    ax.set_xlabel(r"$u_B$",fontsize=13); ax.set_ylabel(r"$u_S$",fontsize=13)
    ax.set_xlim(LO,HI); ax.set_ylim(LO,HI); ax.set_aspect("equal"); ax.tick_params(labelsize=10.5)
    tot=np.sum(~np.isnan(Z))
    for v,xy,lab in [(3,(0.16,0.95),"cap, tax"),(2,(0.42,0.60),"interior, tax"),
                     (1,(0.88,0.30),"floor, no fee"),(0,(1.15,0.10),"floor, subsidize")]:
        s=100*np.sum(Z==v)/tot
        ax.annotate("%s\n%.0f%%"%(lab,s),xy,fontsize=9.5,ha="center",
                    color="#5a3d0a" if v in (2,3) else ("#2f5a22" if v==0 else "#444"),
                    fontweight="bold" if v==1 else "normal")
    ax.text(1.20,1.30,r"$u_B=u_S$",fontsize=9,rotation=45,color=INK,ha="center")
axes[1].text(0.68,0.50,r"$u_B=h(u_S)$",fontsize=9,rotation=-72,color=INK)
fig.legend(handles=[Patch(color=AMBER,label=r"$\beta=1$, $a>0$ — gives up the whole premium to tax"),
                    Patch(color=SAND,label=r"$1-\delta/r<\beta<1$, $a>0$ — hands back part of it"),
                    Patch(color=GREY,label=r"$\beta=1-\delta/r$, $a=0$ — keeps the premium, leaves the developer alone"),
                    Patch(color=GREEN,label=r"$\beta=1-\delta/r$, $a<0$ — keeps the premium and subsidizes"),
                    Line2D([0],[0],color=INK,lw=1.1,ls="dashed",label=r"$u_B=h(u_S)$, the integrated firm's no-tax frontier")],
           loc="lower center",ncol=1,fontsize=10.5,frameon=False,bbox_to_anchor=(0.5,-0.20))
fig.suptitle("What a dominant platform does under separation, by the signs of $\\beta$ and $a$\n"
             r"($\gamma=4$, $v=2$, $r=1/2$; admissible set $\{N_2<0\}$, step $0.01$)",fontsize=12.5,y=1.02)
plt.tight_layout()
fig.savefig("prop9-map.png",dpi=170,bbox_inches="tight")
fig.savefig("prop9-map.pdf",bbox_inches="tight")
print("written")
