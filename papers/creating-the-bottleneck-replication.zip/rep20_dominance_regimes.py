import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import sigma_of, Mof, N2val, Hval, demands, prices_sep, V_DEF, R_DEF
V,R=V_DEF,R_DEF

def coeffs(uB,uS,sg,d):
    """Pi(x,a) = 2(d-x)D(x,a) + a qS(x,a) is a quadratic; fit its 6 coefficients exactly."""
    def Pi(x,a):
        b=(x+R-d)/R
        p1,p2=prices_sep(uB,uS,sg,b*R,b*R,a); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
        return 2*(d-x)*D1 + a*q
    P=[(0,0),(1,0),(0,1),(1,1),(2,0),(0,2)]
    A=np.array([[1,x,a,x*x,x*a,a*a] for x,a in P],float)
    return np.linalg.solve(A,np.array([Pi(x,a) for x,a in P]))
def val(c,x,a): return c[0]+c[1]*x+c[2]*a+c[3]*x*x+c[4]*x*a+c[5]*a*a
def interior(uB,uS,sg,d,x,a):
    b=(x+R-d)/R
    p1,p2=prices_sep(uB,uS,sg,b*R,b*R,a); D1,D2,q=demands(uB,uS,sg,p1,p2,a)
    return D1>0 and q>0

def solve(uB,uS,sg,d):
    k=(8+sg*(8+sg))/(2*uB*(4+3*sg))
    c=coeffs(uB,uS,sg,d)
    cand=[]
    # interior stationary point
    Hm=np.array([[2*c[3],c[4]],[c[4],2*c[5]]]); g=-np.array([c[1],c[2]])
    try:
        xs,as_=np.linalg.solve(Hm,g)
        if -1e-9<=xs<=d+1e-9 and as_<=k*xs+1e-9: cand.append(('interior',xs,as_))
    except np.linalg.LinAlgError: pass
    # edge x=0 : a<=0
    if abs(c[5])>1e-14:
        a0=-c[2]/(2*c[5])
        if a0<=0: cand.append(('floor',0.0,a0))
    cand.append(('floor',0.0,0.0))                                  # vertex (0,0)
    # edge x=d : a<=k d
    if abs(c[5])>1e-14:
        a1=-(c[2]+c[4]*d)/(2*c[5])
        if a1<=k*d: cand.append(('cap',d,a1))
    cand.append(('cap',d,k*d))                                      # vertex (d,kd)
    # edge a = k x, 0<=x<=d
    A2=c[3]+c[4]*k+c[5]*k*k; A1=c[1]+c[2]*k
    if abs(A2)>1e-14:
        xe=-A1/(2*A2)
        if 0<=xe<=d: cand.append(('edge',xe,k*xe))
    best=(-1e18,None)
    for lab,x,a in cand:
        if not interior(uB,uS,sg,d,x,a): continue
        v=val(c,x,a)
        if v>best[0]: best=(v,(lab,x,a,k))
    return best[1]

G=4.0; STEP=0.01; gr=np.arange(0.02,1.4001,STEP); n=len(gr)
for d in (0.1,0.3):
    Z=np.full((n,n),np.nan)
    for i,x in enumerate(gr):
        for j,y in enumerate(gr):
            if Mof(x,y)<=0: continue
            sg=sigma_of(x,y,G)
            if sg<0 or N2val(x,y,sg)>=0: continue
            s=solve(x,y,sg,d)
            if s is None: continue
            lab,xx,aa,k=s
            if xx<1e-7 and aa<-1e-6:   Z[j,i]=0     # floor, subsidize
            elif xx<1e-7:              Z[j,i]=1     # floor, a=0
            elif xx>d-1e-7:            Z[j,i]=3     # cap, tax
            else:                      Z[j,i]=2     # interior, tax
    np.save('/tmp/map9_%s.npy'%str(d).replace('.','p'),Z)
    tot=np.sum(~np.isnan(Z))
    print("delta=%.1f  %d points"%(d,tot))
    for v,lab in [(0,'floor, subsidize'),(1,'floor, a=0'),(2,'interior, tax'),(3,'cap, tax')]:
        print("   %-20s %5d  (%4.1f%%)"%(lab,np.sum(Z==v),100*np.sum(Z==v)/tot))
np.save('/tmp/map9_grid.npy',gr)
