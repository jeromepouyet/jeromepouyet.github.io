# -*- coding: utf-8 -*-
"""rep3_contracts.py -- the contract space (Proposition on the cap, Appendix on
contracts, Online Appendix "The Contract Space").  Replaces b5c.py--b5h.py,
verifD.py, verifE.py, verifE2.py and b5d.py.

Two layers.

  * Symbolic (run with --symbolic, which simply runs rep3_symbolic.py; about
    two minutes): every closed form the appendix displays is regenerated from
    the primitives of rep_core and checked against the printed expression.
    Twenty-two checks.
  * Numerical (default): the calibrated single-host path, the wedge against the
    integrated firm, and the game-consistent search over posted packages
    (beta^1, beta^2, a) with the cap removed, in which the 2x2 adoption game is
    solved exactly at each package and the joint-profit selection rule applied.

The convention that makes the adoption game well posed: under joint refusal no
device runs the platform's system, so a positive fee cannot be collected, while
a subsidy is paid in every configuration (the developer publishes regardless).
"""
import sys
import numpy as np
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_sep, admissible,
                      prices_int, surpluses, Hval, N2val)

V, R = V_DEF, R_DEF

# =============================================================== closed forms
def Lam(sig):            return 8 + sig*(8 + sig)
def bbar(uB, uS, sig, a, r=R):
    """Calibrated share: the host is held exactly at its benchmark profit.
    Affine in a, equal to one at a = 0."""
    return 1.0 + a*2*uB*(3*sig+4)/(r*(sig*sig + 8*sig + 8))
def Phi_prime0(uB, uS, sig, v=V, r=R):
    return 2*(v+r)*(sig+2)*(Lam(sig)*uS - (4+3*sig)*uB)/(Mof(uB,uS)*(sig+4)*Lam(sig))
def Phi_second(sig, g):
    return -2*(g*(sig+2) + 2*(3*sig+4))/Lam(sig)
def a_hat(uB, uS, sig, g, v=V, r=R):
    return -Phi_prime0(uB,uS,sig,v,r)/Phi_second(sig,g)
def Phi(uB, uS, sig, g, a, v=V, r=R):
    return Phi_prime0(uB,uS,sig,v,r)*a + 0.5*Phi_second(sig,g)*a*a
def PiI_prime0(uB, uS, sig, v=V, r=R):
    return 2*(v+r)*((3*sig*(sig*(sig+7)+16)+32)*uS - 2*(sig+2)*(3*sig+4)*uB) \
           / ((sig+4)**2*(3*sig+4)*Mof(uB,uS))
def PiI_second(uB, uS, sig):
    return -2*Hval(uB,uS,sig)/((sig+4)**2*(3*sig+4)**2*Mof(uB,uS))
def a_star(uB, uS, sig, v=V, r=R):
    return -PiI_prime0(uB,uS,sig,v,r)/PiI_second(uB,uS,sig)
def PiI_gain(uB, uS, sig, v=V, r=R):
    a = a_star(uB,uS,sig,v,r)
    return PiI_prime0(uB,uS,sig,v,r)*a + 0.5*PiI_second(uB,uS,sig)*a*a
def a_J(uB, uS, sig, v=V, r=R):
    return (v+r)*sig/(sig*(uB+uS) + 4*uS)
def R_J(sig):    return (4+sig)/4.0
def R_Phi(sig):  return Lam(sig)/(4+3*sig)
def R_a(sig):    return (3*sig*(sig*(sig+7)+16)+32)/(2*(sig+2)*(3*sig+4))

# ========================================================= the adoption game
def _cfg(uB, uS, sig, b1, b2, a):
    p1, p2 = prices_sep(uB, uS, sig, b1, b2, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    return dict(D1=D1, D2=D2, q=q, p1=p1, p2=p2,
                pi1=(p1+b1)*D1, pi2=(p2+b2)*D2)

def _interior(c, b1, b2):
    return (c['D1'] > 0 and c['D2'] > 0 and c['q'] > 0
            and c['p1']+b1 > 0 and c['p2']+b2 > 0)

def game(uB, uS, g, beta1, beta2, a, r=R):
    """Solve the 2x2 adoption game at package (beta^1, beta^2, a); return the
    platform's value at the equilibrium picked by the joint-profit selection
    rule, or None if some configuration is not interior or no pure equilibrium
    exists.  Ties in the acceptance decision go to acceptance, and ties in
    the selection go to adoption (Section 2.3 of the paper): max() returns
    the first maximal element and 'AA' is listed first."""
    sig = sigma_of(uB, uS, g)
    ae = a if a < 0 else 0.0                    # no fee collected on joint refusal
    C = {'AA': _cfg(uB,uS,sig, beta1*r, beta2*r, a),
         'AR': _cfg(uB,uS,sig, beta1*r, r,       a),
         'RA': _cfg(uB,uS,sig, r,       beta2*r, a),
         'RR': _cfg(uB,uS,sig, r,       r,       ae)}
    for k, (b1, b2) in [('AA',(beta1*r,beta2*r)), ('AR',(beta1*r,r)),
                        ('RA',(r,beta2*r)),       ('RR',(r,r))]:
        if not _interior(C[k], b1, b2): return None
    pay = {k: (C[k]['pi1'], C[k]['pi2']) for k in C}
    t, NE = 1e-12, []
    for prof, alt1, alt2 in [('AA','RA','AR'), ('AR','RR','AA'),
                             ('RA','AA','RR'), ('RR','AR','RA')]:
        d1 = pay[alt1][0] - pay[prof][0]; d2 = pay[alt2][1] - pay[prof][1]
        ok1 = d1 < -t or (abs(d1) <= t and prof[0] == 'A')
        ok2 = d2 < -t or (abs(d2) <= t and prof[1] == 'A')
        if ok1 and ok2: NE.append(prof)
    if not NE: return None
    sel = max(NE, key=lambda k: pay[k][0] + pay[k][1])
    c = C[sel]
    val = {'AA': (1-beta1)*r*c['D1'] + (1-beta2)*r*c['D2'] + a*c['q'],
           'AR': (1-beta1)*r*c['D1'] + a*c['q'],
           'RA': (1-beta2)*r*c['D2'] + a*c['q'],
           'RR': 0.0}[sel]
    return val, sel

def game_search(uB, uS, g, amax=3.0, bmax=3.0, na=121, nb=61, r=R):
    """Sweep packages, including the calibrated slivers bar-beta(a)+eps so that
    the participation-binding packages are hit exactly."""
    sig = sigma_of(uB, uS, g); best = (0.0, ('--','--','--','RR'))
    for a in np.linspace(0.0, amax, na):
        cands = sorted(set(list(np.linspace(1.0, bmax, nb)) + [bbar(uB,uS,sig,a)+1e-9]))
        for b1 in cands:
            for b2 in cands:
                out = game(uB, uS, g, b1, b2, a, r)
                if out and out[0] > best[0]:
                    best = (out[0], (b1, b2, a, out[1]))
    return best

# --------------------------------------------- the same search, vectorised
# Identical arithmetic and identical selection rule; the sweep over
# (beta^1, beta^2) is carried out with numpy arrays instead of a double Python
# loop.  This is what makes the region-wide searches of rep2_statistics.py
# tractable.  Section G of the numerical block checks the two against each other.
_TOL = 1e-12

def _sep_vec(uB, uS, sig, b1, b2, a, v=V):
    den = (4+sig)*(4+3*sig)
    p1 = (-2*uB*a*(4+3*sig) + 2*v*(4+3*sig) - (2+sig)*(sig*b2 + 2*(2+sig)*b1))/den
    p2 = (-2*uB*a*(4+3*sig) + 2*v*(4+3*sig) - (2+sig)*(sig*b1 + 2*(2+sig)*b2))/den
    M = 1.0 - 2*uB*uS
    D1 = (2*v-(2+sig)*p1+sig*p2-2*uB*a)/(2*M)
    D2 = (2*v-(2+sig)*p2+sig*p1-2*uB*a)/(2*M)
    q  = (uS*(2*v-p1-p2)-a)/M
    return p1, p2, D1, D2, q, (p1+b1)*D1, (p2+b2)*D2

def game_grid(uB, uS, g, a, beta, r=R):
    """One fee, the whole (beta^1, beta^2) grid: the largest platform value
    among interior packages that have a pure equilibrium."""
    sig = sigma_of(uB, uS, g)
    ae = a if a < 0 else 0.0
    b = beta*r
    b1 = b[:, None]; b2 = b[None, :]
    one = np.ones((len(beta), len(beta)))
    AA = _sep_vec(uB, uS, sig, b1*one, b2*one, a)
    AR = _sep_vec(uB, uS, sig, b1*one, r*one, a)
    RA = _sep_vec(uB, uS, sig, r*one,  b2*one, a)
    RR = _sep_vec(uB, uS, sig, r, r, ae)
    def inter(C, x1, x2):
        return (C[2] > 0) & (C[3] > 0) & (C[4] > 0) & (C[0]+x1 > 0) & (C[1]+x2 > 0)
    ok = (inter(AA, b1, b2) & inter(AR, b1, r) & inter(RA, r, b2)
          & bool(RR[2] > 0 and RR[3] > 0 and RR[4] > 0
                 and RR[0]+r > 0 and RR[1]+r > 0))
    if not np.any(ok):
        return -np.inf, None, None
    P = {'AA': (AA[5], AA[6]), 'AR': (AR[5], AR[6]),
         'RA': (RA[5], RA[6]), 'RR': (RR[5]*one, RR[6]*one)}
    def dev(d, accept):
        return (d < -_TOL) | ((np.abs(d) <= _TOL) & accept)
    NE = {}
    for prof, x1, x2 in [('AA','RA','AR'), ('AR','RR','AA'),
                         ('RA','AA','RR'), ('RR','AR','RA')]:
        NE[prof] = (dev(P[x1][0]-P[prof][0], prof[0] == 'A')
                    & dev(P[x2][1]-P[prof][1], prof[1] == 'A'))
    bet1 = beta[:, None]*one; bet2 = beta[None, :]*one
    val = {'AA': (1-bet1)*r*AA[2] + (1-bet2)*r*AA[3] + a*AA[4],
           'AR': (1-bet1)*r*AR[2] + a*AR[4],
           'RA': (1-bet2)*r*RA[3] + a*RA[4],
           'RR': 0.0*one}
    joint = {k: P[k][0] + P[k][1] for k in P}
    bestJ = np.full(one.shape, -np.inf); pick = np.zeros(one.shape, dtype=int)
    for i, k in enumerate(['AA', 'AR', 'RA', 'RR']):
        take = NE[k] & (joint[k] > bestJ + 1e-15)
        bestJ = np.where(take, joint[k], bestJ); pick = np.where(take, i, pick)
    any_ne = NE['AA'] | NE['AR'] | NE['RA'] | NE['RR']
    out = np.full(one.shape, -np.inf)
    for i, k in enumerate(['AA', 'AR', 'RA', 'RR']):
        out = np.where((pick == i) & any_ne & ok, val[k], out)
    idx = np.unravel_index(np.argmax(out), out.shape)
    return out[idx], idx[0], idx[1]

def game_search_fast(uB, uS, g, amax=3.0, bmax=3.0, na=121, nb=61, r=R):
    """Same signature and same answer as game_search above."""
    sig = sigma_of(uB, uS, g)
    best = (0.0, (float("nan"), float("nan"), float("nan")))
    for a in np.linspace(0.0, amax, na):
        cands = np.array(sorted(set(list(np.linspace(1.0, bmax, nb))
                                    + [bbar(uB, uS, sig, a)+1e-9])))
        v, i, j = game_grid(uB, uS, g, a, cands, r)
        if v > best[0]:
            best = (v, (cands[i], cands[j], a))
    return best

# ==============================================================================
def numeric_block():
    G = 4.0
    REF = [(0.1,0.1), (0.3,0.1), (0.5,0.18), (0.15,1.0)]
    print("rep3_contracts -- numerical layer (gamma = 4, v = 2, r = 1/2)\n")

    print("A. The calibrated single-host path at the reference points")
    print("   %-13s %-9s %-11s %-9s %-9s" % ("(u_B,u_S)","a-hat","Phi(a-hat)","a**","a_J"))
    for (uB,uS) in REF:
        sig = sigma_of(uB,uS,G)
        print("   %-13s %-9.4f %-11.5f %-9.4f %-9.2f" %
              ("(%.2f,%.2f)"%(uB,uS), a_hat(uB,uS,sig,G), Phi(uB,uS,sig,G,a_hat(uB,uS,sig,G)),
               a_star(uB,uS,sig), a_J(uB,uS,sig)))

    print("\nB. Capture share Phi(a-hat) / integrated gain")
    for (uB,uS) in [(0.1,0.3),(0.1,0.1),(0.15,1.0)]:
        sig = sigma_of(uB,uS,G)
        print("   (%.2f,%.2f) : %.1f%%" %
              (uB,uS,100*Phi(uB,uS,sig,G,a_hat(uB,uS,sig,G))/PiI_gain(uB,uS,sig)))

    print("\nC. The wedge Phi'(0) - Pi^{I'}(0) takes both signs")
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        gr = np.arange(0.02, 1.402, 0.02)                 # reference grid
        c = t = 0
        for u1 in gr:
            for u2 in gr:
                if Mof(u1,u2) <= 0: continue
                sig = sigma_of(u1,u2,g)
                if sig < 0 or Hval(u1,u2,sig) <= 0: continue
                if N2val(u1,u2,sig) >= 0: continue
                a = a_star(u1,u2,sig)
                p1, p2 = prices_int(u1,u2,sig,R,a)
                if demands(u1,u2,sig,p1,p2,a)[1] <= 0: continue     # the set A
                t += 1
                if Phi_prime0(u1,u2,sig) - PiI_prime0(u1,u2,sig) >= 0: c += 1
        print("   gamma=%g : nonnegative at %d of %d points of A* (%.0f%%)"
              % (g, c, t, 100*c/t))

    print("\nD. Ratio frontiers  R_J < R_Phi < R_a")
    print("   %-8s %-10s %-10s %-10s" % ("sigma","R_J","R_Phi","R_a"))
    for s_ in (0.0, 1.0, 2.0, 3.0, 3.9):
        print("   %-8.1f %-10.4f %-10.4f %-10.4f" % (s_, R_J(s_), R_Phi(s_), R_a(s_)))

    print("\nE. Game-consistent search: the single-host optimum, second share at one")
    print("   %-13s %-11s %-11s %s" % ("(u_B,u_S)","Phi(a-hat)","game max","at (b1,b2,a)"))
    for (uB,uS) in REF:
        sig = sigma_of(uB,uS,G); ah = a_hat(uB,uS,sig,G)
        b = game_search(uB,uS,G, amax=max(0.6,3*ah), bmax=1.6, na=241, nb=121)
        print("   %-13s %-11.5f %-11.5f (%.3f, %.3f, %.3f)" %
              ("(%.2f,%.2f)"%(uB,uS), Phi(uB,uS,sig,G,ah), b[0], b[1][0], b[1][1], b[1][2]))

    print("\nF. Band points: no package earns anything (Proposition on the cap, part i)")
    for (uB,uS) in [(0.34,0.10),(0.543,0.17),(0.719,0.25),(0.885,0.40)]:
        sig = sigma_of(uB,uS,G)
        b = game_search(uB,uS,G, amax=1.5, bmax=2.0, na=61, nb=41)
        print("   (%.3f,%.2f) : Phi'(0) = %+.4f, game maximum = %.6f"
              % (uB,uS,Phi_prime0(uB,uS,sig),b[0]))

    print("\nG. The vectorised search returns the scalar search's answer")
    for (uB,uS) in REF + [(0.34,0.10),(0.2,0.6)]:
        a1 = game_search(uB,uS,G, amax=0.6, bmax=1.6, na=41, nb=21)[0]
        a2 = game_search_fast(uB,uS,G, amax=0.6, bmax=1.6, na=41, nb=21)[0]
        print("   (%.2f,%.2f) : %.8f vs %.8f  %s"
              % (uB,uS,a1,a2,"PASS" if abs(a1-a2) < 1e-10 else "**FAIL**"))

def publication_single_host():
    """Publication on the platform's store at the single-host package
    (beta^1 = bar-beta(a-hat), M2 outside, fee a-hat): u_S n_B^1 >= a-hat,
    where n_B^1 = D_1 is the demand of the only device running the platform's
    system.  Reference grid, the six gamma, every taxing point of A."""
    print("\nH. Publication at the single-host package (u_S D_1 >= a-hat)")
    gr = np.arange(0.02, 1.4001, 0.02)
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        tot = fail = 0; mn = np.inf
        for uB in gr:
            for uS in gr:
                sig = sigma_of(uB, uS, g)
                if sig < 0 or not admissible(uB, uS, g, False): continue
                if Phi_prime0(uB, uS, sig) <= 0: continue
                ah = a_hat(uB, uS, sig, g)
                p1, p2 = prices_sep(uB, uS, sig, bbar(uB, uS, sig, ah)*R, R, ah)
                D1, D2, q = demands(uB, uS, sig, p1, p2, ah)
                tot += 1; slack = uS*D1 - ah
                mn = min(mn, slack); fail += slack < 0
        print("   gamma = %-4g: %4d taxing points, publication fails at %d, min slack %+.3f"
              % (g, tot, fail, mn))

if __name__ == "__main__":
    if "--symbolic" in sys.argv:
        import rep3_symbolic          # noqa: the symbolic layer
    else:
        numeric_block()
        publication_single_host()
