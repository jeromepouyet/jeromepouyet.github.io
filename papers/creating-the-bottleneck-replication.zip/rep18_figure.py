# -*- coding: utf-8 -*-
"""rep18_figure.py -- Figure 2: Section 4 in one picture, three panels on the
(u_B, u_S) plane at gamma = 4, v = 2, r = 1/2.

  (a) Proposition 6: the best separation package without the cap
  (b) Proposition B.5: integration or separation, the platform's choice
  (c) Proposition B.6: what the choice costs, the welfare ranking

Regions from rep18_contract_vs_merger.py (single host / two hosts / choice)
and the closed forms of rep3_contracts.py.  Cache in /tmp/fig2_cache_v2.npz.
"""
import sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, matplotlib.colors
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from rep_core import (sigma_of, Mof, Hval, N2val, demands, prices_int, prices_sep, V_DEF, R_DEF)
import rep3_contracts as C
import rep9_dnr as D
V, R = V_DEF, R_DEF
G = 4.0
STEP, LO, HI = 0.002, 0.02, 1.40
gr = np.arange(LO, HI+1e-9, STEP); n = len(gr)
CACHE = "/tmp/fig2_cache_v6N2.npz"
if os.path.exists(CACHE):
    z = np.load(CACHE); REG, CHO, FRA, FPH, FK = z["REG"], z["CHO"], z["FRA"], z["FPH"], z["FK"]
else:
    f_a, f_b, f_P, f_D = D.symbolic()
    def cfg(x,y,sg,c1,c2,fee):
        q1,q2 = prices_sep(x,y,sg,c1,c2,fee); Da,Db,q = demands(x,y,sg,q1,q2,fee)
        return (q1+c1)*Da, (q2+c2)*Db
    REG = np.full((n,n), np.nan); CHO = np.full((n,n), np.nan)
    FRA = np.full((n,n), np.nan); FPH = np.full((n,n), np.nan); FK = np.full((n,n), np.nan)
    for i,u1 in enumerate(gr):
        for j,u2 in enumerate(gr):
            if Mof(u1,u2) <= 0: continue
            sg = sigma_of(u1,u2,G)
            if sg < 0 or Hval(u1,u2,sg) <= 0: continue
            if N2val(u1,u2,sg) >= 0: continue
            a = C.a_star(u1,u2,sg); p1,p2 = prices_int(u1,u2,sg,R,a)
            if demands(u1,u2,sg,p1,p2,a)[1] <= 0: continue
            FRA[j,i] = u1/u2 - C.R_a(sg); FPH[j,i] = u1/u2 - C.R_Phi(sg)
            FK[j,i]  = u1/u2 - C.R_Phi(sg)/(2+sg)
            if u1/u2 >= C.R_a(sg):   REG[j,i]=0.0; CHO[j,i]=0.0; continue
            if u1/u2 >= C.R_Phi(sg): REG[j,i]=1.0; CHO[j,i]=1.0; continue
            REG[j,i] = 2.0
            gain = C.PiI_gain(u1,u2,sg)
            SH = C.Phi(u1,u2,sg,G,max(C.a_hat(u1,u2,sg,G),0.0))
            CHO[j,i] = 2.0 if SH > gain + 1e-12 else 1.0
            if u1 >= u2: continue                                   # two-host family on A (chantier 27)
            ad=float(f_a(u1,u2,V,R,G)); bd=float(f_b(u1,u2,V,R,G)); Ps=float(f_P(u1,u2,V,R,G))
            piRR = cfg(u1,u2,sg,R,R,0.0)[0]
            host = cfg(u1,u2,sg,bd*R,R,ad); both = cfg(u1,u2,sg,bd*R,bd*R,ad)
            if ad>0 and bd>1 and host[0]>piRR and both[0]>=host[1] and Ps>SH:
                REG[j,i]=3.0
    np.savez(CACHE, REG=REG, CHO=CHO, FRA=FRA, FPH=FPH, FK=FK)

tot = np.sum(~np.isnan(REG))
adm = ~np.isnan(REG)
print("  (a) no contract earns anything     : %5.1f%%   of which the band %.1f%%"
      % (100*np.sum(REG<=1)/tot, 100*np.sum(REG==1)/tot))
print("      single host                     : %5.1f%%" % (100*np.sum(REG==2)/tot))
print("      two hosts                       : %5.1f%%" % (100*np.sum(REG==3)/tot))
print("  (b) integration preferred          : %5.1f%%" % (100*np.sum(CHO==1)/tot))
print("      separation preferred            : %5.1f%%" % (100*np.sum(CHO>=2)/tot))
print("      no contract earns (integration alone gains): %5.1f%%" % (100*np.sum(CHO==0)/tot))
unr = (REG>=2)
print("  (c) on the unraveling region, separation worse for welfare (K>0): %5.1f%%"
      % (100*np.sum(unr & (FK<0))/np.sum(unr)))
print("      separation preferred AND worse : %5.1f%% of the separation-preferred region"
      % (100*np.sum((CHO>=2)&(FK<0))/max(np.sum(CHO>=2),1)))

# ------------------------------------------------------------------ palette
GREY  = "#e6e6e6"     # neither instrument active / no contract
BLUE  = "#9ec5e3"     # integration / benchmark
SAND  = "#f3d9a4"     # separation, single host
AMBER = "#d9962a"     # separation, two hosts
RED   = "#c8544e"     # separation, dearer copy
GREEN = "#7bb26a"     # separation, cheaper copy
INK   = "#222222"

X, Y = np.meshgrid(gr, gr)
ext  = [LO, HI, LO, HI]
fig = plt.figure(figsize=(12.6, 6.6))
gs = fig.add_gridspec(2, 3, height_ratios=[1.0, 0.40], hspace=0.12, wspace=0.28)
axes = [fig.add_subplot(gs[0, k]) for k in range(3)]
legs = [fig.add_subplot(gs[1, k]) for k in range(3)]
for a in legs: a.axis("off")

# ---- (a) Proposition 6
A = np.where(REG<=1, 0.0, REG-1.0)                      # 0 none, 1 single, 2 pair
axes[0].imshow(A, origin="lower", extent=ext, interpolation="nearest",
               cmap=matplotlib.colors.ListedColormap([GREY, SAND, AMBER]), vmin=-0.5, vmax=2.5)
axes[0].contour(X, Y, FRA, levels=[0.0], colors=INK, linewidths=1.1, linestyles="dashed")
axes[0].contour(X, Y, FPH, levels=[0.0], colors=INK, linewidths=1.1)
axes[0].plot([LO, HI], [LO, HI], color=INK, lw=0.8, ls=":")
axes[0].set_title("(a) the best separation package", fontsize=14)
H0=[Patch(color=GREY, label="no contract earns anything:\nthe outcome of Proposition 1"),
                        Patch(color=SAND, label="single host"),
                        Patch(color=AMBER, label="two hosts (computed)"),
                        Line2D([0],[0], color=INK, lw=1.1, label=r"$u_B = h_\Phi(u_S)$"),
                        Line2D([0],[0], color=INK, lw=1.1, ls="dashed", label=r"$u_B = h(u_S)$, the no-tax frontier"),
                        Line2D([0],[0], color=INK, lw=0.8, ls=":", label=r"$u_B = u_S$")]
# (the inline "the band" callout was removed: it sat badly and the legend says it)

# ---- (b) Proposition 7
B = np.where(CHO>=2, 2.0, CHO)                           # 0 neither, 1 integration, 2 separation
axes[1].imshow(B, origin="lower", extent=ext, interpolation="nearest",
               cmap=matplotlib.colors.ListedColormap([GREY, BLUE, RED]), vmin=-0.5, vmax=2.5)
axes[1].contour(X, Y, FPH, levels=[0.0], colors=INK, linewidths=1.1)
axes[1].contour(X, Y, FK,  levels=[0.0], colors=INK, linewidths=1.1, linestyles="dashdot")
axes[1].set_title("(b) the platform's choice", fontsize=14)
H1=[Patch(color=GREY, label="no contract earns anything;\nintegration alone gains"),
                        Patch(color=BLUE, label="integration preferred"),
                        Patch(color=RED,  label="separation preferred"),
                        Line2D([0],[0], color=INK, lw=1.1, ls="dashdot", label=r"$u_B/u_S = R_p(\sigma)$")]

# ---- (c) Proposition 8
Cc = np.full((n,n), np.nan)
Cc[adm] = 0.0
Cc[unr & (FK<0)] = 1.0                                   # separation worse for welfare
Cc[unr & (FK>=0)] = 2.0                                  # separation better
axes[2].imshow(Cc, origin="lower", extent=ext, interpolation="nearest",
               cmap=matplotlib.colors.ListedColormap([GREY, RED, GREEN]), vmin=-0.5, vmax=2.5)
axes[2].contour(X, Y, FPH, levels=[0.0], colors=INK, linewidths=1.1)
axes[2].contour(X, Y, FK,  levels=[0.0], colors=INK, linewidths=1.1, linestyles="dashdot")
# (the inline R_p label was removed; the two curves are named in the legend below)
# outline of the separation-preferred region
SEP = np.where(np.isnan(CHO), 0.0, (CHO>=2).astype(float))
axes[2].contour(X, Y, SEP, levels=[0.5], colors="white", linewidths=1.6)
axes[2].contour(X, Y, SEP, levels=[0.5], colors=INK, linewidths=0.8)
axes[2].set_title("(c) what the choice costs", fontsize=14)
H2=[Patch(color=GREY, label="only integration active"),
                        Patch(color=RED,  label="separation worse for welfare,\nbuyers and the developer"),
                        Patch(color=GREEN, label="separation better"),
                        Line2D([0],[0], color=INK, lw=1.1, label=r"$u_B = h_\Phi(u_S)$"),
                        Line2D([0],[0], color=INK, lw=1.1, ls="dashdot", label=r"$u_B/u_S = R_p(\sigma)$"),
                        Line2D([0],[0], color=INK, lw=0.8, label="where the platform prefers\nseparation, from panel (b)")]

for ax in axes:
    ax.set_xlabel(r"$u_B$", fontsize=14); ax.set_ylabel(r"$u_S$", fontsize=14)
    ax.set_xlim(LO, HI); ax.set_ylim(LO, HI); ax.set_aspect("equal")
    ax.tick_params(labelsize=11.5)
for a, H, t in zip(legs, (H0, H1, H2), ("panel (a)", "panel (b)", "panel (c)")):
    a.legend(handles=H, loc="upper left", bbox_to_anchor=(-0.02, 1.02), fontsize=12.5, frameon=False,
             title=t, title_fontsize=13, alignment="left", handlelength=1.6, borderaxespad=0.0)
out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fig2-contracts")
fig.savefig(out + ".pdf", bbox_inches="tight"); fig.savefig(out + ".png", dpi=170, bbox_inches="tight")
print("  written", out + ".pdf")
