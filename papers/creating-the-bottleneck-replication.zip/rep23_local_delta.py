# -*- coding: utf-8 -*-
"""rep23_local_delta.py -- the merger's impact under dominance, near delta = 0.

At delta = 0 the two sides collapse onto objects the paper already has: the
separation polyhedron shrinks to (x,a) = (0,0), which is Proposition 1, and
bbar(0) = 1 forces beta^2 = 1, which is Proposition 2.  The local analysis
therefore DIFFERENTIATES Propositions 3-5 rather than introducing a new object.

  (A) inside a regime the policy is exactly affine in delta on both sides, so
      every equilibrium object is an exact quadratic in delta: "near delta = 0"
      means "before the regime switches", with no truncation error;
  (B) at delta = 0 both separation branches give (beta r, a) = (r, 0) and both
      integration branches give b2 = r and the same fee: Propositions 3-5;
  (C) the policy coefficients in closed form;
  (D) four cells, cut by R_Phi (separation) and {b2* = r} (integration);
      the double-marginalization wedge on the integrated device is delta in
      the floor cell, zero in the taxing cell;
  (E) which way each frontier of Propositions 3-5 moves.

The separation benchmark is the asymmetric programme (rep35): as delta -> 0
its taxing branch is b_1 = r (the favored manufacturer at the cap), b_2 = r -
delta (the other at its floor), a = kappa delta, on u_B/u_S < R_Phi; the floor
branch (r - delta, r - delta, 0) beyond.  M1 is the merger partner.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, sympy as sp
from rep_core import sigma_of, Mof, N2val, V_DEF, R_DEF

V, R = V_DEF, R_DEF
ok = lambda c: "PASS" if c else "**FAIL**"
print("="*74, flush=True)
print("rep23 -- the merger under dominance, near delta = 0")
print("="*74, flush=True)

uB, uS, s, v, r, d = sp.symbols('u_B u_S sigma v r delta', positive=True)
M   = 1 - 2*uB*uS
Lam = 8 + s*(8+s)
kap = Lam/(2*uB*(4+3*s))
p1, p2, b, b2, a = sp.symbols('p_1 p_2 b b_2 a')
b1 = sp.Symbol('b_1')

def dem(P1, P2, A):
    return ((2*v-(2+s)*P1+s*P2-2*uB*A)/(2*M),
            (2*v-(2+s)*P2+s*P1-2*uB*A)/(2*M),
            (uS*(2*v-P1-P2)-A)/M)
g_ = (s + 2*uB*uS)/M
def surp(P1, P2, D1, D2, Q):
    VB = (v*(D1+D2) + uB*Q*(D1+D2)
          - (2*(D1**2+D2**2) + g_*(D1+D2)**2)/(4*(1+g_)) - P1*D1 - P2*D2)
    return VB, Q**2/2

D1e, D2e, QSe = dem(p1, p2, a)
sep  = sp.solve([sp.diff((p1+b1)*D1e, p1), sp.diff((p2+b)*D2e, p2)], [p1,p2], dict=True)[0]
objI = (p1+r)*D1e + a*QSe + (r-b2)*D2e
inte = sp.solve([sp.diff(objI, p1), sp.diff((p2+b2)*D2e, p2)], [p1,p2], dict=True)[0]

def outcome_sep(b1v, b2v, av):
    """Separation at benefits (b_1, b_2) and fee a; M1 is the favored one."""
    sub = {b1:b1v, b:b2v, a:av}
    P1 = sp.cancel(sep[p1].subs(sub)); P2 = sp.cancel(sep[p2].subs(sub))
    D1, D2, Q = dem(P1, P2, av); VB, VS = surp(P1, P2, D1, D2, Q)
    pi1, pi2 = (P1+b1v)*D1, (P2+b2v)*D2
    Pi = (r-b1v)*D1 + (r-b2v)*D2 + av*Q
    return dict(p1=P1, p2=P2, D1=D1, D2=D2, qS=Q, VB=VB, VS=VS, pi2=pi2,
                Pi=Pi, W=VB+VS+pi1+pi2+Pi,
                G=Pi + pi1,                      # platform + M1: what the merger gives up
                a=av, b2=b1v, wedge=r-b1v)       # b2 here: the merger partner's benefit

def outcome_int(b2v, av):
    P1 = sp.cancel(inte[p1].subs({b2:b2v, a:av})); P2 = sp.cancel(inte[p2].subs({b2:b2v, a:av}))
    D1, D2, Q = dem(P1, P2, av); VB, VS = surp(P1, P2, D1, D2, Q)
    pi2 = (P2+b2v)*D2; Pi = (P1+r)*D1 + av*Q + (r-b2v)*D2
    return dict(p1=P1, p2=P2, D1=D1, D2=D2, qS=Q, VB=VB, VS=VS, pi2=pi2,
                Pi=Pi, W=VB+VS+pi2+Pi, G=Pi,   # the merged entity
                a=av, b2=b2v, wedge=sp.Integer(0))

PiI     = sp.cancel(sp.together(objI.subs(inte)))
a_of_b2 = sp.cancel(sp.solve(sp.Eq(sp.diff(PiI, a), 0), a)[0])
phi     = sp.cancel(sp.together(sp.diff(PiI, b2).subs(a, a_of_b2)))
b2star  = sp.cancel(sp.solve(sp.Eq(phi, 0), b2)[0])
bbar2   = r - d*Lam/(8*(1+s))

SEP = {'tax'  : outcome_sep(r,   r-d, kap*d),
       'floor': outcome_sep(r-d, r-d, sp.Integer(0))}
INT = {'part' : outcome_int(bbar2, a_of_b2.subs(b2, bbar2)),
       'cap'  : outcome_int(r,     a_of_b2.subs(b2, r))}
KEYS = ('a','b2','wedge','p1','p2','D1','D2','qS','VB','VS','pi2','Pi','G','W')

print("\n  lambdifying ...", flush=True)
LAM = {nm: {k: sp.lambdify((uB,uS,s,v,r,d), O[k], 'numpy') for k in KEYS}
       for nm, O in list(SEP.items())+list(INT.items())}
fb2s = sp.lambdify((uB,uS,s,v,r,d), b2star, 'numpy')
fRd  = lambda sg: (8+sg*(8+sg))/(3*sg+4)     # R_Phi, the asymmetric benchmark's taxing frontier
print("  done", flush=True)

# ===================================================================== (A)
print("\n (A) exact quadratic in delta inside a regime", flush=True)
rng = np.random.default_rng(0); pts = []
while len(pts) < 40:
    x1, x2 = rng.uniform(0.05, 1.2), rng.uniform(0.05, 1.2)
    if Mof(x1, x2) <= 0.02: continue
    G = float(rng.choice([1., 2., 4., 8.])); sg = sigma_of(x1, x2, G)
    if sg < 0 or N2val(x1, x2, sg) >= 0: continue
    pts.append((x1, x2, sg))
DD = np.array([0.0, 0.01, 0.02, 0.03, 0.05, 0.07, 0.09])
worst = 0.0
for nm in LAM:
    for k in KEYS:
        for (x1, x2, sg) in pts:
            y = np.array([LAM[nm][k](x1,x2,sg,V,R,dd) for dd in DD], float)
            c = np.polyfit(DD, y, 2)
            worst = max(worst, np.max(np.abs(np.polyval(c,DD)-y))/max(1e-12,np.max(np.abs(y))))
print("     largest relative residual of a quadratic fit : %.2e" % worst,
      "  ", ok(worst < 1e-9), flush=True)

# ===================================================================== (B)
print("\n (B) the delta = 0 limit is Propositions 3-5", flush=True)
z = {d: 0}
print("     separation, taxing branch -> (beta r, a) = (r, 0)  :",
      ok(sp.simplify(SEP['tax']['a'].subs(z)) == 0
         and sp.simplify(SEP['tax']['b2'].subs(z) - r) == 0))
print("     separation, floor branch  -> (beta r, a) = (r, 0)  :",
      ok(sp.simplify(SEP['floor']['a'].subs(z)) == 0
         and sp.simplify(SEP['floor']['b2'].subs(z) - r) == 0))
print("     integration, both branches -> b2 = r, same fee     :",
      ok(sp.simplify(INT['part']['b2'].subs(z) - r) == 0
         and sp.simplify(INT['cap']['b2'].subs(z) - r) == 0
         and sp.simplify(INT['part']['a'].subs(z) - INT['cap']['a'].subs(z)) == 0), flush=True)

# ===================================================================== (C)
print("\n (C) the policy coefficients, in closed form", flush=True)
c1 = lambda e: sp.cancel(sp.together(sp.diff(e, d).subs(d, 0)))
print("     sep tax   : da/ddelta = Lambda/(2 uB(3sigma+4)) :",
      ok(sp.simplify(c1(SEP['tax']['a']) - kap) == 0),
      "  d(b_1)/ddelta = 0 (partner at the cap), d(b_2)/ddelta = -1 (rival at the floor) :",
      ok(sp.simplify(c1(SEP['tax']['b2'])) == 0))
print("     sep floor : da/ddelta = 0                       :",
      ok(sp.simplify(c1(SEP['floor']['a'])) == 0),
      "  d(beta r)/ddelta = -1:", ok(sp.simplify(c1(SEP['floor']['b2']) + 1) == 0))
print("     int part  : db2/ddelta = -Lambda/(8(1+sigma))   :",
      ok(sp.simplify(c1(INT['part']['b2']) + Lam/(8*(1+s))) == 0))
print("     int cap   : db2/ddelta = 0                      :",
      ok(sp.simplify(c1(INT['cap']['b2'])) == 0), flush=True)
print("     the same Lambda governs both sides: the fee the dominant platform")
print("     can charge, and the share the integrated firm must hand back.", flush=True)
np.save('/tmp/rep23_ready.npy', np.array([1]))

# ===================================================================== (D)
print("\n" + "="*74)
print(" (D) four cells at delta -> 0+, and the double-marginalization wedge")
print("="*74, flush=True)
GRID = np.arange(0.02, 1.4001, 0.02)
def cells(G):
    out = []
    for x1 in GRID:
        for x2 in GRID:
            if Mof(x1, x2) <= 0: continue
            sg = sigma_of(x1, x2, G)
            if sg < 0 or N2val(x1, x2, sg) >= 0: continue
            si = 'tax' if x1/x2 < fRd(sg) else 'floor'
            ii = 'cap' if fb2s(x1, x2, sg, V, R, 0.0) >= R else 'part'
            out.append((x1, x2, sg, si, ii))
    return out
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    C = cells(G); n = len(C)
    tab = {}
    for _,_,_,si,ii in C: tab[(si,ii)] = tab.get((si,ii),0)+1
    print("  gamma=%-3g n=%5d | " % (G,n) +
          "  ".join("(%s,%s) %5.1f%%" % (si,ii,100.*tab.get((si,ii),0)/n)
                    for si in ('tax','floor') for ii in ('cap','part')), flush=True)
print("\n     the wedge delta - x removed by the merger on device 1:")
print("       taxing cell  (beta = 1)         : 0")
print("       floor cell   (beta r = r-delta) : delta        <- maximal")
w_tax = sp.simplify(SEP['tax']['wedge']); w_flo = sp.simplify(SEP['floor']['wedge'])
print("     checked symbolically :", ok(w_tax == 0 and sp.simplify(w_flo - d) == 0))
print("     => the double marginalization integration removes is present exactly")
print("        where the dominant platform does NOT use the developer fee, and")
print("        absent where it does.  R_Phi decides which.", flush=True)

# ===================================================================== (E)
print("\n" + "="*74)
print(" (E) which way each frontier moves")
print("="*74, flush=True)
DD2 = np.array([0.0, 0.01, 0.02])
OBJ = ('G','W','pi2','VB','VS','a')
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    C = cells(G); n = len(C)
    print("\n  gamma = %g  (%d admissible points)" % (G, n), flush=True)
    for X in OBJ:
        c0 = np.empty(n); c1v = np.empty(n)
        for i,(x1,x2,sg,si,ii) in enumerate(C):
            y = np.array([LAM[ii][X](x1,x2,sg,V,R,dd) - LAM[si][X](x1,x2,sg,V,R,dd)
                          for dd in DD2], float)
            q = np.polyfit(DD2, y, 2)
            c0[i], c1v[i] = q[2], q[1]
        pos0 = 100.*np.mean(c0 > 0)
        # points on the delta=0 frontier: |c0| in the lowest percentile
        thr = np.percentile(np.abs(c0), 3)
        near = np.abs(c0) <= thr
        agree = 100.*np.mean(c1v[near] > 0)
        # share with Delta > 0 at delta = 0.02 and 0.05
        def share(dd):
            val = np.array([LAM[ii][X](x1,x2,sg,V,R,dd) - LAM[si][X](x1,x2,sg,V,R,dd)
                            for (x1,x2,sg,si,ii) in C])
            return 100.*np.mean(val > 0)
        print("    %-4s : Delta>0 at delta=0 : %5.1f%% ; at 0.02 : %5.1f%% ; at 0.05 : %5.1f%%"
              "   | on the frontier, c1>0 at %5.1f%%"
              % (X, pos0, share(0.02), share(0.05), agree), flush=True)

# ===================================================================== (F)
print("\n" + "="*74)
print(" (F) cell by cell: where does the movement come from?")
print("="*74, flush=True)
def fine(G, step=0.01):
    gr = np.arange(0.02, 1.4001, step); out = []
    for x1 in gr:
        for x2 in gr:
            if Mof(x1, x2) <= 0: continue
            sg = sigma_of(x1, x2, G)
            if sg < 0 or N2val(x1, x2, sg) >= 0: continue
            si = 'tax' if x1/x2 < fRd(sg) else 'floor'
            ii = 'cap' if fb2s(x1, x2, sg, V, R, 0.0) >= R else 'part'
            out.append((x1, x2, sg, si, ii))
    return out
print("\n  is the cell (floor, cap) empty?  finer grid, step 0.01", flush=True)
for G in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    C = fine(G); k = sum(1 for *_, si, ii in C if si=='floor' and ii=='cap')
    print("    gamma=%-3g : %6d admissible points, (floor,cap) at %d"
          % (G, len(C), k), flush=True)
print("    => the integration cap region sits strictly inside the separation")
print("       taxing region: three cells, not four, and they form a chain.")

print("\n  delta-coefficient by cell (gamma = 4, median over the cell)", flush=True)
C = cells(4.0)
for X in ('G','W','pi2','VB','VS','a'):
    line = "    %-4s :" % X
    for si, ii in (('tax','cap'), ('tax','part'), ('floor','part')):
        sub = [(x1,x2,sg) for (x1,x2,sg,a_,b_) in C if a_==si and b_==ii]
        if not sub: continue
        cc = []
        lev = []
        for (x1,x2,sg) in sub:
            y = np.array([LAM[ii][X](x1,x2,sg,V,R,dd) - LAM[si][X](x1,x2,sg,V,R,dd)
                          for dd in DD2], float)
            q = np.polyfit(DD2, y, 2); cc.append(q[1]); lev.append(q[2])
        line += "  (%s,%s) level %+7.3f  slope %+8.3f |" % (
            si, ii, float(np.median(lev)), float(np.median(cc)))
    print(line, flush=True)
print("\n    'level' = the increment at delta = 0 (Propositions 3-5),")
print("    'slope' = its derivative in delta.", flush=True)
