# -*- coding: utf-8 -*-
"""rep31_microfoundation.py -- can the two-segment single-homing construction
be calibrated so that both segments are interior at the prices of the model?

Construction (Online Appendix, single-homing micro-foundation).  Each
manufacturer k faces a captive segment of mass m_c with reservation values
omega uniform on [V_lo, V_hi], who buy iff omega >= ptilde_k := p_k - u_B q_S;
both manufacturers also compete on a covered Hotelling segment of mass m_h with
transportation cost t.  Matching the aggregate to the paper's demand system
requires, after the slope normalisation m_c = V_hi - V_lo,

    V_hi = v - m_h/2      and      gamma = m_h / t .

V_lo is free: it fixes m_c and nothing else.  The construction is literal at a
given price vector iff

    (i)  captive arm interior     :  V_lo <= ptilde_k <= V_hi  for k = 1, 2,
    (ii) Hotelling segment shared :  |p_1 - p_2| <= t = m_h / gamma.

(i) at the bottom is free (take V_lo <= min_k ptilde_k).  The two remaining
conditions bind m_h in opposite directions,

    gamma |p_1 - p_2|  <=  m_h  <=  2 (v - max_k ptilde_k),

so a calibration exists iff  gamma |p_1 - p_2| <= 2 (v - max_k ptilde_k), the
right-hand side being positive.  This script checks that single inequality on
the reference grid, at the integrated optimum a** and at the separation
benchmark, and reports the slack.  The welfare comparison of the two outcomes
needs one calibration serving both, i.e. a COMMON m_h in the intersection of
the two intervals [gamma |p_1 - p_2|, 2 (v - max_k ptilde_k)] (Refine 2,
point 15): the script also reports the slack of that intersection.
"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, Hval, N2val,
                      demands, prices_int, prices_sep)

V, R = V_DEF, R_DEF
STEP, LO, HI = 0.02, 0.02, 1.40
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)


def a_star(uB, uS, sig, v=V, r=R):
    num = 2*(v+r)*((3*sig*(sig*(sig+7)+16)+32)*uS - 2*(sig+2)*(3*sig+4)*uB) \
          / ((sig+4)**2*(3*sig+4)*Mof(uB, uS))
    den = -2*Hval(uB, uS, sig)/((sig+4)**2*(3*sig+4)**2*Mof(uB, uS))
    return -num/den


def feasible(uB, uS, sig, p1, p2, qS, gamma, v=V):
    """Returns (ok, slack, saturated) for one price vector."""
    t1, t2 = p1 - uB*qS, p2 - uB*qS
    room = 2.0*(v - max(t1, t2))              # upper bound on m_h
    need = gamma*abs(p1 - p2)                 # lower bound on m_h
    return (room > need and room > 0.0), room - need, min(t1, t2) < 0.0


def run(screen, label, v_=V):
    print("\n%s" % label)
    gr = np.arange(LO, HI + STEP/2, STEP)
    for g in GAMMAS:
        tot = fail_int = fail_sep = sat_int = fail_common = 0
        worst_int = worst_sep = worst_common = 1e9
        for uB in gr:
            for uS in gr:
                if Mof(uB, uS) <= 0:
                    continue
                sig = sigma_of(uB, uS, g)
                if sig < 0 or not screen(uB, uS, sig):
                    continue
                a = a_star(uB, uS, sig)
                p1, p2 = prices_int(uB, uS, sig, R, a)
                D1, D2, qS = demands(uB, uS, sig, p1, p2, a)
                if min(D1, D2) <= 0 or qS <= 0:
                    continue                   # outside A: D_2(a**) > 0 fails
                tot += 1
                ok, sl, sat = feasible(uB, uS, sig, p1, p2, qS, g)
                if not ok:
                    fail_int += 1
                if sat:
                    sat_int += 1
                worst_int = min(worst_int, sl)
                q1, q2 = prices_sep(uB, uS, sig, R, R, 0.0)
                _, _, qS0 = demands(uB, uS, sig, q1, q2, 0.0)
                ok0, sl0, _ = feasible(uB, uS, sig, q1, q2, qS0, g)
                if not ok0:
                    fail_sep += 1
                worst_sep = min(worst_sep, sl0)
                # a common m_h: the intersection of the two intervals
                need = max(g*abs(p1 - p2), g*abs(q1 - q2))
                room = min(2.0*(v_ - max(p1 - uB*qS, p2 - uB*qS)),
                           2.0*(v_ - max(q1 - uB*qS0, q2 - uB*qS0)))
                if room <= need:
                    fail_common += 1
                worst_common = min(worst_common, room - need)
        print("  gamma = %5.1f : %5d points | integrated optimum: %d failures, "
              "min slack %.4f | separation: %d failures, min slack %.4f | "
              "common m_h: %d failures, min slack %.4f | "
              "net price < 0 at %d points (%.0f%%)"
              % (g, tot, fail_int, worst_int, fail_sep, worst_sep,
                 fail_common, worst_common,
                 sat_int, 100.0*sat_int/max(tot, 1)))


if __name__ == "__main__":
    print("Existence of a two-segment calibration interior at the model's prices.")
    print("Reference grid: step %.2f on [%.2f,%.2f]^2, v = %.1f, r = %.2f."
          % (STEP, LO, HI, V, R))
    run(lambda uB, uS, sig: Hval(uB, uS, sig) > 0,
        "A. one-instrument admissible set  A  = {sigma >= 0, H > 0, D_2(a**) > 0}")
    run(lambda uB, uS, sig: N2val(uB, uS, sig) < 0,
        "B. two-instrument admissible set  A* = {sigma >= 0, N_2 < 0, D_2(a**) > 0}")
