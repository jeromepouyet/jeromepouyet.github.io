# -*- coding: utf-8 -*-
"""rep35_dominance_asym.py -- the dominant-platform benchmark with asymmetric
packages (Online Appendix B.5, Proposition B.2 as restated).

The earlier benchmark restricted the separated platform to a common share.
The best package is generally asymmetric: with outside option r - delta the
platform hands back x_1 of the premium to ONE manufacturer, enough for its
adoption alone to beat joint refusal (a <= kappa x_1, the divide-and-conquer
constraint), and holds the other at its floor r - delta, where it accepts once
its rival is on the system (a manufacturer indifferent between the contract
and its outside option accepts, Section 2.3).  The feasible set, with the
manufacturers labeled so that x_1 >= x_2, is the convex polyhedron

    P^a = {0 <= x_2 <= x_1 <= delta,  a <= kappa x_1},

the profit (delta - x_1) D_1 + (delta - x_2) D_2 + a q_S is a strictly concave
quadratic on A* (its Hessian is that of the two-host programme), and the
optimum is found exactly from the active sets (rep5_dominance.benchmark_asym).

Blocks.  (A) symbolic: concavity; the taxing edge (M2 at the floor, a = kappa
x_1) and its maximizer x_1^*; its positivity condition, which as delta -> 0 is
u_B/u_S < Lambda/(3 sigma + 4) = R_Phi, the frontier of the single-host package
of Proposition 6; the cap fee a_cap^a = a_sub(delta/2); the sign of the
derivative in x_2 on the edge; the slope of separation welfare at delta = 0 on
the new taxing branch, negative.  (B) the regimes on the reference grid at the
six gamma and delta in {0.05, 0.1, 0.2, 0.3}, and the comparison with the
symmetric programme.  (C) the programme against the enumerated adoption game
(all four configurations, Nash equilibria, the selection rule, symmetric and
asymmetric packages) on the reference grid coarsened to step 0.1.  (D) the
taxing frontier on the grid.
"""
import os, sys, time
import numpy as np
import sympy as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_sep, admissible)
from rep5_dominance import benchmark, benchmark_asym, kappa

V, R = V_DEF, R_DEF
GAMMAS = (0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
GRID = np.arange(0.02, 1.4001, 0.02)
COARSE = np.arange(0.10, 1.401, 0.10)
ok = lambda c: "PASS" if c else "**FAIL**"


def Lam(s): return 8 + s*(8 + s)
def R_Phi(s): return Lam(s)/(4 + 3*s)
def R_delta(s): return Lam(s)/(2*(3*s + 4))

def x1_star(uB, uS, sig, dl, v=V, r=R):
    """Closed form of the taxing edge: M2 at the floor, a = kappa x_1."""
    L = Lam(sig)
    N = (v+r)*(uS*L - uB*(3*sig+4)) - dl*(uS*L + sig*(sig+2)*uB)
    return 2*uB*(sig+2)*(3*sig+4)*N/((sig+4)*L*(L - 2*uB*uS*(5*sig+6)))

def a_cap_asym(uB, uS, sig, dl, v=V, r=R):
    """Fee at the cap with M2 at the floor and the fee constraint slack."""
    return (sig+2)*(2*uS*(v+r) - dl*(uB+uS))/(2*(sig+4-4*uB*uS))


# =========================================================================== A
def symbolic():
    uB, uS, v, r, g, dl = sp.symbols('u_B u_S v r gamma delta', positive=True)
    S = sp.Symbol('sigma', positive=True)
    x1, x2, a = sp.symbols('x1 x2 a', real=True)
    p1, p2 = sp.symbols('p1 p2')
    M = 1 - 2*uB*uS; L = 8 + S*(8+S); kap = L/(2*uB*(3*S+4))
    b1 = r - dl + x1; b2 = r - dl + x2
    D1 = (2*v-(2+S)*p1+S*p2-2*uB*a)/(2*M)
    D2 = (2*v-(2+S)*p2+S*p1-2*uB*a)/(2*M)
    DS = (uS*(2*v-p1-p2)-a)/M
    sol = sp.solve([sp.diff((p1+b1)*D1,p1), sp.diff((p2+b2)*D2,p2)], [p1,p2], dict=True)[0]
    D1e, D2e, qe = [sp.simplify(e.subs(sol)) for e in (D1, D2, DS)]
    Pi = sp.expand((dl - x1)*D1e + (dl - x2)*D2e + a*qe)
    print("A. Symbolic verification\n")
    H = sp.hessian(Pi, (x1, x2, a))
    Dd = 2*(S+4) - 8*uB*uS - (S+2)*(uB+uS)**2
    print(" 1. det H = -4(s+1)(s+2)^2 Delta_delta/((s+4)^2(3s+4)M^3)                :",
          ok(sp.simplify(H.det() + 4*(S+1)*(S+2)**2*Dd/((S+4)**2*(3*S+4)*M**3)) == 0))
    print("    H_11 < 0 and the leading 2x2 minor > 0: negative definite iff Delta_delta > 0 :",
          ok(sp.simplify(H[0,0]*(S+4)*(3*S+4)*M + (S+2)*L) == 0 and
             sp.simplify(H[:2,:2].det() - 4*(S+1)*(S+2)**2/((S+4)*(3*S+4)*M**2)) == 0))
    # 2. the taxing edge
    Pe = sp.expand(Pi.subs({x2: 0, a: kap*x1}))
    P2 = sp.Poly(Pe, x1)
    c2, c1 = P2.coeff_monomial(x1**2), P2.coeff_monomial(x1)
    N = (v+r)*(uS*L - uB*(3*S+4)) - dl*(uS*L + S*(S+2)*uB)
    x1s = 2*uB*(S+2)*(3*S+4)*N/((S+4)*L*(L - 2*uB*uS*(5*S+6)))
    print(" 2. edge concave: coefficient of x1^2 = -Lambda(Lambda - 2u_Bu_S(5s+6))/(4u_B^2(3s+4)^2 M) :",
          ok(sp.simplify(c2 + L*(L - 2*uB*uS*(5*S+6))/(4*uB**2*(3*S+4)**2*M)) == 0))
    print("    x1* closed form                                                       :",
          ok(sp.simplify(-c1/(2*c2) - x1s) == 0))
    print("    edge derivative at 0 = (s+2) N/(u_B(s+4)(3s+4)M), N = (v+r)[u_S Lambda - u_B(3s+4)] - delta[u_S Lambda + s(s+2)u_B] :",
          ok(sp.simplify(c1 - (S+2)*N/(uB*(S+4)*(3*S+4)*M)) == 0))
    print("    as delta -> 0 the edge taxes iff u_B/u_S < Lambda/(3s+4) = R_Phi          :",
          ok(sp.simplify(N.subs(dl, 0) - (v+r)*(3*S+4)*uS*(L/(3*S+4) - uB/uS)) == 0))
    # 3. the cap
    Pc = sp.expand(Pi.subs({x1: dl, x2: 0}))
    ac = sp.solve(sp.diff(Pc, a), a)[0]
    asub = lambda d: (S+2)*(uS*(v+r) - d*(uB+uS))/(S+4-4*uB*uS)
    print(" 3. cap fee with M2 at the floor: a_cap^a = a_sub(delta/2)                     :",
          ok(sp.simplify(ac - asub(dl/2)) == 0))
    # 4. handing back to M2: derivative in x2 on the edge
    dx2 = sp.diff(Pi, x2).subs({x2: 0, a: kap*x1})
    Bx = x1*(uB*(3*S**2+12*S+8) + uS*L) - 2*uB*(3*S+4)*(v + r - 2*dl)
    print(" 4. dPi/dx2 at x2 = 0 on the edge = (s+2) B_2/(2u_B(s+4)(3s+4)M), B_2 = x1[u_B(3s^2+12s+8) + u_S Lambda] - 2u_B(3s+4)(v+r-2 delta) :",
          ok(sp.simplify(dx2 - (S+2)*Bx/(2*uB*(S+4)*(3*S+4)*M)) == 0))
    # 5. welfare slope at delta = 0 on the taxing branch x1 = delta, x2 = 0, a = kappa delta
    VB = (v*(D1e+D2e) + uB*qe*(D1e+D2e) - (2*(D1e**2+D2e**2) + g*(D1e+D2e)**2)/(4*(1+g))
          - sol[p1]*D1e - sol[p2]*D2e)
    W = VB + qe**2/2 + (sol[p1]+b1)*D1e + (sol[p2]+b2)*D2e + Pi
    dWt = sp.simplify(sp.diff(W.subs({x1: dl, x2: 0, a: kap*dl}), dl).subs(dl, 0))
    brk = (2*S**3*uS**2 + S**3 - 2*S**2*uB*uS + 26*S**2*uS**2 + 14*S**2 - 56*S*uB*uS
           + 68*S*uS**2 + 62*S - 64*uB*uS + 48*uS**2 + 56)
    print(" 5. dW_sep/ddelta|0 on the taxing branch = -(v+r)(s+2) B/((s+4)^2(3s+4)M^2)     :",
          ok(sp.simplify(dWt + (v+r)*(S+2)*brk/((S+4)**2*(3*S+4)*M**2)) == 0))
    print("    B > 0 on the feedback set: B >= s^3 + 13s^2 + 34s + 24 + u_S^2(...) when 2u_Bu_S < 1 :",
          ok(sp.simplify(sp.expand(brk - (2*S**3*uS**2 + 26*S**2*uS**2 + 68*S*uS**2 + 48*uS**2)
                                   - (S**3 + 14*S**2 + 62*S + 56) + 2*uB*uS*(S**2 + 28*S + 32))) == 0))
    dWf = sp.simplify(sp.diff(W.subs({x1: 0, x2: 0, a: 0}), dl).subs(dl, 0))
    print("    floor branch unchanged: -4(v+r)(s+2)(s u_Bu_S + s u_S^2 + 2u_S^2 + 1)/((s+4)^2 M^2) :",
          ok(sp.simplify(dWf + 4*(v+r)*(S+2)*(S*uB*uS + S*uS**2 + 2*uS**2 + 1)/((S+4)**2*M**2)) == 0))
    # 6. the favored manufacturer earns exactly pi^bench on the edge
    pi1 = sp.simplify(((sol[p1]+b1)*D1e).subs({x2: 0, a: kap*x1}))
    pib = sp.simplify(((sol[p1]+b1)*D1e).subs({x1: 0, x2: 0, a: 0}))
    print(" 6. on the edge the favored manufacturer earns pi^bench exactly                :",
          ok(sp.simplify(pi1 - pib) == 0))
    # 7. chain: R_p < R_delta < R_J < R_Phi < R_a, with R_Phi = 2 R_delta
    print(" 7. R_Phi = 2 R_delta, so the chain reads R_p < R_delta < R_J < R_Phi < R_a     :",
          ok(sp.simplify(L/(3*S+4) - 2*L/(2*(3*S+4))) == 0))


# =========================================================================== B
def block_B(deltas=(0.05, 0.10, 0.20, 0.30)):
    print("\nB. Regimes on the reference grid, and the comparison with the symmetric programme\n")
    print("   %-5s %-5s %5s | %-62s | %-30s" %
          ("delta", "gamma", "n", "floor(sub) / edge / cap / cap-corner / seam / other", "asym > sym: n, median, max gain"))
    out = {}; full = {}
    for dl in deltas:
        for g in GAMMAS:
            cnt = {}; n = 0; better = 0; gains = []; fee_up = 0; tax = 0; full[(dl, g)] = {}
            for uB in GRID:
                for uS in GRID:
                    if not admissible(uB, uS, g, True) or sigma_of(uB, uS, g) < 0: continue
                    b = benchmark_asym(uB, uS, g, dl)
                    if b is None: continue
                    e = benchmark(uB, uS, g, dl)
                    n += 1
                    reg = b['regime']
                    if reg.endswith('-two') or reg.startswith('cap-both') or reg in ('one-interior', 'sym-edge', 'other'):
                        reg = 'other'
                    cnt[reg] = cnt.get(reg, 0) + 1
                    full[(dl, g)][b['regime']] = full[(dl, g)].get(b['regime'], 0) + 1
                    if e is not None and b['Pi'] > e[0] + 1e-9:
                        better += 1; gains.append((b['Pi'] - e[0])/e[0])
                    if e is not None and e[2] > 1e-9:
                        tax += 1; fee_up += b['a'] > e[2] + 1e-9
                    out[(dl, g, round(uB, 2), round(uS, 2))] = (b, e)
            gains = np.array(gains) if gains else np.zeros(1)
            print("   %-5.2f %-5g %5d | %4d(%3d) / %4d / %4d / %4d / %3d / %3d                    | %4d (%3.0f%%), %4.1f%%, %5.1f%%   fee higher at %d of %d taxing"
                  % (dl, g, n, cnt.get('floor', 0) + cnt.get('floor-subsidy', 0), cnt.get('floor-subsidy', 0),
                     cnt.get('edge', 0), cnt.get('cap', 0), cnt.get('cap-corner', 0), cnt.get('seam', 0),
                     cnt.get('other', 0), better, 100.*better/n, 100*np.median(gains), 100*gains.max(),
                     fee_up, tax))
    print("\n   the residual regimes ('other' above), by active set:")
    for (dl, g), c in full.items():
        rest = {k: v for k, v in c.items() if k not in ('floor', 'floor-subsidy', 'edge', 'cap', 'cap-corner', 'seam')}
        if rest: print("   delta = %.2f gamma = %-4g: %s" % (dl, g, rest))
    return out


# =========================================================================== C
def game_grid(uB, uS, g, dl, a, betas, v=V, r=R):
    """One fee, the whole (beta^1, beta^2) grid: best platform value among
    packages at which the selected configuration is interior."""
    sig = sigma_of(uB, uS, g); bo = r - dl
    b = betas*r; b1 = b[:, None]; b2 = b[None, :]
    one = np.ones((len(betas), len(betas)))
    ae = a if a < 0 else 0.0
    def cfg(bb1, bb2, aa):
        p1, p2 = prices_sep(uB, uS, sig, bb1, bb2, aa, v)
        D1, D2, q = demands(uB, uS, sig, p1, p2, aa, v)
        return D1, D2, q, (p1+bb1)*D1, (p2+bb2)*D2
    AA = cfg(b1*one, b2*one, a); AR = cfg(b1*one, bo*one, a)
    RA = cfg(bo*one, b2*one, a); RR = cfg(bo, bo, ae)
    inter = (np.minimum(np.minimum(AA[0], AA[1]), AA[2]) > 0) & \
            (np.minimum(np.minimum(AR[0], AR[1]), AR[2]) > 0) & \
            (np.minimum(np.minimum(RA[0], RA[1]), RA[2]) > 0) & (min(RR[0], RR[1], RR[2]) > 0)
    t = 1e-12
    def ne(prof, alt1, alt2, first_A, second_A):
        d1 = alt1[3] - prof[3]; d2 = alt2[4] - prof[4]
        ok1 = (d1 < -t) | ((np.abs(d1) <= t) & first_A)
        ok2 = (d2 < -t) | ((np.abs(d2) <= t) & second_A)
        return ok1 & ok2
    RRf = tuple(np.full_like(one, z) for z in RR)
    NE_AA = ne(AA, RA, AR, True, True); NE_AR = ne(AR, RRf, AA, True, False)
    NE_RA = ne(RA, AA, RRf, False, True); NE_RR = ne(RRf, AR, RA, False, False)
    J = {'AA': AA[3]+AA[4], 'AR': AR[3]+AR[4], 'RA': RA[3]+RA[4], 'RR': RRf[3]+RRf[4]}
    val = {'AA': (r-b1)*AA[0] + (r-b2)*AA[1] + a*AA[2], 'AR': (r-b1)*AR[0] + a*AR[2],
           'RA': (r-b2)*RA[1] + a*RA[2], 'RR': ae*RRf[2]}
    NE = {'AA': NE_AA, 'AR': NE_AR, 'RA': NE_RA, 'RR': NE_RR}
    bestJ = np.full_like(one, -np.inf); sel = np.full_like(one, np.nan)
    for k in ('AA', 'AR', 'RA', 'RR'):            # AA first: ties go to adoption
        take = NE[k] & (J[k] > bestJ + 1e-12)
        bestJ = np.where(take, J[k], bestJ); sel = np.where(take, val[k], sel)
    anyNE = NE_AA | NE_AR | NE_RA | NE_RR
    sel = np.where(inter & anyNE, sel, -np.inf)
    return sel.max()

def block_C(deltas=(0.1, 0.2, 0.3)):
    print("\nC. The programme against the enumerated adoption game (grid step 0.1, six gamma)")
    print("   package grid: beta^k in [1 - delta/r, 1] (41 values each), a in [-1, 3] (81 values)\n")
    worst = -np.inf; tot = 0
    for g in GAMMAS:
        for dl in deltas:
            n = 0; gap_max = -np.inf; below = 0
            betas = np.linspace(max(0.0, 1 - dl/R), 1.0, 41)
            for uB in COARSE:
                for uS in COARSE:
                    if not admissible(uB, uS, g, True) or sigma_of(uB, uS, g) < 0: continue
                    b = benchmark_asym(uB, uS, g, dl)
                    if b is None: continue
                    best = max(game_grid(uB, uS, g, dl, a, betas) for a in np.linspace(-1.0, 3.0, 81))
                    n += 1; gap = best - b['Pi']
                    gap_max = max(gap_max, gap); below += gap <= 1e-9
            worst = max(worst, gap_max); tot += n
            print("   gamma = %-4g delta = %.1f: %3d points; game maximum never above the programme: %s (largest excess %.2e)"
                  % (g, dl, n, "yes" if below == n else "NO at %d" % (n - below), gap_max))
    print("   largest excess of the game maximum over the programme, all points: %.2e %s"
          % (worst, ok(worst <= 1e-9)))


# =========================================================================== D
def block_D():
    print("\nD. The taxing frontier: the benchmark taxes (a_sep > 0) iff N > 0, i.e. as delta -> 0 iff u_B/u_S < R_Phi")
    for g in GAMMAS:
        for dl in (0.01, 0.1, 0.3):
            n = mism = 0
            for uB in GRID:
                for uS in GRID:
                    if not admissible(uB, uS, g, True) or sigma_of(uB, uS, g) < 0: continue
                    sig = sigma_of(uB, uS, g); b = benchmark_asym(uB, uS, g, dl)
                    if b is None: continue
                    n += 1
                    L = Lam(sig)
                    N = (V+R)*(uS*L - uB*(3*sig+4)) - dl*(uS*L + sig*(sig+2)*uB)
                    taxes = b['a'] > 1e-9
                    if (N > 0) != taxes: mism += 1
            print("   gamma = %-4g delta = %.2f: %4d points, sign(N) disagrees with a_sep > 0 at %d" % (g, dl, n, mism))


if __name__ == "__main__":
    t0 = time.time()
    print("rep35_dominance_asym\n")
    symbolic()
    block_B()
    block_D()
    block_C()
    print("\ntime: %.0f s" % (time.time() - t0))
