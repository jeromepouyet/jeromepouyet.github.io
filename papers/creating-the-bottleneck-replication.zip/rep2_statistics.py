# -*- coding: utf-8 -*-
"""rep2_statistics.py -- the quantitative statements of the text that no other
script in the package covers.

Six blocks, each producing numbers the manuscript quotes:

  A. the region-wide contract search (game maximum against the clamped
     calibrated value) on the reference grid coarsened to step 0.1;
  B. the locus at which the single-host optimum gives way to divide-and-rule;
  C. the complements counts of Section "Complements" and of the Online Appendix;
  D. the developer frontier h-bar_S: its share of the admissible set, and the
     containment of x-tilde_a in the two-instrument band;
  E. the band in which the developer fee turns positive only with integration;
  F. uniform posting against the discriminatory single-host optimum.

The searches use game_search_fast of rep3_contracts, which is the vectorised
twin of game_search there and is checked against it in that script's section G.
"""
import numpy as np
from rep_core import (V_DEF, R_DEF, sigma_of, Mof, demands, prices_int,
                      prices_sep, surpluses, Hval, N2val)
from rep3_contracts import (a_hat, Phi, game, game_search_fast, bbar,
                            a_star as a_star_int)
from rep1_frontiers import a_star

V, R, G = V_DEF, R_DEF, 4.0
REF   = np.arange(0.02, 1.402, 0.02)      # reference grid
WIDE  = np.arange(0.02, 2.002, 0.02)      # wide grid (Figure of the gamma-map)
COMPL = np.arange(0.02, 1.602, 0.02)      # complements grid
COARSE= np.arange(0.10, 1.401, 0.10)      # reference grid coarsened to step 0.1

def _A(uB, uS, g):
    """The baseline admissible set A: sigma >= 0, H > 0, D_2(a**) > 0."""
    if Mof(uB, uS) <= 0: return None
    sig = sigma_of(uB, uS, g)
    if sig < 0 or Hval(uB, uS, sig) <= 0: return None
    a = a_star(uB, uS, sig)
    p1, p2 = prices_int(uB, uS, sig, R, a)
    if demands(uB, uS, sig, p1, p2, a)[1] <= 0: return None
    return sig

# ============================================ A. the region-wide contract search
def contract_search(g=G, gr=COARSE):
    print("A. Contract search, reference grid coarsened to step 0.1 (gamma = %.0f)" % g)
    tax = sub = agree = better = 0; uS_better = []
    for uB in gr:
        for uS in gr:
            if Mof(uB, uS) <= 0: continue
            sig = sigma_of(uB, uS, g)
            if sig < 0 or Hval(uB, uS, sig) <= 0: continue
            ah = a_hat(uB, uS, sig, g)
            if ah <= 0:
                sub += 1
                b = game_search_fast(uB, uS, g, amax=1.0, bmax=2.0, na=101, nb=51)
                assert b[0] <= 1e-9, (uB, uS, b[0])
                continue
            tax += 1
            clamped = Phi(uB, uS, sig, g, ah)
            b = game_search_fast(uB, uS, g, amax=max(1.0, 3*ah), bmax=3.0,
                                 na=161, nb=81)
            if b[0] > clamped + 1e-3: better += 1; uS_better.append(uS)
            else: agree += 1
    print("   %d taxing points: the game maximum reproduces the clamped value"
          " Phi(max{a-hat,0}) at %d," % (tax, agree))
    print("   and a divide-and-rule pair does strictly better at %d, all with"
          " u_S >= %.1f." % (better, min(uS_better)))
    print("   %d subsidizing points: the game maximum is zero at every one." % sub)

# ================================================== B. the divide-and-rule switch
def switch_locus(g=G, uBs=(0.10, 0.15, 0.25)):
    print("\nB. Where the single-host optimum gives way to divide-and-rule")
    for uB in uBs:
        prev, prev_uS, out = None, None, "no switch on [0.80, 1.30]"
        for uS in np.arange(0.80, 1.301, 0.01):
            if Mof(uB, uS) <= 0: continue
            sig = sigma_of(uB, uS, g)
            if sig < 0 or Hval(uB, uS, sig) <= 0: continue
            ah = a_hat(uB, uS, sig, g)
            if ah <= 0: continue
            clamped = Phi(uB, uS, sig, g, ah)
            b = game_search_fast(uB, uS, g, amax=max(4.0, 3*ah), bmax=3.0,
                                 na=161, nb=81)
            cur = bool(b[0] > clamped + 1e-3)
            if prev is False and cur:
                out = "between u_S = %.2f and %.2f" % (prev_uS, uS); break
            prev, prev_uS = cur, uS
        print("   u_B = %.2f : %s" % (uB, out))

# ============================================================== C. complements
def _W(uB, uS, g, sig, a):
    """Total welfare at the integrated configuration with fee a (a = 0 is the
    separation benchmark: no fee, no licensing margin, so the integrated and
    the standalone price vectors coincide there)."""
    p1, p2 = prices_int(uB, uS, sig, R, a)
    D1, D2, q = demands(uB, uS, sig, p1, p2, a)
    VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
    return VB + VS + (p1+R)*D1 + (p2+R)*D2 + a*q

def complements(g, gr=COMPL):
    tot = adm = tax = sub = buy = dev = 0
    dWneg = dWpos = 0; exc = []
    for uB in gr:
        for uS in gr:
            if Mof(uB, uS) <= 0: continue
            sig = sigma_of(uB, uS, g)
            if not (-1 < sig < 0): continue
            tot += 1
            if Hval(uB, uS, sig) <= 0: continue
            a = a_star(uB, uS, sig)
            p1, p2 = prices_int(uB, uS, sig, R, a)
            D1, D2, q = demands(uB, uS, sig, p1, p2, a)
            if min(D1, D2) <= 0 or q <= 0 or p1+R <= 0 or p2+R <= 0: continue
            adm += 1
            dW = _W(uB, uS, g, sig, a) - _W(uB, uS, g, sig, 0.0)
            if a > 0:
                tax += 1
                if dW < 0: dWneg += 1
                else: exc.append((uB, uS, sig, dW))
                pb1, pb2 = prices_sep(uB, uS, sig, R, R, 0.0)
                Db1, Db2, qb = demands(uB, uS, sig, pb1, pb2, 0.0)
                VB, VS = surpluses(uB, uS, g, p1, p2, D1, D2, q)
                VBb, VSb = surpluses(uB, uS, g, pb1, pb2, Db1, Db2, qb)
                if VB > VBb: buy += 1
                if VS > VSb: dev += 1
            else:
                sub += 1
                if dW > 0: dWpos += 1
    return tot, adm, tax, sub, buy, dev, dWneg, dWpos, exc

# ================================================ D. the developer frontier h_S
def hS_block():
    print("\nD. The developer frontier h-bar_S")
    hS = lambda uB, g: 0.5*(np.sqrt(2*(g+4)+(g+3)**2*uB**2)-(g+3)*uB)
    xt = lambda s, g: (g*(s+2)+3*s+4)/(2*(g+1))
    print("   share of A on which u_S > h-bar_S (wide grid, step 0.02 on [0.02,2])")
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        tot = hit = agree = 0
        for uB in WIDE:
            for uS in WIDE:
                sig = _A(uB, uS, g)
                if sig is None: continue
                tot += 1
                h = uS > hS(uB, g); x = uS*uS > xt(sig, g)
                hit += h; agree += (h == x)
        print("      gamma=%-4g : %4d of %4d = %.1f%%   (the two forms of the"
              " condition agree at %d of %d)" % (g, hit, tot, 100*hit/tot, agree, tot))
    def xbar(sig, g):
        A = 4*(1+g)**2*(4+3*sig)*(12+sig*(11+3*sig))
        B = -4*(1+g)*(128+g*(4+3*sig)*(12+sig*(11+3*sig))
                      + sig*(272+sig*(212+sig*(73+9*sig))))
        C = (g-sig)**2*(4+3*sig)*(12+sig*(11+3*sig))
        return (-B+np.sqrt(B*B-4*A*C))/(2*A)
    print("   containment x-tilde_a <= x-bar in the two-instrument band")
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        ss = np.linspace(0, g*0.9999, 4001)
        ok = np.mean([xt(s, g) <= xbar(s, g) for s in ss])
        print("      gamma=%-4g : %.0f%% of the range of sigma   (at sigma = 0,"
              " x-tilde_a = %.3f, x-bar = %.3f)" % (g, 100*ok, xt(0,g), xbar(0,g)))

# ================================================================ E. the band
def band_share(g=G, gr=REF):
    Ra = lambda s: (3*s*(s*(s+7)+16)+32)/(2*(s+2)*(3*s+4))
    Rd = lambda s: (8+s*(8+s))/(2*(3*s+4))
    tot = both = 0
    for uB in gr:
        for uS in gr:
            sig = _A(uB, uS, g)
            if sig is None: continue
            if not (uS <= uB and uB/uS < Ra(sig)): continue
            tot += 1; both += (uB/uS < Rd(sig))
    print("\nE. The band in which the fee turns positive only with integration")
    print("   admissible points with u_S <= u_B and a** > 0 (gamma = %.0f): %d;"
          % (g, tot))
    print("   the benchmark already taxes at %d of them (%.0f%%)."
          % (both, 100*both/tot))

# =========================================================== F. uniform posting
def uniform_posting(g=G, pts=((0.1,0.1),(0.3,0.1),(0.5,0.18),(0.15,1.0))):
    print("\nF. Uniform posting (beta^1 = beta^2) against the single-host optimum")
    print("   %-13s %-13s %-13s" % ("(u_B,u_S)", "Phi(a-hat)", "best uniform"))
    for (uB, uS) in pts:
        sig = sigma_of(uB, uS, g); ah = a_hat(uB, uS, sig, g)
        clamped = Phi(uB, uS, sig, g, max(ah, 0.0))
        best = 0.0
        for a in np.linspace(0.0, max(0.6, 3*ah), 401):
            for b in np.linspace(1.0, 3.0, 301):
                out = game(uB, uS, g, b, b, a)
                if out and out[1] == 'AA' and out[0] > best: best = out[0]
        print("   %-13s %-13.5f %-13.5f" % ("(%.2f,%.2f)" % (uB,uS), clamped, best))

if __name__ == "__main__":
    print("rep2_statistics -- residual quantitative statements"
          " (v = 2, r = 1/2)\n")
    contract_search()
    switch_locus()
    print("\nC. Complements: grid of step 0.02 over [0.02,1.60]")
    for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
        tot, adm, tax, sub, buy, dev, dWneg, dWpos, exc = complements(g)
        print("   gamma=%g : %d of the %d grid points with sigma in (-1,0) are"
              " admissible;" % (g, adm, tot))
        print("            %d taxing, %d subsidizing; buyers gain at %d and the"
              " developer at %d of the taxing points." % (tax, sub, buy, dev))
        print("            total welfare: Delta W < 0 at %d of the %d taxing"
              " points, > 0 at %d of the %d subsidizing ones."
              % (dWneg, tax, dWpos, sub))
        for uB, uS, sig, dW in exc:
            print("            exception: (u_B,u_S)=(%.2f,%.2f), sigma=%.2f,"
                  " Delta W=%+.3f" % (uB, uS, sig, dW))
    hS_block(); band_share(); uniform_posting()
