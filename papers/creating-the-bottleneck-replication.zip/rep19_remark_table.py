# -*- coding: utf-8 -*-
"""rep19_remark_table.py -- two things behind the revised Section 4.

A.  What the two-host package does on its own domain (where it beats the
    single-host package): manufacturers, buyers, developer and welfare against
    the benchmark, and the sign of device prices.  Feeds the remark on two
    hosts.  Admissible set A of Sections 3-4; reference grid, step 0.02.

B.  Table B.1 of the Online Appendix at four reference points (gamma = 4):
    the single-host optimum, integration, and the benchmark side by side.
"""
import sys, os, numpy as np, sympy as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rep_core import (N2val, sigma_of, Mof, Hval, demands, prices_sep, prices_int, surpluses, V_DEF, R_DEF)
import rep3_contracts as C, rep9_dnr as D9
V, R = V_DEF, R_DEF

_Pi = D9._derive()
_crit = sp.solve([sp.numer(sp.together(sp.diff(_Pi, x))) for x in (D9.a, D9.b1, D9.b2)],
                 [D9.a, D9.b1, D9.b2], dict=True)[0]
f_ad = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_crit[D9.a]), 'numpy')
f_bd = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_crit[D9.b1]), 'numpy')
f_Ps = sp.lambdify((D9.uB, D9.uS, D9.v, D9.r, D9.g), sp.cancel(_Pi.subs(_crit)), 'numpy')

def adm(x, y, g):
    if Mof(x, y) <= 0: return None
    sg = sigma_of(x, y, g)
    if sg < 0 or Hval(x, y, sg) <= 0: return None
    if N2val(x, y, sg) >= 0: return None
    aa = C.a_star(x, y, sg); q1, q2 = prices_int(x, y, sg, R, aa)
    if demands(x, y, sg, q1, q2, aa)[1] <= 0: return None
    return sg

def out_sep(x, y, g, c1, c2, fee):
    sg = sigma_of(x, y, g); p1, p2 = prices_sep(x, y, sg, c1, c2, fee); D1, D2, q = demands(x, y, sg, p1, p2, fee)
    VB, VS = surpluses(x, y, g, p1, p2, D1, D2, q, V)
    plat = (1-c1/R)*R*D1 + (1-c2/R)*R*D2 + fee*q
    pi1, pi2 = (p1+c1)*D1, (p2+c2)*D2
    return dict(p1=p1, p2=p2, D1=D1, D2=D2, q=q, VB=VB, VS=VS, pi1=pi1, pi2=pi2, plat=plat, W=VB+VS+plat+pi1+pi2)

def out_int(x, y, g, fee):
    sg = sigma_of(x, y, g); p1, p2 = prices_int(x, y, sg, R, fee, R, V); D1, D2, q = demands(x, y, sg, p1, p2, fee)
    VB, VS = surpluses(x, y, g, p1, p2, D1, D2, q, V)
    firm = (p1+R)*D1 + fee*q; pi2 = (p2+R)*D2
    return dict(p1=p1, p2=p2, D1=D1, D2=D2, q=q, VB=VB, VS=VS, firm=firm, pi2=pi2, W=VB+VS+firm+pi2)

grid = np.arange(0.02, 1.4001, 0.02)
print("="*78)
print("A.  The two-host package on its own domain (pair beats single host, feasible)")
print("="*78)
print("%-5s %-8s %-7s %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-7s" %
      ("gam","unravel","pair","p1<0","margin>0","M1<bench","M2<bench","VB<bench","VS<bench","W<bench","uS min"))
for g in (0.5, 1.0, 2.0, 4.0, 8.0, 16.0):
    nun = 0; n = 0; c = dict(p1neg=0, mpos=0, m1b=0, m2b=0, vbb=0, vsb=0, wb=0, beat=0, beatneg=0); us = []; mult = []
    for x in grid:
        for y in grid:
            sg = adm(x, y, g)
            if sg is None or C.Phi_prime0(x, y, sg) <= 0: continue
            nun += 1
            if x >= y: continue
            ad = float(f_ad(x, y, V, R, g)); bd = float(f_bd(x, y, V, R, g)); Ps = float(f_Ps(x, y, V, R, g))
            if not (ad > 0 and bd > 1): continue
            b0 = out_sep(x, y, g, R, R, 0.0); host = out_sep(x, y, g, bd*R, R, ad); both = out_sep(x, y, g, bd*R, bd*R, ad)
            if not (host['pi1'] > b0['pi1'] and both['pi1'] >= host['pi2']): continue
            if min(both['D1'], both['D2'], both['q']) <= 0: continue
            SH = C.Phi(x, y, sg, g, max(C.a_hat(x, y, sg, g), 0.0))
            if Ps <= SH: continue
            n += 1; us.append(y); mult.append(ad / max(C.a_hat(x, y, sg, g), 1e-12))
            c['p1neg'] += both['p1'] < 0; c['mpos'] += both['p1'] + bd*R > 0
            c['m1b'] += both['pi1'] < b0['pi1']; c['m2b'] += both['pi2'] < b0['pi2']
            c['vbb'] += both['VB'] < b0['VB']; c['vsb'] += both['VS'] < b0['VS']; c['wb'] += both['W'] < b0['W']
            # does the pair beat the integration gain, and at what prices?
            if Ps > C.PiI_gain(x, y, sg):
                c['beat'] += 1; c['beatneg'] += both['p1'] < 0
    if n == 0: print("%-5g %-8d none" % (g, nun)); continue
    f = lambda k: "%d(%.0f%%)" % (c[k], 100*c[k]/n)
    print("%-5g %-8d %-7d %-9s %-9s %-9s %-9s %-9s %-9s %-9s %-7.2f  fee/a_hat: median %.2f, max %.2f"
          "  beats integration gain: %d, of which p<0: %d" %
          (g, nun, n, f('p1neg'), f('mpos'), f('m1b'), f('m2b'), f('vbb'), f('vsb'), f('wb'), min(us),
           float(np.median(mult)), float(np.max(mult)), c['beat'], c['beatneg']))
print("\n    'unravel' = admissible points of the unraveling region (Phi'(0) > 0).")

print("\n" + "="*78)
print("B.  Table B.1: four reference points at gamma = 4")
print("="*78)
G = 4.0
REF = [(0.10, 0.40), (0.30, 0.30), (0.15, 1.00), (0.50, 0.18)]
rows = {}
for (x, y) in REF:
    sg = sigma_of(x, y, G)
    ah = C.a_hat(x, y, sg, G); bh = C.bbar(x, y, sg, ah); ast = C.a_star(x, y, sg)
    ph = C.Phi(x, y, sg, G, ah); gain = C.PiI_gain(x, y, sg)
    b0 = out_sep(x, y, G, R, R, 0.0); S = out_sep(x, y, G, bh*R, R, ah); I = out_int(x, y, G, ast)
    K = (8+sg*(8+sg))*y - (2+sg)*(4+3*sg)*x
    rows[(x, y)] = dict(sg=sg, ast=ast, ah=ah, bh=bh, ph=ph, gain=gain, K=K, rho=x/y, Rp=C.R_Phi(sg)/(2+sg),
                        b0=b0, S=S, I=I)
    print("\n  (u_B,u_S)=(%.2f,%.2f)  sigma=%.3f  u_B/u_S=%.3f  R_p=%.3f  K %s  -> %s" %
          (x, y, sg, x/y, C.R_Phi(sg)/(2+sg), ">0" if K > 0 else "<0",
           "separation preferred" if ph > gain else "integration preferred"))
    print("    a**=%.4f  a_hat=%.4f  beta_hat=%.4f  Phi=%.4f  gain=%.4f  Phi/gain=%.3f" % (ast, ah, bh, ph, gain, ph/gain))
    for k, lab in (('pi2', 'rival'), ('q', 'q_S'), ('VB', 'V_B'), ('VS', 'V_S'), ('W', 'W')):
        print("    %-6s sep %.4f  int %.4f  bench %.4f" % (lab, S[k], I[k], b0[k]))

print("\n  Game-engine check (rep3_contracts.game_search) against the closed form at the four points:")
for (x, y) in REF:
    sg = sigma_of(x, y, G); ah = C.a_hat(x, y, sg, G); ph = C.Phi(x, y, sg, G, ah)
    b = C.game_search(x, y, G, amax=max(0.6, 3*ah), bmax=1.6, na=241, nb=121)
    print("    (%.2f,%.2f): Phi(a_hat)=%.5f  game max=%.5f  |diff|=%.1e" % (x, y, ph, b[0], abs(ph-b[0])))

# LaTeX rows
def f3(v): return "%.3f" % v
print("\n  LaTeX rows:")
print("  $(u_B, u_S)$ & " + " & ".join("$(%.2f,\\,%.2f)$" % p for p in REF) + " \\\\")
print("  $u_B/u_S$ against $R_p(\\sigma)$ & " + " & ".join("$%.2f$ vs $%.2f$" % (rows[p]['rho'], rows[p]['Rp']) for p in REF) + " \\\\")
print("  $a^{**}$ (integration) & " + " & ".join("$%s$" % f3(rows[p]['ast']) for p in REF) + " \\\\")
print("  $\\hat a$ (separation) & " + " & ".join("$%s$" % f3(rows[p]['ah']) for p in REF) + " \\\\")
print("  $\\hat\\beta = \\bar\\beta(\\hat a)$ & " + " & ".join("$%s$" % f3(rows[p]['bh']) for p in REF) + " \\\\")
print("  separation gain $\\Phi(\\hat a)$ & " + " & ".join("$%.4f$" % rows[p]['ph'] for p in REF) + " \\\\")
print("  integration gain $\\Pi^I(a^{**}) - \\Pi^I(0)$ & " + " & ".join("$%.4f$" % rows[p]['gain'] for p in REF) + " \\\\")
print("  ratio & " + " & ".join("$%.1f\\%%$" % (100*rows[p]['ph']/rows[p]['gain']) for p in REF) + " \\\\")
for k, lab in (('pi2', "rival's profit"), ('q', 'applications $q_S$'), ('VB', 'buyer surplus $V_B$'), ('VS', 'developer surplus $V_S$'), ('W', 'welfare $W$')):
    print("  %s & " % lab + " & ".join("$%s$ / $%s$ ($%s$)" % (f3(rows[p]['S'][k]), f3(rows[p]['I'][k]), f3(rows[p]['b0'][k])) for p in REF) + " \\\\")
